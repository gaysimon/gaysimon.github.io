package version2_8_6_1.spaceMemory;

import java.util.ArrayList;

import version2_8_6_1.Interface.InteractionList;
import version2_8_6_1.Interface.PrimitiveInteraction;
import version2_8_6_1.platform.Agent;

/**
 * Decision system.
 * This class selects the next intended interactions
 * @author simon
 */
public class Decision {

	private Agent agent;

	private Composite lastDecision;				// last selected composite interaction
	private int decisionIndex;					// index of lastDecision's execution
	public int decisionType1=0;				// used to define if the last selection was done
	public int decisionType2=0;				// for learning or for exploitation
	
	private int optimizationLock;				// lock the optimization process
	
	private Composite saccade;					// last selected epistemic interaction
	private int saccadeIndex;					// index of epistemic interaction's execution
	
	private boolean failed;						// result of the last enaction
	private PrimitiveInteraction enacted;
	private PrimitiveInteraction intention;
	
	private boolean isSaccade;					// define if the last enacted interaction is an epistemic interaction
	private boolean isOptimization;				// define if the last intended interaction is tested with optimization process
	
	public Decision(Agent a){
		agent=a;

		lastDecision=null;
		decisionIndex=-1;
		decisionType1=0;
		decisionType2=0;
		
		optimizationLock=0;
		
		saccade=null;
		saccadeIndex=-1;
		
		isSaccade=false;
		isOptimization=false;
	}
	
	/**
	 * decision of the next action
	 * @return the intended interaction
	 */
	public PrimitiveInteraction decision(){
		
		System.out.println();System.out.println();

		
		///////////////////////////////////////////////////////////////////////////////////////////
		// if last intended interaction failed, stop decision cycle
		if (failed){
			if (!isSaccade){
				// if the intended interaction was not completed, the error mays come from an incoherence in memory,
				// as the path is supposed to be enactable
				if (decisionIndex>-1){
					lastDecision.resetReliability(0);
					lastDecision.setPathFail(agent.spaceMemory.timeline[0]);
				}
				decisionIndex=-1;
				System.out.println(" last action failed ");
			}
			
			// the optimization process is locked for 20 steps, during which the agent is expected to move to an other context
			if (isOptimization) optimizationLock=20;
		}
		
		if (optimizationLock>0) optimizationLock--;
		isOptimization=false;
		
		
		///////////////////////////////////////////////////////////////////////////////////////////
		// auto-optimization process
		// this process consists in replacing the end of the current intended composite interaction
		// with a possible primitive interaction with a greater valence in order to learn and test
		// a new interaction with a high valence
		///////////////////////////////////////////////////////////////////////////////////////////
		
		// if one primitive interaction remains in the current sequence, try auto-optimization
		if (optimizationLock==0 && decisionIndex==0 && lastDecision.length()>1 && !isSaccade ){
			float satisfaction=lastDecision.getFinal().valence();
			
			Composite max=getBestComposite(satisfaction);
			if (max!=null){
				// check if the possible new interaction is not already known
				boolean found=false;
				int l=0;
				while (l<agent.spaceMemory.compositeList.size() && !found){
					if (agent.spaceMemory.compositeList.get(l).isEqual(lastDecision, max.getFinal())) found=true;
					l++;
				}
				
				if (!found){
					System.out.println("change for "+max.getName());
					lastDecision=max;
					decisionType1=2;
					isOptimization=true;
				}
			}
		}
		
		
		///////////////////////////////////////////////////////////////////////////////////////////
		// if saccade completed, check decision
		if (saccadeIndex==-1 && decisionIndex>-1){
			
			saccadeIndex=-2;
			
			if (lastDecision!=null){
				float prediction=lastDecision.prediction(agent.environmentMemory.memoryMap3);

				// if the last decision is now expected as a failure with high certitude, last decision is canceled
				if  (lastDecision.isReliable()
				   && (prediction<0 || !lastDecision.isValide(agent.sequenceMemory.sequencesT[2]))) {
					decisionIndex=-1;
					lastDecision.setPathFail(agent.spaceMemory.timeline[0]);
				}
				else{
					// else, the system checks if the last decision is still compatible with the new context, and cancels it otherwise
					if ( lastDecision.isInvalide(agent.sequenceMemory.sequencesF[2],agent.sequenceMemory.sequencesT[2])
						||(prediction<=0 && lastDecision.getReliabilityF()==10 && lastDecision.getReliabilityT()<10)
					    ||(prediction>=0 && lastDecision.getReliabilityT()==10 && lastDecision.getReliabilityF()<10) ){
							decisionIndex=-1;
							lastDecision.setPathFail(agent.spaceMemory.timeline[0]);
							System.out.println("----- last decision interrupted (non reliable case) "+prediction);
					}
				}
			}
		}
		
		
		///////////////////////////////////////////////////////////////////////////////////////////
		// selection of a new interaction
		if (decisionIndex==-1 && saccadeIndex<0){
			
			// select a new interaction
			if (decisionIndex==-1){
				
				// "learning" selection process
				ArrayList<Composite> candidates=agent.sequenceMemory.getCandidates1();
				
				isSaccade=false;
				
				if (!candidates.isEmpty()){
					lastDecision=candidates.get(0);
					decisionIndex=lastDecision.length()-1;
					System.out.println("Interaction selected from candidates 1 : "+lastDecision.getName());
					decisionType1=1;
				}
				else{
					// "exploitation" selection process
					candidates=agent.sequenceMemory.getCandidates2();
					
					lastDecision=selectInteraction(candidates);
					
					decisionIndex=lastDecision.length()-1;
					System.out.println("Interaction selected from candidates 2 : "+lastDecision.getName());
					decisionType1=2;
					
					// define an epistemic interaction if needed
					float[][] missing=agent.environmentMemory.getMissingEnv(lastDecision);
					setSaccade(agent.spaceMemory.getMissingSaccade(missing, lastDecision));
				}
				
			}
			agent.sequenceMemory.memoryBackup();
		}
		
		
		///////////////////////////////////////////////////////////////////////////////////////////

		//agent.observer.trace();
		
		// get the next intended primitive interaction
		if (saccadeIndex>=0){				// enact saccade
			isSaccade=true;
			System.out.println("%%%%%%%%%%%% action from saccade");
			if (saccadeIndex==0) intention=saccade.getFinal();
			else                 intention=agent.spaceMemory.getMovement(saccade.get(saccadeIndex));
			saccadeIndex--;
			System.out.println("%%%%%%%%%%%% action from saccade");
			decisionType2=0;
		}
		else{								// enact the selected interaction
			isSaccade=false;
			System.out.println("%%%%%%%%%%%% action from space memory");
			if (decisionIndex==0) intention=lastDecision.getFinal();
			else                  intention=agent.spaceMemory.getMovement(lastDecision.get(decisionIndex));
			decisionIndex--;
			System.out.println("%%%%%%%%%%%% action from space memory : "+intention.getName());
			decisionType2=1;
		}
		
		////////////////////////////////////////////////////////
		// return the next primitive interaction of the sequence
		return intention;
	}
	
	
	////////////////////////////////////////////////////////////////////////////////////
	// get the result of enaction
	public void learn(PrimitiveInteraction inter){
		
		System.out.println("enacted : "+inter.getName());
		enacted=inter;
		
		if (agent.decision.decisionIndex==-1){
			if (inter.isEqual(intention)) failed=false;
			else{
				failed=true;
				System.out.println("+++ last decision failed");
				if (agent.decision.lastDecision.isReliable()){
					System.out.println("+++ memory reseted");
					resetReliability();
				}
				else System.out.println("+++ not reseted");
			}
		}
		else{
			if (inter.isMovementEqual(intention)) failed=false;
			else failed=true;
		}
		
	}
	
	// set an epistemic interaction to enact before the intended interaction
	public void setSaccade(Composite s){
		saccade=s;
		if (saccade!=null){
			saccadeIndex=saccade.length()-1;
			System.out.println("saccade needed : "+saccade.getName());
		}
	}
	
	// select the best interaction in the list of candidates
	private Composite selectInteraction(ArrayList<Composite> candidates){
		Composite ret=candidates.get(0);
		float max=-1000;
		
		for (int l=0;l<candidates.size();l++){
			float sum=0;
			
			// first detect interactions that are related to themselves (interactions contained in their signatures)
			for (int i=0;i<InteractionList.length1;i++){
				for (int j=0;j<InteractionList.length2;j++){
					sum+=Math.abs(candidates.get(l).pattern[i][j]*candidates.get(l).prediction[i][j]);
				}
			}
			
			// select the interaction with the highest valence
			float satisfaction=candidates.get(l).getValence(agent.sequenceMemory.sequencesT[2], agent.interactionList.getPrimitiveList());
			if (sum<=0 || satisfaction>0){
				if ( satisfaction>max){
					max=satisfaction;
					ret=candidates.get(l);
				}
			}
		}

		return ret;
	}
	
	// reset the reliability values of interactions in which incoherences are detected
	private void resetReliability(){
		for (int k=0;k<3;k++){
			
			for (int i=0;i<agent.sequenceMemory.sequencesT[k].size();i++){
				if (agent.sequenceMemory.sequencesT[k].get(i).composite().isReliable()) agent.sequenceMemory.sequencesT[k].get(i).composite().resetReliability(9);
				else agent.sequenceMemory.sequencesT[k].get(i).composite().resetReliability(1);
				
				if (agent.sequenceMemory.sequencesT[k].get(i).initial().isReliable()) agent.sequenceMemory.sequencesT[k].get(i).initial().resetReliability(9);
				else agent.sequenceMemory.sequencesT[k].get(i).initial().resetReliability(1);
			}
			
			for (int i=0;i<agent.sequenceMemory.sequencesF[k].size();i++){
				if (agent.sequenceMemory.sequencesF[k].get(i).composite().isReliable()) agent.sequenceMemory.sequencesF[k].get(i).composite().resetReliability(9);
				else agent.sequenceMemory.sequencesF[k].get(i).composite().resetReliability(1);
				
				if (agent.sequenceMemory.sequencesF[k].get(i).initial().isReliable()) agent.sequenceMemory.sequencesF[k].get(i).initial().resetReliability(9);
				else agent.sequenceMemory.sequencesF[k].get(i).initial().resetReliability(1);
			}
		}
	}
	
	// return the interaction considered as enactable for which the valence is the greatest, if greater than m
	// for now, we limit the selection to interactions of length 1
	private Composite getBestComposite(float m){
		Composite ret=null;
		
		float max=-100;
		for (int i=0;i<agent.spaceMemory.compositeList.size();i++){
			if (agent.spaceMemory.compositeList.get(i).length()==1 
			 && agent.spaceMemory.compositeList.get(i).isReliable()
			 && agent.spaceMemory.compositeList.get(i).getFinal().valence()>max ){
				
				if (agent.spaceMemory.compositeList.get(i).prediction(agent.environmentMemory.memoryMap2)>0.8){
					ret=agent.spaceMemory.compositeList.get(i);
					max=agent.spaceMemory.compositeList.get(i).getFinal().valence();
				}
			}
		}
		
		return ret;
	}
	
	/////////////////////////////////////////////////////////////////
	
	public boolean failed(){
		return failed;
	}
	
	public Composite getLastDecision(){
		return lastDecision;
	}
	
	public PrimitiveInteraction getEnacted(){
		return enacted;
	}
	
	public PrimitiveInteraction getIntention(){
		return intention;
	}
}

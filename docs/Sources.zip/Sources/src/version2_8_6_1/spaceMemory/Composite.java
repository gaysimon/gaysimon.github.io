 package version2_8_6_1.spaceMemory;

import java.util.ArrayList;

import version2_8_6_1.Interface.InteractionList;
import version2_8_6_1.Interface.PrimitiveInteraction;

/**
 * Composite interaction, containing the sequence of primitive interaction and signatures
 * @author simon gay
 */
public class Composite {

	private String[] sequence;						// sequence of primitive movements (including the final interaction)
	private PrimitiveInteraction finalInteraction;	// final interaction of the composite interaction
	
	
	private float lastPrediction;				// prediction of success
	
	private int lastIndex;						// indexes of composite interactions that match sub sequences of this interaction
	private int firstIndex;
	private int endIndex;
	
	///////////////////////////////////////////////////////////////////
	// signatures
	public float[][] pattern;			// condition pattern
	public float[][][] correlationC;	//  [][][0] -> correlation coef , [][][1] -> correlation Condition,

	public float[][][][] movement;                           
	
	public float[][] prediction;     	// prediction pattern
	public float[][][] correlationP; 	// [][][1] -> correlation Prediction
	
	public float knowledgeMax;       	// define the maximum correlated pattern coefficient
	public float knowledgeMin;      	// define the minimum correlated pattern coefficient
	
	///////////////////////////////////////////////////////////////////
	private boolean[] reliableT;		// reliability coefficients		
	private boolean[] reliableF;
	
	private int nbPathFail=0;
	private int nbTest=0;
	private int nbSuccess=0;

	private int counter=0;
	private String lock=null;
	
	
	public static int reliabilitySize=10;
	
	
	////////////////////////////////////////////////////////////////////////////////////////////////////
	public Composite(PrimitiveInteraction[] seq, int lIndex, int fIndex, int eIndex){
		pattern=new float[InteractionList.length1][InteractionList.length2];
		correlationC=new float[InteractionList.length1][InteractionList.length2][2];
		
		prediction=new float[InteractionList.length1][InteractionList.length2];
		correlationP=new float[InteractionList.length1][InteractionList.length2][2];

		movement=new float[InteractionList.length1][InteractionList.length2][InteractionList.length1][InteractionList.length2];
		
		sequence=new String[seq.length];
		for (int i=0;i<seq.length;i++){
			sequence[i]=seq[i].getMovement();
		}
		finalInteraction=seq[0];
		
		for (int i=0;i<InteractionList.length1;i++){
			for (int j=0;j<InteractionList.length2;j++){
				pattern[i][j]=0;
				prediction[i][j]=0;
				
				correlationC[i][j][0]=0;
				correlationC[i][j][1]=1;
				
				correlationP[i][j][0]=1;
				correlationP[i][j][1]=1;
			}
		}

		reliableT=new boolean[reliabilitySize];
		reliableF=new boolean[reliabilitySize];

		for (int i=0;i<reliabilitySize;i++){
			reliableT[i]=false;
			reliableF[i]=false;
		}

		knowledgeMax=0;
		knowledgeMin=0;

		lastIndex=lIndex;

		firstIndex=fIndex;
		endIndex=eIndex;
	}
	
	public Composite(String[] seq, PrimitiveInteraction f, int lIndex, int fIndex, int eIndex){
		pattern=new float[InteractionList.length1][InteractionList.length2];
		correlationC=new float[InteractionList.length1][InteractionList.length2][2];
		
		prediction=new float[InteractionList.length1][InteractionList.length2];
		correlationP=new float[InteractionList.length1][InteractionList.length2][2];

		movement=new float[InteractionList.length1][InteractionList.length2][InteractionList.length1][InteractionList.length2];
		
		sequence=new String[seq.length];
		for (int i=0;i<seq.length;i++){
			sequence[i]=seq[i];
		}
		finalInteraction=f;
		
		for (int i=0;i<InteractionList.length1;i++){
			for (int j=0;j<InteractionList.length2;j++){
				pattern[i][j]=0;
				prediction[i][j]=0;
				
				correlationC[i][j][0]=0;
				correlationC[i][j][1]=1;
				
				correlationP[i][j][0]=1;
				correlationP[i][j][1]=1;
			}
		}

		reliableT=new boolean[reliabilitySize];
		reliableF=new boolean[reliabilitySize];

		for (int i=0;i<reliabilitySize;i++){
			reliableT[i]=false;
			reliableF[i]=false;
		}

		knowledgeMax=0;
		knowledgeMin=0;

		lastIndex=lIndex;

		firstIndex=fIndex;
		endIndex=eIndex;
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// initialization functions
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	public void setReliability(int t, int f){
		for (int i=0;i<reliabilitySize;i++){
			reliableT[i]=(i<t);
			reliableF[i]=(i<f);
		}
	}
	
	public void setCounters(int c, int f, int nbT, int nbS){
		counter=c;
		nbPathFail=f;
		nbTest=nbT;
		nbSuccess=nbS;
	}
	
	public void setLock(String l){
		lock=l;
	}
	
	public void setExtrema(float min, float max){
		knowledgeMax=max;
		knowledgeMin=min;
	}
	
	public void initialize(){
		knowledgeMax=0;
		knowledgeMin=1;
		for (int i=0;i<InteractionList.length1;i++){
			for (int j=0;j<InteractionList.length2;j++){
				if (correlationC[i][j][1]>=1 && Math.abs(pattern[i][j])>knowledgeMax) knowledgeMax=Math.abs(pattern[i][j]);
				if (correlationC[i][j][1]>=1 && Math.abs(pattern[i][j])<knowledgeMin) knowledgeMin=Math.abs(pattern[i][j]);
			}
		}
	}

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// signatures related functions
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	// prediction of success of this interaction in context img
	public float prediction(float[][] img){
		float result=0;
		for (int i=0;i<InteractionList.length1;i++){
			for (int j=0;j<InteractionList.length2;j++){
				result+=pattern[i][j]*img[i][j];
			}
		}
		return result;
	}
	
	// update signatures weights according to the result res of enaction and a context img
	public void learn(float[][] img, boolean res, PrimitiveInteraction inter){
		float result=0;
		float nb=0;
		
		// prediction
		for (int i=0;i<InteractionList.length1;i++){
			for (int j=0;j<InteractionList.length2;j++){
				result+=pattern[i][j]*img[i][j];
				nb+=Math.abs(img[i][j]);
			}
		}
		
		// define reliability
		if (res){
			if (Math.abs(result)>0.3){
				for (int i=reliabilitySize-1;i>0;i--) reliableT[i]=reliableT[i-1];
				reliableT[0]=(result> 0.3);
				
				if (this.isReliable() && knowledgeMin<0.9){
					reliableF[reliabilitySize-1]=false;
				}
			}
		}
		else{
			if (Math.abs(result)>0.3){
				for (int i=reliabilitySize-1;i>0;i--) reliableF[i]=reliableF[i-1];
				reliableF[0]=(result<-0.3);
				
				if (this.isReliable() && knowledgeMin<0.9){
					reliableT[reliabilitySize-1]=false;
				}
			}
		}

		// update correlation
		int output=0;          // new output
		if (res) output= 1;
		else     output=-1;
		
		for (int i=0;i<InteractionList.length1;i++){
			for (int j=0;j<InteractionList.length2;j++){
				float input=  img[i][j];         // new input i
				if (input!=0){
					if ( output * correlationC[i][j][0]*input >=0){
						if (correlationC[i][j][1]>=1)
							correlationC[i][j][0]= (correlationC[i][j][0]*1 + output*input )/ (1+Math.abs(input));
					}
					else{
						correlationC[i][j][0]=0;
						correlationC[i][j][1]=0;
					}
				}
			}
		}
		
		if (nb>0){
			float delta=0;
			if (res) delta= 1-result/nb;
			else     delta=-1-result/nb;
			
			for (int i=0;i<InteractionList.length1;i++){
				for (int j=0;j<InteractionList.length2;j++){
					
					if (correlationC[i][j][1]>=1){
						if (img[i][j]!=0) pattern[i][j]+=0.1*img[i][j]*delta;
						pattern[i][j]=Math.min(1, Math.max(-1, pattern[i][j]));
					}
					else pattern[i][j]=0;
				}
			}
		}
		
		knowledgeMax=0;
		knowledgeMin=1;
		for (int i=0;i<InteractionList.length1;i++){
			for (int j=0;j<InteractionList.length2;j++){
				if (correlationC[i][j][1]>=1 && Math.abs(pattern[i][j])>knowledgeMax) knowledgeMax=Math.abs(pattern[i][j]);
				if (correlationC[i][j][1]>=1 && Math.abs(pattern[i][j])<knowledgeMin) knowledgeMin=Math.abs(pattern[i][j]);
			}
		}
		
		float sum=0;
		for (int i=0;i<InteractionList.length1;i++){
			for (int j=0;j<InteractionList.length2;j++){
				sum+=Math.abs(pattern[i][j]);
			}
		}
		lock=inter.getMovement();
	}
	
	// update prediction signature
	public void learnPrediction(float[][] img, boolean res){
		if (res){
			for (int i=0;i<InteractionList.length1;i++){
				for (int j=0;j<InteractionList.length2;j++){
					if (img[i][j]!=0 && img[i][j]*prediction[i][j]>=0){
						if (correlationP[i][j][1]>=1){
							correlationP[i][j][0]=img[i][j];
							prediction[i][j]= (prediction[i][j]*1+img[i][j])/(1+1);
						}
					}
					else{
						correlationP[i][j][0]=0;
						correlationP[i][j][1]=0;
					}
				}
			}
		}
	}
	
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// reliability management
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	// reset reliability
	public void resetReliability(int n){
		reliableT[n]=false;
		reliableF[n]=false;
	}

	public boolean isReliable(){
		boolean ret=true;
		int i=0;
		while (i<reliabilitySize && ret){
			if (!reliableT[i] || !reliableF[i]) ret=false;
			i++;
		}
		return ret;
	}
	
	public boolean isReliableT(){
		boolean ret=true;
		int i=0;
		while(i<reliabilitySize && ret){
			if (!reliableT[i]) ret=false;
			i++;
		}
		return ret;
	}
	
	public boolean isReliableF(){
		boolean ret=true;
		int i=0;
		while(i<reliabilitySize && ret){
			if (!reliableF[i]) ret=false;
			i++;
		}
		return ret;
	}
	
	public int getReliabilityT(){
		int i=0;
		while (i<reliabilitySize && reliableT[i]) i++;
		return i;
	}
	
	public int getReliabilityF(){
		int i=0;
		while (i<reliabilitySize && reliableF[i]) i++;
		return i;
	}
	
	public boolean isLessRT(){
		return getReliabilityT()<=getReliabilityF();
	}
	
	public boolean isLessRF(){
		return getReliabilityF()<=getReliabilityT();
	}
	
	public int getNbTest(){
		return nbTest;
	}
	
	public int getNbSuccess(){
		return nbSuccess;
	}
	
	public boolean isAlwaysTrue(){
		return length()>1 && nbSuccess==nbTest && nbSuccess>=30 && isReliableT();
	}
	
	// return true if the signature is uncorrelated
	public boolean isUncorrelated(){
		boolean ret=true;
		for (int i=0;i<InteractionList.length1;i++){
			for (int j=0;j<InteractionList.length2;j++){
				if (correlationC[i][j][1]>=1) ret=false;
			}
		}
		return ret;
	}
	
	// return true if the prediction signature is uncorrelated
	public boolean isUncorrelatedP(){
		boolean ret=true;
		for (int i=0;i<InteractionList.length1;i++){
			for (int j=0;j<InteractionList.length2;j++){
				if (correlationP[i][j][1]>=1) ret=false;
			}
		}
		return ret;
	}
	
	// return true if every subsequence of final primitive interaction corresponds to a reliable interaction
	public boolean isEndReliable(ArrayList<Composite> list){
		if (length()<=2) return true;
		else{
			return (list.get(endIndex).isReliable() || list.get(endIndex).isAlwaysTrue() || list.get(endIndex).isUncorrelated())
				 && list.get(firstIndex).isReliable();
		}
	}
	
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// sequence management
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	public int length(){
		return sequence.length;
	}
	
	// get final interaction valence
	public float getFinalValence(){
		return finalInteraction.valence();
	}
	
	// get the ith element of the sequence
	public String get(int i){
		return sequence[i];
	}
	
	// get the first element of the sequence
	public String getFirst(){
		return sequence[length()-1];
	}
	
	// get final interaction
	public PrimitiveInteraction getFinal(){
		return finalInteraction;
	}
	
	public String[] getSubPath(int l){
		String[] ret=new String[length()-l];
		for (int i=0;i<length()-l;i++){
			ret[i]=get(i+l);
		}
		return ret;
	}
	
	// move forward in sequence
	public Composite getNext(PrimitiveInteraction inter, ArrayList<Composite> pList){
		if (length()<=1 || !getFirst().equals(inter.getMovement())) return null;
		else{
			return pList.get(endIndex);
		}
	}
	
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// valence
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	// compute valence according to the list of possible interactions
	public float getValence(ArrayList<MemoryElement> listT, ArrayList<PrimitiveInteraction> primitives){
		
		float[] max=new float[this.length()];
		for (int i=1;i<this.length();i++) max[i]=-1000;
		max[0]=getFinalValence();
		
		// search for the best interaction that can produce the movement among possible interactions
		for (int i=0;i<listT.size();i++){
			if ( (listT.get(i).composite().length()<this.length()) && (this.beginWith(listT.get(i).composite())) ){
				if (listT.get(i).composite().getFinalValence()>max[this.length()-listT.get(i).composite().length()]){
					max[this.length()-listT.get(i).composite().length()]=listT.get(i).composite().getFinalValence();
				}
			}
		}
		
		// select an interaction that can produce the required movement.
		// We select the worst interaction of each alternative group (most pessimistic case).
		// The selected interaction is the best interaction among selected interactions
		for (int i=1;i<this.length();i++){
			
			float min=1000;
			
			// for each primitive interaction
			for (int n=0;n<primitives.size();n++){
				// find the worst interaction of the alternative group
				if (primitives.get(n).getMovement().equals(sequence[i])){
					min=primitives.get(n).valence();
					for (int a=0;a<primitives.get(n).nbAlternate();a++){
						if (primitives.get(n).getAlternate(a).valence()<min) min=primitives.get(n).getAlternate(a).valence();
					}
					if (min>max[i]) max[i]=min;
				}
			}
		}
		float sum=0;
		for (int i=0;i<this.length();i++) sum+=max[i];
		
		return sum;
	}
	
	
	//////////////////////////////////////////////////////
	// equality tests
	public boolean isEqual(PrimitiveInteraction inter){
		boolean equal=true;
		if (length()!=1) equal=false;
		else{
			if (!finalInteraction.isEqual(inter)) equal=false;
		}
		return equal;
	}
	
	public boolean isEqual(PrimitiveInteraction[] seq){
		boolean equal=true;
		if (length()!=seq.length) equal=false;
		else{
			for (int i=0;i<length();i++){
				if (!sequence[i].equals(seq[i].getMovement())) equal=false;
			}
			if (!finalInteraction.isEqual(seq[0])) equal=false;
		}
		return equal;
	}
	
	public boolean isEqual(String[] seq, PrimitiveInteraction f){
		boolean equal=true;
		if (this.length()!=seq.length) equal=false;
		else{
			for (int i=0;i<this.length();i++){
				if (!sequence[i].equals(seq[i])) equal=false;
			}
			if (!finalInteraction.isEqual(f)) equal=false;
		}
		return equal;
	}
	
	public boolean isEqual(Composite p){
		return this.isEqual(p.sequence, p.getFinal());
	}
	
	// return true if this = [path.path;f]
	public boolean isEqual(Composite path, PrimitiveInteraction f){
		return this.isPathEqual(path.sequence) && finalInteraction.isEqual(f);
	}
	
	//////////////////////////////////////////////////////
	// comparative tests
	
	public boolean isPathEqual(String[] seq){
		boolean equal=true;
		if (this.length()!=seq.length) equal=false;
		else{
			for (int i=1;i<this.length();i++){
				if (!sequence[i].equals(seq[i])) equal=false;
			}
		}
		return equal;
	}
	
	// is compatible with the path of the given interaction
	public boolean isCompatibleWith(Composite p){
		if (p.length()!=this.length()+1) return false;
		else{
			boolean ret=true;
			for (int i=0;i<this.length();i++){
				if (!p.get(i+1).equals(sequence[i])) ret=false;
			}
			return ret;
		}
	}
	
	// return true if this sequence begins with p
	public boolean beginWith(Composite p){
		if (p.length()>this.length()) return false;
		else{
			boolean ret=true;
			int diff=this.length()-p.length();
			for (int i=0;i<p.length();i++){
				if (!p.get(i).equals(this.get(i+diff))) ret=false;
			}
			return ret;
		}
	}
	

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// tests on interactions
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	// return 1 if the signature match the context, 2 if the context does not contain the whole signature
	// and -1 if the context is incompatible with the signature
	public int matchMap(float[][] map){
		int retT=0;
		int retF=0;
		for (int i=0;i<InteractionList.length1;i++){
			for (int j=0;j<InteractionList.length2;j++){
				if (pattern[i][j]>0.2){
					if (map[i][j]>0) retT++;
					else if (map[i][j]<0) retF++;
					else{
						retT++;
						retF++;
					}
				}
				if (pattern[i][j]<-0.2){
					if (map[i][j]<0) retT++;
					else if (map[i][j]>0) retF++;
					else{
						retT++;
						retF++;
					}
				}
			}
		}
		if (retT==0 && retF==0) return 2;
		else if (retT>0 && retF==0) return 1;
		else if (retT==0 && retF>0) return -1;
		else return 0;
	}
	
	// return the result of the composite interaction (if completed)
	public int check(PrimitiveInteraction[] timeline, boolean increment){
		int ret=1;  // 2=success, 1=nothing, 0=failure
		boolean match=true;
		
		if (timeline[length()-1]!=null){
			for (int i=1;i<sequence.length;i++){
				if (!get(i).equals(timeline[i].getMovement())) match=false;
			}
			if (!getFinal().isEqual(timeline[0]) && !getFinal().isAlternate(timeline[0])) match=false;
		}
		else match=false;
		
		if (match){
			if (getFinal().isEqual(timeline[0])){
				ret=2;
				if (increment && nbTest<99 && nbSuccess<99) nbSuccess++;
			}
			else{
				ret=0;
				nbSuccess=0;
			}
			if (increment && nbTest<99) nbTest++;
		}
		return ret;
	}
	
	// check if every subsequences are in list
	public boolean isValide(ArrayList<MemoryElement> list){
		if (length()==1) return true;
		else{
			boolean ret=true;
			for (int i=1;i<length();i++){
				if (ret){
					ret=false;
					int j=0;
					
					while (j<list.size() && !ret){
						if (list.get(j).composite().length()==i){
							if (this.beginWith(list.get(j).composite())) ret=true;
						}
						j++;
					}
				}
			}
			return ret;
		}
	}
	
	// check if every subsequences are in list
	public boolean isValide(ArrayList<MemoryElement> list, ArrayList<Composite> pList, float[][] map, boolean t){
		if (length()==1) return true;
		else{
			boolean ret=true;
			for (int i=1;i<length();i++){
				if (ret){
					ret=false;
					int j=0;
					
					// check if the subsequence composed of the first i elements is in list
					while (j<list.size() && !ret){
						if (list.get(j).composite().length()==i){
							if (this.beginWith(list.get(j).composite())) ret=true;
						}
						j++;
					}
					
					if (!ret){
						// if not, check if there is a compatible composite interaction that is enactable (or not predicted as a fail if t==false)
						j=0;
						while (j<pList.size() && !ret){
							if (pList.get(j).length()==i && (pList.get(j).isReliable() || pList.get(j).getNbTest()>=99)){
								if (this.beginWith(pList.get(j)) 
										&& this.prediction(pList.get(j).pattern)>0.8
										&& (pList.get(j).prediction(map)>0 || (pList.get(j).prediction(map)>=0 && !t)) ) ret=true;
							}
							j++;
						}
					}
				}
			}
			return ret;
		}
	}
	
	// return true if the sequence or a sub path is in listF and not in listT
	public boolean isInvalide(ArrayList<MemoryElement> listF, ArrayList<MemoryElement> listT){
		
		if (isValide(listT)) return false;
		else{
			boolean ret=false;
			int i=0;
			
			while (i<length()-1 && !ret){
				int j=0;
				// check if a sub path is in list F
				while (j<listF.size() && !ret){
					if (listF.get(j).composite().length()==i+1){
						if (this.beginWith(listF.get(j).composite())) ret=true;
					}
					j++;
				}
				
				// if true, check if the sub path is in list T
				if (ret){
					j=0;
					while (j<listT.size() && ret){
						if (listT.get(j).composite().length()==i+1){
							if (this.beginWith(listT.get(j).composite())) ret=false;
						}
						j++;
					}
				}
				i++;
			}
			return ret;
		}
	}

	public boolean canBeTestedT(ArrayList<Composite> pList){
		boolean findT=false;
		
		if (length()==1 || getReliabilityF()<reliabilitySize) return true;
		else{
			for (int i=0;i<pList.size();i++){
				if (pList.get(i).isCompatibleWith(this) && !pList.get(i).isUncorrelated()){
					// compute compatibility
					float result=0;
					for (int k=0;k<3;k++){
						for (int l=0;l<2;l++){
							result+=this.pattern[k][l]*pList.get(i).pattern[k][l];
						}
					}
					if (result>=0) findT=true;
				}
			}
		}
		return findT;
	}
	public boolean canBeTestedF(ArrayList<Composite> pList){
		boolean findF=false;
		
		if (length()==1 || getReliabilityT()<reliabilitySize) return true;
		else{
			for (int i=0;i<pList.size();i++){
				if (pList.get(i).isCompatibleWith(this) && !pList.get(i).isUncorrelated()){
					// compute compatibility
					float result=0;
					for (int k=0;k<3;k++){
						for (int l=0;l<2;l++){
							result+=this.pattern[k][l]*pList.get(i).pattern[k][l];
						}
					}
					if (result<=0) findF=true;
				}
			}
		}
		return findF;
	}
	
	
	public boolean isPathCorrelated(ArrayList<Composite> pList){
		boolean ret=false;
		if (length()<=2) return true;
		else{
			for (int i=0;i<pList.size();i++){
				if (pList.get(i).isCompatibleWith(this) && !pList.get(i).isUncorrelated()) ret=true;
			}
		}
		return ret;
	}
	

	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// lock management
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	public void setPathFail(PrimitiveInteraction inter){
		nbPathFail++;
		if (nbPathFail>10){
			nbPathFail=0;
			counter=100;
			lock=inter.getMovement();
		}
	}
	
	public void resetLock(PrimitiveInteraction inter){
		if (lock!=null){
			if (!inter.getMovement().equals(lock) && nbPathFail<10){
				lock=null;
			}
		}
	}
	
	public boolean isUnlocked(){
		return counter==0;
	}
	
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// getters
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	public String name(){
		String ret="";
		for (int i=length()-1;i>0;i--){
			ret+=get(i)+" ";
		}
		ret+= getFinal().name();
		return ret;
	}
	
	public String getName(){
		String ret="";
		for (int i=length()-1;i>0;i--){
			ret+=get(i)+" ";
		}
		ret+= getFinal().name();
		ret+=" ("+nbSuccess+"/"+nbTest+") "+nbPathFail+", "+counter+" ; "+this.getReliabilityT()+", "+this.getReliabilityF();
		if (lock!=null) ret+=" lock="+lock;
		return ret;
	}
	
	public boolean getReliabilityT(int i){
		return reliableT[i];
	}
	public boolean getReliabilityF(int i){
		return reliableF[i];
	}
	
	public float lastPrediction(){
		return lastPrediction;
	}
	public void setLastPrediction(float p){
		lastPrediction=p;
	}
	
	public int lastIndex(){
		return lastIndex;
	}
	public int firstIndex(){
		return firstIndex;
	}

	public String getLock(){
		return lock;
	}
	
	public int getNbPathFail(){
		return nbPathFail;
	}
	public int getCounter(){
		return counter;
	}
}
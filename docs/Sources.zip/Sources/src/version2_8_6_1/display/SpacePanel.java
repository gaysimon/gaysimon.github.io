package version2_8_6_1.display;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import version2_8_6_1.Interface.InteractionList;
import version2_8_6_1.platform.Agent;
import version2_8_6_1.spaceMemory.Composite;
import version2_8_6_1.spaceMemory.SpaceMemory;

/**
 * Display the memory maps, list of composite interactions and signatures
 * @author simon gay
 */

/* - inherited from EnvPanel :
 *   Agent agent      : pointer to the agent
 */
public class SpacePanel extends EnvPanel implements MouseListener{

	private static final long serialVersionUID = 1L;
	
	private int clic_x=0;
	private int clic_y=0;
	private int selected_interaction=-1;
	
	public SpacePanel(Agent a){
		super(a);
		addMouseListener(this);
	}
	
	public void paintComponent(Graphics g){
		g.setColor(Color.white);
		
		g.fillRect(0, 0, 1200, 1000);
		
		// display interaction list
		for (int i=0;i<agent.spaceMemory.compositeList.size();i++){
			if (selected_interaction==i) g.setColor(Color.red);
			else g.setColor(Color.black);
			g.fillOval(350+((int)(i/50)*300),20+15*(i%50),5,5);
			
			g.setColor(Color.black);
			g.drawString(agent.spaceMemory.compositeList.get(i).getName(), 355+((int)(i/50)*300), 30+15*(i%50));
			
			if (agent.spaceMemory.compositeList.get(i).isReliable()){
				g.setColor(Color.green);
				g.fillOval(340+((int)(i/50)*300),20+15*(i%50),5,5);
			}			
			if (agent.spaceMemory.compositeList.get(i).isAlwaysTrue()){
				g.setColor(Color.cyan);
				g.fillOval(340+((int)(i/50)*300),20+15*(i%50),5,5);
			}
			if (agent.spaceMemory.compositeList.get(i).isUncorrelated()){
				g.setColor(Color.magenta);
				g.fillOval(340+((int)(i/50)*300),20+15*(i%50),5,5);
			}
			if (!agent.spaceMemory.compositeList.get(i).canBeTestedT(agent.spaceMemory.compositeList)){
				g.setColor(Color.red);
				g.fillOval(345+((int)(i/50)*300),20+15*(i%50),2,5);
			}
			if (!agent.spaceMemory.compositeList.get(i).canBeTestedF(agent.spaceMemory.compositeList)){
				g.setColor(Color.red);
				g.fillOval(348+((int)(i/50)*300),20+15*(i%50),2,5);
			}
		}
		
		///////////////////////////////////////////////////////////////////////////
		// draw perceived environment
		for (int i=0;i<InteractionList.length1;i++){
			g.setColor(new Color( (agent.environmentMemory.map[0][i][1]+1)/2,
								  (agent.environmentMemory.map[0][i][0]+1)/2,
								  0));
			g.fillRect( 20+40*i, 20+40*(i-1)*(i-1), 40, 40);
		}
		
		// draw previous perceived environment
		for (int t=0;t<SpaceMemory.timeSize;t++){
			for (int i=0;i<InteractionList.length1;i++){
				g.setColor(new Color( (agent.environmentMemory.map[t][i][1]+1)/2,
									  (agent.environmentMemory.map[t][i][0]+1)/2,
									  0));
				g.fillRect(170+40*t, 70-30*i, 30, 30);
			}
		}
		
		
		// draw signature of the selected interaction
		if (selected_interaction<agent.spaceMemory.compositeList.size() && selected_interaction>=0){
			int ident=selected_interaction;
			
			// interaction signature
			for (int i=0;i<InteractionList.length1;i++){
				g.setColor(new Color( (agent.spaceMemory.compositeList.get(ident).pattern[i][1]+1)/2,
									  (agent.spaceMemory.compositeList.get(ident).pattern[i][0]+1)/2,
									  0));
				g.fillRect(15+20*i, 150+20*(i-1)*(i-1), 20, 20);
			}
			
			// correlation pattern
			for (int i=0;i<InteractionList.length1;i++){
				if (agent.spaceMemory.compositeList.get(ident).correlationC[i][1][1]>=1)
				g.setColor(new Color( (agent.spaceMemory.compositeList.get(ident).correlationC[i][1][0]+1)/2,
									  (agent.spaceMemory.compositeList.get(ident).correlationC[i][1][0]+1)/2,
									  (agent.spaceMemory.compositeList.get(ident).correlationC[i][1][0]+1)/2));
				else g.setColor(Color.blue);
				g.fillRect( 85+20*i, 150+20*(i-1)*(i-1), 9, 20);
				
				if (agent.spaceMemory.compositeList.get(ident).correlationC[i][0][1]>=1)
				g.setColor(new Color( (agent.spaceMemory.compositeList.get(ident).correlationC[i][0][0]+1)/2,
									  (agent.spaceMemory.compositeList.get(ident).correlationC[i][0][0]+1)/2,
									  (agent.spaceMemory.compositeList.get(ident).correlationC[i][0][0]+1)/2));
				else g.setColor(Color.blue);
				g.fillRect( 95+20*i, 150+20*(i-1)*(i-1), 9, 20);
			}
			
			// prediction pattern
			for (int i=0;i<InteractionList.length1;i++){
				if (agent.spaceMemory.compositeList.get(ident).correlationP[i][0][1]>=1
				 || agent.spaceMemory.compositeList.get(ident).correlationP[i][1][1]>=1){
					g.setColor(new Color( (agent.spaceMemory.compositeList.get(ident).prediction[i][1]+1)/2,
										  (agent.spaceMemory.compositeList.get(ident).prediction[i][0]+1)/2,
										  0));
				}
				else g.setColor(Color.blue);
				g.fillRect(180+20*i, 150+20*(i-1)*(i-1), 20, 20);
			}
			
			// correlationP pattern
			for (int i=0;i<InteractionList.length1;i++){
				if (agent.spaceMemory.compositeList.get(ident).correlationP[i][1][1]>=1) g.setColor(Color.gray);
				else g.setColor(Color.blue);
				g.fillRect(250+20*i, 150+20*(i-1)*(i-1), 9, 20);
				
				if (agent.spaceMemory.compositeList.get(ident).correlationP[i][0][1]>=1) g.setColor(Color.gray);
				else g.setColor(Color.blue);
				g.fillRect(260+20*i, 150+20*(i-1)*(i-1), 9, 20);
			}
		}/**/
		

		// display reliability of the selected interaction
		if (selected_interaction<agent.spaceMemory.compositeList.size() && selected_interaction>=0){
			for (int i=0;i<Composite.reliabilitySize;i++){
				if (agent.spaceMemory.compositeList.get(selected_interaction).getReliabilityT(i)) g.setColor(Color.green);
				else g.setColor(Color.red);
				g.fillRect(10+20*i, 220, 20, 20);
				
				if (agent.spaceMemory.compositeList.get(selected_interaction).getReliabilityF(i)) g.setColor(Color.green);
				else g.setColor(Color.red);
				g.fillRect(10+20*i, 250, 20, 20);
			}
		}/**/
		
		
		///////////////////////////////////////////////////////////////////////////
		// display memory map 1
		for (int i=0;i<InteractionList.length1;i++){
			
			float green=(Math.max(-1, Math.min(1,agent.environmentMemory.memoryMap1[0][i][0]))+1)/2;
			float red  =(Math.max(-1, Math.min(1,agent.environmentMemory.memoryMap1[0][i][1]))+1)/2;
				
			g.setColor(new Color(red,green,0));
			g.fillRect(20+40*i, 320+40*(i-1)*(i-1), 40, 40);
		}
		
		// draw previous memory maps 1
		for (int t=0;t<SpaceMemory.timeSize;t++){
			for (int i=0;i<InteractionList.length1;i++){
				g.setColor(new Color( (agent.environmentMemory.memoryMap1[t][i][1]+1)/2,
									  (agent.environmentMemory.memoryMap1[t][i][0]+1)/2,
									  0));
				g.fillRect(170+40*t, 370-30*i, 30, 30);
			}
		}
		
		///////////////////////////////////////////////////////////////////////////
		// display memory map 2
		for (int i=0;i<InteractionList.length1;i++){
				
				float green=(Math.max(-1, Math.min(1,agent.environmentMemory.memoryMap2[i][0]))+1)/2;
				float red  =(Math.max(-1, Math.min(1,agent.environmentMemory.memoryMap2[i][1]))+1)/2;
					
				g.setColor(new Color(red,green,0));
				g.fillRect(75+50*i, 450+50*(i-1)*(i-1), 50, 50);
		}
		
		// display memory map 3
		for (int i=0;i<InteractionList.length1;i++){

			float green=(Math.max(-1, Math.min(1,agent.environmentMemory.memoryMap3[i][0]))+1)/2;
			float red  =(Math.max(-1, Math.min(1,agent.environmentMemory.memoryMap3[i][1]))+1)/2;
				
			g.setColor(new Color(red,green,0));
			g.fillRect(75+50*i, 600+50*(i-1)*(i-1), 50, 50);
		}
		///////////////////////////////////////////////////////////////////////////
	}
	
	
	///////////////////////////////////////////////////////////////////////////
	// interaction selection
	public void mouseClicked(MouseEvent e) {

		clic_x=e.getX();
		clic_y=e.getY();
		
		float dmin=10;
		float d=10;
		
		selected_interaction=-1;
		
		int nbCol=(int)(agent.spaceMemory.compositeList.size()/50);
		int nbLast=agent.spaceMemory.compositeList.size()%50;

		for (int i=0;i<nbCol;i++){
			for (int j=0;j<50;j++){
				d= (350+300*i-clic_x)*(350+300*i-clic_x) + (20+j*15-clic_y)*(20+j*15-clic_y);
				d=(float) Math.sqrt(d);
				
				if (d<dmin){
					dmin=d;
					selected_interaction=i*50+j;
				}
			}
		}
		
		for (int j=0;j<nbLast;j++){
			d= (350+300*nbCol-clic_x)*(350+300*nbCol-clic_x) + (20+j*15-clic_y)*(20+j*15-clic_y);
			d=(float) Math.sqrt(d);
			
			if (d<dmin){
				dmin=d;
				selected_interaction=nbCol*50+j;
			}
		}
		
		this.repaint();
	}

	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {}
	public void mouseReleased(MouseEvent e) {}
}

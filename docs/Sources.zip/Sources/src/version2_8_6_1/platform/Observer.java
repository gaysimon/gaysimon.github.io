package version2_8_6_1.platform;

import version2_8_6_1.Interface.PrimitiveInteraction;
import version2_8_6_1.spaceMemory.SpaceMemory;

/**
 * This class extract data about agents' behaviors for an external observer
 * @author simon gay
 */
public class Observer {

	private Agent agent;
	
	private int counter;								// number of completed decision cycle
	
	public PrimitiveInteraction[] timelinePrimitive;	// sequence of enacted interactions (limited to the "length" last interactions)
	
	public static int length=200;						// length of the timeline
	
	//////////////////////////////////////////////////////
	// compute the average valence. t1 to t4 give four time windows
	private int t1=1;
	private int t2=10;
	private int t3=50;
	private int t4=100;
	public int[] timelineEfficiency1;
	public int[] timelineEfficiency2;
	public int[] timelineEfficiency3;
	public int[] timelineEfficiency4;
	
	//////////////////////////////////////////////////////
	
	public static int stepSize=5;
	public static int nbStep=1000;
	
	public int count=0;
	public int[][] decisionType;
	
	public int indexPattern=0;
	public int[][] timelineNbPattern;
	public int[][] timelineNbReliableP;
	public int[][] timelineNbATrueP;
	public int[][] timelineNbUncorrelatedP;
	
	public int[] timelineNbCorrect;
	public int[] timelineMemorySize;
	
	private float percent=0;
	
	
	//////////////////////////////////////////////////////
	private int frame;									// index of captured images
	
	private boolean picture=false;					// if true, frames associated to the agent can be saved as jpeg images (if allowed)
	private static int capture_delay=200;				// nb of decision cycles between two image captures
	public static String path=System.getProperty("user.home") +"/IDEAL/version2_8_6_1/";	// path of the saved images
	
	//////////////////////////////////////////////////////
	private XMLStreamTracer m_tracer;
	
	//////////////////////////////////////////////////////
	
	public Observer(Agent a){
		agent=a;

		timelineEfficiency1=new int[length];
		timelineEfficiency2=new int[length];
		timelineEfficiency3=new int[length];
		timelineEfficiency4=new int[length];
		for (int i=0;i<length;i++){
			timelineEfficiency1[i]=0;
			timelineEfficiency2[i]=0;
			timelineEfficiency3[i]=0;
			timelineEfficiency4[i]=0;
		}
		
		timelinePrimitive=new PrimitiveInteraction[length];
		for (int i=0;i<length;i++){
			timelinePrimitive[i]=null;
		}
		

		decisionType=new int[nbStep][stepSize];
		timelineNbPattern      =new int[nbStep][1];
		timelineNbReliableP    =new int[nbStep][SpaceMemory.timeSize];
		timelineNbATrueP       =new int[nbStep][SpaceMemory.timeSize];
		timelineNbUncorrelatedP=new int[nbStep][SpaceMemory.timeSize];
		timelineNbCorrect      =new int[nbStep];
		
		for (int i=0;i<nbStep;i++){
			timelineNbPattern[i][0] =0;
			for (int j=0;j<SpaceMemory.timeSize;j++){
				timelineNbReliableP[i][j]    =0;
				timelineNbATrueP[i][j]       =0;
				timelineNbUncorrelatedP[i][j]=0;
			}
			timelineNbCorrect[i]      =0;
			for (int j=0;j<stepSize;j++){
				decisionType[i][j]=0;
			}
		}

		frame=0;
		counter=0;
		
		/*
		m_tracer=new XMLStreamTracer("http://134.214.128.53/abstract/lite/php/stream/",
				                     "dsyRyrlVFmaeVjpOdSDCeNPsGcmfwr");
		/**/
		
		/*
		m_tracer=new XMLStreamTracer("http://localhost/alite/php/stream/",
				                     "LUAsNP-QqEAStUfzDFwewQIPcwRlnM");
		/**/
	}
	
	public void updateObserver(PrimitiveInteraction inter){
		
		/////////////////////////////////////////////////////////////
		// update timeline
		/////////////////////////////////////////////////////////////
		for (int i=length-1;i>0;i--){
			timelinePrimitive[i]=timelinePrimitive[i-1];
		}
		timelinePrimitive[0]=inter;
		
		/////////////////////////////////////////////////////////////
		// get the average valence
		/////////////////////////////////////////////////////////////
		float sum1=0;
		float sum2=0;
		float sum3=0;
		float sum4=0;
		
		for (int i=0;i<t4;i++){
			if (i<t1){
				if (timelinePrimitive[i]!=null) sum1+=timelinePrimitive[i].valence();
			}
			if (i<t2){
				if (timelinePrimitive[i]!=null) sum2+=timelinePrimitive[i].valence();
			}
			if (i<t3){
				if (timelinePrimitive[i]!=null) sum3+=timelinePrimitive[i].valence();
			}
			if (timelinePrimitive[i]!=null) sum4+=timelinePrimitive[i].valence();
		}
		
		for (int i=200-1;i>0;i--){
			timelineEfficiency1[i]=timelineEfficiency1[i-1];
			timelineEfficiency2[i]=timelineEfficiency2[i-1];
			timelineEfficiency3[i]=timelineEfficiency3[i-1];
			timelineEfficiency4[i]=timelineEfficiency4[i-1];
		}
		timelineEfficiency1[0]=(int) (sum1*10/t1);
		timelineEfficiency2[0]=(int) (sum2*10/t2);
		timelineEfficiency3[0]=(int) (sum3*10/t3);
		timelineEfficiency4[0]=(int) (sum4*10/t4);
		
		/////////////////////////////////////////////////////////////
		// get signature data
		/////////////////////////////////////////////////////////////
		
		// update decision type list
		if (agent.decision.decisionType2==0) decisionType[indexPattern][count]=0;
		else decisionType[indexPattern][count]=agent.decision.decisionType1;
		
		// update composite list counters
		if (count==0){
			timelineNbPattern[indexPattern][0]=0;
			for (int j=0;j<SpaceMemory.timeSize;j++){
				timelineNbReliableP[indexPattern][j]=0;
				timelineNbATrueP[indexPattern][j]  =0;
				timelineNbUncorrelatedP[indexPattern][j]=0;
			}
			
			timelineNbCorrect[indexPattern]  =0;
			
			int nbRel=0;
			int nbAT=0;
			int nbUnCorr=0;
			
			timelineNbPattern[indexPattern][0]=agent.spaceMemory.compositeList.size();
			for (int i=0;i<agent.spaceMemory.compositeList.size();i++){
				if (agent.spaceMemory.compositeList.get(i).isReliable()){
					timelineNbReliableP[indexPattern][agent.spaceMemory.compositeList.get(i).length()-1]++;
					nbRel++;
				}
				
				if (agent.spaceMemory.compositeList.get(i).isAlwaysTrue()){
					timelineNbATrueP[indexPattern][agent.spaceMemory.compositeList.get(i).length()-1]++;
					nbAT++;
				}
				
				if (agent.spaceMemory.compositeList.get(i).isUncorrelated()){
					timelineNbUncorrelatedP[indexPattern][agent.spaceMemory.compositeList.get(i).length()-1]++;
					nbUnCorr++;
				}
			}
			
			timelineNbCorrect[indexPattern]=agent.colliculus.getNbCorrect();
			
			// display interaction counters
			percent=(float)(nbRel+nbAT+nbUnCorr)/(float)agent.spaceMemory.compositeList.size();
			System.out.println("+++ "+agent.spaceMemory.compositeList.size()+" ; "+nbRel+" ; "+nbAT+" ; "+nbUnCorr+" ;"+timelineNbCorrect[indexPattern]+" : "+percent);

			indexPattern++;
			if (indexPattern>=nbStep)indexPattern=0;
		}
		
		// update step timer
		count++;
		if (count>=stepSize) count=0;
		
		
		/////////////////////////////////////////////////////////////
		// screen shot
		/////////////////////////////////////////////////////////////
		
		if (picture){
			frame++;
			if (frame>=capture_delay){
				frame=0;
				agent.saveImage(Observer.path);
			}
		}
		
	}
	
	// send data to Abstract-Lite module
	public void trace(){
		
		// abstract lite trace
		m_tracer.startNewEvent(counter);
		
		m_tracer.addEventElement("Source", "VacuumSG");
		m_tracer.addEventElement("clock", ""+counter);
		
		// intended interaction
		m_tracer.addEventElement("primitive_intended_act", agent.decision.getIntention().name());
		
		// enacted interaction
		m_tracer.addEventElement("primitive_enacted_act", agent.decision.getEnacted().name());
		
		// enacted schema
		m_tracer.addEventElement("primitive_enacted_schema", agent.decision.getEnacted().getAction());
		
		// valence
		m_tracer.addEventElement("satisfaction", ""+agent.decision.getEnacted().valence());
		
		// selected sequence
		m_tracer.addEventElement("enacted_sequence", ""+agent.decision.getLastDecision().getName());
		m_tracer.addEventElement("enacted_sequence_length", ""+agent.decision.getLastDecision().length());
		
		if (agent.decision.failed()){
			m_tracer.addEventElement("intention_incorrect", "true");
		}
		
		counter++;
		
		m_tracer.finishEvent();
	}
	
}

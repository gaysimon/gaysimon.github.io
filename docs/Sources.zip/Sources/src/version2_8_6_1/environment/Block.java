package version2_8_6_1.environment;

import java.awt.Color;

/**
 * Definition of a block in the environment
 * @author simon gay, olivier georgeon
 */
public class Block {

	// define properties and a name of a block
	private Color color;
	private int touch;
	private boolean visible;
	private String name;
	
	public Block(int tactile, Color visual, String n, boolean v){
		color=visual;
		touch=tactile;
		visible=v;
		name=n;
	}
	
	public Color seeBlock(){
		return color;
	}
	
	public int touchBlock(){
		return touch;
	}
	
	public boolean isWall(){
		return (touch==Environment.HARD);
	}
	
	public boolean isFood(){
		return (touch==Environment.FOOD);
	}
	
	public boolean isAlga(){
		return (touch==Environment.SMOOTH);
	}
	
	public boolean isEmpty(){
		return (touch==Environment.EMPTY);
	}
	
	public boolean isWalkthroughable(){
		return (touch!=Environment.HARD);
	}
	
	public String getName(){
		return name;
	}
	
	public Color getColor(){
		return color;
	}
	
	public int getTactile(){
		return touch;
	}
	
	public boolean isVisible(){
		return visible;
	}
}

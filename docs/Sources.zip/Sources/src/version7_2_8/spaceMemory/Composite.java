package version7_2_8.spaceMemory;

import version7_2_8.Interface.PrimitiveInteraction;

/**
 * Define composite interactions
 * @author simon
 */
public class Composite {

	public PrimitiveInteraction[] sequence;		// path of the composite interaction
	public Signature pattern;					// signature of the composite interaction

	private float prediction;  				// prediction according to the pattern
	
	private float valence;						// satisfaction value

	
	public Composite(PrimitiveInteraction[] seq){
		
		sequence=new PrimitiveInteraction[seq.length];
		valence=0;
		for (int i=0;i<seq.length;i++){
			sequence[i]=seq[i];
			valence+=seq[i].valence();
		}

		prediction=0;
		pattern=new Signature();
	}
	
	public int size(){
		return sequence.length;
	}
	
	// equality functions
	public boolean isEqual(Composite inter){
		if (this.size()!=inter.size()) return false;
		else{
			boolean ret=true;
			int i=0;
			while (ret && i<this.size()){
				if (!this.sequence[i].isEqual(inter.sequence[i])) ret=false;
				i++;
			}
			return ret;
		}
	}
	
	public boolean isEqual(PrimitiveInteraction[] inter){
		if (this.size()!=inter.length) return false;
		else{
			boolean ret=true;
			int i=0;
			while (ret && i<this.size()){
				if (!this.sequence[i].isEqual(inter[i])) ret=false;
				i++;
			}
			return ret;
		}
	}
	
	// return the result of the composite interaction (1 success, -1 failure, 0 not used)
	public int checkSequence(PrimitiveInteraction[] seq){
		int ret=1;
		
		for (int i=this.size()-1;i>0;i--){
			if (!seq[i].isEqual(this.sequence[i])) ret=0;
		}
		
		if (ret==1){
			if (!seq[0].isAlternate(this.sequence[0])) ret=0;
			else{
				if (!seq[0].isEqual(this.sequence[0])) ret=-1;
			}
		}
		
		return ret;
	}
	
	// return true if this interaction is included in the path of seq
	public boolean isPath(Composite seq){
		if (seq.size()>=this.size()) return false;
		else{
			boolean ret=true;
			int diff=this.size()-seq.size();
			for (int i=seq.size()-1;i>=0;i--){
				if (!seq.sequence[i].isEqual(this.sequence[i+diff])) ret=false;
			}
			return ret;
		}
	}
	
	
	public void setPrediction(float[] img){
		prediction=pattern.prediction(img);
	}
	
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// getters
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	public float getValence(){
		return valence;
	}
	
	public float getPrediction(){
		return prediction;
	}
	
	public String getName(int param){
		String ret="";
		for (int i=size()-1;i>=0;i--){
			ret+="("+sequence[i].getName()+"),";
		}
		if (param>=1){
			ret+="    :   "+prediction+ "  ; ";
		}
		return ret;
	}
	
}

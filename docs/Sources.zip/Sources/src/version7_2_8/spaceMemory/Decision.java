package version7_2_8.spaceMemory;

import version7_2_8.Interface.PrimitiveInteraction;
import version7_2_8.platform.Agent;

/**
 * Decision system.
 * This class selects the next intended interactions
 * @author simon
 */
public class Decision {

	private Agent agent;
	
	private Composite lastSequence=null;
	private PrimitiveInteraction intention=null;

	private int sequenceIndex=-1;
	private int decisionType=0;

	private boolean learning=false;	// allow learning
	
	///////////////////////////////////////////////////////////
	public Decision(Agent a){
		agent=a;
	}
	
	/**
	 * decision of the next action
	 * @return the intended interaction
	 */
	public PrimitiveInteraction decision(){
		
		System.out.println();System.out.println();

		// select an interaction (for learning or exploitation
		if (learning){
			
			sequenceIndex--;
			
			// try to select an interaction for place signature learning
			intention=agent.agnosticMemory.getDecisionCuriosity();
			
			// if no interaction was selected, select the most unreliable interaction
			if (intention==null){
				
				if (sequenceIndex<0){
				
					int imin=-1;
					float min=0;
					
					for (int i=0;i<agent.spaceMemory.nbInteraction();i++){
						if (isPathPossible(agent.spaceMemory.getInteraction(i))){
							if (Math.abs(1-Math.abs(agent.spaceMemory.getInteraction(i).getPrediction()))>min){
								imin=i;
								min=Math.abs(1-Math.abs(agent.spaceMemory.getInteraction(i).getPrediction()));
							}
						}
					}
					
					lastSequence=agent.spaceMemory.getInteraction(imin);
					decisionType=2;
					sequenceIndex=lastSequence.size()-1;
					
					System.out.println("+++++ select sequence "+lastSequence.getName(0));
				}
				intention=lastSequence.sequence[sequenceIndex];
			}
			else{
				sequenceIndex=-1;
				decisionType=3;
			}
			
			if (decisionType<3) System.out.println("select interaction "+intention.getName()+" element of "+lastSequence.getName(0)+" selected by "+decisionType);
			else System.out.println("select interaction "+intention.getName()+" selected by extraPersonal memory");
		}
		else{
			// select an interaction for exploitation
			intention=agent.agnosticMemory.getDecisionExploitation();
			System.out.println("select interaction "+intention.getName());
		}

		return intention;
	}
	
	
	public void check(PrimitiveInteraction inter){
		if (!intention.isEqual(inter)){
			sequenceIndex=-1;
		}
	}
	
	private boolean isPathPossible(Composite inter){
		if (inter.size()==1) return true;
		else{
			boolean ret=true;
			for (int i=0;i<agent.spaceMemory.nbInteraction();i++){
				if (inter.isPath(agent.spaceMemory.getInteraction(i))){
					if (agent.spaceMemory.getInteraction(i).getPrediction()<0.8) ret=false;
				}
			}
			return ret;
		}
	}
	
	public int getDecisionType(){
		return decisionType;
	}
	
	public PrimitiveInteraction getIntention(){
		return intention;
	}
}

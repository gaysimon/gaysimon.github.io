package version7_2_8.spaceMemory;

import version7_2_8.Interface.InteractionList;

/**
 * signature of an interaction
 * @author simon gay
 */
public class Signature {

	public static float learning_rate=0.01f;
	
	public float[] pattern;
	
	public float maxPattern;				// maximum weight value (in absolute value), used for display color normalization
	public float maxPattern1;				// maximum weight value of visual interactions
	public float maxPattern2;				// maximum weight value of primary interactions
	
	public Signature(){
		pattern=new float[InteractionList.length];
		for (int i=0;i<InteractionList.length;i++){
			pattern[i]=0;
		}
		maxPattern=0;
		maxPattern1=0;
		maxPattern2=0;
	}
	
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// signatures related functions
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	// prediction of success of this interaction in context img
	public float prediction(float[] img){
		float result=0;
		for (int i=0;i<InteractionList.length;i++){
			result+=pattern[i]*img[i];
		}
		result= (float) ( 1 / (1+Math.exp(-result)))*2-1;
		
		return result;
	}
	
	// update signatures weights according to the result res of enaction and a context img
	public void learn(float[] img, float output){
		maxPattern1=0;
		maxPattern2=0;
		
		float result=prediction(img);
		float delta=output-result;
		
		for (int i=0;i<InteractionList.length;i++){

			pattern[i]+= learning_rate * delta * img[i];
			
			if (Math.abs(pattern[i])>maxPattern) maxPattern=Math.abs(pattern[i]);
			if (i< InteractionList.length-8 && Math.abs(pattern[i])>maxPattern1) maxPattern1=Math.abs(pattern[i]);
			if (i>=InteractionList.length-8 && Math.abs(pattern[i])>maxPattern2) maxPattern2=Math.abs(pattern[i]);
		}
	}
}

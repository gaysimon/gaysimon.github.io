package version7_2_8.spaceMemory;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;

import version7_2_8.Interface.InteractionList;
import version7_2_8.Interface.PrimitiveInteraction;
import version7_2_8.platform.Agent;
import version7_2_8.platform.Observer;


/**
 * Main class of the space memory mechanism
 * @author simon gay
 */
public class EnvironmentContext {

	private Agent agent;
	
	public float[][] enactedEnsembles;				// sequence of the last 'timesize' last enacted ensembles
	
	private ArrayList<Composite> interactionList;	// list of known composite interactions
	
	private PrimitiveInteraction[] timeline;		// timeline of the last enacted primary interactions
	
	public static int timeSize=1;
	
	public EnvironmentContext(Agent a){
		agent=a;
		
		enactedEnsembles=new float[timeSize+1][InteractionList.length];
		
		interactionList=new ArrayList<Composite>();

		timeline=new PrimitiveInteraction[timeSize];
		for (int i=0;i<timeSize;i++){
			timeline[i]=null;
		}

		// load signatures of interaction
		loadFile();
	}
	
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////
	// main space memory update function
	public void updateMemory(PrimitiveInteraction inter, float[] enacted){
		
		System.out.println("SpaceMemory observed primitive "+inter.getName());
		
		// update timeline
		for (int i=timeSize-1;i>0;i--){
			timeline[i]=timeline[i-1];
		}
		timeline[0]=inter;
		
		
		// display timeline
		System.out.print("time line : ");
		for (int i=timeSize-1;i>=0;i--){
			if (timeline[i]!=null) System.out.print(timeline[i].getName()+", ");
			else System.out.print("null , ");
		}
		System.out.println();
		
		
		// update contexts
		for (int i=0;i<InteractionList.length;i++){
			for (int t=timeSize;t>0;t--){
				enactedEnsembles[t][i]=enactedEnsembles[t-1][i];
			}
			enactedEnsembles[0][i]=enacted[i];
		}
		
		
		// read timeline and learn new sequences
		int t=0;
		while (t<timeSize && timeline[t]!=null){
			PrimitiveInteraction[] temp=new PrimitiveInteraction[t+1];
			for (int i=0;i<=t;i++) temp[i]=timeline[i];
			learn(temp);
			t++;
		}
		
		for (int i=0;i<interactionList.size();i++){
			
			if (interactionList.get(i).checkSequence(timeline)!=0){
				interactionList.get(i).pattern.learn(
						enactedEnsembles[interactionList.get(i).size()],
						interactionList.get(i).checkSequence(timeline)
						);
			}
			interactionList.get(i).setPrediction(enactedEnsembles[0]);
		}

	}
	
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// add new Composite interaction
	public int learn(PrimitiveInteraction[] seq){

		// sequences and patterns
		int found=-1;
		int i=0;
		while (i<interactionList.size() && found==-1){
			if (interactionList.get(i).size()==seq.length){
				if (interactionList.get(i).isEqual(seq)) found=i;
			}
			i++;
		}
		
		if (found==-1){
			interactionList.add(new Composite(seq));
			found=interactionList.size()-1;
		}

		return found;
	}
	
	public int nbInteraction(){
		return interactionList.size();
	}
	
	public Composite getInteraction(int i){
		return interactionList.get(i);
	}
	
	public PrimitiveInteraction getTimeline(int i){
		return timeline[i];
	}
	
	/////////////////////////////////////////////////////////////////////
	public void save() {
		System.out.println("=====================prepare to save...======================");
		
		// save second level patterns
		
		String fileName = Observer.path+"spaceMemory/spaceMemoryV7_2_8 ("+timeSize+") "+agent.getIdent()+".txt";
		
		try {
			PrintWriter file  = new PrintWriter(new FileWriter(fileName));
			
			
			// save patterns
			for (int i=0;i<interactionList.size();i++){
				
				// save the sequence
				for (int j=0;j<interactionList.get(i).size();j++){
					for (int k=0;k<agent.interactionList.nbInteraction();k++){
						if (interactionList.get(i).sequence[j].isEqual(agent.interactionList.getInteraction(k))) file.print(k+" ");
					}
					file.println();
					
					// save condition pattern
					for (int k=0;k<InteractionList.length;k++){
						file.print(interactionList.get(i).pattern.pattern[k]+" ");
					}
					file.println();
				}
			}
			file.close();
			System.out.println("memory file saved");
		}
		catch (Exception e) {e.printStackTrace();}
	}
	
	
	public void load(){

		PrimitiveInteraction[] temp=new PrimitiveInteraction[1];
		for (int i=0;i<agent.interactionList.nbInteraction();i++){
			temp[0]=agent.interactionList.getInteraction(i);
			interactionList.add(new Composite(temp));
		}
		
	}
	
	public void loadFile(){
		String fileName = Observer.path+"spaceMemory/spaceMemoryV7_2_8 ("+timeSize+") "+agent.getIdent()+".txt";
		String[] elements;

		try {
			InputStream ips=new FileInputStream(fileName); 
			InputStreamReader ipsr=new InputStreamReader(ips);
			BufferedReader br=new BufferedReader(ipsr);
			String line;

			
			// load patterns
			while ((line=br.readLine())!=null){
				elements=line.split(" ");
				// build sequences
				PrimitiveInteraction[] temp=new PrimitiveInteraction[elements.length];
				for (int i=0;i<elements.length;i++){
					temp[i]=agent.interactionList.getInteraction(Integer.parseInt(elements[i]));
				}
				learn(temp);
				
				line=br.readLine();
				elements=line.split(" ");

				// get condition pattern
				float max1=0,max2=0;
				for (int i=0;i<elements.length;i++){
					interactionList.get(interactionList.size()-1).pattern.pattern[i]=Float.parseFloat(elements[i]);
					if (i<InteractionList.length-8){
						if (Math.abs(Float.parseFloat(elements[i]))>max1) max1=Math.abs(Float.parseFloat(elements[i]));
					}
					else{
						if (Math.abs(Float.parseFloat(elements[i]))>max2) max2=Math.abs(Float.parseFloat(elements[i]));
					}
				}
				//interactionList.get(interactionList.size()-1).pattern.maxPattern=max;
				interactionList.get(interactionList.size()-1).pattern.maxPattern1=max1;
				interactionList.get(interactionList.size()-1).pattern.maxPattern2=max2;

			}
		} 
		catch (Exception e) {
			System.out.println("no file found (space memory)");
			load();
		}
	}
}

package version7_2_8.display;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import version7_2_8.Interface.InteractionList;
import version7_2_8.platform.Agent;
import version7_2_8.spaceMemory.Signature;

/**
 * Display space memory data
 * @author simon gay
 */

/* - inherited from EnvPanel :
 *   Agent agent      : pointer to the agent
 */
public class SpacePanel extends EnvPanel implements MouseListener{

	private static final long serialVersionUID = 1L;
	
	private int clic_x=0;
	private int clic_y=0;
	private int selected_interaction=-1;
	
	public SpacePanel(Agent a){
		super(a);
		addMouseListener(this);
	}
	
	public void paintComponent(Graphics g){
		g.setColor(Color.white);
		
		g.fillRect(0, 0, 1200, 1000);

		
		///////////////////////////////////////////////////////////////////////////
		// draw perceived environment
		for (int i=0;i<InteractionList.size1;i++){
			for (int j=0;j<InteractionList.size2;j++){
				g.setColor(new Color(agent.spaceMemory.enactedEnsembles[0][i*InteractionList.size2*3+j*3+2],
									 agent.spaceMemory.enactedEnsembles[0][i*InteractionList.size2*3+j*3  ],
									 agent.spaceMemory.enactedEnsembles[0][i*InteractionList.size2*3+j*3+1]));
				g.fillRect(10+i*2, 10+100-j*2, 2, 2);
			}
		}

		for (int i=0;i<8;i++){
			g.setColor(new Color(1-(agent.spaceMemory.enactedEnsembles[0][InteractionList.nbDF+i]/2+0.5f),
									agent.spaceMemory.enactedEnsembles[0][InteractionList.nbDF+i]/2+0.5f,0));
			g.fillRect(10+12*i,70+ 50, 10, 10);
		}
		
		
		
		// all sequences
		for (int i=0;i<agent.spaceMemory.nbInteraction();i++){
			if (selected_interaction==i) g.setColor(Color.red);
			else g.setColor(Color.black);
			g.fillOval(10+((int)(i/30)*250),150+15*(i%30),5,5);
			
			g.setColor(Color.black);
			g.drawString(agent.spaceMemory.getInteraction(i).getName(1), 15+((int)(i/30)*250), 160+15*(i%30));
		}
		
		/////////////////////////////////////////////////////////////////////////////////
		// draw patterns
		if (selected_interaction!=-1){
			int ident=selected_interaction;
			Signature s=agent.spaceMemory.getInteraction(ident).pattern;

			float max1=s.maxPattern1;
			float max2=s.maxPattern2;

			if (max1!=0){
				
				for (int i=0;i<InteractionList.size1;i++){
					for (int j=0;j<InteractionList.size2;j++){
						g.setColor(new Color(Math.abs(s.pattern[i*InteractionList.size2*3+j*3+2]/max1+1)/2,
											 Math.abs(s.pattern[i*InteractionList.size2*3+j*3  ]/max1+1)/2,
											 Math.abs(s.pattern[i*InteractionList.size2*3+j*3+1]/max1+1)/2));
						
						g.fillRect(10+i*2,410-j*2, 2, 2);
					}
				}
			}
			
			if (max2!=0){
				for (int i=0;i<8;i++){
					g.setColor(new Color(Math.max(-1, Math.min(1,(1-((s.pattern[InteractionList.size1*InteractionList.size2*3+i]/max2/2)+0.5f)))),
							             Math.max(-1, Math.min(1,(    s.pattern[InteractionList.size1*InteractionList.size2*3+i]/max2/2)+0.5f)),
							             0));
					g.fillRect( 10+i*15, 420, 10, 10);
				}
			}
			
			
			
		}
		
		///////////////////////////////////////////////////////////////////
		// draw sequence context
		if (agent.observer.selectedObject<agent.agnosticMemory.objectList.size()){
			for (int i=0;i<8;i++){
				for (int k=0;k<7;k++){
					for (int d=0;d<10;d++){
						float grey=agent.placeContext.map[0].get(agent.observer.selectedObject)[i][k][d];
						
						if (agent.agnosticMemory.objectList.get(agent.observer.selectedObject).objectId==0)
							g.setColor(new Color(grey,0,0));
						else if (agent.agnosticMemory.objectList.get(agent.observer.selectedObject).objectId==1)
							g.setColor(new Color(0,grey,0));
						else if (agent.agnosticMemory.objectList.get(agent.observer.selectedObject).objectId==2)
							g.setColor(new Color(0,0,grey));
						else g.setColor(new Color(grey,grey,grey));
						
						g.fillRect(375 + d*8, 10 + i*60 + k*8, 8, 8);
						
					}
				}
			}
			
			for (int i=0;i<8;i++){
				for (int k=0;k<7;k++){
					for (int d=0;d<10;d++){
						float grey=agent.agnosticMemory.objectList.get(agent.observer.selectedObject).sequenceMap[i][k][d];
						
						if (agent.agnosticMemory.objectList.get(agent.observer.selectedObject).objectId==0)
							g.setColor(new Color(grey,0,0));
						else if (agent.agnosticMemory.objectList.get(agent.observer.selectedObject).objectId==1)
							g.setColor(new Color(0,grey,0));
						else if (agent.agnosticMemory.objectList.get(agent.observer.selectedObject).objectId==2)
							g.setColor(new Color(0,0,grey));
						else g.setColor(new Color(grey,grey,grey));
						
						g.fillRect(500 + d*8, 10 + i*60 + k*8, 8, 8);
						
					}
				}
			}
			for (int i=0;i<8;i++){
				for (int k=0;k<7;k++){
					for (int d=0;d<10;d++){
						float grey=agent.agnosticMemory.objectList.get(agent.observer.selectedObject).sequenceMap2[i][k][d];
						
						if (agent.agnosticMemory.objectList.get(agent.observer.selectedObject).objectId==0)
							g.setColor(new Color(grey,0,0));
						else if (agent.agnosticMemory.objectList.get(agent.observer.selectedObject).objectId==1)
							g.setColor(new Color(0,grey,0));
						else if (agent.agnosticMemory.objectList.get(agent.observer.selectedObject).objectId==2)
							g.setColor(new Color(0,0,grey));
						else g.setColor(new Color(grey,grey,grey));
						
						g.fillRect(600 + d*8, 10 + i*60 + k*8, 8, 8);
						
					}
				}
			}
		}
		
		// draw sequence signature
		if (agent.observer.selectedSequence>=0 && agent.agnosticMemory.placeList.get(agent.observer.selectedSequence).isValide()){
			for (int i=0;i<8;i++){
				for (int k=0;k<7;k++){
					for (int d=0;d<10;d++){
						float grey=Math.max(-1,Math.min(1,agent.agnosticMemory.placeList.get(agent.observer.selectedSequence).presenceSignature.pattern[i][k][d]));
						grey= grey/2+0.5f;
						g.setColor(new Color(grey,grey,grey));
						
						g.fillRect(250 + d*8, 10 + i*60 + k*8, 8, 8);
					}
				}
			}
		}
	}
	
	
	///////////////////////////////////////////////////////////////////////////
	public void mouseClicked(MouseEvent e) {

		clic_x=e.getX();
		clic_y=e.getY();
		
		float dmin=10;
		float d=10;
		
		selected_interaction=-1;
		
		int nbCol=(int)(agent.spaceMemory.nbInteraction()/30);
		int nbLast=agent.spaceMemory.nbInteraction()%30;
		
		for (int i=0;i<nbCol;i++){
			for (int j=0;j<30;j++){
				d= (15+250*i-clic_x)*(15+250*i-clic_x) + (155+j*15-clic_y)*(155+j*15-clic_y);
				d=(float) Math.sqrt(d);
				
				if (d<dmin){
					dmin=d;
					selected_interaction=i*30+j;
				}
			}
		}
		
		for (int j=0;j<nbLast;j++){
			d= (15+250*nbCol-clic_x)*(15+250*nbCol-clic_x) + (155+j*15-clic_y)*(155+j*15-clic_y);
			d=(float) Math.sqrt(d);
			
			if (d<dmin){
				dmin=d;
				selected_interaction=nbCol*30+j;
			}
		}
	}

	@Override
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {}
	public void mouseReleased(MouseEvent e) {}
	
}

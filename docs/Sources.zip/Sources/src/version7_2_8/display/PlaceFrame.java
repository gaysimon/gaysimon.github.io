package version7_2_8.display;

import version7_2_8.platform.Agent;

/**
 * Display place signatures
 * @author simon gay
 */
public class PlaceFrame extends EnvFrame{

	private static final long serialVersionUID = 1L;

	public PlaceFrame(Agent a){
		
		super(a);
		this.setTitle("Place Signatures");
    	this.setSize(1150, 800);
    	this.setLocationRelativeTo(null);               
    	this.setVisible(true);
    	this.setFocusable(true);
    	panel=new PlacePanel(a);
    	this.setContentPane(panel);
	}
	
}


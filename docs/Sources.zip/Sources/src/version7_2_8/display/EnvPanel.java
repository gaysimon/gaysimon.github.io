package version7_2_8.display;

import java.awt.Graphics;

import version7_2_8.platform.Agent;
import version7_2_8.platform.PrintablePanel;

/**
 * Generic class of Panels that display informations about an agent
 * @author simon gay
 */
public class EnvPanel extends PrintablePanel{
	
	private static final long serialVersionUID = 1L;
	
	protected Agent agent;
	
	public EnvPanel(Agent a){
		super();
		agent=a;
	}
	
	/**
	 * change the observed agent
	 */
	public void setAgent(Agent a){
		agent=a;
	}
	
	/**
	 * print the displayed image in a pdf file
	 */
	public void drawPDF(Graphics g){
		paintComponent(g);
	}
	
	public void paintComponent(Graphics g){
	
	}
}

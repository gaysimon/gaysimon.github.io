package version7_2_8.display;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import version7_2_8.platform.Agent;
import version7_2_8.Interface.InteractionList;

/**
 * Display place signatures
 * @author simon gay
 */
public class PlacePanel extends EnvPanel implements MouseListener{
	
	private static final long serialVersionUID = 1L;
	
	public int clic_x=0;
	public int clic_y=0;
	
	private int pixel=4;
	
	private int size1=InteractionList.aSize1;
	private int size2=InteractionList.aSize2;
	
	private int selected_node=0;
	
	private int selectedObjectSequence=0;
	private int selectedObjectEvoked=0;
	
	private int display=0;
	
	private int nbLines=25;
	
	public PlacePanel(Agent a){
		super(a);
		addMouseListener(this);
	}
	
	public void paintComponent(Graphics g){
		g.setColor(Color.white);
		
		g.fillRect(0, 0, 3000, 900);
		
		/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// first line
		/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		///////////////////////////////////////////////////////////////////////////////
		// Interactional context
		
		// dynamic features
		for (int i=0;i<size1;i++){
			for (int j=0;j<size2;j++){
				g.setColor(new Color(agent.agnosticMemory.enactedEnsembles[0][i*size2*3+j*3+2],
									 agent.agnosticMemory.enactedEnsembles[0][i*size2*3+j*3  ],
									 agent.agnosticMemory.enactedEnsembles[0][i*size2*3+j*3+1] ));		
				g.fillRect(20+i*pixel, (110-j*pixel), pixel, pixel);
			}
		}
		// primitive interactions
		for (int i=0;i<7;i++){
			g.setColor(new Color(1-(agent.agnosticMemory.enactedEnsembles[0][InteractionList.nbDF2+i]/2+0.5f),
								    agent.agnosticMemory.enactedEnsembles[0][InteractionList.nbDF2+i]/2+0.5f,0));
			g.fillRect(20+i*20, 120, 10, 10);
			if (i==selected_node){
				g.setColor(Color.black);
				g.drawRect(19+i*20, 119, 11, 11);
			}
		}
		
		///////////////////////////////////////////////////////////////////////////////
		// draw the blur signature of the selected interaction
		for (int i=0;i<InteractionList.aSize1;i++){
			for (int j=0;j<InteractionList.aSize2;j++){
				g.setColor(new Color(Math.max(0,Math.min(1, (agent.agnosticMemory.interactionList.get(selected_node).blurPattern[i][j][2]/2+0.5f))),
								 	 Math.max(0,Math.min(1, (agent.agnosticMemory.interactionList.get(selected_node).blurPattern[i][j][0]/2+0.5f))),
								 	 Math.max(0,Math.min(1, (agent.agnosticMemory.interactionList.get(selected_node).blurPattern[i][j][1]/2+0.5f)))));
				
				g.fillRect(250+i*pixel, (110-j*pixel), pixel, pixel);
			}
		}
		
		///////////////////////////////////////////////////////////////////////////////
		// draw interaction areas map
		for (int i=0;i<InteractionList.aSize1;i++){
			for (int j=0;j<InteractionList.aSize2;j++){
				if (agent.agnosticMemory.interactionList.get(selected_node).interactionMap[i][j]==0) g.setColor(Color.red);
				else if (agent.agnosticMemory.interactionList.get(selected_node).interactionMap[i][j]==1) g.setColor(Color.green);
				else if (agent.agnosticMemory.interactionList.get(selected_node).interactionMap[i][j]==2) g.setColor(Color.blue);
				
				else if (agent.agnosticMemory.interactionList.get(selected_node).interactionMap[i][j]==3) g.setColor(Color.magenta);
				else if (agent.agnosticMemory.interactionList.get(selected_node).interactionMap[i][j]==4) g.setColor(Color.cyan);
				else if (agent.agnosticMemory.interactionList.get(selected_node).interactionMap[i][j]==5) g.setColor(Color.yellow);
				else if (agent.agnosticMemory.interactionList.get(selected_node).interactionMap[i][j]==6) g.setColor(Color.orange);
				else g.setColor(Color.black);
				
				g.fillRect(460+i*pixel, (110-j*pixel), pixel, pixel);
			}
		}
		
		///////////////////////////////////////////////////////////////////////////////
		// draw object map (walls and preys objects)
		int area=0;
		int dist=0;
		for (int o=1;o<=2;o++){
			for (int i=0;i<InteractionList.aSize1*2;i+=2){
				for (int j=0;j<InteractionList.aSize2*2;j+=2){
					area=agent.agnosticMemory.interactionList.get(o).interactionMap2[i][j];
					dist=agent.agnosticMemory.interactionList.get(o).distanceMap[i][j];
					if (area>=0){
						if (agent.agnosticMemory.mapObjects[o][area][dist]){
							if (o==1) g.setColor(Color.green);
							else  g.setColor(Color.blue);
						}
						else g.setColor(Color.black);
					}
					else g.setColor(Color.black);
					g.fillRect(700+i*pixel/2+(o-1)*210, (110-j*pixel/2), pixel, pixel);
				}
			}
		}
		
		/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// second line
		/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		///////////////////////////////////////////////////////////////////////////////
		// display places in geometrical translation reference
		for (int i=InteractionList.aSize1/3;i<InteractionList.aSize1*2-InteractionList.aSize1/3;i++){
			for (int j=20;j<InteractionList.aSize2*2;j++){

				if (agent.agnosticMemory.interactionList.get(selected_node).interactionMap2[i][j]==0) 
					g.setColor(new Color(20+15*agent.agnosticMemory.interactionList.get(selected_node).distanceMap[i][j],0,0));
				else if (agent.agnosticMemory.interactionList.get(selected_node).interactionMap2[i][j]==1) 
					g.setColor(Color.green);
				else if (agent.agnosticMemory.interactionList.get(selected_node).interactionMap2[i][j]==2) 
					g.setColor(Color.orange);
				
				else if (agent.agnosticMemory.interactionList.get(selected_node).interactionMap2[i][j]==3) 
					g.setColor(new Color(20+15*agent.agnosticMemory.interactionList.get(selected_node).distanceMap[i][j],0,20+15*agent.agnosticMemory.interactionList.get(selected_node).distanceMap[i][j]));
				else if (agent.agnosticMemory.interactionList.get(selected_node).interactionMap2[i][j]==4)
					g.setColor(new Color(0,20+15*agent.agnosticMemory.interactionList.get(selected_node).distanceMap[i][j],20+15*agent.agnosticMemory.interactionList.get(selected_node).distanceMap[i][j]));
				else if (agent.agnosticMemory.interactionList.get(selected_node).interactionMap2[i][j]==5)
					g.setColor(new Color(20+15*agent.agnosticMemory.interactionList.get(selected_node).distanceMap[i][j],20+15*agent.agnosticMemory.interactionList.get(selected_node).distanceMap[i][j],0));
				else if (agent.agnosticMemory.interactionList.get(selected_node).interactionMap2[i][j]==6)
					g.setColor(new Color(0,0,20+15*agent.agnosticMemory.interactionList.get(selected_node).distanceMap[i][j]));
				else g.setColor(Color.black);
	
				if (agent.agnosticMemory.objectPointMax[0][i][j]==1 || agent.agnosticMemory.objectPointMax[1][i][j]==1 || agent.agnosticMemory.objectPointMax[2][i][j]==1){
					g.setColor(new Color(Math.max(0,Math.min(255, (agent.agnosticMemory.objectPointMax[0][i][j]*255))),
							 Math.max(0,Math.min(255, (agent.agnosticMemory.objectPointMax[1][i][j]*255))),
							 Math.max(0,Math.min(255, (agent.agnosticMemory.objectPointMax[2][i][j]*255)))));
				}
				
				g.fillRect(20+(-InteractionList.aSize1/3+i)*pixel, (340-j*pixel), pixel, pixel);
			}
		}
		g.setColor(Color.white);
		g.fillRect(20+(InteractionList.aSize1-InteractionList.aSize1/3)*pixel, 340-InteractionList.aSize2*pixel, pixel, pixel);
		
		///////////////////////////////////////////////////////////////////////////////
		// draw map of certitude of instances
		for (int i=InteractionList.aSize1/3;i<InteractionList.aSize1*2-InteractionList.aSize1/3;i++){
			for (int j=0;j<InteractionList.aSize2*2;j++){
				g.setColor(new Color(Math.max(0,Math.min(1, (agent.agnosticMemory.objectRecognition2[0][i][j]*100))),
									 Math.max(0,Math.min(1, (agent.agnosticMemory.objectRecognition2[1][i][j]*100))),
									 Math.max(0,Math.min(1, (agent.agnosticMemory.objectRecognition2[2][i][j]*100)))));
				
				g.fillRect(300+(-InteractionList.aSize1/3+i)*pixel, (340-j*pixel), pixel, pixel);
			}
		}
		
		///////////////////////////////////////////////////////////////////////////////
		float gray=0;
		if (display==0){
			
			// draw detected object instances
			for (int i=InteractionList.aSize1/3;i<InteractionList.aSize1*2-InteractionList.aSize1/3;i++){
				for (int j=0;j<InteractionList.aSize2*2;j++){
					
					g.setColor(new Color(Math.max(0,Math.min(255, (agent.agnosticMemory.objectPointMax[0][i][j]*255))),
										 Math.max(0,Math.min(255, (agent.agnosticMemory.objectPointMax[1][i][j]*255))),
										 Math.max(0,Math.min(255, (agent.agnosticMemory.objectPointMax[2][i][j]*255)))));
					
					g.fillRect(580+(-InteractionList.aSize1/3+i)*pixel, (340-j*pixel), pixel, pixel);
				}
			}
			
			// draw place signature of the selected place
			for (int i=InteractionList.aSize1/3;i<InteractionList.aSize1*2-InteractionList.aSize1/3;i++){
				for (int j=0;j<InteractionList.aSize2*2;j++){

					gray= Math.max(0,Math.min(1, (agent.agnosticMemory.placeList.get(agent.observer.selectedSequence).placeSignature.pattern[i][j]/2+0.5f)));
					
					g.setColor(new Color(gray,gray,gray));
					g.fillRect(800+i*pixel, (340-j*pixel), pixel, pixel);
				}
			}
		}
		if (display==1){
			
			for (int i=InteractionList.aSize1/3;i<InteractionList.aSize1*2-InteractionList.aSize1/3;i++){
				for (int j=0;j<InteractionList.aSize2*2;j++){
					
					// draw estimated position of selected instance according to first list of places
					if (agent.agnosticMemory.objectList.size()>agent.observer.selectedObject)
						gray= Math.max(0,Math.min(1, (agent.agnosticMemory.objectList.get(agent.observer.selectedObject).map[i][j]/4+0.5f)));
					g.setColor(new Color(gray,gray,gray));
					g.fillRect(520+i*pixel, (340-j*pixel), pixel, pixel);
					
					// draw estimated position of selected instance according to second list of places
					if (agent.agnosticMemory.objectList.size()>agent.observer.selectedObject)
						gray= Math.max(0,Math.min(1, (agent.agnosticMemory.objectList.get(agent.observer.selectedObject).map2[i][j]/4+0.5f)));
					g.setColor(new Color(gray,gray,gray));
					g.fillRect(800+i*pixel, (340-j*pixel), pixel, pixel);
					
					// draw the place signature of the selected place in first list of the selected instance
					if (agent.agnosticMemory.objectList.size()>agent.observer.selectedObject && agent.agnosticMemory.objectList.get(agent.observer.selectedObject).memory.size()>selectedObjectSequence)
						gray= Math.max(0,Math.min(1, (agent.agnosticMemory.objectList.get(agent.observer.selectedObject).memory.get(selectedObjectSequence).placeSignature.pattern[i][j]/2+0.5f)));
					g.setColor(new Color(gray,gray,gray));
					g.fillRect(800+i*pixel, (550-j*pixel), pixel, pixel);
					
					// draw the place signature of the selected place in second list of the selected instance
					if (agent.agnosticMemory.objectList.size()>agent.observer.selectedObject && agent.agnosticMemory.objectList.get(agent.observer.selectedObject).evoked.size()>selectedObjectEvoked)
						gray= Math.max(0,Math.min(1, (agent.agnosticMemory.objectList.get(agent.observer.selectedObject).evoked.get(selectedObjectEvoked).placeSignature.pattern[i][j]/2+0.5f)));
					g.setColor(new Color(gray,gray,gray));
					g.fillRect(800+i*pixel, (760-j*pixel), pixel, pixel);
				}
			}
		}
		
		
		/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// third line
		/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		
		///////////////////////////////////////////////////////////////////////////////
		// display switch
		g.setColor(Color.black);
		if (display==0){
			g.drawString("list of places", 40, 330);
			g.setColor(Color.blue);
		}
		else{
			g.drawString("object instances", 40, 330);
			g.setColor(Color.green);
		}
		g.fillRect(20, 320, 10, 10);
		
		///////////////////////////////////////////////////////////////////////////////
		int index=0;
		if (display==0){
			// write the list of places
			for (int i=0;i<agent.agnosticMemory.placeList.size();i++){
				if (agent.agnosticMemory.placeList.get(i).isValide() && agent.agnosticMemory.placeList.get(i).objectTypeId==2){
					if ((i==agent.observer.selectedSequence)) g.setColor(Color.red);
					else g.setColor(Color.black);
					g.fillRect(14+150*(int)(index/nbLines), 365+15*(index%nbLines), 5, 5);
					g.setColor(Color.black);
					g.drawString(agent.agnosticMemory.placeList.get(i).getName(), 20+150*(int)(index/nbLines), 370+15*(index%nbLines));
					index++;
				}
			}
		}
		if (display==1){
			// write the list of stored object instances
			for (int i=0;i<agent.agnosticMemory.objectList.size();i++){
				if ((i==agent.observer.selectedObject)) g.setColor(Color.red);
				else g.setColor(Color.black);
				g.fillRect(14, 365+15*i, 5, 5);
				g.setColor(Color.black);	
				g.drawString(agent.agnosticMemory.objectList.get(i).getName(), 25, 370+15*(i));
			}
			
			if (agent.observer.selectedObject<agent.agnosticMemory.objectList.size()){
				// write places of the first list of the selected instance
				for (int i=0;i<agent.agnosticMemory.objectList.get(agent.observer.selectedObject).memory.size();i++){
					if ((i==selectedObjectSequence)) g.setColor(Color.red);
					else g.setColor(Color.black);
					g.fillRect(200, 365+15*i, 5, 5);
					g.setColor(Color.black);	
					g.drawString(agent.agnosticMemory.objectList.get(agent.observer.selectedObject).memory.get(i).getName()+", "
							    +(float)((int)(agent.agnosticMemory.objectList.get(agent.observer.selectedObject).memoryCoef.get(i)*100))/100, 210, 370+15*(i));
				}
				
				// write places of the second list of the selected instance
				for (int i=0;i<agent.agnosticMemory.objectList.get(agent.observer.selectedObject).evoked.size();i++){
					if ((i==selectedObjectEvoked)) g.setColor(Color.red);
					else g.setColor(Color.black);
					g.fillRect(610, 365+15*i, 5, 5);
					g.setColor(Color.black);	
					g.drawString(agent.agnosticMemory.objectList.get(agent.observer.selectedObject).evoked.get(i).getName()+" , "
							    +(float)((int)(agent.agnosticMemory.objectList.get(agent.observer.selectedObject).evokedCoef.get(i)*100))/100, 620, 370+15*(i));
				}
				
				// write the lists of evoked places of the selected instance
				for (int i=0;i<7;i++){
					for (int s=0;s<agent.agnosticMemory.objectList.get(agent.observer.selectedObject).evokedLists[i].size();s++){
						g.setColor(Color.black);	
						g.drawString(agent.agnosticMemory.objectList.get(agent.observer.selectedObject).evokedLists[i].get(s).getName()+" , "
								    +(float)((int)(agent.agnosticMemory.objectList.get(agent.observer.selectedObject).evokedListCoefs[i].get(s)*100))/100,
								    1150+220*i, 370+15*(s));
					}
				}
			}
		}
	}
	
	
	///////////////////////////////////////////////////////////////////////////
	public void mouseClicked(MouseEvent e) {

		clic_x=e.getX();
		clic_y=e.getY();
		float dmin=1000;
		float d=10;
		
		// display switch
		d=(clic_x-25)*(clic_x-25) + (clic_y - 325)*(clic_y - 325);
		if (d<dmin){
			dmin=d;
			display=(display+1)%2;
		}
		
		// primary interaction selection
		for (int i=0;i<7;i++){
			d=(clic_x-(25+i*20))*(clic_x-(25+i*20) ) + (clic_y - 135)*(clic_y - 135);
			if (d<dmin){
				dmin=d;
				selected_node= i;
			}
		}
		
		//////////////////////////////////////////////////////////////////////
		float index=0;
		if (display==0){
			
			// selection of a place in the list
			for (int l=0;l<agent.agnosticMemory.placeList.size();l++){
	
				if (agent.agnosticMemory.placeList.get(l).isValide() && agent.agnosticMemory.placeList.get(l).objectTypeId==2){
					d=(clic_x - (16+150*(int)(index/nbLines))) * (clic_x - (16+150*(int)(index/nbLines)))
					+ (clic_y - (368+15*(int)(index%nbLines))) * (clic_y - (368+15*(int)(index%nbLines)));
					if (d<dmin){
						dmin=d;
						agent.observer.selectedSequence= l;
					}
					index++;
				}
			}
		}
		/////////////////////////////////////////////////////////////////////
		if (display==1){
			
			// selection of an object instance
			for (int l=0;l<agent.agnosticMemory.objectList.size();l++){
				d=(clic_x-16)*(clic_x-16) + (clic_y - (368+15*l))*(clic_y - (368+15*l));
				if (d<dmin){
					dmin=d;
					agent.observer.selectedObject= l;
				}
			}
			
			if (agent.observer.selectedObject<agent.agnosticMemory.objectList.size()){
				
				// selection of a place in the first list of the selected object instance
				for (int i=0;i<agent.agnosticMemory.objectList.get(agent.observer.selectedObject).memory.size();i++){
					d=(clic_x-202)*(clic_x-202) + (clic_y - (368+15*i))*(clic_y - (368+15*i));
					if (d<dmin){
						dmin=d;
						selectedObjectSequence= i;
					}
				}
				
				// selection of a place in the second list of the selected object instance
				for (int i=0;i<agent.agnosticMemory.objectList.get(agent.observer.selectedObject).evoked.size();i++){
					d=(clic_x-612)*(clic_x-612) + (clic_y - (368+15*i))*(clic_y - (368+15*i));
					if (d<dmin){
						dmin=d;
						selectedObjectEvoked= i;
					}
				}
			}
		}
	}

	@Override
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {}
	public void mouseReleased(MouseEvent e) {}
}

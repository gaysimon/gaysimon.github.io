package version7_2_8.agnosticMemory;

import version7_2_8.Interface.InteractionList;
import version7_2_8.Interface.PrimitiveInteraction;
import version7_2_8.platform.Agent;
import version7_2_8.spaceMemory.Signature;

/**
 * Interaction used by the agnostic memory
 * This kind of interaction differs from the interactions used by the hard-coded space memory
 * @author simon
 */
public class Interaction{

	
	public PrimitiveInteraction interaction;
	
	public float[][][] signature;
	public float[][][] blurPattern;
	public float[][][] movementPattern;	// gives for each primary interaction and at each position the variation of distance
	
	public int[][] interactionMap; 		// map that gives for each position in observable space the interaction that can bring this point closer.
	public int[][] interactionMap2;		// map that gives for each transformation tau the interaction that can bring this position closer.
	
	public int[][] distanceMap;  			// map that define the distance for each point in space
	
	public Interaction(PrimitiveInteraction inter){
		interaction=inter;

		signature=new float[InteractionList.aSize1][InteractionList.aSize2][3];
		blurPattern=new float[InteractionList.aSize1][InteractionList.aSize2][3];
		movementPattern=new float[7][InteractionList.aSize1][InteractionList.aSize2];
		
		interactionMap=new int[InteractionList.aSize1][InteractionList.aSize2];
		
		interactionMap2=new int[InteractionList.aSize1*2][InteractionList.aSize2*2];
		distanceMap=new int[InteractionList.aSize1*2][InteractionList.aSize2*2];
	}
	
	// measure the variation of distance at each point of the observable space
	public void learnMovement(Agent agent){
		for (int k=0;k<7;k++){
			for (int i=0;i<InteractionList.aSize1;i++){
				for (int j=0;j<InteractionList.aSize2;j++){
					
					// get the translated position (x,y) of (i,j)
					int x=(int) (agent.interactionList.getInteraction(k).vectorFlow[i*2][j*2+InteractionList.size2][0]/2);
					int y=(int) (agent.interactionList.getInteraction(k).vectorFlow[i*2][j*2+InteractionList.size2][1]-InteractionList.size2)/2;

					if (x>=0 && y>=0 && x<InteractionList.aSize1 && y<InteractionList.aSize2){

						// compute the value given by the blur pattern (which depends on the distance) at current and translated position.
						float max1=Math.max(Math.abs(blurPattern[i][j][0]), Math.max(Math.abs(blurPattern[i][j][1]), Math.abs(blurPattern[i][j][2])));
						float max2=Math.max(Math.abs(blurPattern[x][y][0]), Math.max(Math.abs(blurPattern[x][y][1]), Math.abs(blurPattern[x][y][2])));
						
						// set the variation produced by the kth interaction at position (i,j)
						movementPattern[k][i][j]=max2-max1;
					}
					else movementPattern[k][i][j]=0;
				}
			}
		}
	}
	
	// determine for each position the interaction that produce the greatest variation of distance
	public void detection(){
		for (int i=0;i<InteractionList.aSize1;i++){
			for (int j=0;j<InteractionList.aSize2;j++){
				int imax=-1;
				float max=0;
				
				for (int k=0;k<7;k++){
					if (movementPattern[k][i][j]>max){
						max=movementPattern[k][i][j];
						imax=k;
					}
				}
				interactionMap[i][j]=imax;
			}
		}
	}
	
	
	public void getPositions(){
		
		float x=0;
		float y=0;
		float sum=0;
		
		// determine the barycenter of the signature
		for (int i=0;i<InteractionList.aSize1;i++){
			for (int j=0;j<InteractionList.aSize2;j++){
				for (int k=0;k<3;k++){
					if (Math.abs(signature[i][j][k])>0.2){
						x+= i * Math.abs(signature[i][j][k]);
						y+= j * Math.abs(signature[i][j][k]);
						sum+=Math.abs(signature[i][j][k]);
					}
				}
			}
		}
		if (sum>0){
			x=x/sum;
			y=y/sum;
		}
		
		// define, for each position (translation), the interaction that can bring closer this position the most
		for (int i=-(InteractionList.aSize1)+InteractionList.aSize1/3;i<InteractionList.aSize1-InteractionList.aSize1/3;i++){
			for (int j=-(InteractionList.aSize2);j<InteractionList.aSize2;j++){
				// for each translation (i,j)
				if (i+x>=0 && i+x<InteractionList.aSize1 && j+y>=0 && j+y<InteractionList.aSize2){
					
					interactionMap2[i+InteractionList.aSize1][j+InteractionList.aSize2] = interactionMap[(int)(i+x)][(int)(j+y)];
					
					int d=(int) (Math.sqrt(i*i + j*j)/2);
					distanceMap[i+InteractionList.aSize1][j+InteractionList.aSize2]=Math.min(d, 9);
				}
				else interactionMap2[i+InteractionList.aSize1][j+InteractionList.aSize2] =-1;
			}
		}
	}
	
	// copy signature of interactions and generate blur patterns
	public void setPatterns(Signature s,Agent agent){

		// copy signature
		for (int i=0;i<InteractionList.aSize1;i++){
			for (int j=0;j<InteractionList.aSize2;j++){
				for (int k=0;k<3;k++){
					signature[i][j][k]=s.pattern[i*2*InteractionList.size2*3 + j*2*3 + k];
				}
			}
		}

		// initialize blur pattern
		for (int i=0;i<InteractionList.aSize1;i++){
			for (int j=0;j<InteractionList.aSize2;j++){
				for (int k=0;k<3;k++){
					if (Math.abs(signature[i][j][k])>0.1)
						blurPattern[i][j][k]=signature[i][j][k];
				}
			}
		}

		// generate the blur pattern
		for (int n=0;n<10;n++)
		for (int l=0;l<7;l++){
			for (int i=0;i<InteractionList.aSize1;i++){
				for (int j=0;j<InteractionList.aSize2;j++){
					
					int x=(int) (agent.interactionList.getInteraction(l).vectorFlow[i*2][j*2+50][0]/2);
					int y=(int) (agent.interactionList.getInteraction(l).vectorFlow[i*2][j*2+50][1]-50)/2;

					if (x>=0 && y>=0 && x<InteractionList.aSize1 && y<InteractionList.aSize2){
						for (int k=0;k<3;k++){
							if (Math.abs(0.8*blurPattern[x][y][k])>Math.abs(blurPattern[i][j][k]))
								blurPattern[i][j][k]=0.8f*blurPattern[x][y][k];
						}
					}
				}
			}
		}
	}
}

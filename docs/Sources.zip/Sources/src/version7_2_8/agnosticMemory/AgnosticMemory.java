package version7_2_8.agnosticMemory;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;

import version7_2_8.spaceMemory.EnvironmentContext;
import version7_2_8.Interface.InteractionList;
import version7_2_8.Interface.PrimitiveInteraction;
import version7_2_8.platform.Agent;
import version7_2_8.platform.Observer;

/**
 * Agnostic memory for the agent.
 * @author simon gay
 */
public class AgnosticMemory{
	
	private Agent agent;
	
	public static int range=3;					// range of the agnostic memory (length of composite places, including final place interaction)
	
	public static boolean load=true;				// load place and presence signatures
	
	public static int share=0;					// allow comparison between signatures ( 0 -> no comparison, 1 -> remove incoherences, 2 -> copy "eat" related signatures to "bump" related signatures. 
	public static boolean learn_place=false;		// true -> learn place signatures (presence signature disabled), false -> learn presence signatures
	
	public static float memoryCoef = 1;    		// influence coefficient of the space memory
	public static float objectCoef = 1;	     	// influence of objects according to their distances
	
	
	public float[][] enactedEnsembles;				// enacted ensembles E_t and E_{t-range}
	
	public PrimitiveInteraction[] timeline;			// sequence of the last primary enacted interactions
	
	public ArrayList<Interaction> interactionList; // primitive interactions of the agnostic memory
	public ArrayList<Place> placeList;      		// list of possible sequences
	
	public boolean[][][] mapObjects;				// indicate the presence of instances of objects in places
	
	public float[][][][] objectRecognition;		// "map" of object instances, each position give the certitude of success of each interaction
	public float[][][] objectRecognition2;			// "map" of object instances, weighted by their distance 
	public int[][][] objectPointMax;				// "map" of local maximum of certitude
	public ArrayList<Object> objectList;			// list of stored object instances
	
	private ArrayList<float[]> objectRelations;	// used to merge object instances that are expected to be the same

	
	public AgnosticMemory(Agent a){
		agent = a;

		// initialize environmental contexts
		enactedEnsembles=new float[AgnosticMemory.range][InteractionList.length2];
		for (int t=0;t<AgnosticMemory.range;t++){
			for (int i=0;i<InteractionList.length2;i++){
				enactedEnsembles[t][i]=0;
			}
		}
		
		// define the list of primitive interactions
		interactionList=new ArrayList<Interaction>();
		for (int i=0;i<7;i++){
			interactionList.add(new Interaction(agent.interactionList.getInteraction(i)));
		}

		// initialize timeline
		timeline=new PrimitiveInteraction[range];
		for (int i=0;i<range;i++){
			timeline[i]=null;
		}

		// generate the set of sequences
		placeList=new ArrayList<Place>();
		if (load){
			loadFile();
			loadPresenceSignatures();
		}
		else generateSequences();

		mapObjects=new boolean[7][7][10];

		// get the blur patterns
		for (int i=0;i<7;i++) interactionList.get(i).setPatterns(agent.spaceMemory.getInteraction(i).pattern, agent);

		// define interaction map
		for (int i=0;i<7;i++) interactionList.get(i).learnMovement(agent);

		objectRecognition=new float[range][3][InteractionList.aSize1*2][InteractionList.aSize2*2]; // we do not take turn "objects" into consideration
		objectRecognition2=new float[3][InteractionList.aSize1*2][InteractionList.aSize2*2];		// as "turn" interactions are always true
		objectPointMax=new int[3][InteractionList.aSize1*2][InteractionList.aSize2*2];
		objectList=new ArrayList<Object>();

		objectRelations=new ArrayList<float[]>();

		// generate area map
		for (int i=0;i<7;i++) interactionList.get(i).detection();
		for (int i=0;i<7;i++) interactionList.get(i).getPositions();
	}
	
	
	
	//////////////////////////////////////////////////////////////////////////////////////
	// update memory components
	public void updateMemory(PrimitiveInteraction inter, float[] enacted){
		
		// update timeline of primary enacted interactions
		for (int t=range-1;t>0;t--) timeline[t]=timeline[t-1];
		timeline[0]=inter;
		
		// update environmental context
		for (int i=0;i<InteractionList.length2;i++){
			for (int t=AgnosticMemory.range-1;t>0;t--){
				enactedEnsembles[t][i]=enactedEnsembles[t-1][i];
			}
			enactedEnsembles[0][i]=enacted[i];
		}
		
		// update object instance timeline
		for (int o=0;o<3;o++){
			for (int i=0;i<InteractionList.aSize1*2;i++){
				for (int j=0;j<InteractionList.aSize2*2;j++){
					
					for (int t=range-1;t>0;t--)objectRecognition[t][o][i][j]=objectRecognition[t-1][o][i][j];
					objectRecognition[0][o][i][j]=0;
				}
			}
		}
		
		/////////////////////////////////////
		// detect objects position in context
		for (int o=0;o<3;o++){
			// for each translation (i,j)
			for (int i=-(InteractionList.aSize1)+InteractionList.aSize1/3;i<InteractionList.aSize1-InteractionList.aSize1/3;i++){
				for (int j=-(InteractionList.aSize2);j<InteractionList.aSize2;j++){
					// for each position (x,y) of the signature
					for (int x=0;x<InteractionList.aSize1;x++){
						for (int y=0;y<InteractionList.aSize2;y++){
							
							if (i+x>=0 && i+x<InteractionList.aSize1 && j+y>=0 && j+y<InteractionList.aSize2){
								for (int c=0;c<3;c++){
									if (interactionList.get(o).signature[x][y][c]>0.2 && enactedEnsembles[0][ (i+x)*InteractionList.aSize2*3 + (j+y)*3 +c]!=0){
										objectRecognition[0][o][i+InteractionList.aSize1][j+InteractionList.aSize2]+=
												enactedEnsembles[0][ (i+x)*InteractionList.aSize2*3 + (j+y)*3 +c] * interactionList.get(o).signature[x][y][c];
									}
								}
								float d=(i*i)+(j*j);
								if (d>0) objectRecognition2[o][i+InteractionList.aSize1][j+InteractionList.aSize2]=objectRecognition[0][o][i+InteractionList.aSize1][j+InteractionList.aSize2]/d;
							}
						}
					}
					objectPointMax[o][i+InteractionList.aSize1][j+InteractionList.aSize2]=0;
				}
			}
		}
		
		////////////////////////////////////////
		// detect maximum probability of objects
		for (int o=0;o<3;o++){
			// for each translation (i,j)
			for (int i=InteractionList.aSize1/3;i<InteractionList.aSize1*2-InteractionList.aSize1/3;i++){
				for (int j=20;j<InteractionList.aSize2*2;j++){
					
					if (objectPointMax[o][i][j]==0){
						if (objectRecognition2[o][i][j]>0){
							float val=objectRecognition2[o][i][j];
							boolean found=false;
							for (int i2=-4;i2<=4;i2++){
								for (int j2=-4;j2<=4;j2++){
									if (!(i2==0 && j2==0) && i+i2>=0 && i+i2<InteractionList.aSize1*2 && j+j2>=0 && j+j2<InteractionList.aSize2*2){
										
										if (objectRecognition2[o][i+i2][j+j2]>val)found=true;
										else objectPointMax[o][i+i2][j+j2]=-1;
									}
								}
							}
							if (found) objectPointMax[o][i][j]=-1;
							else       objectPointMax[o][i][j]= 1;
						}
						else objectPointMax[o][i][j]=-1;
					}
				}
			}
		}
		
		
		//////////////////////////
		// detect objects in primitive places
		for (int l=0;l<7;l++){
			for (int p=0;p<7;p++){
				for (int d=0;d<10;d++){
					mapObjects[l][p][d]=false;
				}
			}
		}
		for (int l=0;l<3;l++){
			for (int i=InteractionList.aSize1/3;i<InteractionList.aSize1*2-InteractionList.aSize1/3;i++){
				for (int j=20;j<InteractionList.aSize2*2;j++){
					if (objectRecognition[0][l][i][j]>0 && interactionList.get(l).interactionMap2[i][j]>=0){
						mapObjects[l][interactionList.get(l).interactionMap2[i][j]][interactionList.get(l).distanceMap[i][j]]=true;
					}
				}
			}
		}
		
		///////////////////
		// learn place signatures
		for (int i=0;i<placeList.size();i++){
			if (placeList.get(i).isValide())
				placeList.get(i).learnPlaceSignature(timeline, mapObjects, objectRecognition);
		}
		
		/////////////////
		// share place signatures learning: compare signatures learned for each object type
		
		if (share==1){
			// reset inconsistent weights
			for (int l=0;l<placeList.size();l++){
				for (int k=l+1;k<placeList.size();k++){
					if (placeList.get(l).isValide() && placeList.get(k).isValide() && placeList.get(l).isEqual(placeList.get(k))){
						for (int i=0;i<InteractionList.aSize1*2;i++){
							for (int j=0;j<InteractionList.aSize2*2;j++){
								if (placeList.get(l).placeSignature.pattern[i][j]>0 && placeList.get(k).placeSignature.pattern[i][j]<0)
									placeList.get(l).placeSignature.pattern[i][j]=0;
								
								if (placeList.get(l).placeSignature.pattern[i][j]<0 && placeList.get(k).placeSignature.pattern[i][j]>0)
									placeList.get(k).placeSignature.pattern[i][j]=0;
							}
						}
					}
				}
			}
		}
		
		if (share==2){
			// copy weights of "eat" presence and place signatures to weights of wall signatures
			for (int l=0;l<placeList.size();l++){
				for (int k=0;k<placeList.size();k++){
					if (placeList.get(l).isValide() && placeList.get(l).objectTypeId==2 
					 && placeList.get(k).isValide() && placeList.get(k).objectTypeId==1 && placeList.get(l).isEqual(placeList.get(k))){
						
						// copy place signature
						for (int i=0;i<InteractionList.aSize1*2;i++){
							for (int j=0;j<InteractionList.aSize2*2;j++){
								placeList.get(k).placeSignature.pattern[i][j]=placeList.get(l).placeSignature.pattern[i][j];
							}
						}
						
						// copy presence signature
						for (int i=0;i<8;i++){
							for (int j=0;j<7;j++){
								for (int d=0;d<10;d++){
									placeList.get(k).presenceSignature.pattern[i][j][d]=placeList.get(l).presenceSignature.pattern[i][j][d];
								}
							}
						}
					}
				}
			}
		}
		
		///////////////////////////
		// update memorized objects
		for (int i=0;i<objectList.size();i++){
			objectList.get(i).update(inter, placeList);
			if (objectList.get(i).isEmpty() || objectList.get(i).path.size()>20){
				System.out.println("---- remove "+objectList.get(i).getName());
				objectList.remove(i);
				i--;
			}
		}
		int oldObjects=objectList.size();

		/////////////////////
		// define new objects
		float min=1000;
		int imin=-1;
		do{
			// remove new objects
			while (oldObjects<objectList.size()) objectList.remove(oldObjects);
			
			// create a new object for each maxima
			for (int o=0;o<3;o++){
				for (int i=InteractionList.aSize1/3;i<InteractionList.aSize1*2-InteractionList.aSize1/3;i++){
					for (int j=20;j<InteractionList.aSize2*2;j++){
						if (objectPointMax[o][i][j]>0.01){
							objectList.add(new Object(agent.interactionList.getInteraction(o),o, i,j));
						}
					}
				}
			}
			
			// associate sequences to objects
			for (int i=oldObjects;i<objectList.size();i++){
				for (int l=0;l<placeList.size();l++){
					if (placeList.get(l).isValide() && placeList.get(l).objectTypeId==objectList.get(i).objectId){
						if (placeList.get(l).placeSignature.pattern[objectList.get(i).x][objectList.get(i).y]>0){
							boolean found=false;
							int j=oldObjects;
							while (!found && j<objectList.size()){
								if (i!=j && placeList.get(l).placeSignature.pattern[objectList.get(j).x][objectList.get(j).y]>0) found=true;
								j++;
							}
							if (!found){
								objectList.get(i).addSequence(placeList.get(l),
										placeList.get(l).placeSignature.prediction(objectRecognition[0][placeList.get(l).objectTypeId], true));
							}
						}
					}
				}
			}
			
			// get the empty objects and remove the one with the lowest value
			min=1000;
			imin=-1;
			for (int i=oldObjects;i<objectList.size();i++){
				if (objectList.get(i).isEmpty() && objectRecognition2[objectList.get(i).objectId][objectList.get(i).x][objectList.get(i).y]<min){
					min=objectRecognition2[objectList.get(i).objectId][objectList.get(i).x][objectList.get(i).y];
					imin=i;
				}
			}
			if (imin!=-1) objectPointMax[objectList.get(imin).objectId][objectList.get(imin).x][objectList.get(imin).y]=-1;
			
		}while (imin!=-1);
		
		
		for (int i=0;i<objectList.size();i++){
			// get evoked sequences
			objectList.get(i).evoke(placeList);
			
			// define object map
			objectList.get(i).defineMap();
			
			// compute movement coefficients
			//objectList.get(i).computeMovements(this.interactionList);
		}
		
		
		//////////////////////////////
		// recognize stored objects in the current context
		int newObjects=objectList.size()-oldObjects;

		objectRelations.clear();
		for (int i=0;i<oldObjects;i++){
			objectRelations.add(new float[newObjects]);
		}
		
		for (int i=oldObjects;i<objectList.size();i++){
			for (int j=0;j<oldObjects;j++){
				if (objectList.get(i).objectId==objectList.get(j).objectId){
					objectRelations.get(j)[i-oldObjects]=objectList.get(j).getMax(objectList.get(i).x,objectList.get(i).y);
				}
				else objectRelations.get(j)[i-oldObjects]=0;
			}
		}
		
		boolean maxFound=true;
		while (maxFound){
			maxFound=false;
			float max=0;
			int imax=-1;
			int jmax=-1;
			for (int i=oldObjects;i<objectList.size();i++){
				for (int j=0;j<oldObjects;j++){
					if (objectRelations.get(j)[i-oldObjects]>max){
						max=objectRelations.get(j)[i-oldObjects];
						imax=i-oldObjects;
						jmax=j;
					}
				}
			}
			if (max>0.1){
				objectList.remove(jmax);
				objectRelations.remove(jmax);
				oldObjects--;
				for (int j=0;j<oldObjects;j++){
					objectRelations.get(j)[imax]=-1;
				}
				maxFound=true;
			}
		}
		
		///////////////////////////////////////////////
		for (int i=oldObjects;i<objectList.size();i++){
			for (int j=0;j<oldObjects;j++){
				if (objectList.get(i).objectId==objectList.get(j).objectId && objectRelations.get(j)[i-oldObjects]!=-1){
					objectRelations.get(j)[i-oldObjects]=objectList.get(j).getDistMin(objectList.get(i).x,objectList.get(i).y);
					System.out.println(" ++++++ "+objectList.get(j).getName()+ " and "+objectList.get(i).getName()+" -> "+objectRelations.get(j)[i-oldObjects]);
				}
				else objectRelations.get(j)[i-oldObjects]=-1;
			}
		}
		
		maxFound=true;
		while (maxFound){
			maxFound=false;
			float max=100;
			int imax=-1;
			int jmax=-1;
			for (int i=oldObjects;i<objectList.size();i++){
				for (int j=0;j<oldObjects;j++){
					if (objectRelations.get(j)[i-oldObjects]!=-1 && objectRelations.get(j)[i-oldObjects]<max){
						max=objectRelations.get(j)[i-oldObjects];
						imax=i-oldObjects;
						jmax=j;
					}
				}
			}
			if (max<8){
				System.out.println(" ++++++ "+imax+" ; "+jmax+"  ;  "+objectList.get(jmax).getName()+ " recognized as "+objectList.get(imax+oldObjects).getName());
				objectList.remove(jmax);
				objectRelations.remove(jmax);
				oldObjects--;
				for (int j=0;j<oldObjects;j++){
					objectRelations.get(j)[imax]=-1;
				}
				maxFound=true;
			}
		}
		
		//////////////////////////
		// update sequence context
		agent.placeContext.updateContext(objectList);
		
		////////////////////////////
		// learn presence signatures
		if (!learn_place){
			for (int i=0;i<placeList.size();i++){
				if (placeList.get(i).isValide() && placeList.get(i).getLength()>1){
					for (int j=0;j<agent.placeContext.map[placeList.get(i).getLength()-1].size();j++){
						if (agent.placeContext.objectIndex[placeList.get(i).getLength()-1].get(j)==placeList.get(i).objectTypeId){
							placeList.get(i).learnPresenceSignature(timeline, mapObjects, agent.placeContext.map[placeList.get(i).getLength()-1].get(j));
						}
					}
				}
			}
		}
	}

	
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////
	// select an interaction to learn place signatures
	public PrimitiveInteraction getDecisionCuriosity(){
		
		// get eligible sequences
		//int sum=0;
		float min=2;
		int imin=-1;
		int i=0;
		
		// find the first eligible interaction in the list (and thus do not test previous interactions of the list)
		while(i<placeList.size() && imin==-1){
			if (placeList.get(i).isValide() && placeList.get(i).getLength()>1 && agent.spaceMemory.getInteraction(placeList.get(i).get(1).getIndex()).getPrediction()>=0) imin=i;
			i++;
		}
		System.out.println("+++++ decision : curiosity +++++ ");


		// find a candidate composite place to reinforce its place signature
		int[] sumList=new int[7];
		for (i=0;i<7;i++){
			sumList[i]=0;
		}

		imin=-1;
		min=2;
		
		for (int l=0;l<placeList.size();l++){
			if (placeList.get(l).isValide() && placeList.get(l).getLength()>1){								// primitive place doesn't have signatures

				// a candidate composite place is tested when the n-1 first interactions are already enacted and if the last interaction is enactable
				if (agent.spaceMemory.getInteraction(placeList.get(l).get(1).getIndex()).getPrediction()>0	// last interaction must be enactable
				 && placeList.get(l).nbTest>0																// must has been experimented at last once
				 && placeList.get(l).canBeTested(timeline)													// n-1 first interaction are already enacted
				){
				
					if (learn_place){
						// find the place with the lowest certitude
						float predict=placeList.get(l).placeSignature.prediction(objectRecognition[placeList.get(l).getLength()-2][placeList.get(l).objectTypeId],false);
						if (predict>0.1 && predict<min){
							imin=l;
							min=predict;
						}
					}
					else{
						// find the place with the lowest presence certitude
						for (int n=0;n<agent.placeContext.map[placeList.get(l).getLength()-2].size();n++){
							float predict=placeList.get(l).presenceSignature.prediction(agent.placeContext.map[placeList.get(l).getLength()-2].get(n), false);
							if (predict>0.1 && predict<min){
								imin=l;
								min=predict;
							}
						}
					}
				}
			}
		}
		if (imin!=-1){
			System.out.println(imin+" , "+placeList.get(imin).getName());
			System.out.println( " select "+placeList.get(imin).get(1).getName()+" from "+placeList.get(imin).getName()+" : "+min);
			return placeList.get(imin).get(1);
		}
		else return null;
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// select an interaction to maximize valence
	public PrimitiveInteraction getDecisionExploitation(){
		
		float[] sumList=new float[7];			// global satisfaction values
		
		// get the satisfaction value of each primitive interaction (with a malus if predicted as a fail)
		for (int i=0;i<7;i++){
			if (agent.spaceMemory.getInteraction(i).getPrediction()>-0.1)
				sumList[i]=agent.spaceMemory.getInteraction(i).getValence();
			else sumList[i]=-10000+agent.spaceMemory.getInteraction(i).getValence();
		}
		
		// compute movement coefficients
		for (int i=0;i<objectList.size();i++){
			objectList.get(i).computeMovements(this.interactionList);
		}
		
		
		int imax=0;
		float max=-11000;
		for (int i=0;i<7;i++){
			for (int o=0;o<objectList.size();o++){
				
				// we do not consider an object instance if the agent is going to interact with it in the next interaction
				if (agent.spaceMemory.getInteraction(objectList.get(o).objectId).getPrediction()<0 || objectList.get(o).distance>2){
					
					// we do not consider instances of the object that afford the considered candidate interaction
					if (objectList.get(o).object.getIndex()!=i){
					
						// add the utility value given by the considered object instance (the "15" coef is used as a distance offset)
						sumList[i]+= memoryCoef * objectList.get(o).object.valence() * objectList.get(o).influence[i] * 15*Math.exp(-objectCoef*(objectList.get(o).distance));
						System.out.println(" +++ "+i+" ; "+objectList.get(o).getName()+" adds "
								+memoryCoef * objectList.get(o).object.valence() * objectList.get(o).influence[i] * 15*Math.exp(-objectCoef*(objectList.get(o).distance))+" ; "
								+objectList.get(o).distance);
					}
				}
					
			}
		}
		
		// define the interaction with the highest global satisfaction value
		for (int i=0;i<7;i++){
			if (sumList[i]>max){
				imax=i;
				max=sumList[i];
			}
		}
		
		// display global satisfaction values and selected intended interaction
		for (int i=0;i<7;i++) System.out.print(sumList[i]+" , ");
		System.out.println();
		System.out.println(" --- exploitation mechanism selects "+agent.interactionList.getInteraction(imax).getName());
		/**/
		
		return agent.interactionList.getInteraction(imax);
	}

	
	//////////////////////////////////////////////////////////////////////////////////	
	// define the sequence list
	public void generateSequences(){
		for (int i=0;i<15360;i++){
			placeList.add(new Place(i, agent, agent.interactionList.getList()));
		}
	}
	
	//////////////////////////////////////////////////////////////////////////////////
	// save place signatures
	public void saveSeqSignatures(){
		System.out.println("=====================prepare to save sequence signatures...======================");
		
		String fileName = Observer.path+"spaceMemory/seqSignaturesV7_2_8 ("+EnvironmentContext.timeSize+") "+agent.getIdent()+".txt";
		
		try {
			PrintWriter file  = new PrintWriter(new FileWriter(fileName));
			
			// save signatures
			for (int l=0;l<placeList.size();l++){
				// signature
				if (placeList.get(l).isValide() && placeList.get(l).getLength()>1){
					for (int i=0;i<8;i++){
						for (int k=0;k<7;k++){
							for (int d=0;d<10;d++){
								if (placeList.get(l).presenceSignature.pattern[i][k][d]==0)
									file.print("0 ");
								else
									file.print(placeList.get(l).presenceSignature.pattern[i][k][d]+" ");
							}
						}
					}
					file.println();
				}
				if (l%500==0) System.out.println((int)((float)l/(float)placeList.size()*100)+"%");
			}
			file.close();
			System.out.println("signatures saved");
		}
		catch (Exception e) {e.printStackTrace();}
	}
	
	// load place signatures
	public void loadPresenceSignatures(){
		String fileName = Observer.path+"spaceMemory/seqSignaturesV7_2_8 ("+EnvironmentContext.timeSize+") "+agent.getIdent()+".txt";
		String[] elements;

		try {
			InputStream ips=new FileInputStream(fileName); 
			InputStreamReader ipsr=new InputStreamReader(ips);
			BufferedReader br=new BufferedReader(ipsr);
			String line;

			int index=0;
			int i,k,d;

			// load signatures
			while ((line=br.readLine())!=null){
				elements=line.split(" ");
				
				while (!placeList.get(index).isValide() || placeList.get(index).getLength()<=1){
					index++;
				}
				i=0;
				k=0;
				d=0;
				for (int l=0;l<elements.length;l++){
					placeList.get(index).presenceSignature.pattern[i][k][d]=Float.parseFloat(elements[l]);
					d++;
					if (d==10){
						d=0;
						k++;
					}
					if (k==7){
						k=0;
						i++;
					}
				}
				index++;
			}
		} 
		catch (Exception e) {
			System.out.println("no file found (signatures)");
			generateSequences();
		}
	}
	
	
	
	//////////////////////////////////////////////////////////////////////////////////
	// save signatures of interaction
	public void save(){
		System.out.println("=====================prepare to save agnostic memory...======================");
		String fileName = Observer.path+"spaceMemory/agnosticMemoryV7_2_8 ("+EnvironmentContext.timeSize+") "+agent.getIdent()+".txt";
		try {
			PrintWriter file  = new PrintWriter(new FileWriter(fileName));
			// save signatures
			for (int l=0;l<placeList.size();l++){
				// signature
				if (placeList.get(l).isValide()){
					for (int i=0;i<InteractionList.aSize1*2;i++){
						for (int j=0;j<InteractionList.aSize2*2;j++){
							if (placeList.get(l).placeSignature.pattern[i][j]==0)
								file.print("0 ");
							else
								file.print(placeList.get(l).placeSignature.pattern[i][j]+" ");
						}
					}
				}
				else{file.print(0);}
				file.println();
				if (l%500==0) System.out.println((int)((float)l/(float)placeList.size()*100)+"%");
			}
			file.close();
			System.out.println("memory file saved");
		}
		catch (Exception e) {e.printStackTrace();}
	}
	
	// load signatures of interaction
	public void loadFile(){
		String fileName = Observer.path+"spaceMemory/agnosticMemoryV7_2_8 ("+EnvironmentContext.timeSize+") "+agent.getIdent()+".txt";
		String[] elements;

		try {
			InputStream ips=new FileInputStream(fileName); 
			InputStreamReader ipsr=new InputStreamReader(ips);
			BufferedReader br=new BufferedReader(ipsr);
			String line;

			generateSequences();

			int index=0;
			int i,j;

			// load signatures
			while ((line=br.readLine())!=null){
				elements=line.split(" ");
				
				if (elements.length==1) index++;
				else{
					i=0;
					j=0;
					for (int k=0;k<elements.length;k++){
						
						placeList.get(index).placeSignature.pattern[i][j]=Float.parseFloat(elements[k]);
						j++;
						if (j==InteractionList.aSize2*2){
							j=0;
							i++;
						}                                   
					}
					index++;
				}
			}
		} 
		catch (Exception e) {
			System.out.println("no file found (agnostic memory)");
			generateSequences();
		}
	}
}

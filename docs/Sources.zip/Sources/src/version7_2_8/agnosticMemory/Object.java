package version7_2_8.agnosticMemory;

import java.util.ArrayList;

import version7_2_8.Interface.InteractionList;
import version7_2_8.Interface.PrimitiveInteraction;

/**
 * Instance of an object
 * @author simon
 */
public class Object {

	public PrimitiveInteraction object;				// interaction afforded by this instance
	public int objectId;
	public ArrayList<PrimitiveInteraction> path;	// sequence of interaction enacted after creating this object
	
	public int x;
	public int y;
	
	public ArrayList<Place> memory;					// list of detected places that contain this instance
	public ArrayList<Float> memoryCoef;	
	
	public ArrayList<Place> evoked;					// list of places that contain this instance, including places that are evoked at each step
	public ArrayList<Float> evokedCoef;
	
	public ArrayList<Place>[] evokedLists;			// list of evoked places, grouped by the first interaction of the path
	public ArrayList<Float>[] evokedListCoefs;
	
	public float[][] map;							// estimated position of the instance, computed by adding place signatures
	public float[][] map2;
	
	public float[][][] sequenceMap;
	public float[][][] sequenceMap2;
	
	public float max1;
	public float max2;
	
	public float[] influence;						// gives the distance variation influence of each primitive interaction.
	public float distance=10;						// estimated distance
	
	
	public Object(PrimitiveInteraction inter, int o, int i,int j){
		object=inter;
		objectId=o;
		
		memory=new ArrayList<Place>();
		memoryCoef=new ArrayList<Float>();
		
		evoked=new ArrayList<Place>();
		evokedCoef=new ArrayList<Float>();
		
		evokedLists=new ArrayList[7];
		evokedListCoefs=new ArrayList[7];
		for (int n=0;n<7;n++){
			evokedLists[n]=new ArrayList<Place>();
			evokedListCoefs[n]=new ArrayList<Float>();		
		}
		
		influence=new float[7];
		
		path=new ArrayList<PrimitiveInteraction>();
		map=new float[InteractionList.aSize1*2][InteractionList.aSize2*2];
		map2=new float[InteractionList.aSize1*2][InteractionList.aSize2*2];
		x=i;
		y=j;

		sequenceMap=new float[8][7][10];
		sequenceMap2=new float[8][7][10];
	}
	
	public void addSequence(Place p, float val){
		if (val>0.8){
			memory.add(p);
			memoryCoef.add(val);
		}
	}
	
	
	public void update(PrimitiveInteraction inter, ArrayList<Place> list){
		
		// update sequences
		for (int i=0;i<memory.size();i++){
			// update or remove sequences
			if (memory.get(i).getLength()>1 && memory.get(i).getFirst().isEqual(inter)){
				memory.add(i,list.get(memory.get(i).getNextIndex(0)) );
				memory.remove(i+1);
			}
			else{
				memory.remove(i);
				memoryCoef.remove(i);
				i--;
			}
		}
		
		// update evoked sequences
		for (int i=0;i<evoked.size();i++){
			// update or remove sequences
			if (evoked.get(i).getLength()>1 && evoked.get(i).getFirst().isEqual(inter)){
				evoked.add(i,list.get(evoked.get(i).getNextIndex(0)) );
				evoked.remove(i+1);
			}
			else{
				evoked.remove(i);
				evokedCoef.remove(i);
				i--;
			}
		}
		
		
		//get the previous evoked sequences
		for (int i=0;i<7;i++){
			
			for (int s=0;s<evokedLists[inter.getIndex()].size();s++){
				evoked.add(list.get(evokedLists[inter.getIndex()].get(s).getNextIndex(0)));
				evokedCoef.add(evokedListCoefs[inter.getIndex()].get(s));
			}
			
			evokedLists[i].clear();
			evokedListCoefs[i].clear();
		}
		
		// remove the most unreliable places
		/*float max=0;
		for (int i=0;i<evoked.size();i++){
			if (evokedCoef.get(i)>max) max=evokedCoef.get(i);
		}
		for (int i=0;i<evoked.size();i++){
			if (evokedCoef.get(i)<max/4){
				evoked.remove(i);
				evokedCoef.remove(i);
			}
		}*/
		
		
		// update the object itself
		path.add(inter);
	}
	
	
	public void evoke(ArrayList<Place> list){
		
		// generate the sequence map1
		int i,k,d;
		for (i=0;i<8;i++){
			for (k=0;k<7;k++){
				for (d=0;d<10;d++){
					sequenceMap[i][k][d]=0;
				}
			}
		}
		for (int s=0;s<memory.size();s++){
			if (memory.get(s).getLength()<=2){
				if (memory.get(s).getLength()==1) i=0;
				else i=memory.get(s).get(1).getIndex() +1;
				k=memory.get(s).get(0).getIndex();
				d=(int)memory.get(s).distance;
				sequenceMap[i][k][d]=1;
			}
		}
		
		// generate the sequence map2
		for (i=0;i<8;i++){
			for (k=0;k<7;k++){
				for (d=0;d<10;d++){
					sequenceMap2[i][k][d]=0;
					if (sequenceMap[i][k][d]==1) sequenceMap2[i][k][d]=1;
				}
			}
		}
		for (int s=0;s<evoked.size();s++){
			if (evoked.get(s).getLength()<=2){
				if (evoked.get(s).getLength()==1) i=0;
				else i=evoked.get(s).get(1).getIndex() +1;
				k=evoked.get(s).get(0).getIndex();
				d=(int)evoked.get(s).distance;
				sequenceMap2[i][k][d]=1;
			}
		}
		
		// get the evoked sequences from memory 1
		float[] interactionMax=new float[7];
		for (i=0;i<list.size();i++){
			if (list.get(i).isValide() && list.get(i).objectTypeId==this.objectId){
				float predict=list.get(i).presenceSignature.prediction(sequenceMap, false);
				
				if (predict>interactionMax[list.get(i).getFirst().getIndex()])interactionMax[list.get(i).getFirst().getIndex()]=predict;
				if (predict>0){
					evokedLists[list.get(i).getFirst().getIndex()].add(list.get(i));
					evokedListCoefs[list.get(i).getFirst().getIndex()].add(predict);
				}
				
				if (predict>0.5){
					evoked.add(list.get(i));
					evokedCoef.add(predict);
				}
			}
		}
		
		// get the evoked sequences from memory 2
		for (i=0;i<list.size();i++){
			if (list.get(i).isValide() && list.get(i).objectTypeId==this.objectId){
				float predict=list.get(i).presenceSignature.prediction(sequenceMap2, false);
				
				if (predict>interactionMax[list.get(i).getFirst().getIndex()])interactionMax[list.get(i).getFirst().getIndex()]=predict;
				if (predict>0){
					evokedLists[list.get(i).getFirst().getIndex()].add(list.get(i));
					evokedListCoefs[list.get(i).getFirst().getIndex()].add(predict);
				}
				
				if (predict>0.2){
					evoked.add(list.get(i));
					evokedCoef.add(predict);
				}
			}
		}
		
		//System.out.println("***** "+this.getName()+" : ");
		//for (int n=0;n<7;n++) System.out.print(interactionMax[n]+" , ");
		//System.out.println();
		//System.out.println();
		
		// remove doubles
		for (i=0;i<evoked.size();i++){
			for (int j=i+1;j<evoked.size();j++){
				if (evoked.get(i).isEqual(evoked.get(j))){
					evokedCoef.set(i, Math.max(evokedCoef.get(i), evokedCoef.get(j)));
					evoked.remove(j);
					j--;
				}
			}
		}
		
		// remove unreliables
		for (int n=0;n<7;n++){
			for (int s=0;s<evokedLists[n].size();s++){
				if (evokedListCoefs[n].get(s)<interactionMax[n]/2 || evokedListCoefs[n].get(s)<0.03){
					evokedLists[n].remove(s);
					evokedListCoefs[n].remove(s);
					s--;
				}
			}
		}
		/*if (max>0){
			for (i=0;i<evoked.size();i++){
				if (evokedCoef.get(i)<max*0.2){
					evoked.remove(i);
					i--;
				}
			}
		}*/
	}
	
	////////////////////////////////////////////////////////
	public void defineMap(){
		for (int i=InteractionList.aSize1/3;i<InteractionList.aSize1*2-InteractionList.aSize1/3;i++){
			for (int j=20;j<InteractionList.aSize2*2;j++){
				map[i][j]=0;
				map2[i][j]=0;
			}
		}
		max1=0;
		max2=0;
		
		for (int l=0;l<memory.size();l++){
			for (int i=InteractionList.aSize1/3;i<InteractionList.aSize1*2-InteractionList.aSize1/3;i++){
				for (int j=20;j<InteractionList.aSize2*2;j++){
					map[i][j]+=memory.get(l).placeSignature.pattern[i][j] * memoryCoef.get(l);
					if (map[i][j]>max1) max1=map[i][j];
				}
			}
		}
		
		for (int l=0;l<evoked.size();l++){
			for (int i=InteractionList.aSize1/3;i<InteractionList.aSize1*2-InteractionList.aSize1/3;i++){
				for (int j=20;j<InteractionList.aSize2*2;j++){
					map2[i][j]+=evoked.get(l).placeSignature.pattern[i][j] * evokedCoef.get(l);
					if (map2[i][j]>max2) max2=map2[i][j];
				}
			}
		}
	}
	
	////////////////////////////////////////////////////////
	public void computeMovements(ArrayList<Interaction> list){
		
		float distMax1[]=new float[10];
		float distMax2[]=new float[10];
		
		float coef[] = new float[7];
		int observed[]=new int[7];
		
		for (int i=0;i<7;i++) observed[i]=-1;
		
		System.out.println(this.getName());
		
		if (!memory.isEmpty()){
			// compute distance of the object before interaction (first list)
			
			// search the maximum certitude for each proposed distance
			for (int i=0;i<memory.size();i++){
				float d=Math.min(9, memory.get(i).distance + memory.get(i).getLength()-1);
				if (d>0 && memoryCoef.get(i)>0 && memoryCoef.get(i)>=distMax1[(int)d]) distMax1[(int)d]=memoryCoef.get(i);
			}
			
			// search the first maximum given by first list
			int imax=0;
			boolean found=false;
			while (!found && imax<9){
				if (distMax1[imax]>distMax1[imax+1]) found=true;
				else imax++;
			}
			System.out.println(" max1 = "+imax);

			// get the average distance
			if (imax==0) distance=distMax1[1]*0.1f/(distMax1[0]+distMax1[1]*0.1f);
			else if (imax==9) distance= (8*distMax1[8]*0.1f + 9*distMax1[9]) / (distMax1[8]*0.1f+distMax1[9]);
			else distance= ( (imax-1)*distMax1[imax-1]*0.1f +  (imax)*distMax1[imax] + (imax+1)*distMax1[imax+1]*0.1f) 
						 / ( distMax1[imax-1]*0.1f+distMax1[imax]+distMax1[imax+1]*0.1f);
			System.out.println(distance);
		}
		else{
			// compute distance of the object before interaction (second list)
			
			// search the maximum certitude for each proposed distance
			for (int i=0;i<evoked.size();i++){
				float d=Math.min(9, evoked.get(i).distance + evoked.get(i).getLength()-1);
				if (d>0 && evokedCoef.get(i)>0 && evokedCoef.get(i)>=distMax2[(int)d]) distMax2[(int)d]=evokedCoef.get(i);
			}

			// search the first maximum given by second list
			int imax=0;
			boolean found=false;
			while (!found && imax<9){
				if (distMax2[imax]>distMax2[imax+1]) found=true;
				else imax++;
			}
			System.out.println(" max2 = "+imax);
	
			// get the average distance
			if (imax==0) distance=(distMax2[1]*0.1f)/(distMax2[0]+distMax2[1]*0.1f);
			else if (imax==9) distance= (8*distMax2[8]*0.1f + 9*distMax2[9]) / (distMax2[8]*0.1f+distMax2[9]);
			else distance= ( (imax-1)*distMax2[imax-1]*0.1f +  (imax)*distMax2[imax] + (imax+1)*distMax2[imax+1]*0.1f) 
							/ ( distMax2[imax-1]*0.1f+distMax2[imax]+distMax2[imax+1]*0.1f);
			System.out.println(distance);
		}
		
		if (!memory.isEmpty()){
			for (int i=0;i<memory.size();i++){
				if (memory.get(i).getLength()<=2){
					if (memory.get(i).distance + memory.get(i).getLength() <=distance+2){
						observed[memory.get(i).getFirst().getIndex()]=1;
					}
					else{
						if (observed[memory.get(i).getFirst().getIndex()]==-1) observed[memory.get(i).getFirst().getIndex()]=0;
					}
				}
			}
			
			for (int i=0;i<evoked.size();i++){
				if (evoked.get(i).getLength()<=2){
					if (observed[evoked.get(i).getFirst().getIndex()]==-1) observed[evoked.get(i).getFirst().getIndex()]=0;
				}
			}
		}
		else{
			for (int i=0;i<evoked.size();i++){
				if (evoked.get(i).getLength()<=2){
					if (evoked.get(i).distance + evoked.get(i).getLength()  <=distance+2){
						observed[evoked.get(i).getFirst().getIndex()]=1;
					}
					else{
						if (observed[evoked.get(i).getFirst().getIndex()]==-1) observed[evoked.get(i).getFirst().getIndex()]=0;
					}
				}
			}
		}
		
		for (int i=0;i<7;i++){
			if (observed[i]==-1) coef[i]=-1;
			else{
				if (observed[i]==0) coef[i]=0;
				else{
					coef[i]=1;
				}
			}
			influence[i]=coef[i];
			System.out.println("+++ "+i+" -> "+influence[i]);
		}
		System.out.println();
	}
	
	
	public float getMax(int i,int j){
		float ret=0;
		for (int k=0;k<memory.size();k++) if (memory.get(k).placeSignature.pattern[i][j]>ret) ret=memory.get(k).placeSignature.pattern[i][j];	
		
		return ret;
	}
	
	public float getDistMin(int x, int y){
		float min=1000;
		
		for (int i=InteractionList.aSize1/3;i<InteractionList.aSize1*2-InteractionList.aSize1/3;i++){
			for (int j=20;j<InteractionList.aSize2*2;j++){
				if (map2[i][j]>max2/2 && map2[i][j]>1){
					float d=(float)Math.sqrt( (x-i)*(x-i) + (y-j)*(y-j) );
					if (d<min){
						if (this.objectId==2) System.out.println("***** "+this.getName()+" ; "+ map2[i][j]);
						min=d;
					}
				}
			}
		}
		return min;
	}
	

	
	public boolean isEmpty(){
		return memory.size()==0 && evoked.size()==0;
	}
	
	
	public String getName(){
		String ret=object.getName()+" : ("+x+"; "+y+")";
		for (int i=0;i<path.size();i++) ret+=" ; "+path.get(i).getName();
		return ret;
	}
	
}

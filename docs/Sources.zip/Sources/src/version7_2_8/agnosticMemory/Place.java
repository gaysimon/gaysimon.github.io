package version7_2_8.agnosticMemory;

import java.util.ArrayList;

import version7_2_8.Interface.PrimitiveInteraction;
import version7_2_8.platform.Agent;

/**
 * Definition of a place (both primitive and composite)
 * @author simon
 */
public class Place {

	public PrimitiveInteraction finalPosition;			// interaction that characterize the final primitive place
	public PrimitiveInteraction objectType;	
	public int objectTypeId;
	public float distance=0;
	
	public ArrayList<PrimitiveInteraction> sequence;	// path of the place
	private ArrayList<Integer> sequenceIndex;			// index of interactions that compose the path
	
	public PlaceSignature placeSignature;
	public PresenceSignature presenceSignature;
	
	public int ident;
	
	public ArrayList<Integer> nextSequence;

	public float value=0;								// variable used to store various data
	public int nbTest=0;

	
	public Place(int ident, Agent a, ArrayList<PrimitiveInteraction> objList){

		placeSignature=new PlaceSignature();
		presenceSignature=new PresenceSignature();
		sequence=new ArrayList<PrimitiveInteraction>();
		sequenceIndex=new ArrayList<Integer>();
		nextSequence=new ArrayList<Integer>();
		this.ident =ident;
		
		
		ArrayList<Integer> seq=new ArrayList<Integer>();
		int i=ident;
		
		objectTypeId=i-3*(int)(i/3);
		objectType=objList.get(objectTypeId);
		i=(int)(i/3);
		
		distance=i-10*(int)(i/10);
		i=(int)(i/10);
		
		while (i>=8){
			seq.add(i-8*(int)(i/8));
			i=(int)(i/8);
		}
		seq.add(i);
		
		for (int l=0;l<seq.size()-1;l++){
			int next=0;
			for (int j=seq.size()-2-l;j>=0;j--){
				next=next*8+seq.get(j);
			}
			next=next*10+(int)distance;
			next=next*3+objectTypeId;
			nextSequence.add(next);
		}
		
		// get the final position
		if (seq.get(0)>0){
			finalPosition=a.interactionList.getInteraction(seq.get(0)-1);
			seq.remove(0);
		}
		else{
			finalPosition=null;
			sequence=null;
		}
		
		// get the sequence of interaction
		if (finalPosition!=null){
			boolean error=false;
			while (!seq.isEmpty() && !error){
				if (seq.get(0)>0){
					this.add(a.interactionList.getInteraction(seq.get(0)-1), seq.get(0)-1);
					seq.remove(0);
				}
				else error=true;
			}
			if (error){
				finalPosition=null;
				sequence=null;
			}
		}
	}
	
	
	public void add(PrimitiveInteraction inter, int i){
		sequence.add(inter);
		sequenceIndex.add(i);
	}
	
	
	public int getLength(){
		return 1+sequence.size();
	}
	
	public boolean isEqual(Place seq){
		if (this.sequence.size()!=seq.sequence.size()) return false;
		else{
			if (!this.finalPosition.isEqual(seq.finalPosition) || this.distance!=seq.distance) return false;
			else{
				boolean ret=true;
				int i=0;
				while(ret && i<this.sequence.size()){
					if (!this.sequence.get(i).isEqual(seq.sequence.get(i))) ret=false;
					i++;
				}
				return ret;
			}
		}
	}
	
	public PrimitiveInteraction getFirst(){
		if (sequence.size()==0) return this.finalPosition;
		else return sequence.get(sequence.size()-1);
	}
	
	public PrimitiveInteraction get(int i){
		if (i==0) return this.finalPosition;
		else return sequence.get(i-1);
	}
	
	public String getName(){
		
		String ret="{"+objectType.getName()+"} : ";

		for (int i=sequence.size()-1;i>=0;i--) 
			ret+=sequence.get(i).getName()+", ";
		ret+="["+finalPosition.getName()+", "+(int)distance+"]";

		return ret;
	}
	
	
	public int getIdent(){
		return ident;
	}
	
	public boolean isValide(){
		return finalPosition!=null;
	}
	
	
	public void learnPlaceSignature(PrimitiveInteraction[] timeline , boolean[][][] map, float[][][][] context){

		boolean equal=true;
		for (int i=0;i<sequence.size();i++){
			if (timeline[i]==null) equal=false;
			else if (!sequence.get(i).isEqual(timeline[i])) equal=false;
		}
		
		// if the sequence is recognized, reinforce the signature
		if (equal){
			if (map[objectTypeId][finalPosition.getIndex()][(int)distance]){
				// learn as success
				placeSignature.learn(context[sequence.size()][objectTypeId], 1);
				if (nbTest<100) nbTest++;
			}
			else{
				// learn as fail
				placeSignature.learn(context[sequence.size()][objectTypeId],-1);
			}
		}
	}
	
	
	public void learnPresenceSignature(PrimitiveInteraction[] timeline , boolean[][][] map, float[][][] context){

		boolean equal=true;
		for (int i=0;i<sequence.size();i++){
			if (timeline[i]==null) equal=false;
			else if (!sequence.get(i).isEqual(timeline[i])) equal=false;
		}
		
		// if the sequence is recognized, reinforce the signature
		if (equal){
			if (map[objectTypeId][finalPosition.getIndex()][(int)distance]){
				// learn as success
				presenceSignature.learn(context, 1, this.getFirst().getIndex());
				if (nbTest<100) nbTest++;
			}
			else{
				// learn as fail
				presenceSignature.learn(context,-1, this.getFirst().getIndex());
			}
		}
	}
	
	
	
	public int getNextIndex(int i){
		if (i>=nextSequence.size()) return -1;
		else return this.nextSequence.get(i);
	}
	
	
	// return true if the n-1 first elements of the path match the timeline
	public boolean canBeTested(PrimitiveInteraction[] timeline){
		boolean match=true;
		
		// compare timeline
		for (int t=0;t<this.sequence.size()-1;t++){
			if (timeline[t]==null) match=false;
			else if (!this.sequence.get(t+1).isEqual(timeline[t])) match=false;
		}
		
		return match;
	}

}

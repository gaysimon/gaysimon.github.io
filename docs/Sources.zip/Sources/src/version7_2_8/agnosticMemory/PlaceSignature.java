package version7_2_8.agnosticMemory;

import version7_2_8.Interface.InteractionList;

/**
 * Place signatures
 * @author simon gay
 */
public class PlaceSignature {

	public float[][] pattern;
	
	public PlaceSignature(){
		pattern=new float[InteractionList.aSize1*2][InteractionList.aSize2*2];
		for (int i=0;i<InteractionList.aSize1*2;i++){
			for (int j=0;j<InteractionList.aSize2*2;j++){
				pattern[i][j]=0;
			}
		}
	}
	
	// prediction according to the context img. if positive==true, only use positive weights
	public float prediction(float[][] img, boolean positive){
		float result=0;
		for (int i=InteractionList.aSize1/3;i<InteractionList.aSize1*2-InteractionList.aSize1/3;i++){
			for (int j=20;j<InteractionList.aSize2*2;j++){
				if ( ( pattern[i][j]>0) || !positive )
					result+=pattern[i][j]*img[i][j];
			}
		}
		result= (float) ( 1 / (1+Math.exp(-result)))*2-1;
		
		return result;
	}
	
	public void learn(float[][] img, float output){
		
		float result=prediction(img, output==1);
		
		for (int i=0;i<InteractionList.aSize1*2;i++){
			for (int j=0;j<InteractionList.aSize2*2;j++){
				pattern[i][j]+= 0.05 * (output-result) * img[i][j];
			}
		}
	}

}

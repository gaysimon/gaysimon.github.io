package version7_2_8.agnosticMemory;

/**
 * Presence signature
 * @author simon
 */
public class PresenceSignature {

	public float[][][] pattern;
	
	public PresenceSignature(){
		pattern=new float[8][7][10];
		for (int i=0;i<8;i++){
			for (int k=0;k<7;k++){
				for (int d=0;d<10;d++){
					pattern[i][k][d]=0;
				}
			}
		}
	}
	
	
	public float prediction(float[][][] img, boolean positive){
		float result=0;
		for (int i=0;i<8;i++){
			for (int k=0;k<7;k++){
				for (int d=0;d<10;d++){
					if ( ( pattern[i][k][d]>0) || !positive )
						result+=pattern[i][k][d]*img[i][k][d];
				}
			}
		}
		result= (float) ( 1 / (1+Math.exp(-result)))*2-1;
		
		return result;
	}
	
	// reinforce the signature according to the result output in the context img.
	public void learn(float[][][] img, float output, int firstIndex){
		
		float result=prediction(img, output==1);
		
		for (int i=0;i<8;i++){
			if (i!=firstIndex+1){
				for (int k=0;k<7;k++){
					for (int d=0;d<10;d++){
						pattern[i][k][d]+= 0.05 * (output-result) * img[i][k][d];
					}
				}
			}
			else{
				for (int k=0;k<7;k++){
					for (int d=0;d<10;d++){
						pattern[i][k][d]=0;
					}
				}
			}
		}
	}

}

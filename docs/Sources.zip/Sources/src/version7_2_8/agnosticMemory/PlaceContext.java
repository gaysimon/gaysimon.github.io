package version7_2_8.agnosticMemory;

import java.util.ArrayList;

/**
 * Context of presence defined by an object instance
 * @author simon
 */
public class PlaceContext {

	public ArrayList<float[][][]>[] map;
	public ArrayList<Integer>[] objectIndex;
	
	
	public PlaceContext(){
		
		map=new ArrayList[4];
		for (int t=0;t<4;t++){
			map[t]=new ArrayList<float[][][]>();
		}
		
		objectIndex=new ArrayList[4];
		for (int t=0;t<4;t++){
			objectIndex[t]=new ArrayList<Integer>();
		}
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////////
	// set interactional context
	public void updateContext(ArrayList<Object> objectList){
		
		
		// update context
		map[3].clear();
		for (int t=3;t>0;t--)map[t]=map[t-1];
		map[0]=new ArrayList<float[][][]>();
		
		objectIndex[3].clear();
		for (int t=3;t>0;t--)objectIndex[t]=objectIndex[t-1];
		objectIndex[0]=new ArrayList<Integer>();

		int i,k,d;
		
		for (int o=0;o<objectList.size();o++){
			
			map[0].add(new float[8][7][10]);
			objectIndex[0].add(objectList.get(o).objectId);
			
			for (int s=0;s<objectList.get(o).memory.size();s++){
				
				if (objectList.get(o).memory.get(s).getLength()<=2){
					if (objectList.get(o).memory.get(s).getLength()==1) i=0;
					else i=objectList.get(o).memory.get(s).get(1).getIndex() +1;

					k=objectList.get(o).memory.get(s).get(0).getIndex();
					
					d=(int)objectList.get(o).memory.get(s).distance;
					
					map[0].get(o)[i][k][d]=1;
				}
			}
		}
	}
}

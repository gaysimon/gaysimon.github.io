package version7_2_8.environment;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.Color;

import version7_2_8.platform.Observer;
import version7_2_8.platform.PrintablePanel;

/**
 * A panel that display the environment
 * @author simon gay, olivier georgeon
 */
public class EnvironnementPanel extends PrintablePanel implements MouseListener{

	private static final long serialVersionUID = 1L;
	
	private Environment m_env;
	
	private int m_clicked=0;
	private int m_clickX;
	private int m_clickY;
	
	private float m_FclickX;
	private float m_FclickY;
	
	private CubicCurve2D.Double petal1 = new CubicCurve2D.Double(0, 0,  0,80, 80,0,   0, 0);
	private CubicCurve2D.Double petal2 = new CubicCurve2D.Double(0, 0, 80, 0,  0,-80, 0, 0);
	private CubicCurve2D.Double petal3 = new CubicCurve2D.Double(0, 0,  0,-80,-80, 0, 0, 0);
	private CubicCurve2D.Double petal4 = new CubicCurve2D.Double(0, 0, -80, 0, 0, 80, 0, 0);

	private GeneralPath m_leaf = new GeneralPath();
	private GeneralPath m_fish = new GeneralPath();
	
	private float h;
	private float w;
		
	public EnvironnementPanel(Environment env){
		super();
		m_env=env;
		
		addMouseListener(this);
		
		m_leaf.append(petal1, false);
		m_leaf.append(petal2, false);
		m_leaf.append(petal3, false);
		m_leaf.append(petal4, false);
		
		m_fish.append(new CubicCurve2D.Double(-40, 15,  -30, 0, 40, -40,   40, 0), false);
		m_fish.append(new CubicCurve2D.Double( 40,  0,  40, 40, -30,  0,   -40, -15), true);
		m_fish.append(new Area(new Ellipse2D.Double( 20,  -10,  8, 8)), false);

	}
	
	
	public int[] transform_x(float[] polygon_x,float[] polygon_y,float angle_x,float scale_x,int translation_x){
		int[] ret=new int[polygon_x.length];
		for (int i=0;i<polygon_x.length;i++){
			// rotation and scale
			ret[i]=(int)( ( (polygon_x[i]*Math.cos(angle_x)) - (polygon_y[i]*Math.sin(angle_x)) )*scale_x);
			
			// translation
			ret[i]+=translation_x;
		}
		
		return ret;
	}
	
	public int[] transform_y(float[] polygon_x,float[] polygon_y,float angle_y,float scale_y,int translation_y){
		int[] ret=new int[polygon_y.length];
		for (int i=0;i<polygon_y.length;i++){
			// rotation and scale
			ret[i]=(int) (( (polygon_x[i]*Math.sin(angle_y)) + (polygon_y[i]*Math.cos(angle_y)) )*scale_y);
			
			// translation
			ret[i]+=translation_y;
		}
		
		return ret;
	}
	
	public void drawPDF(Graphics g){
		paintComponent(g,0.5f,0.5f);
	}
	
	public void paintComponent(Graphics g){
		paintComponent(g,1,1);
	}
	
	// draw simulated system
	public void paintComponent(Graphics g,float sx,float sy){

		Graphics2D g2d = (Graphics2D)g;

		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
		AffineTransform boardReference = g2d.getTransform();

		h=this.getHeight();
		w=this.getWidth();
		
		float c_w= (sx*w/m_env.m_w);
		float c_h= (sy*h/m_env.m_h);
		
		g2d.setColor(Color.white);
		g2d.fillRect(0, 0, (int)w, (int)h);
		
		
		// draw agents
		for (int i=0;i<m_env.platform().nbAgent();i++){
			
			int parameter=0;
			if (m_env.platform().selectAgent(i).body.sensors[0]==2) parameter=1;
			
			paintAgent((Graphics2D)g.create(),
					   (int) (   m_env.platform().selectAgent(i).body.getpx()   *c_w+(c_w/2)),
					   (int) (h-(m_env.platform().selectAgent(i).body.getpy()+1)*c_h+(c_h/2)),
					   (   m_env.platform().selectAgent(i).body.getrz()),
					   Math.min((double)c_w/100, (double)c_h/100),Math.min((double)c_w/100, (double)c_h/100),
					   parameter);
		}
		
		for (int i=0;i<m_env.m_w;i++){
			for (int j=0;j<m_env.m_h;j++){
				
				// walls
				if (m_env.isWall(i, j)){
					g2d.setColor(m_env.seeBlock(i,j));
					g2d.fillRect((int)(i*c_w), (int)(h-(j+1)*c_h), (int)c_w+1, (int)c_h+1);
				}
				
				// fish
				if (m_env.isFood(i, j)){
					AffineTransform centerCell = new AffineTransform();
					centerCell.translate(i*c_w+c_w/2, h-(j+1)*c_h+c_h/2);
					centerCell.scale((double) c_w / 100, (double) c_h / 100); 
					g2d.transform(centerCell);
					g2d.setColor(m_env.seeBlock(i,j));
					g2d.fill(m_fish);
					g2d.setTransform(boardReference);
				}
				
				// leaf
				if (m_env.isAlga(i, j)){
					AffineTransform centerCell = new AffineTransform();
					centerCell.translate(i*c_w+c_w/2, h-(j+1)*c_h+c_h/2);
					centerCell.scale((double) c_w / 100, (double) c_h / 100); 
					g2d.transform(centerCell);

					g2d.setColor(m_env.seeBlock(i,j));
					
					g2d.fill(m_leaf);
					g2d.setTransform(boardReference);
				}
				
			}
		}

		Stroke stroke3 = new BasicStroke(3f*Math.min(c_w,c_h)/80);
		
		g2d.setStroke(stroke3);
		
		// draw agent touch actions
		for (int i=0;i<m_env.platform().nbAgent();i++){
				
			double x= (   m_env.platform().selectAgent(i).body.getpx()   *c_w+(c_w/2));
			double y= (h-(m_env.platform().selectAgent(i).body.getpy()+1)*c_h+(c_h/2));

			double th=m_env.platform().selectAgent(i).body.getrz();
			
			g.setColor(Color.blue);
				
			
			if (m_env.platform().selectAgent(i).body.display[0]){
				g2d.fillOval( (int)(x+0.5*Math.cos(th)*c_w) -5, (int)(y-0.5*Math.sin(th)*c_h)-5, 10, 10);
			}
			
			if (m_env.platform().selectAgent(i).body.display[1]){
				g2d.fillOval( (int)(x-0.5*Math.sin(th)*c_w) -5, (int)(y-0.5*Math.cos(th)*c_h)-5, 10, 10);
			}
			
			if (m_env.platform().selectAgent(i).body.display[2]){
				g2d.fillOval( (int)(x+0.5*Math.sin(th)*c_w) -5, (int)(y+0.5*Math.cos(th)*c_h)-5, 10, 10);
			}
		}
		
		
		// draw agent trace
		for (int i=0;i<m_env.platform().nbAgent();i++){
			for (int l=1;l<Observer.pathLength;l++){
				g2d.setColor(Color.black);
				g2d.drawLine((int)((  m_env.platform().selectAgent(i).observer.trace[l-1][0]*c_w)+(c_w/2)),
							 (int)((h-m_env.platform().selectAgent(i).observer.trace[l-1][1]*c_h)-(c_h/2)),
							 (int)((  m_env.platform().selectAgent(i).observer.trace[l  ][0]*c_w)+(c_w/2)),
							 (int)((h-m_env.platform().selectAgent(i).observer.trace[l  ][1]*c_h)-(c_h/2)));
				
				
				if (m_env.platform().selectAgent(i).observer.interactionType[l-1]!=0 && m_env.platform().selectAgent(i).observer.interactionType[l-1]<3){
					int radius= (int)((Observer.pathLength-l)*(20/(float)Observer.pathLength));
					if (m_env.platform().selectAgent(i).observer.interactionType[l-1]==1) g2d.setColor(Color.red);
					else if (m_env.platform().selectAgent(i).observer.interactionType[l-1]==2) g2d.setColor(Environment.FISH1);
					else g2d.setColor(Color.LIGHT_GRAY);
					
					g2d.fillOval((int)(  m_env.platform().selectAgent(i).observer.trace[l-1][0]*c_w+(c_w/2))-radius/2,
								 (int)(h-m_env.platform().selectAgent(i).observer.trace[l-1][1]*c_h-(c_h/2))-radius/2, radius, radius);
				}
			}
		}
		
		// draw informations
		drawInformation((Graphics2D)g.create());
	}

	// detect events for environment edition
	public void mouseClicked(MouseEvent e){

		h=this.getHeight();
		w=this.getWidth();
		
		m_clicked=0;

		m_clickX= (e.getX() / (int)( (float)w/(float)m_env.m_w ));
		m_clickY= (e.getY() / (int)( (float)h/(float)m_env.m_h ));
		
		m_FclickX=(float)e.getX() / ((float)w/(float)m_env.m_w );
		m_FclickY=(float)e.getY() / ((float)h/(float)m_env.m_h );
		
		if (e.getButton() == MouseEvent.BUTTON1)
			if (e.isShiftDown()) m_clicked = 4;
			else m_clicked = 1;
		if (e.getButton() == MouseEvent.BUTTON2)
				if (e.isShiftDown()) m_clicked = 5;
				else m_clicked = 2;
		if (e.getButton() == MouseEvent.BUTTON3)
		{
			if (e.isShiftDown()) m_clicked = 6;
			else m_clicked = 3;
		}
		
		m_env.drawGrid(m_clicked);
	}


	@Override
	public void mouseEntered(MouseEvent arg0){}
	public void mouseExited(MouseEvent arg0){}
	public void mousePressed(MouseEvent arg0){}
	public void mouseReleased(MouseEvent arg0){}
	
	/**
	 * Draw the information square.
	 */
	private void drawInformation(Graphics2D g2d){
		
		h=this.getHeight();
		w=this.getWidth();
		
		float c_w=w/m_env.m_w;
		float c_h=h/m_env.m_h;
		
		String counter ="";
		
		counter+="#"+m_env.id+": "+m_env.platform().selectAgent(m_env.id).action.getNbStep();
		
		
		//Font font = new Font("Dialog", Font.BOLD, 10);
		Font font = new Font("Dialog", Font.BOLD, 18);
		g2d.setFont(font);
		
		FontMetrics fm = getFontMetrics(font);

		int width = fm.stringWidth(counter);
		
		//g2d.setColor(new Color(200, 255, 200));		
		g2d.setColor(Color.GRAY);		
		g2d.drawString(counter, m_env.m_w*c_w - c_w*1.1f - width, c_h*1.5f + 5);	
	}
	
    public void paintAgent(Graphics2D g2d,int x,int y,double rz,double sx,double sy,int parameter){
        // The orientation
        AffineTransform orientation = new AffineTransform();
        orientation.translate(x,y);
        orientation.rotate(-rz+Math.PI/2);
        orientation.scale(sx,sy);
        g2d.transform(orientation);

        // The shark body
        Area shark = shape(1);
        
        //Arc2D.Double pixelIn = new Arc2D.Double(-20, -20, 40, 40,0, 180 / Ernest.RESOLUTION_RETINA + 1, Arc2D.PIE);
        Arc2D.Double focus = new Arc2D.Double(-10, -35, 20, 20,0, 180, Arc2D.PIE);
        
        // Draw the body
        g2d.setColor(Environment.AGENT_COLOR);
        if (parameter==1) g2d.setColor(Color.red);
        g2d.fill(shark);
        g2d.fill(focus);
    }
	
    
    public static Area shape(int ID){
        GeneralPath body = new GeneralPath();
        body.append(new CubicCurve2D.Double(0,-40, -30,-40, -5, 45, 0, 45), false);
        body.append(new CubicCurve2D.Double(0, 45,   5, 45, 30,-40, 0,-40), false);
        
        GeneralPath leftPectoralFin = new GeneralPath();
        leftPectoralFin.append(new CubicCurve2D.Double(-15, -15, -30, -10, -40, 0, -40, 20), false);
        leftPectoralFin.append(new CubicCurve2D.Double(-40,  20, -30,  10, -20, 8, -10, 10), true);

        GeneralPath leftPelvicFin = new GeneralPath();
        leftPelvicFin.append(new CubicCurve2D.Double(-10, 15, -15, 18, -20, 25, -15, 30), false);
        leftPelvicFin.append(new CubicCurve2D.Double(-15, 30,  -10, 25, -10,  25,  -5, 28), true);

        GeneralPath rightPectoralFin = new GeneralPath();
        rightPectoralFin.append(new CubicCurve2D.Double(15, -15, 30, -10, 40, 0, 40, 20), false);
        rightPectoralFin.append(new CubicCurve2D.Double(40,  20, 30,  10, 20, 8, 10, 10), true);

        GeneralPath rightPelvicFin = new GeneralPath();
        rightPelvicFin.append(new CubicCurve2D.Double(10, 15, 15, 18, 20, 25, 15, 30), false);
        rightPelvicFin.append(new CubicCurve2D.Double(15, 30, 10, 25, 10, 25,  5, 28), true);

        GeneralPath caudalFin = new GeneralPath();
        caudalFin.append(new CubicCurve2D.Double(10, 50, 15, 20, -15, 20, -10, 50), false);
        caudalFin.append(new CubicCurve2D.Double(-10, 50, -15, 30, 15, 30, 10, 50), false);

        Area shark = new Area(body);
    	shark.add(new Area(leftPectoralFin));
        if ((ID & 1) == 0)
        	shark.add(new Area(leftPelvicFin));
        shark.add(new Area(rightPectoralFin));
        if ((ID & 2) == 0)
        	shark.add(new Area(rightPelvicFin));
        
        return shark;
    }
    
    
    ////////////////////////////////////////////////////////////////////////
    
    public int getClickX(){
    	return m_clickX;
    }
    public int getClickY(){
    	return m_clickY;
    } 
    
    public float getFClickX(){
    	return m_FclickX;
    }
    public float getFClickY(){
    	return m_FclickY;
    }
}

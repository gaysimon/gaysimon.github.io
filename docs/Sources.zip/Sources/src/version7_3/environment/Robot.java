package version7_3.environment;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * robot interface
 * @author simon gay
 */
public class Robot {

	private File file = new File("/dev/ttyUSB0" );
	
	private FileInputStream fis;
	private BufferedInputStream bis;
	private DataInputStream dis;
	
	private FileOutputStream fos; 
	private DataOutputStream dos;
	
	public Byte[] data;
	
	//////////////////////////////////////////////////////////////////////
	// sensors
	public int result;

	//--------------------------------------------------------------------
	
	public Robot(){
		
		// connect camera
		try{
			fis = new FileInputStream(file);
			bis = new BufferedInputStream(fis);
			dis = new DataInputStream(bis);
		
			fos= new FileOutputStream(file); 
			dos= new DataOutputStream(fos);
		}
		catch(Exception ie){ }
	}
	
	
	// robot command
	public void move(int msg){
		
		// send action
		try{
			// packet head
			dos.write((byte)0x55);
			dos.write((byte)0xff);
			dos.write((byte)0x00);
			
			dos.write((byte)0xf7);
			dos.write((byte)0x08);
	
			// send message
			dos.write((byte) msg);
			dos.write((byte)~msg);
			
			// sum
			dos.write((byte) (0xf7+msg));
			dos.write((byte)~(0xf7+msg));
		}
		catch (IOException e) {e.printStackTrace();}
		
		
		// get the response from the robot
		byte data;

		try{
			int nbfail=0;
			while (this.dis.available() <18 ){
				try{Thread.currentThread();
					Thread.sleep(10);}
				catch(Exception ie){ }

				nbfail++;
			}
			int i=0;
			while (this.dis.available() != 0){
				data= dis.readByte();
				if (i==14){
					System.out.println("+++ "+data);
					result=data;
				}
				i++;
			}
		}
		catch (IOException e) {{
			e.printStackTrace();}
		}
	}
}

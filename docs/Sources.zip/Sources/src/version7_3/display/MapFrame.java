package version7_3.display;

import version7_3.platform.Agent;

public class MapFrame extends EnvFrame{

	private static final long serialVersionUID = 1L;

	public MapFrame(Agent a){
		super(a);
		this.setTitle("Map");
    	this.setSize(1200, 500);
    	this.setLocationRelativeTo(null);               
    	this.setVisible(true);
    	this.setFocusable(true);
    	panel=new MapPanel(a);
    	this.setContentPane(panel);
	}
}

package version7_3.display;

import version7_3.platform.Agent;

/**
 * Display the visual system of the robot
 * @author simon
 */
/* - inherited from EnvFrame :
 *   Agent agent      : pointer to the agent
 *   EnvPanel panel   : panel of this frame
 *   
 * - inherited from PrintableFrame :
 *   boolean printable   : define if the frame can be printed
 *   int indexImage      : counter for image name
 */
public class CamFrame extends EnvFrame{

	private static final long serialVersionUID = 1L;

	public CamFrame(Agent a){
		super(a);
		this.setTitle("Webcam");
    	this.setSize(1300, 650);
    	this.setLocationRelativeTo(null);               
    	this.setVisible(true);
    	this.setFocusable(true);
    	panel=new CamPanel(a);
    	this.setContentPane(panel);
	}
}

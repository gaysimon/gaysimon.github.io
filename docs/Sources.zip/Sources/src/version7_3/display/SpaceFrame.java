package version7_3.display;

import version7_3.platform.Agent;

/**
 * Display the space memory
 * @author simon gay
 */

/* - inherited from EnvFrame :
 *   Agent agent      : pointer to the agent
 *   EnvPanel panel   : panel of this frame
 *   
 * - inherited from PrintableFrame :
 *   boolean printable   : define if the frame can be printed
 *   int indexImage      : counter for image name
 */
public class SpaceFrame extends EnvFrame{

	private static final long serialVersionUID = 1L;

	public SpaceFrame(Agent a){
		super(a);
		this.setTitle("SpaceMemory");
    	this.setSize(1200, 900);
    	this.setLocationRelativeTo(null);               
    	this.setVisible(true);
    	this.setFocusable(true);
    	panel=new SpacePanel(a);
    	this.setContentPane(panel);
	}
}


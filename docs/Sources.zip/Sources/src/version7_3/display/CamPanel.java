package version7_3.display;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import version7_3.platform.Agent;

/**
 * Display the visual system of the robot
 * @author simon
 */
public class CamPanel extends EnvPanel implements MouseListener,MouseMotionListener{

	private static final long serialVersionUID = 1L;
	
	private int x=0,y=0;
	
	public CamPanel(Agent a){
		super(a);
		addMouseListener(this);
		addMouseMotionListener(this);
	}

	
	public void paintComponent(Graphics g){
		g.setColor(Color.white);
		
		g.fillRect(0, 0, 1300, 650);
		
		
		for (int i=1;i<640;i++){
			for (int j=1;j<480;j++){
				
				int red  =agent.webcam.image[i][j][0];
				int green=agent.webcam.image[i][j][1];
				int blue =agent.webcam.image[i][j][2];

				g.setColor(new Color(red,green,blue));
				g.fillRect(i, j, 5, 5);
			}
		}
		
		int red=agent.webcam.image[x][y][0];
		g.setColor(Color.red);
		g.fillRect(30, 510, 20+red*2, 20);
		
		int green=agent.webcam.image[x][y][1];
		g.setColor(Color.green);
		g.fillRect(30, 540, 20+green*2, 20);
		
		int blue=agent.webcam.image[x][y][2];
		g.setColor(Color.blue);
		g.fillRect(30, 570, 20+blue*2, 20);
		
		g.setColor(Color.black);
		//g.drawString(""+red  , 5, 525);
		//g.drawString(""+green, 5, 555);
		g.drawString(""+blue , 5, 585);
		
		g.setColor(Color.red);
		//g.drawLine(660, 10, 660,160);
		//g.drawLine(660,180, 660,330);
		g.fillRect(660, 520, 20, 20);
		
		g.setColor(Color.green);
		//g.drawLine(660, 160, 810, 160);
		//g.drawLine(660, 350, 660, 500);
		g.fillRect(700, 520, 20, 20);
		
		g.setColor(Color.blue);
		//g.drawLine(660, 330, 810, 330);
		//g.drawLine(660, 500, 810, 500);
		g.fillRect(740, 520, 20, 20);
		
		g.setColor(Color.black);
		g.drawRect(780, 520, 20, 20);
		g.fillRect(820, 520, 20, 20);
		/**/
		// draw selected points
		/*g.setColor(Color.red);
		for (int i=0;i<colors.red.size();i++){
			g.fillOval(660 + colors.red.get(i).getGreen()/2-1, 160-colors.red.get(i).getRed()/2+1, 3, 3);
			g.fillOval(660 + colors.red.get(i).getBlue()/2 -1, 330-colors.red.get(i).getRed()/2+1, 3, 3);
			g.fillOval(660 + colors.red.get(i).getGreen()/2-1, 500-colors.red.get(i).getBlue()/2+1, 3, 3);
		}
		
		g.setColor(Color.green);
		for (int i=0;i<colors.green.size();i++){
			g.fillOval(660 + colors.green.get(i).getGreen()/2-1, 160-colors.green.get(i).getRed()/2+1, 3, 3);
			g.fillOval(660 + colors.green.get(i).getBlue()/2 -1, 330-colors.green.get(i).getRed()/2+1, 3, 3);
			g.fillOval(660 + colors.green.get(i).getGreen()/2-1, 500-colors.green.get(i).getBlue()/2+1, 3, 3);
		}
		
		g.setColor(Color.blue);
		for (int i=0;i<colors.blue.size();i++){
			g.fillOval(660 + colors.blue.get(i).getGreen()/2-1, 160-colors.blue.get(i).getRed()/2+1, 3, 3);
			g.fillOval(660 + colors.blue.get(i).getBlue()/2 -1, 330-colors.blue.get(i).getRed()/2+1, 3, 3);
			g.fillOval(660 + colors.blue.get(i).getGreen()/2-1, 500-colors.blue.get(i).getBlue()/2+1, 3, 3);
		}
		
		g.setColor(Color.black);
		for (int i=0;i<colors.white.size();i++){
			g.fillOval(660 + colors.white.get(i).getGreen()/2-1, 160-colors.white.get(i).getRed()/2+1, 3, 3);
			g.fillOval(660 + colors.white.get(i).getBlue()/2 -1, 330-colors.white.get(i).getRed()/2+1, 3, 3);
			g.fillOval(660 + colors.white.get(i).getGreen()/2-1, 500-colors.white.get(i).getBlue()/2+1, 3, 3);
		}/**/
		
		
		for (int i=1;i<640;i++){
			for (int j=1;j<480;j++){
				g.setColor(Color.black);
				if (agent.colors.colorMap[i][j]==0) g.setColor(Color.red);
				else if (agent.colors.colorMap[i][j]==1) g.setColor(Color.green);
				else if (agent.colors.colorMap[i][j]==2) g.setColor(Color.blue);
				else if (agent.colors.colorMap[i][j]==3) g.setColor(Color.white);

				g.fillRect(650+i, j, 5, 5);
			}
		}/**/
		
		/*for (int i=0;i<15;i++){
			for (int j=0;j<15;j++){
				if (calibration.x==i && calibration.y==j) g.setColor(Color.red);
				else{
					if (calibration.calibration[i][j][0]!=-1) g.setColor(Color.green);
					else g.setColor(Color.blue);
				}
				g.fillOval(700+i*20, 400-j*20, 10, 10);
			}
		}*/
		
		/*g.setColor(Color.green);
		for (int i=0;i<15;i++){
			for (int j=0;j<15;j++){
				if (calibration.calibration[i][j][0]!=-1){
					g.fillOval(320+(int)calibration.calibration[i][j][0]-4, 480-(int)calibration.calibration[i][j][1]-4, 5, 5);
					if (i!=0) g.fillOval(320-(int)calibration.calibration[i][j][0]+4, 480-(int)calibration.calibration[i][j][1]-4, 5, 5);
				}
			}
		}
		for (int i=0;i<14;i++){
			for (int j=0;j<14;j++){
				if (calibration.calibration[i][j][0]!=-1 && calibration.calibration[i+1][j][0]!=-1){
					g.drawLine(320+(int)calibration.calibration[i  ][j][0], 480-(int)calibration.calibration[i  ][j][1],
							   320+(int)calibration.calibration[i+1][j][0], 480-(int)calibration.calibration[i+1][j][1]);
				}
				if (calibration.calibration[i][j][0]!=-1 && calibration.calibration[i][j+1][0]!=-1){
					g.drawLine(320+(int)calibration.calibration[i][j  ][0]-2, 480-(int)calibration.calibration[i][j  ][1]+2,
							   320+(int)calibration.calibration[i][j+1][0]-2, 480-(int)calibration.calibration[i][j+1][1]+2);
				}
			}
		}/**/
	}

	public void mouseDragged(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		if (e.getY()<480 && e.getX()<640){
			x=e.getX();
			y=e.getY();
		}
	}

	public void mouseClicked(MouseEvent e) {
		if (e.getY()<480 && e.getX()<640){
			agent.colors.addColor(new Color(agent.webcam.image[e.getX()][e.getY()][0],
					                               agent.webcam.image[e.getX()][e.getY()][1],
					                               agent.webcam.image[e.getX()][e.getY()][2]));
		}
		
		if (e.getX()>660 && e.getX()<680 && e.getY()>520 && e.getY()<540) agent.colors.setColor(1);
		if (e.getX()>700 && e.getX()<720 && e.getY()>520 && e.getY()<540) agent.colors.setColor(2);
		if (e.getX()>740 && e.getX()<760 && e.getY()>520 && e.getY()<540) agent.colors.setColor(3);
		if (e.getX()>780 && e.getX()<800 && e.getY()>520 && e.getY()<540) agent.colors.setColor(4);
		
		if (e.getX()>820 && e.getX()<840 && e.getY()>520 && e.getY()<540) agent.colors.removeLast();
		/**/
		
		System.out.println(e.getX()+" ; "+e.getY());
		
		agent.colors.getColorMap();
	}


	@Override
	public void mouseEntered(MouseEvent arg0){}
	public void mouseExited(MouseEvent arg0){}
	public void mousePressed(MouseEvent arg0){}
	public void mouseReleased(MouseEvent arg0){}
}

package version7_3.display;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import version7_3.Interface.InteractionList;
import version7_3.platform.Agent;

public class MapPanel extends EnvPanel implements MouseListener,MouseMotionListener{

	private static final long serialVersionUID = 1L;
	
	int x=0,y=0;
	
	public MapPanel(Agent a){
		super(a);
		addMouseListener(this);
		addMouseMotionListener(this);
	}

	
	public void paintComponent(Graphics g){
		g.setColor(Color.white);
		
		g.fillRect(0, 0, 1200, 500);
		
		
		for (int i=1;i<640;i++){
			for (int j=1;j<480;j++){
				
				//int red  =agent.webcam.image[i][j][0];
				//int green=agent.webcam.image[i][j][1];
				//int blue =agent.webcam.image[i][j][2];

				//if (i==320) g.setColor(Color.green);
				//else g.setColor(new Color(red,green,blue));
				
				g.setColor(Color.black);
				if (agent.colors.colorMap2[i][j]==0) g.setColor(Color.red);
				else if (agent.colors.colorMap2[i][j]==1) g.setColor(Color.green);
				else if (agent.colors.colorMap2[i][j]==2) g.setColor(Color.blue);
				else if (agent.colors.colorMap2[i][j]==3) g.setColor(Color.white);
				
				g.fillRect(i, j, 5, 5);
			}
		}
		
		

	
		g.setColor(Color.LIGHT_GRAY);
		for (int i=0;i<InteractionList.size1;i++){
			for (int j=0;j<InteractionList.size2;j++){
				if (agent.calibration.calibration2[i][j][0]!=-1){
					g.fillOval((int)agent.calibration.calibration2[i][j][0]-1, (int)agent.calibration.calibration2[i][j][1]-1, 1, 1);
				}
			}
		}
		
		
		
		for (int i=0;i<InteractionList.size1;i++){
			for (int j=0;j<InteractionList.size2;j++){
				
				g.setColor(Color.black);
				if (agent.calibration.map[i][j]==0) g.setColor(Color.red);
				else if (agent.calibration.map[i][j]==1) g.setColor(Color.green);
				else if (agent.calibration.map[i][j]==2) g.setColor(Color.blue);
				else if (agent.calibration.map[i][j]==3) g.setColor(Color.white);

				g.fillRect(650+5*i, 300-5*j, 5, 5);
			}
		}
		
	}

	public void mouseMoved(MouseEvent e) {
		if (e.getY()<480 && e.getX()<640){
			x=e.getX();
			y=e.getY();
		}
	}


	@Override
	public void mouseDragged(MouseEvent arg0){}
	public void mouseClicked(MouseEvent e){}
	public void mouseEntered(MouseEvent arg0){}
	public void mouseExited(MouseEvent arg0){}
	public void mousePressed(MouseEvent arg0){}
	public void mouseReleased(MouseEvent arg0){}
}

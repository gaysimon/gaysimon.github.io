package version7_3.Interface;

import version7_3.platform.Agent;

/**
 * This class controls the main simulation loop of the agent :
 * it gets the decision of the agent, enact the interaction through the body
 * and update decision modules once cycle is completed.
 * @author simon gay
 */
public class Action {

	private boolean acting;    			// is the agent acting
	private PrimitiveInteraction lastAct;	// last action signal
	private PrimitiveInteraction enacted;	// last enacted interaction
	private Agent agent;
	
	private int state;         			// 0=stop or step mode, 1=run
	private boolean step;					// move one step
	
	private int stepNb;					// number of completed decision cycle
	private int subStep=0;					// substep counter
	
	public Action(Agent a){
		acting=false;
		lastAct=null;
		enacted=null;
		
		agent=a;
		state=0;
		step=false;
		
		stepNb=0;
	}
	
	public void act(){
		
		// if action interrupted, select new action
		if (!acting && (state==1 || step)){
			
			System.out.println("==================== step #"+stepNb+" =========================================================");
			lastAct=agent.decision.decision();

			acting=true;
			
			// simulation of the robot consists in one sub step
			subStep=1;
		}
		
		///////////////////////////////////////////////////
		// end of a decision cycle
		if (subStep==0){
			
			if (acting || step){

				agent.sensors.update();
				
				enacted=agent.sensors.recognize(lastAct);

				//%%%%%%%%%%%%% specific to robot %%%%%%%%%%%%%
				agent.webcam.setImage();
				agent.colors.getColorMap();
				agent.calibration.getMap();
				//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

				// update decision system
				agent.observer.updateObserver(enacted);
				agent.decision.check(enacted);
				agent.spaceMemory.updateMemory(enacted, agent.sensors.recognizeEnactedEnsemble(enacted));

				stepNb++;
			}
			
			acting=false;
			step=false;
			
			if (state==0){
				try{Thread.currentThread();
					Thread.sleep(100);}
				catch(Exception ie){}
			}
			
		}
		else{
			// define the command to be sent to the body
			if (lastAct.getAction().getName().equals(">")) agent.body.move(42);
			if (lastAct.getAction().getName().equals("^")) agent.body.move(200);
			if (lastAct.getAction().getName().equals("v")) agent.body.move(164);
			if (lastAct.getAction().getName().equals("\\"))agent.body.move(64);
			if (lastAct.getAction().getName().equals("/")) agent.body.move(128);
				
			try{
				Thread.currentThread();
				Thread.sleep(100);
			}
			catch(Exception ie){
			}

			agent.sensors.update();
			subStep--;
		}
	}
	
	/////////////////////////////////////////////
	// start, stop and allow one decision cycle
	public void start(){
		state=1;
	}
	public void stop(){
		state=0;
	}
	public void step(){
		step=true;
	}
	
	/////////////////////////////////////////////
	
	public int getNbStep(){
		return stepNb;
	}
	
	public void setNbstep(int i){
		stepNb=i;
	}
	
	public int getState(){
		return state;
	}

	public boolean isStopped(){
		return state==0 && subStep==0 && !step;
	}
	
}

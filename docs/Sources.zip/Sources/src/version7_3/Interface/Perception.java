package version7_3.Interface;

import version7_3.platform.Agent;

/**
 * convert signals from the robot into interactions
 * @author simon
 */
public class Perception {

	private Agent agent;

	private int size=3;       						// nb of status
	private boolean[] status;
	
	public Perception(Agent a){
		agent=a;
		
		// "physical" robot input
		status=new boolean[size];
		for (int i=0;i<size;i++){
			status[i]=false;
		}
	}

	
	public void update(){
		
		// get the input vector
		for (int i=0;i<size;i++) status[i]=false;
		if (agent.body.result==1) status[0]=true;
		if (agent.body.result==2) status[1]=true;
		if (agent.body.result==3) status[2]=true;
	}
	
	
	// interpretation of enacted interaction according to action and inputs
	public PrimitiveInteraction recognize(PrimitiveInteraction intended){
		
		if (intended.getAction().getName().equals(">")){
			if (status[2]) 		return agent.interactionList.getInteraction(2);
			else if (status[1]) return agent.interactionList.getInteraction(1);
			else 				return agent.interactionList.getInteraction(0);
		}
		else{
			return intended;
		}
	}
	
	public float[] recognizeEnactedEnsemble(PrimitiveInteraction enacted){

		float[] enactedEnsemble=new float[InteractionList.length];
		
		// initialize enacted ensemble
		for (int i=0;i<InteractionList.length;i++){
			enactedEnsemble[i]=0;
		}
		
		// set primary interaction
		enactedEnsemble[enacted.getIndex()+InteractionList.nbDF]=1;
		
		// set secondary interactions
		for (int i=0;i<InteractionList.size1;i++){
			for (int j=0;j<InteractionList.size2;j++){
				if (agent.calibration.map[i][j]!=-1 && agent.calibration.map[i][j]!=3){
					enactedEnsemble[i*InteractionList.size2*3 + j*3 +agent.calibration.map[i][j]]=1;
				}
					
			}
		}
		
		// bias input
		enactedEnsemble[InteractionList.length-1]=1;
		
		return enactedEnsemble;
	}
	
}

package version7_3.spaceMemory;

import version7_3.Interface.InteractionList;

/**
 * Algorithmic simplification for object instance detection
 * @author simon
 */
public class BlurPattern {

	public float[][][] pattern;
	private int counter=0;
	
	private static int cycle=50;
	
	public BlurPattern(){
		pattern=new float[InteractionList.size1][InteractionList.size2*2][3];
		for (int i=0;i<InteractionList.size1;i++){
			for (int j=0;j<InteractionList.size2*2;j++){
				for (int k=0;k<3;k++){
					pattern[i][j][k]=0;
				}
			}
		}
	}
	
	
	public void generateBlur(Signature s){
		if (counter==0) blur(s);
		counter++;
		if (counter==cycle) counter=0;
	}
	
	private void blur(Signature s){
		
		// reset blur pattern
		for (int i=0;i<InteractionList.size1;i++){
			for (int j=0;j<InteractionList.size2*2;j++){
				for (int k=0;k<3;k++){
					pattern[i][j][k]=0;
				}
			}
		}
		
		for (int i=0;i<InteractionList.size1;i++){
			for (int j=0;j<InteractionList.size2;j++){
				for (int k=0;k<3;k++){
					
					if (Math.abs(s.pattern[i*InteractionList.size2*3 + j*3 + k])>s.maxPattern1*0.5){

						// set blur pattern
						for (int i2=-100;i2<=100;i2++){
							for (int j2=-100;j2<=100;j2++){
								if (i+i2>=0 && i+i2<InteractionList.size1 && j+j2+InteractionList.size2>=0 && j+j2+InteractionList.size2<InteractionList.size2*2){
									
									float d=(float) Math.sqrt(i2*i2+j2*j2);
									
									if (d<100){
										pattern[i+i2][j+j2+InteractionList.size2][k]+= s.pattern[i*InteractionList.size2*3 + j*3 + k] * Math.exp(-SpaceMemory.objectCoef*d);
									}
								}
							}
						}
					}
				}
			}
		}
	}	
	
}

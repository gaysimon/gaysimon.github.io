package version7_3.spaceMemory;

import version7_3.Interface.PrimitiveInteraction;
import version7_3.platform.Agent;

/**
 * Decision system.
 * This class selects the next intended interactions
 * @author simon
 */
public class Decision {

	private Agent agent;
	
	private Composite lastSequence=null;
	private PrimitiveInteraction intention=null;

	private int sequenceIndex=-1;
	private boolean learning=true;  // allow learning
	private int decisionType=0;
	
	public static float incertitude=0.2f;
	
	///////////////////////////////////////////////////////////
	public Decision(Agent a){
		agent=a;
	}
	
	/**
	 * decision of the next action
	 * @return the intended interaction
	 */
	public PrimitiveInteraction decision(){
		
		System.out.println();System.out.println();

		sequenceIndex--;
		
		if (sequenceIndex<0){
		
			int imax=-1;
			int imin=-1;
			float max=-1000;
			float min=0;

			
			for (int i=0;i<agent.spaceMemory.nbInteraction();i++){
				
				if (isPathPossible(agent.spaceMemory.getInteraction(i))){
					
					// get the interaction with the greatest valence
					if (agent.spaceMemory.getInteraction(i).getPrediction()>=0
					 &&(agent.spaceMemory.getInteraction(i).getValence()+agent.spaceMemory.getAdditional(i) *SpaceMemory.memoryCoef>max)){
						imax=i;
						max=agent.spaceMemory.getInteraction(i).getValence()+agent.spaceMemory.getAdditional(i) *SpaceMemory.memoryCoef;
					}
					
					// get the interaction with the lower certitude (in absolute value)
					if (Math.abs(1-Math.abs(agent.spaceMemory.getInteraction(i).getPrediction()))>min){
						imin=i;
						min=Math.abs(1-Math.abs(agent.spaceMemory.getInteraction(i).getPrediction()));
					}
				}
			}
			
			if (min<incertitude || !learning){
				lastSequence=agent.spaceMemory.getInteraction(imax);
				decisionType=1;
			}
			else{
				lastSequence=agent.spaceMemory.getInteraction(imin);
				decisionType=2;
			}
			sequenceIndex=lastSequence.size()-1;
			System.out.println("+++++ select sequence "+lastSequence.getName(0));
		}
		
		intention=lastSequence.sequence[sequenceIndex];
		System.out.println("select interaction "+intention.getName()+" element of "+lastSequence.getName(0));
		
		return intention;
	}
	
	
	public void check(PrimitiveInteraction enacted){
		if (!intention.isEqual(enacted)){
			sequenceIndex=-1;
		}
	}
	
	private boolean isPathPossible(Composite inter){
		if (inter.size()==1) return true;
		else{
			boolean ret=true;
			for (int i=0;i<agent.spaceMemory.nbInteraction();i++){
				if (inter.isPath(agent.spaceMemory.getInteraction(i))){
					if (agent.spaceMemory.getInteraction(i).getPrediction()<0.8) ret=false;
				}
			}
			return ret;
		}
	}
	
	public int getDecisionType(){
		return decisionType;
	}
	
	public boolean learning(){
		return learning;
	}
	
	public void setLearning(){
		learning= !learning;
	}
	
	public PrimitiveInteraction getIntention(){
		return intention;
	}
}

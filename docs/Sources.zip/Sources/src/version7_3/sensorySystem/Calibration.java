package version7_3.sensorySystem;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import version7_3.Interface.InteractionList;
import version7_3.platform.Agent;
import version7_3.platform.Observer;

public class Calibration {

	private Agent agent;
	
	public float[][][] calibration; 									// matrix of saved points
	public float[][][] calibration2;									// matrix of calibration
	private int x=0;
	private int y=0;
	
	public static boolean load=true;									// if true, load a calibration file
	
	//public int[][][] render;
	public int[][] map;
	
	
	public Calibration(Agent a){
		
		agent=a;
		
		calibration=new float[15][15][2];
		calibration2=new float[InteractionList.size1][InteractionList.size2][2];
		
		if (load) load();
		else{
			for (int i=0;i<15;i++){
				for (int j=0;j<15;j++){
					calibration[i][j][0]=-1;
					calibration[i][j][1]=-1;
				}
			}
		}
		
		//render=new int[26][15][4];
		map=new int[InteractionList.size1][InteractionList.size2];
		
		/*for (int i=0;i<26;i++){
			for (int j=0;j<15;j++){
				for (int k=0;k<4;k++){
					render[i][j][k]=0;
				}
			}
		}*/
		for (int i=0;i<InteractionList.size1;i++){
			for (int j=0;j<InteractionList.size2;j++){
				map[i][j]=-1;
			}
		}
	}
	
	public void setPoint(int i,int j){
		x=i;
		y=j;
	}
	
	public void setPosition(float i,float j){
		calibration[x][y][0]=i;
		calibration[x][y][1]=j;
		
		save();
	}
	
	public void getMap(){
		for (int i=0;i<InteractionList.size1;i++){
			for (int j=0;j<InteractionList.size2;j++){
				if (calibration2[i][j][0]!=-1)
					map[i][j]=agent.colors.colorMap2[(int)calibration2[i][j][0]][(int)calibration2[i][j][1]];
				else
					map[i][j]=-1;
			}
		}
	}
	
	private void save() {
		System.out.println("=====================prepare to save...======================");
		
		// save second level patterns
		
		String fileName = Observer.path+"spaceMemory/calibration.txt";
		
		try {
			PrintWriter file  = new PrintWriter(new FileWriter(fileName));
			
			for (int j=0;j<15;j++){
				for (int i=0;i<15;i++){
					file.print(calibration[i][j][0]+" "+calibration[i][j][1]+" ");
				}
				file.println();
			}
			file.close();
			System.out.println("memory file saved");
		}
		catch (Exception e) {e.printStackTrace();}
	}
	
	
	
	public void load(){
		String fileName = Observer.path+"spaceMemory/calibration.txt";
		String[] elements;
		
		try {
			InputStream ips=new FileInputStream(fileName); 
			InputStreamReader ipsr=new InputStreamReader(ips);
			BufferedReader br=new BufferedReader(ipsr);
			String line;

			int j=0;
			while ((line=br.readLine())!=null){
				elements=line.split(" ");
				for (int i=0;i<15;i++){
					calibration[i][j][0]=Float.parseFloat(elements[i*2]);
					calibration[i][j][1]=Float.parseFloat(elements[i*2+1]);
				}
				j++;
			}
		} 
		catch (Exception e) {
			System.out.println("no file found");
		}
		
		// place read points on the calibration matrix
		for (int i=0;i<13;i++){
			for (int j=0;j<15;j++){
				calibration2[12*4+i*4][j*4][0]=320+calibration[i][j][0];
				calibration2[12*4+i*4][j*4][1]=480-calibration[i][j][1];
				
				calibration2[12*4-i*4][j*4][0]=320-calibration[i][j][0];
				calibration2[12*4-i*4][j*4][1]=480-calibration[i][j][1];
			}
		}
		
		
		// interpolate points
		for (int i=2;i<InteractionList.size1-2;i+=4){
			for (int j=0;j<InteractionList.size2;j+=4){
				
				calibration2[i-1][j][0]= (3*calibration2[i-2][j][0] + calibration2[i+2][j][0])/4;
				calibration2[i-1][j][1]= (3*calibration2[i-2][j][1] + calibration2[i+2][j][1])/4;
				
				calibration2[i][j][0]= (calibration2[i-2][j][0] + calibration2[i+2][j][0])/2;
				calibration2[i][j][1]= (calibration2[i-2][j][1] + calibration2[i+2][j][1])/2;
				
				calibration2[i+1][j][0]= (calibration2[i-2][j][0] + 3*calibration2[i+2][j][0])/4;
				calibration2[i+1][j][1]= (calibration2[i-2][j][1] + 3*calibration2[i+2][j][1])/4;
			}
		}
		for (int i=0;i<InteractionList.size1;i++){
			for (int j=2;j<InteractionList.size2-2;j+=4){
				
				calibration2[i][j-1][0]= (3*calibration2[i][j-2][0] + calibration2[i][j+2][0])/4;
				calibration2[i][j-1][1]= (3*calibration2[i][j-2][1] + calibration2[i][j+2][1])/4;
				
				calibration2[i][j][0]= (calibration2[i][j-2][0] + calibration2[i][j+2][0])/2;
				calibration2[i][j][1]= (calibration2[i][j-2][1] + calibration2[i][j+2][1])/2;
				
				calibration2[i][j+1][0]= (calibration2[i][j-2][0] + 3*calibration2[i][j+2][0])/4;
				calibration2[i][j+1][1]= (calibration2[i][j-2][1] + 3*calibration2[i][j+2][1])/4;
			}
		}
	}
	
}
package version7_3.sensorySystem;

import java.awt.image.BufferedImage;

import au.edu.jcu.v4l4j.CaptureCallback;
import au.edu.jcu.v4l4j.FrameGrabber;
import au.edu.jcu.v4l4j.V4L4JConstants;
import au.edu.jcu.v4l4j.VideoDevice;
import au.edu.jcu.v4l4j.VideoFrame;
import au.edu.jcu.v4l4j.exceptions.StateException;
import au.edu.jcu.v4l4j.exceptions.V4L4JException;

public class Webcam implements CaptureCallback {
	 
	private static int width = 640, height = 480, std = V4L4JConstants.STANDARD_WEBCAM, channel = 0;
	private static String device = "/dev/video0"; //getting device this is the path of device
	
	private VideoDevice videoDevice;
	private FrameGrabber frameGrabber;
	public BufferedImage bf;
	
	public boolean connected=false;

	public int[][][] image;
 
 
	public Webcam() {
 
		image=new int[width][height][3];
		for (int i=0;i<width;i++){
			for (int j=0;j<height;j++){
				image[i][j][0]=0;
				image[i][j][1]=0;
				image[i][j][2]=0;
			}
		}
		startCapture();
	}
 
	// capture an image from the camera
	public void setImage(){
		for (int i=1;i<width-1;i++){
			for (int j=1;j<height-1;j++){
				image[width-i][j][0]=((bf.getRGB(i  ,j  ) & 0x00ff0000)>>16)
				              +((bf.getRGB(i-1,j  ) & 0x00ff0000)>>16)
				              +((bf.getRGB(i+1,j  ) & 0x00ff0000)>>16)
				              +((bf.getRGB(i  ,j-1) & 0x00ff0000)>>16)
				              +((bf.getRGB(i  ,j+1) & 0x00ff0000)>>16);
				image[width-i][j][0]=image[width-i][j][0]/5;
				
				image[width-i][j][1]=((bf.getRGB(i  ,j  ) & 0x0000ff00)>> 8)
							  +((bf.getRGB(i-1,j  ) & 0x0000ff00)>> 8)
							  +((bf.getRGB(i+1,j  ) & 0x0000ff00)>> 8)
							  +((bf.getRGB(i  ,j-1) & 0x0000ff00)>> 8)
							  +((bf.getRGB(i  ,j+1) & 0x0000ff00)>> 8);
				image[width-i][j][1]=image[width-i][j][1]/5;
				
				image[width-i][j][2]=((bf.getRGB(i  ,j  ) & 0x000000ff))
				 			  +((bf.getRGB(i-1,j  ) & 0x000000ff))
				 			  +((bf.getRGB(i+1,j  ) & 0x000000ff))
				 			  +((bf.getRGB(i  ,j-1) & 0x000000ff))
				 			  +((bf.getRGB(i  ,j+1) & 0x000000ff));
				image[width-i][j][2]=image[width-i][j][2]/5;
			}
		}
	}
	
	
	private void initFrameGrabber() throws V4L4JException {   // Setting Framegrabber
		videoDevice = new VideoDevice(device); // getting the webcam
		frameGrabber = videoDevice.getJPEGFrameGrabber(width, height, channel, std, 80);
		frameGrabber.setCaptureCallback(this);
		width = frameGrabber.getWidth();
		height = frameGrabber.getHeight();
	}
 
	// connect the camera
	public void startCapture(){
		
		if (!connected){
			try {
				initFrameGrabber();     // creating frame grabber
			} catch (V4L4JException e1) {
				System.err.println("Error setting up capture");
				e1.printStackTrace();
	
				cleanupCapture();
				return;
			}
			
			try {
				frameGrabber.startCapture();   // Starting cam
				connected=true;
			} catch (V4L4JException e) {
				System.err.println("Error starting the capture");
				e.printStackTrace();
			}
		}
	}
 
	// this method is use for turn off cam and release framegrabber and device
	public void cleanupCapture() {
		try {
			frameGrabber.stopCapture();
		} catch (StateException ex) {}
 
		videoDevice.releaseFrameGrabber();
		videoDevice.release();

		connected=false;
	}
 
	public void exceptionReceived(V4L4JException e) {
		e.printStackTrace();
	}
 

	public void nextFrame(VideoFrame frame) {
		try{
			bf=frame.getBufferedImage();
			frame.recycle();
		}
		catch (Exception ex) {
			System.out.println("error capture");
		}
	}

}

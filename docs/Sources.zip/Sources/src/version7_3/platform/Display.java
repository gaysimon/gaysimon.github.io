package version7_3.platform;

import java.util.ArrayList;

import version7_3.display.EnvFrame;

/**
 * A list of panel that display data about an agent
 * @author simon gay
 *
 */
public class Display {

	private ArrayList<EnvFrame> frameList;			// list of displayer
	
	public Display(){
		frameList=new ArrayList<EnvFrame>();
	}
	
	// repaint each frame
	public void repaint(){
		for (int i=0;i<frameList.size();i++){
			frameList.get(i).repaint();
		}
	}
	
	// save panels as jpeg images
	public void saveImage(String path){
		for (int i=0;i<frameList.size();i++){
			if (frameList.get(i).export()) frameList.get(i).saveImage(path+"/graph/", "graph"+i+"_");
		}
	}
	
	public int nbFrame(){
		return frameList.size();
	}
	
	public EnvFrame get(int i){
		return frameList.get(i);
	}
	
	public void addFrame(EnvFrame frame){
		frameList.add(frame);
	}
}

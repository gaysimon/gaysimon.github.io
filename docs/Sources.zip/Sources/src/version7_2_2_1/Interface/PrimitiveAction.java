package version7_2_2_1.Interface;

/**
 * Definition of a primitive action
 * @author simon
 */
public class PrimitiveAction{

	// define a primitive action
	private String name;
	private int id;
	
	public PrimitiveAction(String n, int i){
		name=n;
		id=i;
	}
	
	public boolean isEqual(PrimitiveAction a){
		return this.id==a.id;
	}
	
	public int getId(){
		return id;
	}
	
	public String getName(){
		return name;
	}
}

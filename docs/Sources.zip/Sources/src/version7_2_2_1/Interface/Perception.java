package version7_2_2_1.Interface;

import version7_2_2_1.environment.Environment;
import version7_2_2_1.platform.Agent;

/**
 * convert signals from the robot into interactions
 * @author simon
 */
public class Perception {

	private Agent agent;

	private int size=3;       						// nb of status
	private boolean[] status;
	
	public Perception(Agent a){
		agent=a;
		
		// "physical" robot input
		status=new boolean[size];
		for (int i=0;i<size;i++){
			status[i]=false;
		}
	}

	
	public void update(){
		
		//%%%%%%%%%%%%%%%% specific to render function %%%%%%%%%%%%%%%%%%%
		agent.probe.rendu();
		//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		
		// get the input vector
		for (int i=0;i<size;i++) status[i]=false;
		if (agent.body.sensors[0]==1) status[0]=true;
		if (agent.body.sensors[0]==2) status[1]=true;
		if (agent.body.sensors[5]==1) status[2]=true;
	}
	
	
	// interpretation of enacted interaction according to action and inputs
	public PrimitiveInteraction recognize(PrimitiveInteraction intended){
		
		if (intended.getAction().getName().equals(">")){
			if (status[2]) 		return agent.interactionList.getInteraction(2);
			else if (status[1]) return agent.interactionList.getInteraction(1);
			else 				return agent.interactionList.getInteraction(0);
		}
		else{
			return intended;
		}
	}
	
	public float[] recognizeEnactedEnsemble(PrimitiveInteraction enacted){

		float[] enactedEnsemble=new float[InteractionList.length];
		
		// initialize enacted ensemble
		for (int i=0;i<InteractionList.length;i++){
			enactedEnsemble[i]=0;
		}
		
		// set primary interaction
		enactedEnsemble[enacted.getIndex()+InteractionList.nbDF]=1;
		
		// set secondary interactions
		int inter=0; // used to define the enacted DFs
		if (enacted.getAction().getName().equals(">")){
			if (enacted.getPerception().getId()==2){
				inter=2;
			}
			else if (enacted.getPerception().getId()==0){
				inter=1;
			}
		}
		else{
			inter=enacted.getIndex();
		}

		if (inter>0){
			for (int i=0;i<agent.visual.color.length;i++){
				if (agent.visual.opticFlow[i]!=0 && agent.visual.opticFlow[i]<49){
					int col=0;
					if (agent.visual.color[i].equals(Environment.WALL1)) col=1;
					else if (agent.visual.color[i].equals(Environment.FISH1)) col=2;
					else if (agent.visual.color[i].equals(Environment.ALGA1)) col=3;
					
					if (col!=0){
	
						float theta=(float) Math.toRadians((i*5)-90);
						
						float x= (float) ( (agent.visual.opticFlow[i]/3)*Math.sin(theta))+(InteractionList.size1/2);
						float y= (float) ( (agent.visual.opticFlow[i]/3)*Math.cos(theta));
	
						if (x>=0 && x<InteractionList.size1 && y>=0 && y<InteractionList.size2){
							int n= ((int)x * InteractionList.size2*3 + (int)y*3 + (col-1)) + (inter-1)*InteractionList.size1*InteractionList.size2*3; 
							enactedEnsemble[n]=1f;
						}
					}
				}
			}
		}
		
		// bias input
		enactedEnsemble[InteractionList.length-1]=1;
		
		return enactedEnsemble;
	}
	
}

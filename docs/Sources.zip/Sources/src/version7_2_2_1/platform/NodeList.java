package version7_2_2_1.platform;

import java.util.ArrayList;

import version7_2_2_1.Interface.InteractionList;
import version7_2_2_1.platform.Agent;

public class NodeList {

	private Agent agent;
	
	private ArrayList<Node> nodeList;		// list of nodes
	
	private boolean mesh=false;			// true : display meshes correspondences. false : display interaction transformations
	
	public NodeList(Agent a){
		
		agent=a;
		nodeList=new ArrayList<Node>();
		
		
		int index=0;
		
		if (mesh){
			// if mesh display, the position of nodes is defined randomly (except for the first group of interactions)
			for (int i=0;i<InteractionList.size1;i++){
				for (int j=0;j<InteractionList.size2;j++){
					nodeList.add(new Node(index, 0, 2+ 3*i, 3 + 3*j));
					index++;
					nodeList.add(new Node(index, 1, 2+ 3*i, 3 + 3*j));
					index++;
					nodeList.add(new Node(index, 2, 2+ 3*i, 3 + 3*j));
					index++;
				}
			}
			for (int t=1;t<6;t++){
				for (int i=0;i<InteractionList.size1*InteractionList.size2;i++){
					for (int c=0;c<3;c++){
						nodeList.add(new Node(index,c));
						index++;
					}
				}
			}
		}
		else{
			// else, the position of nodes is defined to match the real position of nodes
			for (int t=0;t<6;t++){
				for (int i=0;i<InteractionList.size1;i++){
					for (int j=0;j<InteractionList.size2;j++){
						nodeList.add(new Node(index, 0, 2+ 3*i, 3 + 3*j));
						index++;
						nodeList.add(new Node(index, 1, 2+ 3*i, 3 + 3*j));
						index++;
						nodeList.add(new Node(index, 2, 2+ 3*i, 3 + 3*j));
						index++;
					}
				}
			}/**/
		}
		
		// nodes of primary interactions
		nodeList.add(new Node(index  ,-1));  // move forward
		nodeList.add(new Node(index+1,-1));  // bump		 
		nodeList.add(new Node(index+2,-1));  // eat
		nodeList.add(new Node(index+3,-1));  // turn left 90
		nodeList.add(new Node(index+4,-1));  // turn right 90
		nodeList.add(new Node(index+5,-1));  // turn left 45
		nodeList.add(new Node(index+6,-1));  // turn right 45
		nodeList.add(new Node(index+7,-1));  // bias input
	}
	
	
	public void moveNode(){

		if (mesh){
			// move nodes
			float d=0;
			for (int a=0;a<10;a++){
				for (int i=0;i<InteractionList.length-7;i++){
					
					// attraction force
					for (int n=0;n<InteractionList.size1*InteractionList.size2*3;n++){
						if (agent.signatureList.get(i).signature[n]>5){
							
							// gather nodes
							for (int k=InteractionList.size1*InteractionList.size2*3;k<InteractionList.length-7;k++){
								if (agent.signatureList.get(i).signature[k]>5){
									d=(float) Math.sqrt((get(n).x-get(k).x)*(get(n).x-get(k).x)
						                               +(get(n).y-get(k).y)*(get(n).y-get(k).y));
					
									if (d>0.01){
										get(k).x+= 0.01 * agent.signatureList.get(i).signature[k]* (get(n).x-get(k).x)/d;
										get(k).y+= 0.01 * agent.signatureList.get(i).signature[k]* (get(n).y-get(k).y)/d;
									}
								}
							}
						}
					}
		
				}
				
				agent.getMain().display.repaint();
			}
			
			
			for (int i=0;i<InteractionList.length;i++){
				if (nodeList.get(i).x<0  ) nodeList.get(i).x=0;
				if (nodeList.get(i).x>130) nodeList.get(i).x=130;
				if (nodeList.get(i).y<0  ) nodeList.get(i).y=0;
				if (nodeList.get(i).y>100) nodeList.get(i).y=100;
			}
		}
	}
	
	// reset node positions
	private void set(boolean m){

		int index=0;
		
		if (mesh){
			// if mesh display, the position of nodes is defined randomly (except for the first group of interactions)
			for (int i=0;i<InteractionList.size1;i++){
				for (int j=0;j<InteractionList.size2;j++){
					nodeList.get(index).setPosition(2+ 3*i, 3 + 3*j);
					index++;
					nodeList.get(index).setPosition(2+ 3*i, 3 + 3*j);
					index++;
					nodeList.get(index).setPosition(2+ 3*i, 3 + 3*j);
					index++;
				}
			}
			for (int t=1;t<6;t++){
				for (int i=0;i<InteractionList.size1*InteractionList.size2*3;i++){
					nodeList.get(index).setPosition();
					index++;
				}
			}
		}
		else{
			// else, the position of nodes is defined to match the real position of nodes
			for (int t=0;t<6;t++){
				for (int i=0;i<InteractionList.size1;i++){
					for (int j=0;j<InteractionList.size2;j++){
						nodeList.get(index).setPosition(2+ 3*i, 3 + 3*j);
						index++;
						nodeList.get(index).setPosition(2+ 3*i, 3 + 3*j);
						index++;
						nodeList.get(index).setPosition(2+ 3*i, 3 + 3*j);
						index++;
					}
				}
			}/**/
		}
		
		// nodes of primary interactions
		nodeList.get(index  ).setPosition(); // move forward
		nodeList.get(index+1).setPosition(); // bump		 
		nodeList.get(index+2).setPosition(); // eat
		nodeList.get(index+3).setPosition(); // turn left 90
		nodeList.get(index+4).setPosition(); // turn right 90
		nodeList.get(index+5).setPosition(); // turn left 45
		nodeList.get(index+6).setPosition(); // turn right 45
		nodeList.get(index+7).setPosition(); // bias input
	}
	
	//////////////////////////////////////////////////////////
	
	public Node get(int i){
		return nodeList.get(i);
	}
	
	public int size(){
		return nodeList.size();
	}
	
	public boolean getMesh(){
		return mesh;
	}
	
	public void changeMest(){
		mesh=!mesh;
		set(mesh);
	}
	
}

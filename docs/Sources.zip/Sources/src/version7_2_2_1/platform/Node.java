package version7_2_2_1.platform;


public class Node {

	public float x;
	public float y;
	
	public int index;
	public int color;
	
	// create a node at a random position
	public Node(int i, int c){
		index=i;
		color=c;
		
		x=(float) (Math.random()*100+140);
		y=(float) (Math.random()*100+80);
	}
	
	// create a node with a predefined position
	public Node(int i, int c, float px, float py){
		index=i;
		color=c;
		
		x=px;
		y=py;
	}
	
	// set new random position
	public void setPosition(){
		x=(float) (Math.random()*100+140);
		y=(float) (Math.random()*100+80);
	}
	
	// set a predefined position
	public void setPosition(float px, float py){
		x=px;
		y=py;
	}
}

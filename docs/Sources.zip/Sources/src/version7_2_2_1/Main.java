package version7_2_2_1;

import java.util.ArrayList;

import version7_2_2_1.environment.Environment;
import version7_2_2_1.platform.Agent;
import version7_2_2_1.platform.Display;
import version7_2_2_1.platform.UserInterfaceFrame;


public class Main {

	//%%%%%%%%%%%%%%%%%%%%%%% specific to simulators %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	public Environment env;
	//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	public UserInterfaceFrame userInterface;
	public Display display;
	private ArrayList<Agent> agentList;
	
	private boolean run=true;
	
	public Main(){
		agentList=new ArrayList<Agent>();
		display=new Display();
		
		//%%%%%%%%%%%%%%%%%%%%%%% specific to simulators %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		env=new Environment(this);
		//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		
		if (nbAgent()>0){
			selectAgent(0).setDisplay();
		}

		userInterface=new UserInterfaceFrame(this);
		
		while (run){
			boolean tempo=true;
			for (int i=0;i<nbAgent();i++){
				selectAgent(i).act();
				if (!selectAgent(i).isStopped()) tempo=false;
			}
			
			if (tempo){
				try{Thread.currentThread();
					Thread.sleep(200);}
				catch(Exception ie){}
			}
			
			//%%%%%%%%%%%%%%%%%%%%%%% specific to simulators %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			env.drawGrid();
			//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			
			display.repaint();

		}
	}
	
	
	////////////////////////////////////////////////////////
	// function used to manage the agent list
	public void addAgent(int ident){
		agentList.add(new Agent(ident,this));
	}
	public void resetList(){
		agentList.clear();
	}
	public int nbAgent(){
		return agentList.size();
	}

	// select the last agent of the list
	public Agent lastAgent(){
		return agentList.get(nbAgent()-1);
	}
	
	// select an agent according to its index
	public Agent selectAgent(int index){
		if (index<nbAgent()) return agentList.get(index);
		else              return null;
	}

	//%%%%%%%%%%%%%%%%%%%%%%% specific to simulators %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	public void agentPosition(float x,float y, float theta){
		lastAgent().setPosition(x,y,theta);
	}
	
	// get the ident of the closest agent from the selected point
	public int agentId(float x, float y){
		int ident=-1;
		float min=2;
		float d=0;
		
		for (int i=0;i<nbAgent();i++){
			d= (selectAgent(i).body.getpx() - x)*(selectAgent(i).body.getpx() - x)
			  +(selectAgent(i).body.getpy() - (env.getHeight()-y))*(selectAgent(i).body.getpy() - (env.getHeight()-y));
			d=(float) Math.sqrt(d);
			
			if (d<=2 && d<min){
				min=d;
				ident=selectAgent(i).getIdent();
			}
		}
		return ident;
	}
	
	// get the index of the closest agent from the selected point
	public int agentIndex(float x, float y){
		int index=-1;
		float min=2;
		float d=0;
		
		for (int i=0;i<nbAgent();i++){
			d= (selectAgent(i).body.getpx() - x)*(selectAgent(i).body.getpx() - x)
			  +(selectAgent(i).body.getpy() - (env.getHeight()-y))*(selectAgent(i).body.getpy() - (env.getHeight()-y));
			d=(float) Math.sqrt(d);
			
			if (d<=2 && d<min){
				min=d;
				index=i;
			}
		}
		return index;
	}
	//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	// get the index of an agent designated by its ident
	public int agentIndex(int id){
		int index=-1;
		
		for (int i=0;i<nbAgent();i++){
			if (selectAgent(i).getIdent()==id) index=i;
		}
		
		return index;
	}
	
	
	public boolean isStopped(){
		int nb=nbAgent();
		boolean test=true;
		for (int i=0;i<nb;i++){
			if (selectAgent(i).action.getState()==1) test=false;
		}
		return test;
	}
	
	public boolean isStopped(int index){
		return (selectAgent(index).action.getState()==0);
	}
	
	public boolean isStarted(){
		int nb=nbAgent();
		boolean test=true;
		for (int i=0;i<nb;i++){
			if (selectAgent(i).action.getState()==0) test=false;
		}
		return test;
	}
	
	public boolean isStarted(int index){
		return (selectAgent(index).action.getState()==1);
	}
	
	
	// stop the simulation
	public void stop(){
		run=false;
	}
	
	public int getAgentIndex(){
		//%%%%%%%%%%%%%%%%%%%%%%% specific to simulators %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		return env.getIndex();
		//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	}
	
	public void saveImage(String path){
		display.saveImage(path);
	}
	
	
	
	///////////////////////////////////////////////////////
	
	public static void main(String[] args){
		new Main();
	}
	
}


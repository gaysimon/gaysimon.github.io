package version7_2_2_1.display;

import version7_2_2_1.platform.Agent;

/**
 * Frame to display images of signatures
 * @author simon
 */

/* - inherited from EnvFrame :
 *   Agent agent      : pointer to the agent
 *   EnvPanel panel   : panel of this frame
 *   
 * - inherited from PrintableFrame :
 *   boolean printable   : define if the frame can be printed
 *   int indexImage      : counter for image name
 */
public class MovementFrame extends EnvFrame{

	private static final long serialVersionUID = 1L;

	public MovementFrame(Agent a){
		super(a);
		this.setTitle("Signature Images");
    	this.setSize(1150, 700);
    	this.setLocationRelativeTo(null);               
    	this.setVisible(true);
    	this.setFocusable(true);
    	panel=new MovementPanel(a);
    	this.setContentPane(panel);
	}
}


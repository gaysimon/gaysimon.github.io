package version7_2_2_1.display;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import version7_2_2_1.platform.Agent;
import version7_2_2_1.Interface.InteractionList;
import version7_2_2_1.agnosticMemory.Signature;

/**
 * Frame to display images of signatures
 * @author simon
 */

/* - inherited from EnvPanel :
 *   Agent agent      : pointer to the agent
 */
public class MovementPanel extends EnvPanel implements MouseListener{

	private static final long serialVersionUID = 1L;
	
	private float[][][][][] maps;						// sequence of signature images
	private int[] selection;
	private int color;
	private int nbStep=5;
	
	private int clic_x=0;
	private int clic_y=0;
	
	private int size1=InteractionList.size1;
	private int size2=InteractionList.size2;
	
	public MovementPanel(Agent a){
		super(a);
		addMouseListener(this);
		
		maps=new float[nbStep][6][size1][size2][3];
		selection=new int[7];
		for (int i=0;i<nbStep;i++){
			selection[i]=0;
		}
		
		color=0;
		
		setSignature();
		fillMap();
	}
	
	public void setAgent(Agent a){
		agent=a;
	}
	
	public void paintComponent(Graphics g){
		g.setColor(Color.white);
		
		g.fillRect(0, 0, 1160, 705);
		
		
		// draw color selector
		for (int j=0;j<3;j++){
			if (color==j) g.setColor(Color.red);
			else g.setColor(Color.black);
			
			g.fillRect(40, 200 + 20*j, 10, 10);
		}
		
		for (int i=0;i<nbStep;i++){
			
			// draw selector
			for (int j=0;j<7;j++){
				if (i==0 || j<6){
					if (selection[i]==j) g.setColor(Color.red);
					else g.setColor(Color.black);
					g.fillRect(40+220*i, 50 + 20*j, 10, 10);
				}
			}
			
			
			// draw maps
			for (int n=0;n<6;n++){
				for (int j=0;j<size1;j++){
					for (int k=0;k<size2;k++){
						g.setColor(new Color(Math.min(1, Math.max(0, (maps[i][n][j][k][2]/2+0.5f))),
								 			 Math.min(1, Math.max(0, (maps[i][n][j][k][0]/2+0.5f))),
								 			 Math.min(1, Math.max(0, (maps[i][n][j][k][1]/2+0.5f)))));
						g.fillRect(60+220*i+6*j, 20+(size2*6- 6*k) +100*n,6,6);
					}
				}
			}
		}
	}
	
	public void setSignature(){
		// fill initial signature
		float max=0;
		for (int n=0;n<6;n++){
			for (int i=0;i<size1;i++){
				for (int j=0;j<size2;j++){
					maps[0][n][i][j][0]=agent.signatureList.get(InteractionList.nbDF+selection[0]).signature[i*size2*3+j*3+n*size1*size2*3  ];
					maps[0][n][i][j][1]=agent.signatureList.get(InteractionList.nbDF+selection[0]).signature[i*size2*3+j*3+n*size1*size2*3+1];
					maps[0][n][i][j][2]=agent.signatureList.get(InteractionList.nbDF+selection[0]).signature[i*size2*3+j*3+n*size1*size2*3+2];
					
					if (maps[0][n][i][j][0]>max) max=maps[0][n][i][j][0];
					if (maps[0][n][i][j][1]>max) max=maps[0][n][i][j][1];
					if (maps[0][n][i][j][2]>max) max=maps[0][n][i][j][2];
				}
			}
		}
		if (max>1){
			for (int n=0;n<6;n++){
				for (int i=0;i<size1;i++){
					for (int j=0;j<size2;j++){
						for (int c=0;c<3;c++){
							maps[0][n][i][j][c]=maps[0][n][i][j][c]/max;
						}
					}
				}
			}
		}
	}
	
	
	public void fillMap(){
		
		// generate moved signatures
		for (int a=1;a<nbStep;a++){
		
			// reset map
			float max=0;
			for (int n=0;n<6;n++){
				for (int i=0;i<size1;i++){
					for (int j=0;j<size2;j++){
						for (int c=0;c<3;c++){
							maps[a][n][i][j][c]=0;
						}
					}
				}
			}
			
			// compute map
			for (int n=selection[a];n<selection[a]+1;n++){
				for (int i=0;i<size1;i++){
					for (int j=0;j<size2;j++){
						for (int c=0;c<3;c++){
							
							// get the signature
							Signature sig=agent.signatureList.get(i*size2*3+j*3+n*size2*size1*3+c);
								
							//if (sig.average_delta1<0.7 && sig.average_delta2<0.7){
								
								// apply the signature
								for (int n2=0;n2<6;n2++){
									for (int i2=0;i2<size1;i2++){
										for (int j2=0;j2<size2;j2++){
											for (int c2=0;c2<3;c2++){
												if (Math.abs(maps[a-1][n][i][j][c]*sig.signature[i2*size2*3+j2*3+n2*size2*size1*3+c2])>1){
													maps[a][n2][i2][j2][c2]+= maps[a-1][n][i][j][c] * sig.signature[i2*size2*3+j2*3+n2*size2*size1*3+c2];
													if (Math.abs(maps[a][n2][i2][j2][c2])>max) max = maps[a][n2][i2][j2][c2];
												}
											}
										}
									}
								}
							//}
						}
					}
				}
			}
			
			// normalise map
			if (max>1.5){
				for (int n=0;n<6;n++){
					for (int i=0;i<size1;i++){
						for (int j=0;j<size2;j++){
							for (int c=0;c<3;c++){
								maps[a][n][i][j][c]=maps[a][n][i][j][c]/(max);
							}
						}
					}
				}
			}
		}
	}
	
	
	///////////////////////////////////////////////////////////////////////////
	public void mouseClicked(MouseEvent e) {

		clic_x=e.getX();
		clic_y=e.getY();

		boolean found=false;
		
		for (int i=0;i<nbStep;i++){
			for (int j=0;j<7;j++){
				if (i==0 || j<6){
					if (clic_x>=38+220*i && clic_x<52+220*i && clic_y>=48+20*j && clic_y<62+20*j){
						selection[i]=j;
						found=true;
					}
				}
			}
		}

		for (int j=0;j<3;j++){
			if (clic_x>=38 && clic_x<52 && clic_y>=198+20*j && clic_y<212+20*j){
				color=j;
				found=true;
			}
		}

		
		if (found) setSignature();
		else{
			int x=0,y=0;
			for (int i=0;i<size1;i++){
				for (int j=0;j<size2;j++){
					if (clic_x>=60+6*i && clic_x<67+6*i && clic_y>=20+(size2*6-6*j) && clic_y<27+(size2*6-6*j)){
						x=i;
						y=j;
						found=true;
					}
				}
			}
			if (found){
				for (int n=0;n<6;n++){
					for (int i=0;i<size1;i++){
						for (int j=0;j<size2;j++){
							for (int c=0;c<3;c++){
								if (i==x && j==y && c==color)  maps[0][n][i][j][c]=1;
								else maps[0][n][i][j][c]=0;
							}
						}
					}
				}
			}
		}
		fillMap();
	}

	@Override
	public void mouseEntered(MouseEvent e){}
	public void mouseExited(MouseEvent e){}
	public void mousePressed(MouseEvent e){}
	public void mouseReleased(MouseEvent e){}
}

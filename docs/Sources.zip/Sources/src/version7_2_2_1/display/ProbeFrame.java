package version7_2_2_1.display;

import version7_2_2_1.platform.Agent;

/**
 * Display the probe input
 * @author simon gay
 */

/* - inherited from EnvFrame :
 *   Agent agent      : pointer to the agent
 *   EnvPanel panel   : panel of this frame
 *   
 * - inherited from PrintableFrame :
 *   boolean printable   : define if the frame can be printed
 *   int indexImage      : counter for image name
 */
public class ProbeFrame extends EnvFrame{

	private static final long serialVersionUID = 1L;

	public ProbeFrame(Agent a){
		super(a);
		this.setTitle("Probe");
    	this.setSize(720, 225);
    	this.setLocationRelativeTo(null);               
    	this.setVisible(true);
    	panel=new ProbePanel(a);
    	this.setContentPane(panel);
	}
}

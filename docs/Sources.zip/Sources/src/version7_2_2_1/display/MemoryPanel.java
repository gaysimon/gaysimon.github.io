package version7_2_2_1.display;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import version7_2_2_1.Interface.InteractionList;
import version7_2_2_1.platform.Agent;

/**
 * Panel to display the links between positions
 * @author simon
 */

/* - inherited from EnvPanel :
 *   Agent agent      : pointer to the agent
 */
public class MemoryPanel extends EnvPanel implements MouseListener{

	private static final long serialVersionUID = 1L;
	
	private int clic_x=0;
	private int clic_y=0;
	
	private boolean[] display;
	private static int gap=8;			// distance between nodes
	private int color=0;				// color of displayed interactions (0-> green, 1 -> blue, 2 -> red)
	
	public MemoryPanel(Agent a){
		super(a);
		addMouseListener(this);

		display=new boolean[6];
		for (int i=0;i<6;i++) display[i]=true;
	}
	
	public void setAgent(Agent a){
		agent=a;
	}
	
	public void paintComponent(Graphics g){
		g.setColor(Color.white);
		
		g.fillRect(0, 0, 1200, 1000);
		
		// draw mesh type switch
		if (agent.nodeList.getMesh()) g.setColor(Color.blue);
		else g.setColor(Color.red);
		g.fillRect(20, 70, 10, 10);
		
		// draw color switch
		g.setColor(Color.green);
		g.fillRect(20,100, 10, 10);
		g.setColor(Color.blue);
		g.fillRect(20,120, 10, 10);
		g.setColor(Color.red);
		g.fillRect(20,140, 10, 10);
		
		g.setColor(Color.black);
		g.drawRect(19, 99+20*color, 10, 10);
		
		// draw interaction switch
		for (int i=0;i<6;i++){
			if (display[i]) g.setColor(Color.red);
			else g.setColor(Color.black);
			g.fillRect(20, 180+20*i, 10, 10);
		}
		
		int nbPos=InteractionList.size1*InteractionList.size2*3;
		
		// draw nodes		
		for (int i=0; i<nbPos;i++){
			g.setColor(Color.black);
			g.fillOval(150+(int)(agent.nodeList.get(i).x*gap)-1, 
					    50+(int)(agent.nodeList.get(i).y*gap)-1, 2, 2);
		}
		
		for (int l=0;l<6;l++){	
			if (display[l]){
				for (int i=color; i<nbPos;i+=3){

					if (i%3==0) g.setColor(Color.green);
					if (i%3==1) g.setColor(Color.blue);
					if (i%3==2) g.setColor(Color.red);
					
					g.fillOval(150+(int)(agent.nodeList.get(i+l*nbPos).x*gap)-3,
							    50+(int)(agent.nodeList.get(i+l*nbPos).y*gap)-3, 5, 5);
				}
			}
		}
		
		g.setColor(Color.black);
		for (int i=0; i<7;i++){
			g.fillOval(150+(int)(agent.nodeList.get(i+InteractionList.nbDF).x*gap)-3,
					    50+(int)(agent.nodeList.get(i+InteractionList.nbDF).y*gap)-3, 5, 5);
		}
		
		g.setColor(Color.black);
		
		if (!agent.nodeList.getMesh()){
			// draw links between each interaction and the barycentre of its signature
			for (int l=0;l<6;l++){
				
				if (display[l]){
					for (int i=color; i<nbPos;i+=3){
	
						// for each node, draw links between this node and average position of high weights
						float x=0;
						float y=0;
						float n=0;
						
						for (int k=0;k<6;k++){
							for (int j=1; j<nbPos;j++){
								if (agent.signatureList.get(i+l*nbPos).signature[j+k*nbPos]>4){	
									x+=agent.nodeList.get(j).x * agent.signatureList.get(i+l*nbPos).signature[j+k*nbPos];
									y+=agent.nodeList.get(j).y * agent.signatureList.get(i+l*nbPos).signature[j+k*nbPos];
									n+=agent.signatureList.get(i+l*nbPos).signature[j+k*nbPos];
								}
							}
						}
						
						if (n>0){
							x=x/n;
							y=y/n;
							g.drawLine(150+(int)(agent.nodeList.get(i).x*gap),
								   	    50+(int)(agent.nodeList.get(i).y*gap),
								   	   150+(int)(x*gap),
								   	    50+(int)(y*gap));
						}
					}
				}
			}
		}
		else{
			// draw mesh
			g.setColor(Color.black);
			for (int l=0;l<6;l++){
				if (display[l]){
					for (int i=0;i<InteractionList.size2;i++){
						for (int j=0;j<InteractionList.size1;j++){
							
							for (int c=color;c<color+1;c+=3){
								
							// connect each node of a row with the next node
								if (j<InteractionList.size1-1){
									if ((agent.nodeList.get(l*nbPos+3*i+InteractionList.size2*3* j   +c).x*gap<730 || agent.nodeList.get(l*nbPos+3*i+InteractionList.size2*3* j   +c).y*gap<420)
									&&  (agent.nodeList.get(l*nbPos+3*i+InteractionList.size2*3*(j+1)+c).x*gap<730 || agent.nodeList.get(l*nbPos+3*i+InteractionList.size2*3*(j+1)+c).y*gap<420)){
										g.drawLine(150+(int)(agent.nodeList.get(l*nbPos + 3*i + InteractionList.size2*3*j +c).x*gap),
											   	    50+(int)(agent.nodeList.get(l*nbPos + 3*i + InteractionList.size2*3*j +c).y*gap),
											   	   150+(int)(agent.nodeList.get(l*nbPos + 3*i + InteractionList.size2*3*(j+1) +c).x*gap),
											   	    50+(int)(agent.nodeList.get(l*nbPos + 3*i + InteractionList.size2*3*(j+1) +c).y*gap));
									}
								}
								
								// and each node of a column with the next
								if (i<InteractionList.size2-1){
									if ((agent.nodeList.get(l*nbPos+3* i   +InteractionList.size2*3*j+c).x*gap<730 || agent.nodeList.get(l*nbPos+3* i   +InteractionList.size2*3*j+c).y*gap<420)
									&&  (agent.nodeList.get(l*nbPos+3*(i+1)+InteractionList.size2*3*j+c).x*gap<730 || agent.nodeList.get(l*nbPos+3*(i+1)+InteractionList.size2*3*j+c).y*gap<420)){
										g.drawLine(150+(int)(agent.nodeList.get(l*nbPos + 3*i + InteractionList.size2*3*j +c).x*gap),
											   	    50+(int)(agent.nodeList.get(l*nbPos + 3*i + InteractionList.size2*3*j +c).y*gap),
											   	   150+(int)(agent.nodeList.get(l*nbPos + 3*(i+1) + InteractionList.size2*3*j +c).x*gap),
											   	    50+(int)(agent.nodeList.get(l*nbPos + 3*(i+1) + InteractionList.size2*3*j +c).y*gap));
									}
								}
							}
						}
					}
				}
			}
		}
	}
	
	
	///////////////////////////////////////////////////////////////////////////
	public void mouseClicked(MouseEvent e) {

		clic_x=e.getX();
		clic_y=e.getY();
		
		float dmin=1000;
		float d=10;
		
		boolean found=false;
		
		
		if (clic_x>=20 && clic_x<30){
			
			// mesh type switch
			if (clic_y>=70 && clic_y<80){
				found=true;
				agent.nodeList.changeMest();
			}
			
			// color switch
			for (int c=0;c<3;c++){
				if (clic_y>=100+c*20 && clic_y<110+c*20){
					found=true;
					color=c;
				}
			}
			
			// interaction switch
			for (int i=0;i<6;i++){
				if (clic_y>=180+i*20 && clic_y<190+i*20){
					found=true;
					display[i]=!display[i];
				}
			}
		}
		
		if (!found){
			agent.observer.setSelectedNode(-1);
			
			// select a node
			for (int i=0;i<agent.nodeList.size();i++){
				if (agent.nodeList.get(i).color==this.color){
					d=(clic_x-(150+agent.nodeList.get(i).x*8-3)) * (clic_x-(150+agent.nodeList.get(i).x*8-3)) 
					+ (clic_y-( 50+agent.nodeList.get(i).y*8-3)) * (clic_y-( 50+agent.nodeList.get(i).y*8-3));
					if (d<dmin){
						dmin=d;
						agent.observer.setSelectedNode(i);
					}
				}
			}
		}
	}

	@Override
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {}
	public void mouseReleased(MouseEvent e) {}

}

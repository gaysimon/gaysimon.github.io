package version7_2_2_1.display;

import java.awt.Graphics;

import version7_2_2_1.platform.Agent;
import version7_2_2_1.platform.PrintableFrame;

/**
 * Generic class of Frames that display information about an agent
 * @author simon gay
 */
 
/* - inherited from PrintableFrame :
 *   boolean printable   : define if the frame can be printed
 *   int indexImage      : counter for image name
 */
public class EnvFrame extends PrintableFrame{

	private static final long serialVersionUID = 1L;
	
	protected Agent agent;
	protected EnvPanel panel;
	
	protected boolean export;    // if true, the frame can be saved as an jpeg file (false by default)
	
	public EnvFrame(Agent a){
		super();
		agent=a;
		export=false;
	}
	
	/**
	 * print the displayed image in a pdf file
	 */
	public void drawPDF(Graphics g){
		panel.drawPDF(g);
	}
	
	/**
	 * change the observed agent
	 */
	public void setAgent(Agent a){
		panel.setAgent(a);
	}

	public void paint(){
    	panel.repaint();
    }
	
	public boolean export(){
		return export;
	}
}

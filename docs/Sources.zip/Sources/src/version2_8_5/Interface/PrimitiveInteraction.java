package version2_8_5.Interface;

import java.util.ArrayList;

/**
 * Definition of a primitive interaction
 * @author simon
 */
public class PrimitiveInteraction{

	private String action;
	private String perception;
	
	private float valence;
	
	private ArrayList<PrimitiveInteraction> alternateGroup;		//alternative group of this interaction
	
	public PrimitiveInteraction(String a,String p) {
		action=a;
		perception=p;
		valence=InteractionList.valence(a,p);
		alternateGroup=new ArrayList<PrimitiveInteraction>();
	}
	
	public boolean isEqual(PrimitiveInteraction inter){
		return this.action.equals(inter.action ) &&  this.perception.equals(inter.perception);
	}

	// add an alternative interaction
	public void addAlternate(PrimitiveInteraction inter){
		boolean found=false;
		int i=0;
		while (!found && i<alternateGroup.size()){
			if (alternateGroup.get(i).isEqual(inter)) found=true;
			i++;
		}
		if (!found) alternateGroup.add(inter);
	}
	
	// return true if inter is an alternative interaction
	public boolean isAlternate(PrimitiveInteraction inter){
		boolean found=false;
		int i=0;
		while (!found && i<alternateGroup.size()){
			if (alternateGroup.get(i).isEqual(inter)) found=true;
			i++;
		}
		return found;
	}
	
	// get alternative interaction
	public PrimitiveInteraction getAlternate(int i){
		if (i<alternateGroup.size()) return alternateGroup.get(i);
		else return null;
	}
	
	public int nbAlternate(){
		return alternateGroup.size();
	}
	
	/////////////////////////////////////////
	public String getAction(){
		return action;
	}

	public String getPerception(){
		return perception;
	}
	
	public float valence(){
		return valence;
	}

	public String name(){
		return "["+action+perception+"]";
	}
	
	public String getName(){
		return "[{"+action+","+perception+"}:("+valence+")] ";
	}
}

package version2_8_5.platform;

import java.awt.Graphics;
import javax.swing.JPanel;

/**
 * Generic class of panel that can be exported as pdf file and jpeg image
 * @author simon
 */
public class PrintablePanel extends JPanel{

	private static final long serialVersionUID = 1L;

	public PrintablePanel(){

	}

	public void drawPDF(Graphics g){
		paintComponent(g);
	}
	
	public void paintComponent(Graphics g){

	}
}

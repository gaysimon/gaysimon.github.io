package version2_8_5.platform;

import version2_8_5.Interface.*;
import version2_8_5.display.*;
import version2_8_5.environment.*;
import version2_8_5.spaceMemory.*;
import version2_8_5.Main;

/**
 * whole learning mechanism
 * This class is used as a bridge between modules
 * @author simon gay
 */
public class Agent {

	public Action action;
	public InteractionList interactionList;
	
	public Robot body;
	public Observer observer;
	public SpaceMemory spaceMemory;
	
	public SequenceMemory sequenceMemory;
	public EnvironmentMemory environmentMemory;
	public Colliculus colliculus;
	
	public Decision decision;
	
	private Main main;
	
	private int ident;
	
	public Agent(int id, Main m){

		action=new Action(this);
		interactionList=new InteractionList();
		
		body=new Robot();
		decision=new Decision(this);
		observer=new Observer(this);
		spaceMemory=new SpaceMemory(this);
		
		sequenceMemory=new SequenceMemory(this);
		environmentMemory=new EnvironmentMemory(this);
		colliculus=new Colliculus(this);

		ident=id;
		
		main=m;
		
	}
	
	// enact a simulation substep
	public void act(){
		action.act();
	}
	
	public boolean isStopped(){
		return action.isStopped();
	}
	
	public int getIdent(){
		return ident;
	}
	
	//%%%%%%%%%%%%%%%%% specific to simulators %%%%%%%%%%%%%%%%%%%%%%%
	public void setPosition(float x, float y, float theta){
		body.setPosition(x,y,theta);
	}
	
	public void setEnvironment(Environment e){
		body.setEnvironment(e);
	}
	//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	
	// initialize the set of panels related to the agent
	public void setDisplay(){
		
		boolean efficiency=true;
		boolean space=true;
		boolean colliculus=true;
		
		int size;
		int i;
		boolean found;

		//////////////////////
		if (efficiency){
			size=main.display.nbFrame();
			i=0;
			found=false; 
			while (i<size && !found){
				if (main.display.get(i).getClass().getName().equals("version2_8_5.display.EfficiencyFrame")) found=true;
				i++;
			}
			if (!found) main.display.addFrame(new EfficiencyFrame(this));
			else        
				((EfficiencyFrame)main.display.get(i-1)).setAgent(this);
		}
		
		//////////////////////
		if (space){
			size=main.display.nbFrame();
			i=0;
			found=false; 
			while (i<size && !found){
				if (main.display.get(i).getClass().getName().equals("version2_8_5.display.SpaceFrame")) found=true;
				i++;
			}
			if (!found) main.display.addFrame(new SpaceFrame(this));
			else
				((SpaceFrame)main.display.get(i-1)).setAgent(this);
		}
		
		//////////////////////
		if (colliculus){
			size=main.display.nbFrame();
			i=0;
			found=false; 
			while (i<size && !found){
				if (main.display.get(i).getClass().getName().equals("version2_8_5.display.ColliculusFrame")) found=true;
				i++;
			}
			if (!found) main.display.addFrame(new ColliculusFrame(this));
			else        
				((ColliculusFrame)main.display.get(i-1)).setAgent(this);
		}
	}

	// save modules data
	public void save() {
		spaceMemory.save();
	}
	
	// save images from displayers
	public void saveImage(String path){
		main.saveImage(path);
	}
	
}

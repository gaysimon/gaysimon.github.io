package version2_8_5.platform;

import java.util.ArrayList;

import version2_8_5.Interface.InteractionList;
import version2_8_5.platform.Agent;
import version2_8_5.spaceMemory.Composite;

/**
 * Show implicit relations between signatures. Each interaction is considered as a point
 * for which the position is defined according to the properties of its signature.
 * This class can also define the real signatures for comparisons with the signatures
 * learned by the agent.
 * The agent cannot read information given by this class
 * @author simon gay
 */
public class Colliculus {

	private Agent agent;
	
	private boolean repulsion=false;
	
	// point list
	public ArrayList<float[]> pointList;	// position of interactions according to related location in space
	public ArrayList<Integer> pointColor;	// color of interactions according to their real position
	public ArrayList<float[]> objList;		// position of interactions according to object relation
	
	private int[][] simulator;				// matrix used for interaction simulation
	
	
	public Colliculus(Agent a){
		agent=a;
		simulator=new int[9][9];
		pointList=new ArrayList<float[]>();
		pointColor=new ArrayList<Integer>();
		objList  =new ArrayList<float[]>();
	}
	
	// compute position of interactions according to their properties
	public void updatePoints(){
		
		int size=agent.spaceMemory.compositeList.size();

		// add points if needed
		if (pointList.size()<size){
			for (int i=pointList.size();i<size;i++){
				pointList.add(new float[2]);
				pointList.get(pointList.size()-1)[0]=(float) (Math.random()*50-25);
				pointList.get(pointList.size()-1)[1]=(float) (Math.random()*50-25);
				
				pointColor.add(simulation(agent.spaceMemory.compositeList.get(i)));
				
				objList.add(new float[3]);
				objList.get(pointList.size()-1)[0]=(float) (Math.random()*50-25);
				objList.get(pointList.size()-1)[1]=(float) (Math.random()*50-25);
				
				if (agent.spaceMemory.compositeList.get(i).get(0).getPerception().equals(":")
				  ||agent.spaceMemory.compositeList.get(i).get(0).getPerception().equals("'")
				  ||agent.spaceMemory.compositeList.get(i).get(0).getPerception().equals("O")
				  ){
					
					objList.get(pointList.size()-1)[2]=0;
				}
				else
					objList.get(pointList.size()-1)[2]=1;
			}
		}
		
		// define position of interactions in space according to their signatures
		for (int i=0;i<pointList.size();i++){
			
			float sum=0;
			float sumX=0;
			float sumY=0;
			for (int k=0;k<InteractionList.length1;k++){
				for (int l=0;l<InteractionList.length2;l++){
					sum+=Math.abs(agent.spaceMemory.compositeList.get(i).pattern[k][l]);
					
					sumX+=Math.abs(agent.spaceMemory.compositeList.get(i).pattern[k][l])*(k-1);
					if (k==1) sumY-=Math.abs(agent.spaceMemory.compositeList.get(i).pattern[k][l])*(2f/3f);
					else sumY+=Math.abs(agent.spaceMemory.compositeList.get(i).pattern[k][l])*(1f/3f);
				}
			}
			if (sum>0){
				pointList.get(i)[0]=sumX*20;
				pointList.get(i)[1]=sumY*20;
			}
			else{
				pointList.get(i)[0]=0;
				pointList.get(i)[1]=0;
			}
		}
		
		// move object points
		for (int i=0;i<objList.size();i++){
			if (!agent.spaceMemory.compositeList.get(i).isUncorrelated() )
			for (int j=0;j<objList.size();j++){
				if (!agent.spaceMemory.compositeList.get(j).isUncorrelated())
				
				if (i!=j){
					
					float dx=objList.get(i)[0] - objList.get(j)[0];
					float dy=objList.get(i)[1] - objList.get(j)[1];
					
					float d=(float) Math.sqrt(dx*dx+dy*dy);
					
					// repulsion force
					if (repulsion && d<10){
						// if points are too close
						objList.get(i)[0]+= 0.01*(dx*(10-d))/d/2;
						objList.get(i)[1]+= 0.01*(dy*(10-d))/d/2;
						
						objList.get(j)[0]-= 0.01*(dx*(10-d))/d/2;
						objList.get(j)[1]-= 0.01*(dy*(10-d))/d/2;
					}
					
					// composite distance force
					float dist=0;
					boolean match=true;
					for (int i2=0;i2<3;i2++){
						if (match) dist+= agent.spaceMemory.compositeList.get(i).pattern[i2][0]*agent.spaceMemory.compositeList.get(j).pattern[i2][0];
						
						if (  (agent.spaceMemory.compositeList.get(i).pattern[i2][0]==0 && agent.spaceMemory.compositeList.get(j).pattern[i2][0]!=0)
							||(agent.spaceMemory.compositeList.get(i).pattern[i2][0]!=0 && agent.spaceMemory.compositeList.get(j).pattern[i2][0]==0)){
							match=false;
							dist=0;
						}
					}
					
					if (dist>0){
						// attraction
						if (dx!=0){
						objList.get(i)[0]-=0.01*dist*dx/Math.abs(dx);
						objList.get(j)[0]+=0.01*dist*dx/Math.abs(dx);
						}
						if (dy!=0){
						objList.get(i)[1]-=0.01*dist*dy/Math.abs(dy);
						objList.get(j)[1]+=0.01*dist*dy/Math.abs(dy);
						}
					}
					if (dist<0){
						//repulsion
						if (d<50){
							if (dx!=0){
							objList.get(i)[0]-=0.01*dist*(dx/Math.abs(dx));
							objList.get(j)[0]+=0.01*dist*(dx/Math.abs(dx));
							}
							if (dy!=0){
							objList.get(i)[1]-=0.01*dist*(dy/Math.abs(dy));
							objList.get(j)[1]+=0.01*dist*(dy/Math.abs(dy));
							}
						}
					}

					// connection force
					if (agent.spaceMemory.compositeList.get(i).lastIndex()>=0){
						int index=agent.spaceMemory.compositeList.get(i).lastIndex();
						if (j==index){
							objList.get(i)[0]-=0.5*(dx);
							objList.get(j)[0]+=0.5*(dx);
		
							objList.get(i)[1]-=0.5*(dy);
							objList.get(j)[1]+=0.5*(dy);
						}
					}
				}
			}
		}
		
		// normalize points
		float mx=0;
		float my=0;
		
		mx=0;
		my=0;
		for (int i=0;i<objList.size();i++){
			mx+=objList.get(i)[0];
			my+=objList.get(i)[1];
		}
		
		mx=mx/objList.size();
		my=my/objList.size();
		
		for (int i=0;i<objList.size();i++){
			objList.get(i)[0]-=mx;
			objList.get(i)[1]-=my;
			
			if (objList.get(i)[0]<-100) objList.get(i)[0]=-100;
			if (objList.get(i)[1]<-100) objList.get(i)[1]=-100;
			if (objList.get(i)[0]> 100) objList.get(i)[0]= 100;
			if (objList.get(i)[1]> 100) objList.get(i)[1]= 100;
		}
	}
	
	
	// define the real position of interactions in space
	public int simulation(Composite p){
		
		int index=p.length()-1;
		
		for (int i=0;i<9;i++){
			for (int j=0;j<9;j++){
				simulator[i][j]=0;
			}
		}
		simulator[3][4]=1;
		simulator[4][5]=2;
		simulator[5][4]=3;

		// uncomment to display simulator
		/*System.out.println("++++++++++++++++++++++++++++++++++");
		System.out.println(p.name());
		System.out.println("**************************************");
		for (int i=0;i<9;i++){
			for (int j=0;j<9;j++){
				System.out.print(simulator[j][8-i]+" ");
			}
			System.out.println();
		}
		System.out.println("**************************************");/**/
		
		// apply transformations produced by primitive interactions of the path of an interaction
		while (index>0){
			if (p.get(index).getAction().equals(">") && p.get(index).getPerception().equals("O")){
				for (int i=0;i<9;i++){
					for (int j=0;j<8;j++){
						simulator[i][j]=simulator[i][j+1];
					}
				}
			}
			if (p.get(index).getAction().equals("v")){
				int temp=0;
				for (int i=0;i<5;i++){
					for (int j=0;j<4;j++){
						temp=simulator[i][j];
						
						simulator[i][j]=simulator[j][8-i];
						simulator[j][8-i]=simulator[8-i][8-j];
						simulator[8-i][8-j]=simulator[8-j][i];
						simulator[8-j][i]=temp;
					}
				}
			}
			if (p.get(index).getAction().equals("^")){
				int temp=0;
				for (int i=0;i<5;i++){
					for (int j=0;j<4;j++){
						temp=simulator[i][j];
						
						simulator[i][j]=simulator[8-j][i];
						simulator[8-j][i]=simulator[8-i][8-j];
						simulator[8-i][8-j]=simulator[j][8-i];
						simulator[j][8-i]=temp;
					}
				}
			}
			for (int i=0;i<9;i++){
				for (int j=0;j<9;j++){
					System.out.print(simulator[j][8-i]+" ");
				}
				System.out.println();
			}
			//System.out.println("**************************************");
			index--;
		}
		
		// front
		if (p.get(0).getAction().equals(">")
		  ||p.get(0).getAction().equals("-")) return simulator[4][5];
		
		// left
		if (p.get(0).getAction().equals("^")
		  ||p.get(0).getAction().equals("/")) return simulator[3][4];
		
		// right
		if (p.get(0).getAction().equals("v")
		  ||p.get(0).getAction().equals("\\"))return simulator[5][4];
		
		return 0;
		
	}
	
	// apply a force to separate interactions
	public void setRepulsion(){
		repulsion=!repulsion;
	}
}

package version2_8_5.display;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import version2_8_5.platform.Agent;

/**
 * Display signatures of composite interactions
 * @author simon gay
 */

/* - inherited from EnvPanel :
 *   Agent agent      : pointer to the agent
 */
public class ColliculusPanel extends EnvPanel implements MouseListener,MouseMotionListener{

	private static final long serialVersionUID = 1L;
	
	private boolean name=false;
	private boolean wires=true;
	
	private int selectedPoint=-1;
	private int selectedTypePoint=-1;
	
	private int offsetX1=300;
	private int offsetY1=200;
	
	private int offsetX3=300;
	private int offsetY3=500;
	
	private int offsetX2=800;
	private int offsetY2=200;
	
	private int offsetX4=800;
	private int offsetY4=600;
	
	public ColliculusPanel(Agent a){
		super(a);
		addMouseListener(this);
		addMouseMotionListener(this);
	}
	
	public void paintComponent(Graphics g){
		g.setColor(Color.white);
		g.fillRect(0, 0, 1200, 800);
		
		/////////////////////////////////////////////////////////////////////////////
		// draw position graph
		/////////////////////////////////////////////////////////////////////////////
		
		// draw "position" squares
		g.setColor(Color.red);
		g.drawRect(-240+offsetX1, -27+offsetY1,160, 160);
		g.setColor(Color.green);
		g.drawRect( -80+offsetX1,-187+offsetY1,160, 160);
		g.setColor(Color.blue);
		g.drawRect(  80+offsetX1, -27+offsetY1,160, 160);
		
		
		// draw wires between composite interactions
		if (wires){
			for (int i=0;i<agent.colliculus.pointList.size();i++){
				if (!agent.spaceMemory.compositeList.get(i).isUncorrelated()
						&& agent.spaceMemory.compositeList.get(i).knowledgeMax>0
				   ){
					
					if (agent.spaceMemory.compositeList.get(i).lastIndex()>=0){
						int index=agent.spaceMemory.compositeList.get(i).lastIndex();
						g.setColor(Color.gray);
						g.drawLine((int)(agent.colliculus.pointList.get(i)[0]*4)+offsetX1+5,
								   (int)(agent.colliculus.pointList.get(i)[1]*4)+offsetY1+5,
								   (int)(agent.colliculus.pointList.get(index)[0]*4)+offsetX1+5,
								   (int)(agent.colliculus.pointList.get(index)[1]*4)+offsetY1+5);
					}
				}
			}
		}
		
		// draw composite interactions
		for (int i=0;i<agent.colliculus.pointList.size();i++){
			if (!agent.spaceMemory.compositeList.get(i).isUncorrelated()
					&& agent.spaceMemory.compositeList.get(i).knowledgeMax>0
				){
				
				// left related interactions are represented with red discs
				if (agent.colliculus.pointColor.get(i)==1){
					g.setColor(Color.red);
					g.fillOval((int)(agent.colliculus.pointList.get(i)[0]*4)+offsetX1, 
							   (int)(agent.colliculus.pointList.get(i)[1]*4)+offsetY1, 10, 10);
				}
				// front related interactions are represented with green squares
				else if (agent.colliculus.pointColor.get(i)==2){
					g.setColor(Color.green);
					g.fillRect((int)(agent.colliculus.pointList.get(i)[0]*4)+offsetX1, 
							   (int)(agent.colliculus.pointList.get(i)[1]*4)+offsetY1, 10, 10);
				}
				// right related interactions are represented with blue circles
				else if (agent.colliculus.pointColor.get(i)==3){
					g.setColor(Color.blue);
					g.drawOval((int)(agent.colliculus.pointList.get(i)[0]*4)+offsetX1, 
							   (int)(agent.colliculus.pointList.get(i)[1]*4)+offsetY1, 10, 10);
					g.drawOval((int)(agent.colliculus.pointList.get(i)[0]*4)+offsetX1+1, 
							   (int)(agent.colliculus.pointList.get(i)[1]*4)+offsetY1+1, 8, 8);
				}
				// interactions with no related position are represented with black squares
				else{
					g.setColor(Color.black);
					g.drawRect((int)(agent.colliculus.pointList.get(i)[0]*4)+offsetX1, 
							   (int)(agent.colliculus.pointList.get(i)[1]*4)+offsetY1, 10, 10);
					g.drawRect((int)(agent.colliculus.pointList.get(i)[0]*4)+offsetX1+1, 
							   (int)(agent.colliculus.pointList.get(i)[1]*4)+offsetY1+1, 8, 8);
				}
			}
		}
		
		// display name of composite interactions
		if (name){
			for (int i=0;i<agent.colliculus.pointList.size();i++){
				if (!agent.spaceMemory.compositeList.get(i).isUncorrelated()
						&& agent.spaceMemory.compositeList.get(i).knowledgeMax>0
					){
					// display name
					g.setColor(Color.black);
					g.drawString(agent.spaceMemory.compositeList.get(i).name(),
							(int)(agent.colliculus.pointList.get(i)[0]*4)+offsetX1,
							(int)(agent.colliculus.pointList.get(i)[1]*4)+offsetY1);
				}
			}
		}
		
		// display interaction predictions
		for (int i=0;i<agent.colliculus.pointList.size();i++){
			if (!agent.spaceMemory.compositeList.get(i).isUncorrelated()
					&& agent.spaceMemory.compositeList.get(i).knowledgeMax>0
				){
				// pure red means prediction of a failure and green means a prediction of success
				g.setColor(new Color((agent.spaceMemory.compositeList.get(i).lastPrediction()+1)/2,
									 1-(agent.spaceMemory.compositeList.get(i).lastPrediction()+1)/2,
									 0) );

				g.fillOval((int)(agent.colliculus.pointList.get(i)[0]*4)+offsetX2, 
						   (int)(agent.colliculus.pointList.get(i)[1]*4)+offsetY2, 10, 10);
			}
		}
		
		
		/////////////////////////////////////////////////////////////////////////////
		// draw object graph
		/////////////////////////////////////////////////////////////////////////////
		
		// draw wires between composite interactions
		if (wires){
			for (int i=0;i<agent.colliculus.objList.size();i++){
				if (!agent.spaceMemory.compositeList.get(i).isUncorrelated()){

					if (agent.spaceMemory.compositeList.get(i).lastIndex()>=0){
						int index=agent.spaceMemory.compositeList.get(i).lastIndex();
						g.setColor(Color.gray);
						g.drawLine((int)(agent.colliculus.objList.get(i)[0]*4)+offsetX3+5,
								   (int)(agent.colliculus.objList.get(i)[1]*4)+offsetY3+5,
								   (int)(agent.colliculus.objList.get(index)[0]*4)+offsetX3+5,
								   (int)(agent.colliculus.objList.get(index)[1]*4)+offsetY3+5);
					}
				}
			}
		}
		
		// draw composite interactions
		for (int i=0;i<agent.colliculus.objList.size();i++){
			if (!agent.spaceMemory.compositeList.get(i).isUncorrelated()){
				// empty space related interactions are represented with gray crosses
				if (agent.colliculus.objList.get(i)[2]==0){
					g.setColor(Color.gray);
					g.drawLine((int)(agent.colliculus.objList.get(i)[0]*4)+offsetX3   ,(int)(agent.colliculus.objList.get(i)[1]*4)+offsetY3,
							   (int)(agent.colliculus.objList.get(i)[0]*4)+offsetX3+10,(int)(agent.colliculus.objList.get(i)[1]*4)+offsetY3+10);
					
					g.drawLine((int)(agent.colliculus.objList.get(i)[0]*4)+offsetX3+10,(int)(agent.colliculus.objList.get(i)[1]*4)+offsetY3,
							   (int)(agent.colliculus.objList.get(i)[0]*4)+offsetX3   ,(int)(agent.colliculus.objList.get(i)[1]*4)+offsetY3+10);
				}
				// wall related interactions are represented with green discs
				else{
					g.setColor(Color.green);
					g.fillOval((int)(agent.colliculus.objList.get(i)[0]*4)+offsetX3, 
							   (int)(agent.colliculus.objList.get(i)[1]*4)+offsetY3, 10, 10);
				}
			}
		}
		
		// display name of composite interactions
		if (name){
			for (int i=0;i<agent.colliculus.objList.size();i++){
				if (!agent.spaceMemory.compositeList.get(i).isUncorrelated()
						&& (agent.spaceMemory.compositeList.get(i).length()==1)){
					// display name
					g.setColor(Color.black);
					g.drawString(agent.spaceMemory.compositeList.get(i).name(),
							(int)(agent.colliculus.objList.get(i)[0]*4)+offsetX3,
							(int)(agent.colliculus.objList.get(i)[1]*4)+offsetY3);
				}
			}
		}
		
		
		/////////////////////////////////////////////////////////////////////////////
		// draw interface
		/////////////////////////////////////////////////////////////////////////////
		
		g.setColor(Color.lightGray);
		g.fillRect(offsetX4-100, offsetY4-100, 200, 200);
		
		////// display/hide names button
		if (name) g.setColor(Color.green);
		else g.setColor(Color.black);
		g.fillRect(offsetX4-80, offsetY4-80, 10, 10);
		
		g.setColor(Color.black);
		g.drawString("names", offsetX4-60, offsetY4-70);
		
		////// display/hide wires button
		if (wires) g.setColor(Color.green);
		else g.setColor(Color.black);
		g.fillRect(offsetX4-80, offsetY4-40, 10, 10);
		
		g.setColor(Color.black);
		g.drawString("wires", offsetX4-60, offsetY4-30);
		
		////// repulsion force enable/disable button
		g.setColor(Color.black);
		g.fillRect(offsetX4-80, offsetY4 , 10, 10);
		
		g.setColor(Color.black);
		g.drawString("repulsion force", offsetX4-60, offsetY4+10);
	}

	
	///////////////////////////////////////////////////////////////////////////////
	// detect when an interaction is moved
	public void mouseDragged(MouseEvent e) {
		if (selectedPoint!=-1 && selectedTypePoint==0){
			agent.colliculus.pointList.get(selectedPoint)[0]=(e.getX()-offsetX1)/4;
			agent.colliculus.pointList.get(selectedPoint)[1]=(e.getY()-offsetY1)/4;
		}
		if (selectedPoint!=-1 && selectedTypePoint==1){
			agent.colliculus.objList.get(selectedPoint)[0]=(e.getX()-offsetX3)/4;
			agent.colliculus.objList.get(selectedPoint)[1]=(e.getY()-offsetY3)/4;
		}
		this.repaint();
	}
	
	// release interaction
	public void mouseReleased(MouseEvent arg0) {
		selectedPoint=-1;
		selectedTypePoint=-1;
	}

	// interaction selection
	public void mousePressed(MouseEvent e) {
		
		float x=e.getX();
		float y=e.getY();

		selectedPoint=-1;
		selectedTypePoint=-1;
		
		float dmin=10;
		float d=10;

		for (int i=0;i<agent.colliculus.pointList.size();i++){
			d= (agent.colliculus.pointList.get(i)[0]*4+offsetX1+5-x)*(agent.colliculus.pointList.get(i)[0]*4+offsetX1+5-x)
			  +(agent.colliculus.pointList.get(i)[1]*4+offsetY1+5-y)*(agent.colliculus.pointList.get(i)[1]*4+offsetY1+5-y);
			
			d=(float) Math.sqrt(d);
			if (d<dmin){
				dmin=d;
				selectedPoint=i;
				selectedTypePoint=0;
			}			
		}
		for (int i=0;i<agent.colliculus.objList.size();i++){
			d= (agent.colliculus.objList.get(i)[0]*4+offsetX3+5-x)*(agent.colliculus.objList.get(i)[0]*4+offsetX3+5-x)
			  +(agent.colliculus.objList.get(i)[1]*4+offsetY3+5-y)*(agent.colliculus.objList.get(i)[1]*4+offsetY3+5-y);
			
			d=(float) Math.sqrt(d);
			if (d<dmin){
				dmin=d;
				selectedPoint=i;
				selectedTypePoint=1;
			}			
		}
		
		// name display
		if (x<=(offsetX4-70) && x>=(offsetX4-80)
		 && y<=(offsetY4-70) && y>=(offsetY4-80)) name=!name;
		
		// wire display
		if (x<=(offsetX4-70) && x>=(offsetX4-80)
		 && y<=(offsetY4-30) && y>=(offsetY4-40)) wires=!wires;
		
		// repulsion between interactions
		if (x<=(offsetX4-70) && x>=(offsetX4-80)
		 && y<=(offsetY4+10) && y>=(offsetY4   )) agent.colliculus.setRepulsion();
	}
	
	public void mouseMoved(MouseEvent arg0) {}
	public void mouseClicked(MouseEvent arg0) {}
	public void mouseEntered(MouseEvent arg0) {}
	public void mouseExited(MouseEvent arg0) {}
}

package version2_8_5.spaceMemory;

import version2_8_5.Interface.InteractionList;
import version2_8_5.Interface.PrimitiveInteraction;
import version2_8_5.platform.Agent;

/**
 * Environmental contexts
 * @author simon gay
 */
public class EnvironmentMemory {

	private Agent agent;
	
	public float[][][] map;							// sequence of the last "timeSize" environmental contexts
	public float[][][] memoryMap1;						// sequence of the last "timeSize" first level memory maps
	public float[][] memoryMap2;						// second and third level memory maps
	public float[][] memoryMap3;
	
	public EnvironmentMemory(Agent a){
		agent=a;
		
		map=new float[SpaceMemory.timeSize+1][InteractionList.length1][InteractionList.length2];
		memoryMap1=new float[SpaceMemory.timeSize+1][InteractionList.length1][InteractionList.length2];
		memoryMap2=new float[InteractionList.length1][InteractionList.length2];
		memoryMap3=new float[InteractionList.length1][InteractionList.length2];
	}
	
	
	//////////////////////////////////////////////////////////////////////////////////////////////////
	// update environmental context and improved contexts
	public void updateEnvironment(PrimitiveInteraction inter){
		
		// update timeline
		for (int i=0;i<InteractionList.length1;i++){
			for (int j=0;j<InteractionList.length2;j++){
				for (int t=SpaceMemory.timeSize;t>0;t--){
					map[t][i][j]=map[t-1][i][j];
					memoryMap1[t][i][j]=memoryMap1[t-1][i][j];
				}
				map[0][i][j]=0;
				memoryMap1[0][i][j]=0;
				memoryMap2[i][j]=0;
				memoryMap3[i][j]=0;
			}
		}

		// generate environmental context with last enacted interaction
		if (inter.name().equals("[-:]")){
			map[0][1][0]= 1;
			map[0][1][1]=-1;
		}
		if (inter.name().equals("[-|]")){
			map[0][1][0]=-1;
			map[0][1][1]= 1;
		}
		if (inter.name().equals("[/:]")){
			map[0][0][0]= 1;
			map[0][0][1]=-1;
		}
		if (inter.name().equals("[/|]")){
			map[0][0][0]=-1;
			map[0][0][1]= 1;
		}
		if (inter.name().equals("[\\:]")){
			map[0][2][0]= 1;
			map[0][2][1]=-1;
		}
		if (inter.name().equals("[\\|]")){
			map[0][2][0]=-1;
			map[0][2][1]= 1;
		}
		
		//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		// generate memory maps with sequences memories
		//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

		Composite temp;
		
		// generate first level memory map with informations from memory
		for (int l=0;l<agent.sequenceMemory.memoryT[0].size();l++){
			temp=agent.sequenceMemory.memoryT[0].get(l).composite();
			if (temp!=null){
				for (int i=0;i<InteractionList.length1;i++){
					for (int k=0;k<InteractionList.length2;k++){
						if (temp.pattern[i][k] * map[0][i][k] >= 0){
							memoryMap1[0][i][k]+=temp.pattern[i][k];
						}
						else{
							// if an incoherence is detected
							System.out.println("wrong connexion detected T1");
							if (temp.knowledgeMin>0.8 || temp.getNbTest()>=99)
								temp.resetReliability(9);
							else
								temp.resetReliability(0);
							agent.sequenceMemory.memoryT[0].get(l).initial().resetReliability(0);
						}
					}
				}
			}
		}
		for (int l=0;l<agent.sequenceMemory.memoryF[0].size();l++){
			temp=agent.sequenceMemory.memoryF[0].get(l).composite();
			if (temp!=null){
				for (int i=0;i<InteractionList.length1;i++){
					for (int k=0;k<InteractionList.length2;k++){
						if (temp.pattern[i][k] * map[0][i][k] <= 0){
							memoryMap1[0][i][k]-=temp.pattern[i][k];
						}
						else{
							System.out.println("wrong connexion detected F1");
							if (temp.knowledgeMin>0.8 || temp.getNbTest()>=99)
								temp.resetReliability(9);
							else
								temp.resetReliability(0);
							agent.sequenceMemory.memoryF[0].get(l).initial().resetReliability(0);
						}
					}
				}
			}
		}
		
		
		//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		
		// generate second level memory map with informations from memory
		for (int l=0;l<agent.sequenceMemory.memoryT[1].size();l++){
			temp=agent.sequenceMemory.memoryT[1].get(l).composite();
			if (temp!=null){
				for (int i=0;i<InteractionList.length1;i++){
					for (int k=0;k<InteractionList.length2;k++){
						if (temp.pattern[i][k] * map[0][i][k] >= 0){
							memoryMap2[i][k]+=temp.pattern[i][k];
						}
						else{
							System.out.println("wrong connexion detected T2");
							if (temp.knowledgeMin>0.8 || temp.getNbTest()>=99)
								temp.resetReliability(9);
							else
								temp.resetReliability(0);
							agent.sequenceMemory.memoryT[1].get(l).initial().resetReliability(0);
						}
					}
				}
			}
		}
		
		for (int l=0;l<agent.sequenceMemory.memoryF[1].size();l++){
			temp=agent.sequenceMemory.memoryF[1].get(l).composite();
			if (temp!=null){
				for (int i=0;i<InteractionList.length1;i++){
					for (int k=0;k<InteractionList.length2;k++){
						if (temp.pattern[i][k] * map[0][i][k] <= 0){
							memoryMap2[i][k]-=temp.pattern[i][k];
						}
						else{
							System.out.println("wrong connexion detected F2");
							if (temp.knowledgeMin>0.8 || temp.getNbTest()>=99)
								temp.resetReliability(9);
							else
								temp.resetReliability(0);
							agent.sequenceMemory.memoryF[1].get(l).initial().resetReliability(0);
						}
					}
				}
			}
		}
		
		//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		
		// generate third level memory map with informations from memory
		for (int l=0;l<agent.sequenceMemory.memoryT[2].size();l++){
			temp=agent.sequenceMemory.memoryT[2].get(l).composite();
			if (temp!=null){
				for (int i=0;i<InteractionList.length1;i++){
					for (int k=0;k<InteractionList.length2;k++){
						if (temp.pattern[i][k] * map[0][i][k] >= 0){
							memoryMap3[i][k]+=temp.pattern[i][k];
						}
						else{
							System.out.println("wrong connexion detected T3");
							if (temp.knowledgeMin>0.8 || temp.getNbTest()>=99)
								temp.resetReliability(9);
							else
								temp.resetReliability(0);
							agent.sequenceMemory.memoryT[2].get(l).initial().resetReliability(0);
						}
					}
				}
			}
		}
		
		for (int l=0;l<agent.sequenceMemory.memoryF[2].size();l++){
			temp=agent.sequenceMemory.memoryF[2].get(l).composite();
			if (temp!=null){
				for (int i=0;i<InteractionList.length1;i++){
					for (int k=0;k<InteractionList.length2;k++){
						if (temp.pattern[i][k] * map[0][i][k] <= 0){
							memoryMap3[i][k]-=temp.pattern[i][k];
						}
						else{
							System.out.println("wrong connexion detected F3");
							if (temp.knowledgeMin>0.8 || temp.getNbTest()>=99)
								temp.resetReliability(9);
							else
								temp.resetReliability(0);
							agent.sequenceMemory.memoryF[2].get(l).initial().resetReliability(0);
						}
					}
				}
			}
		}
		
		//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		// add information from perception map and limit values to [-1;1]
		for (int i=0;i<InteractionList.length1;i++){
			for (int j=0;j<InteractionList.length2;j++){
				if (map[0][i][j]!=0){
					memoryMap1[0][i][j]=map[0][i][j];
					memoryMap2[i][j]=map[0][i][j];
					memoryMap3[i][j]=map[0][i][j];
				}
				
				memoryMap1[0][i][j]=Math.max(-1, Math.min(1,memoryMap1[0][i][j]));
				memoryMap2[i][j]=Math.max(-1, Math.min(1,memoryMap2[i][j]));
				memoryMap3[i][j]=Math.max(-1, Math.min(1,memoryMap3[i][j]));
			}
		}
	}


	//////////////////////////////////////////////////////////////////////////////////////////////////
	// get missing information for a sequence
	public float[][] getMissingEnv(Composite p){
		float[][] ret=new float[InteractionList.length1][InteractionList.length2];
		
		// compute prediction
		float prediction=p.prediction(memoryMap1[0]);          // prediction coefficient
		
		boolean env=false;			 // environment contains correlated elements
		for (int i=0;i<InteractionList.length1;i++){
			for (int j=0;j<InteractionList.length2;j++){
				if (map[0][i][j]!=0 && p.correlationC[i][j][1]>=1){
					env=true;
				}
			}
		}
		
		// if sequence cannot be predicted, or if the prediction reliability is low, a saccade is needed
		if ((prediction==0 || p.knowledgeMax>=0.8 && Math.abs(prediction)<0.2) && (!env || p.knowledgeMax<0.8)){
			for (int i=0;i<InteractionList.length1;i++){
				for (int j=0;j<InteractionList.length2;j++){
					if (p.correlationC[i][j][1]>=1 && Math.abs(p.pattern[i][j])==p.knowledgeMax) ret[i][j]=1;
					else ret[i][j]=0;
				}
			}
		}
		else{
			for (int i=0;i<InteractionList.length1;i++) for (int j=0;j<InteractionList.length2;j++) ret[i][j]=0;
		}
		
		// the returned vector gives the missing data on environmental context
		return ret;
	}

}

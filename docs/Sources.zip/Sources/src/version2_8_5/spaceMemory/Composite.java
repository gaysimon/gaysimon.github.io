package version2_8_5.spaceMemory;

import java.util.ArrayList;

import version2_8_5.Interface.InteractionList;
import version2_8_5.Interface.PrimitiveInteraction;

/**
 * Composite interaction, containing the sequence of primitive interaction and signatures
 * @author simon gay
 */
public class Composite {

	private PrimitiveInteraction[] sequence;	// sequence of primitive interactions
												// Note that the sequence is reversed (sequence[0] is the final interaction)
	
	private float valence;						// valence of this interaction
	
	private float lastPrediction;				// prediction of success
	
	private int lastIndex;						// indexes of composite interactions that
	private int pathIndex;						// match sub sequences of this interaction
	private int firstIndex;
	private int endIndex;
	
	///////////////////////////////////////////////////////////////////
	// signatures
	public float[][] pattern;			// condition pattern
	public float[][][] correlationC;	//  [][][0] -> correlation coef , [][][1] -> correlation Condition,
	
	public float[][] prediction;     	// prediction pattern
	public float[][][] correlationP; 	// [][][1] -> correlation Prediction
	
	public float knowledgeMax;       	// define the maximum correlated pattern coefficient
	public float knowledgeMin;      	// define the minimum correlated pattern coefficient
	
	///////////////////////////////////////////////////////////////////
	private int reliableT;				// reliability coefficients		
	private int reliableF;
	
	private int nbPathFail=0;
	private int nbTest=0;
	private int nbSuccess=0;

	private int counter=0;
	
	
	public static int reliabilitySize=10;
	
	
	////////////////////////////////////////////////////////////////////////////////////////////////////
	public Composite(PrimitiveInteraction[] seq, int lIndex,int pIndex, int fIndex, int eIndex){

		valence=0;

		sequence=new PrimitiveInteraction[seq.length];
		for (int i=0;i<seq.length;i++){
			sequence[i]=seq[i];
			valence+=seq[i].valence();
		}
		
		pattern=new float[InteractionList.length1][InteractionList.length2];
		correlationC=new float[InteractionList.length1][InteractionList.length2][2];
		
		prediction=new float[InteractionList.length1][InteractionList.length2];
		correlationP=new float[InteractionList.length1][InteractionList.length2][2];
		
		for (int i=0;i<InteractionList.length1;i++){
			for (int j=0;j<InteractionList.length2;j++){
				pattern[i][j]=0;
				prediction[i][j]=0;
				
				correlationC[i][j][0]=0;
				correlationC[i][j][1]=1;
				
				correlationP[i][j][0]=1;
				correlationP[i][j][1]=1;
			}
		}

		reliableT=0;
		reliableF=0;

		knowledgeMax=0;
		knowledgeMin=0;

		lastIndex=lIndex;
		pathIndex=pIndex;
		firstIndex=fIndex;
		endIndex=eIndex;
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// initialization functions
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	public void setReliability(int t, int f){
		reliableT=t;
		reliableF=f;
	}
	
	public void setCounters(int c, int f, int nbT, int nbS){
		counter=c;
		nbPathFail=f;
		nbTest=nbT;
		nbSuccess=nbS;
	}
	
	public void setExtrema(float min, float max){
		knowledgeMax=max;
		knowledgeMin=min;
	}
	
	public void initialize(){
		knowledgeMax=0;
		knowledgeMin=1;
		for (int i=0;i<InteractionList.length1;i++){
			for (int j=0;j<InteractionList.length2;j++){
				if (correlationC[i][j][1]>=1 && Math.abs(pattern[i][j])>knowledgeMax) knowledgeMax=Math.abs(pattern[i][j]);
				if (correlationC[i][j][1]>=1 && Math.abs(pattern[i][j])<knowledgeMin) knowledgeMin=Math.abs(pattern[i][j]);
			}
		}
	}

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// signatures related functions
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	// prediction of success of this interaction in context img
	public float prediction(float[][] img){
		float result=0;
		for (int i=0;i<InteractionList.length1;i++){
			for (int j=0;j<InteractionList.length2;j++){
				result+=pattern[i][j]*img[i][j];
			}
		}
		return result;
	}
	
	// update signatures weights according to the result res of enaction and a context img
	public void learn(float[][] img, boolean res){
		float result=0;
		float nb=0;
		
		// prediction
		for (int i=0;i<InteractionList.length1;i++){
			for (int j=0;j<InteractionList.length2;j++){
				result+=pattern[i][j]*img[i][j];
				nb+=Math.abs(img[i][j]);
			}
		}
		
		// define reliability
		if (res){
			if (Math.abs(result)>0.3){
				if (result>0.3 && reliableT<reliabilitySize) reliableT++;
			}
		}
		else{
			if (Math.abs(result)>0.3){
				if (result<-0.3 && reliableF<reliabilitySize) reliableF++;
			}
		}

		// update correlation
		int output=0;          // new output
		if (res) output= 1;
		else     output=-1;
		
		for (int i=0;i<InteractionList.length1;i++){
			for (int j=0;j<InteractionList.length2;j++){
				float input=  img[i][j];         // new input i
				if (input!=0){
					if ( output * correlationC[i][j][0]*input >=0){
						if (correlationC[i][j][1]>=1)
							correlationC[i][j][0]= (correlationC[i][j][0]*1 + output*input )/ (1+Math.abs(input));
					}
					else{
						correlationC[i][j][0]=0;
						correlationC[i][j][1]=0;
					}
				}
			}
		}
		
		if (nb>0){
			float delta=0;
			if (res) delta= 1-result/nb;
			else     delta=-1-result/nb;
			
			for (int i=0;i<InteractionList.length1;i++){
				for (int j=0;j<InteractionList.length2;j++){
					
					if (correlationC[i][j][1]>=1){
						if (img[i][j]!=0) pattern[i][j]+=0.1*img[i][j]*delta;
						pattern[i][j]=Math.min(1, Math.max(-1, pattern[i][j]));
					}
					else pattern[i][j]=0;
				}
			}
		}
		
		knowledgeMax=0;
		knowledgeMin=1;
		for (int i=0;i<InteractionList.length1;i++){
			for (int j=0;j<InteractionList.length2;j++){
				if (correlationC[i][j][1]>=1 && Math.abs(pattern[i][j])>knowledgeMax) knowledgeMax=Math.abs(pattern[i][j]);
				if (correlationC[i][j][1]>=1 && Math.abs(pattern[i][j])<knowledgeMin) knowledgeMin=Math.abs(pattern[i][j]);
			}
		}
		
		float sum=0;
		for (int i=0;i<InteractionList.length1;i++){
			for (int j=0;j<InteractionList.length2;j++){
				sum+=Math.abs(pattern[i][j]);
			}
		}
	}
	
	// update prediction signature
	public void learnPrediction(float[][] img, boolean res){
		if (res){
			for (int i=0;i<InteractionList.length1;i++){
				for (int j=0;j<InteractionList.length2;j++){
					if (img[i][j]!=0 && img[i][j]*prediction[i][j]>=0){
						if (correlationP[i][j][1]>=1){
							correlationP[i][j][0]=img[i][j];
							prediction[i][j]= (prediction[i][j]*1+img[i][j])/(1+1);
						}
						else correlationP[i][j][1]+=0.001;
					}
					else{
						correlationP[i][j][0]=0;
						correlationP[i][j][1]=0;
					}
				}
			}
		}
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// reliability management
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	// reset reliability
	public void resetReliability(int n){
		reliableT=n;
		reliableF=n;
	}
	
	public int getReliabilityT(){
		return reliableT;
	}
	
	public int getReliabilityF(){
		return reliableF;
	}
	
	public int getNbTest(){
		return nbTest;
	}
	
	public int getNbSuccess(){
		return nbSuccess;
	}
	
	// return true if the interaction has never failed
	public boolean isStillTrue(){
		return length()>1 && nbSuccess==nbTest;
	}
	
	// return true if the signature is uncorrelated
	public boolean isUncorrelated(){
		boolean ret=true;
		for (int i=0;i<InteractionList.length1;i++){
			for (int j=0;j<InteractionList.length2;j++){
				if (correlationC[i][j][1]>=1) ret=false;
			}
		}
		return ret;
	}
	
	// return true if the prediction signature is uncorrelated
	public boolean isUncorrelatedP(){
		boolean ret=true;
		for (int i=0;i<InteractionList.length1;i++){
			for (int j=0;j<InteractionList.length2;j++){
				if (correlationP[i][j][1]>=1) ret=false;
			}
		}
		return ret;
	}
	
	
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// sequence management
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	public int length(){
		return sequence.length;
	}
	
	// get interaction valence
	public float getValence(){
		return valence;
	}
	
	// get the ith element of the sequence
	public PrimitiveInteraction get(int i){
		return sequence[i];
	}
	
	// get the first element of the sequence
	public PrimitiveInteraction getFirst(){
		return sequence[length()-1];
	}
	
	// move forward in sequence
	public Composite getNext(PrimitiveInteraction inter, ArrayList<Composite> pList){
		if (length()<=1 || !getFirst().isEqual(inter)) return null;
		else{
			return pList.get(endIndex);
		}
	}
	
	//////////////////////////////////////////////////////
	// equality tests
	public boolean isEqual(PrimitiveInteraction inter){
		boolean equal=true;
		if (length()!=1) equal=false;
		else{
			if (!sequence[0].isEqual(inter)) equal=false;
		}
		return equal;
	}
	
	public boolean isEqual(PrimitiveInteraction[] seq){
		boolean equal=true;
		if (length()!=seq.length) equal=false;
		else{
			for (int i=0;i<length();i++){
				if (!sequence[i].isEqual(seq[i])) equal=false;
			}
		}
		return equal;
	}
	
	public boolean isEqual(Composite p){
		return this.isEqual(p.sequence);
	}
	
	// return true if this = [path.path;f]
	public boolean isEqual(Composite path, PrimitiveInteraction f){
		return this.isPathEqual(path.sequence) && sequence[0].isEqual(f);
	}
	
	//////////////////////////////////////////////////////
	// comparative tests
	
	public boolean isPathEqual(PrimitiveInteraction[] seq){
		boolean equal=true;
		if (this.length()!=seq.length) equal=false;
		else{
			for (int i=1;i<this.length();i++){
				if (!sequence[i].isEqual(seq[i])) equal=false;
			}
		}
		return equal;
	}
	
	// return true if this sequence begins with p
	public boolean beginWith(Composite p){
		if (p.length()>this.length()) return false;
		else{
			boolean ret=true;
			int diff=this.length()-p.length();
			for (int i=0;i<p.length();i++){
				if (!p.get(i).isEqual(this.get(i+diff))) ret=false;
			}
			return ret;
		}
	}
	
	public boolean endWith(Composite p){
		if (p.length()>this.length()) return false;
		else{
			boolean ret=true;
			for (int i=0;i<p.length();i++){
				if (!p.get(i).isEqual(this.get(i))) ret=false;
			}
			return ret;
		}
	}
	
	// return true if this sequence (with last element replaced by f) ends with p
	public boolean endWith(Composite p, PrimitiveInteraction f){
		if (p.length()>this.length()) return false;
		else{
			boolean ret=true;
			for (int i=1;i<p.length();i++){
				if (!p.get(i).isEqual(this.get(i))) ret=false;
			}
			if (!p.get(0).isEqual(f)) ret=false;
			return ret;
		}
	}
	

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// tests on interactions
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	// return the result of the composite interaction (if completed)
	public int check(PrimitiveInteraction[] timeline, boolean increment){
		int ret=1;  // 2=success, 1=nothing, 0=failure
		boolean match=true;
		
		if (timeline[length()-1]!=null){
			for (int i=1;i<sequence.length;i++){
				if (!get(i).isEqual(timeline[i])) match=false;
			}
			if (!get(0).isEqual(timeline[0]) && !get(0).isAlternate(timeline[0])) match=false;
		}
		else match=false;
		
		if (match){
			if (get(0).isEqual(timeline[0])){
				ret=2;
				if (increment && nbTest<99 && nbSuccess<99) nbSuccess++;
			}
			else{
				ret=0;
				nbSuccess=0;
			}
			if (increment && nbTest<99) nbTest++;
		}
		return ret;
	}
	
	// check if every subsequences are in list
	public boolean isValide(ArrayList<MemoryElement> list){
		if (length()==1) return true;
		else{
			boolean ret=true;
			for (int i=1;i<length();i++){
				if (ret){
					ret=false;
					int j=0;
					
					while (j<list.size() && !ret){
						if (list.get(j).composite().length()==i){
							if (this.beginWith(list.get(j).composite())) ret=true;
						}
						j++;
					}
				}
			}
			return ret;
		}
	}
	
	// return true if the sequence or a sub path is in list
	public boolean isInvalide(ArrayList<MemoryElement> list){
		boolean ret=false;
		int i=0;
		while (i<length()-1 && !ret){
			int j=0;
			while (j<list.size() && !ret){
				if (list.get(j).composite().length()==i+1){
					if (this.beginWith(list.get(j).composite())) ret=true;
				}
				j++;
			}
			i++;
		}
		return ret;
	}
	
	// return true if the signature is not coherent
	public boolean isFalseAT(ArrayList<Composite> compositeList){
		if (length()==1) return false;
		else{
			float sum=0;
			for (int i=0;i<InteractionList.length1;i++){
				for (int j=0;j<InteractionList.length2;j++){
					sum+=compositeList.get(pathIndex).pattern[i][j]*compositeList.get(lastIndex).pattern[i][j];
				}
			}
			
			boolean ret=false;
			if (nbSuccess!=nbTest && sum>0) ret=true;
			if (nbSuccess==nbTest && sum<0) ret=true;
			if (nbSuccess!=nbTest && getReliabilityF()==0) ret=true;
			if (nbSuccess==nbTest && compositeList.get(pathIndex).isUncorrelated()) ret=true;
			
			return ret;
		}
	}
	
	
	// check if composites are compatible
	public boolean isCompatible(Composite p){
		boolean res=true;
		for (int i=0;i<InteractionList.length1;i++){
			for (int j=0;j<InteractionList.length2;j++){
				if (this.pattern[i][j]*p.pattern[i][j]<0) res=false;
			}
		}
		return res;
	}
	

	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// lock management
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	public void setPathFail(){
		nbPathFail++;
		if (nbPathFail>10){
			nbPathFail=0;
			counter=100;
		}
	}
	
	public boolean isUnlocked(){
		return counter==0;
	}
	
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// getters
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	public String name(){
		String ret="";
		for (int i=length()-1;i>=0;i--){
			ret+=get(i).name()+" ";
		}
		return ret;
	}
	
	public String getName(){
		String ret="";
		for (int i=length()-1;i>=0;i--){
			ret+=get(i).name()+" ";
		}
		ret+=" ("+nbSuccess+"/"+nbTest+") "+nbPathFail+", "+counter+" ; "+this.getReliabilityT()+", "+this.getReliabilityF();
		return ret;
	}
	
	public boolean getReliabilityT(int i){
		return reliableT>=i;
	}
	public boolean getReliabilityF(int i){
		return reliableF>=i;
	}
	
	public float lastPrediction(){
		return lastPrediction;
	}
	public void setLastPrediction(float p){
		lastPrediction=p;
	}
	
	public int lastIndex(){
		return lastIndex;
	}
	public int firstIndex(){
		return firstIndex;
	}
	public int pathIndex(){
		return pathIndex;
	}
	
	public int getNbPathFail(){
		return nbPathFail;
	}
	public int getCounter(){
		return counter;
	}
}
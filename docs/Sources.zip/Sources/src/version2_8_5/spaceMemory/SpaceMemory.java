package version2_8_5.spaceMemory;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;

import version2_8_5.Interface.InteractionList;
import version2_8_5.Interface.PrimitiveInteraction;
import version2_8_5.platform.Agent;
import version2_8_5.platform.Observer;


/**
 * Main class of the space memory mechanism
 * @author simon gay
 */
public class SpaceMemory {

	private Agent agent;

	public ArrayList<Composite> compositeList;			// list of discovered interactions
	private ArrayList<Float[]> predictions;
	private PrimitiveInteraction[] timeline;
	
	public static int timeSize=2;					// maximum length for interactions
	
	public static boolean load=false;			// if true, load an agent file
	
	
	public SpaceMemory(Agent a){
		agent=a;
		
		compositeList=new ArrayList<Composite>();
		predictions=new ArrayList<Float[]>();

		// timeline
		timeline=new PrimitiveInteraction[timeSize];
		for (int i=0;i<timeSize;i++){
			timeline[i]=null;
		}
		
		if (load) load();
		else loadPrimitives();
	}
	
	
	////////////////////////////////////////////////////////////
	// update timeline and make predictions
	public void nextStep(PrimitiveInteraction interaction){
		
		// update sequence memory
		agent.sequenceMemory.updateMemory(interaction);
		
		// update timeline
		for (int i=timeSize-1;i>0;i--){
			timeline[i]=timeline[i-1];
		}
		timeline[0]=interaction;

		// read timeline and learn new sequences
		int t=0;
		while (t<timeSize && timeline[t]!=null){
			PrimitiveInteraction[] temp=new PrimitiveInteraction[t+1];
			for (int i=0;i<=t;i++) temp[i]=timeline[i];
			learn(temp);
			t++;
		}
		
		// display timeline
		System.out.print("----- timeline : ");
		for (int i=timeSize-1;i>=0;i--){
			if (timeline[i]!=null) System.out.print(timeline[i].name()+" , ");
		}
		System.out.println();

		
		// update environments
		agent.environmentMemory.updateEnvironment(interaction);
		
		// update colliculus
		agent.colliculus.updatePoints();
		
		// make predictions
		for (int i=0;i<predictions.size();i++){
			predictions.get(i)[0]=compositeList.get(i).prediction(agent.environmentMemory.map[0]);
			
			compositeList.get(i).setLastPrediction(Math.min(1, Math.max(-1,compositeList.get(i).prediction(agent.environmentMemory.map[0]))));
			
			predictions.get(i)[1]=compositeList.get(i).prediction(agent.environmentMemory.memoryMap1[0]);
			predictions.get(i)[2]=compositeList.get(i).prediction(agent.environmentMemory.memoryMap2);
		}
		
		// update possible/impossible sequence lists
		agent.sequenceMemory.updateSequences(compositeList,predictions);
		
		// learn composites
		learnComposite();

	}
	
	
	////////////////////////////////////////////////////////////////////
	// add new primitives, sequences and composites
	private int learn(PrimitiveInteraction[] seq){

		// sequences and composites
		int found=-1;
		int i=0;
		while (i<compositeList.size() && found==-1){
			if (compositeList.get(i).length()==seq.length){
				if (compositeList.get(i).isEqual(seq)) found=i;
			}
			i++;
		}
		
		if (found==-1){
			// add composite
			PrimitiveInteraction[] seqTemp1=new PrimitiveInteraction[seq.length-1];
			for (int j=0;j<seq.length-1;j++) seqTemp1[j]=seq[j+1];
			PrimitiveInteraction[] seqTemp2=new PrimitiveInteraction[seq.length-1];
			for (int j=0;j<seq.length-1;j++) seqTemp2[j]=seq[j];
			
			Composite temp=new Composite(seq, getCompositeIndexOf(seq[0])			  ,getCompositeIndexOf(seqTemp1),
										  getCompositeIndexOf(seq[seq.length-1]),getCompositeIndexOf(seqTemp2));
			
			// check if new composite does not end with always true
			boolean endWithAT=false;
			i=0;
			while(i<compositeList.size() && !endWithAT){
				if (compositeList.get(i).isStillTrue()){
					if (temp.endWith(compositeList.get(i))) endWithAT=true;
				}
				i++;
			}
			
			if (!endWithAT){
				compositeList.add(temp);
				predictions.add(new Float[3]);
				for (i=0;i<3;i++) predictions.get(predictions.size()-1)[i]=0f;
			}
		}

		return found;
	}
	
	
	// learn composite of the last interaction
	private void learnComposite(){
		
		int result;
		for (int i=0;i<compositeList.size();i++){
			
			result=compositeList.get(i).check(timeline,true);
			
			// learn composite of completed sequences
			if (result==2){
				compositeList.get(i).learn(agent.environmentMemory.map[compositeList.get(i).length()], true);
				compositeList.get(i).learnPrediction(agent.environmentMemory.map[0], true);
			}
			else if (result==0){
				compositeList.get(i).learn(agent.environmentMemory.map[compositeList.get(i).length()], false);
				compositeList.get(i).learnPrediction(agent.environmentMemory.map[0], false);
			}
		}
	}
	
	/////////////////////////////////////////////////////////////////////
	
	public int getCompositeIndexOf(PrimitiveInteraction[] interList){
		int ret=-1;
		int i=0;
		while (i<compositeList.size() && ret==-1){
			if (compositeList.get(i).isEqual(interList)) ret=i;
			i++;
		}
		return ret;
	}
	
	public int getCompositeIndexOf(PrimitiveInteraction inter){
		int ret=-1;
		int i=0;
		while (i<compositeList.size() && ret==-1){
			if (compositeList.get(i).isEqual(inter)) ret=i;
			i++;
		}
		return ret;
	}

	
	// get the best saccade to fill missing perception
	public Composite getMissingSaccade(float[][] missing){
		float matching=0;
		
		float pmax=-1000;
		int imax=-1;

		for (int l=0;l<compositeList.size();l++){
			matching=0;
			
			// saccade must be possible
			if (compositeList.get(l).isValide(agent.sequenceMemory.sequencesT[1])
			  && !compositeList.get(l).isUncorrelatedP()){
			
				for (int i=0;i<InteractionList.length1;i++){
					if (missing[i][0]>0){
						if (compositeList.get(l).correlationP[i][0][1]>=1
							&& compositeList.get(l).correlationC[i][0][0]>=0
							) matching+=1;
					}
					if (missing[i][1]>0){
						if (compositeList.get(l).correlationP[i][1][1]>=1
							&& compositeList.get(l).correlationC[i][0][0]>=0
							) matching+=1;
					}
				}

				if (matching!=0){
					if (matching>pmax){
						pmax=matching;
						imax=l;
					}
				}
			}
		}

		if (imax==-1) return null;
		else return compositeList.get(imax);
	}
	
	
	/////////////////////////////////////////////////////////////////////
	public void save() {
		System.out.println("=====================prepare to save...======================");
		
		// save second level composites
		
		String fileName = Observer.path+"spaceMemory/spaceMemoryV2_8_5 "+timeSize+" "+agent.getIdent()+".txt";
		
		try {
			PrintWriter file  = new PrintWriter(new FileWriter(fileName));
			
			// save counter
			file.println(agent.action.getNbStep());
			file.println("***");
			
			// save composites
			for (int i=0;i<compositeList.size();i++){
				
				// save the sequence
				for (int j=0;j<compositeList.get(i).length();j++){
					for (int k=0;k<agent.interactionList.nbInteraction();k++){
						if (compositeList.get(i).get(j).isEqual(agent.interactionList.getInteraction(k))) file.print(k+" ");
					}
				}
				file.println();
				
				// save reliability, nbSuccess and nbTest
				file.println(compositeList.get(i).getReliabilityT()+" "+compositeList.get(i).getReliabilityF()+" "
						    +compositeList.get(i).knowledgeMin+" "+compositeList.get(i).knowledgeMax);
				file.println(compositeList.get(i).getNbSuccess()+" "+compositeList.get(i).getNbTest()+" "
						    +compositeList.get(i).getNbPathFail()+" "+compositeList.get(i).getCounter());
				
				// save condition composite
				for (int j=0;j<InteractionList.length1;j++){
					for (int k=0;k<InteractionList.length2;k++){
						file.print(compositeList.get(i).pattern[j][k]+" ");
					}
				}
				file.println();
				
				// save prediction composite
				for (int j=0;j<InteractionList.length1;j++){
					for (int k=0;k<InteractionList.length2;k++){
						file.print(compositeList.get(i).prediction[j][k]+" ");
					}
				}
				file.println();
				
				// save correlation composites
				for (int l=0;l<2;l++){
					for (int j=0;j<InteractionList.length1;j++){
						for (int k=0;k<InteractionList.length2;k++){
							file.print(compositeList.get(i).correlationC[j][k][l]+" ");
						}
					}
					file.println();
				}
				for (int l=0;l<2;l++){
					for (int j=0;j<InteractionList.length1;j++){
						for (int k=0;k<InteractionList.length2;k++){
							file.print(compositeList.get(i).correlationP[j][k][l]+" ");
						}
					}
					file.println();
				}
			}
			file.close();
			System.out.println("memory file saved");
		}
		catch (Exception e) {e.printStackTrace();}
	}
	
	// load the set of primitive interactions
	private void loadPrimitives(){
		
		for (int i=0;i<agent.interactionList.nbInteraction();i++){
			PrimitiveInteraction[] temp=new PrimitiveInteraction[1];
			temp[0]=agent.interactionList.getInteraction(i);
			learn(temp);
		}
	}
	
	
	// load composite interactions with signatures
	public void load(){

		// open file
		String fileName = Observer.path+"spaceMemory/spaceMemoryV2_8_5 "+timeSize+" "+agent.getIdent()+".txt";
		String[] elements;

		try {
			InputStream ips=new FileInputStream(fileName); 
			InputStreamReader ipsr=new InputStreamReader(ips);
			BufferedReader br=new BufferedReader(ipsr);
			String line;

			// set agent's step counter
			line=br.readLine();
			agent.action.setNbstep(Integer.parseInt(line));

			// separator
			line=br.readLine();

			// load composite interactions and signatures
			while ((line=br.readLine())!=null){
				elements=line.split(" ");

				// build sequences
				PrimitiveInteraction[] temp=new PrimitiveInteraction[elements.length];
				for (int i=0;i<elements.length;i++){
					temp[i]=agent.interactionList.getInteraction(Integer.parseInt(elements[i]));
				}
				learn(temp);

				// set reliability and counters
				line=br.readLine();
				elements=line.split(" ");
				compositeList.get(compositeList.size()-1).setReliability(Integer.parseInt(elements[0]),Integer.parseInt(elements[1]) );
				compositeList.get(compositeList.size()-1).setExtrema(Float.parseFloat(elements[2]), Float.parseFloat(elements[3]));
				
				line=br.readLine();
				elements=line.split(" ");
				compositeList.get(compositeList.size()-1).setCounters(Integer.parseInt(elements[3]),Integer.parseInt(elements[2]),
						                                          Integer.parseInt(elements[1]),Integer.parseInt(elements[0]) );
				
				// get condition composite
				line=br.readLine();
				elements=line.split(" ");
				for (int i=0;i<InteractionList.length1;i++){
					for (int j=0;j<InteractionList.length2;j++){
						compositeList.get(compositeList.size()-1).pattern[i][j]=Float.parseFloat(elements[j+2*i]);
					}
				}
				
				// get prediction composite
				line=br.readLine();
				elements=line.split(" ");
				for (int i=0;i<InteractionList.length1;i++){
					for (int j=0;j<InteractionList.length2;j++){
						compositeList.get(compositeList.size()-1).prediction[i][j]=Float.parseFloat(elements[j+2*i]);
					}
				}
				
				// load correlation
				for (int l=0;l<2;l++){
					line=br.readLine();
					elements=line.split(" ");
					for (int i=0;i<InteractionList.length1;i++){
						for (int j=0;j<InteractionList.length2;j++){
							compositeList.get(compositeList.size()-1).correlationC[i][j][l]=Float.parseFloat(elements[j+2*i]);
						}
					}
				}
				for (int l=0;l<2;l++){
					line=br.readLine();
					elements=line.split(" ");
					for (int i=0;i<InteractionList.length1;i++){
						for (int j=0;j<InteractionList.length2;j++){
							compositeList.get(compositeList.size()-1).correlationP[i][j][l]=Float.parseFloat(elements[j+2*i]);
						}
					}
				}
			}

			br.close();
		}
		catch (Exception e) {
			System.out.println(e);
		}
	}
}

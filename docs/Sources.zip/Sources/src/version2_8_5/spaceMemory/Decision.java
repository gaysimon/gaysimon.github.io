package version2_8_5.spaceMemory;

import java.util.ArrayList;

import version2_8_5.Interface.InteractionList;
import version2_8_5.Interface.PrimitiveInteraction;
import version2_8_5.platform.Agent;

/**
 * Decision system.
 * This class selects the next intended interactions
 * @author simon
 */
public class Decision {

	private Agent agent;

	private Composite lastDecision;				// last selected composite interaction
	private int decisionIndex;					// index of lastDecision's execution
	
	private Composite saccade;					// last selected epistemic interaction
	private int saccadeIndex;					// index of epistemic interaction's execution
	
	private boolean failed;						// result of the last enaction
	private PrimitiveInteraction enacted;
	private PrimitiveInteraction intention;
	
	private boolean isSaccade;					// define if the last enacted interaction is an epistemic interaction
	
	public Decision(Agent a){
		agent=a;

		lastDecision=null;
		decisionIndex=-1;
		
		saccade=null;
		saccadeIndex=-1;
		
		isSaccade=false;
	}
	
	/**
	 * decision of the next action
	 * @return the intended interaction
	 */
	public PrimitiveInteraction decision(){
		
		System.out.println();System.out.println();

		
		///////////////////////////////////////////////////////////////////////////////////////////
		// if last intended interaction failed, stop decision cycle
		if (failed && !isSaccade){
			
			// case of an interaction considered as always true
			if (lastDecision.isStillTrue() && lastDecision.getNbTest()>10){
				
				if (lastDecision.prediction(agent.environmentMemory.map[lastDecision.length()-decisionIndex-1])>=0){
					for (int i=0;i<InteractionList.length1;i++){
						for (int j=0;j<InteractionList.length2;j++){
							if (agent.environmentMemory.map[lastDecision.length()-decisionIndex-1][i][j]*lastDecision.correlationC[i][j][0]>0){
								lastDecision.pattern[i][j]=0;
								lastDecision.correlationC[i][j][0]=0;
								lastDecision.correlationC[i][j][1]=0;
							}
						}
					}
				}
				
				if (lastDecision.prediction(agent.environmentMemory.memoryMap1[lastDecision.length()-decisionIndex-1])>0){
					for (int i=0;i<InteractionList.length1;i++){
						for (int j=0;j<InteractionList.length2;j++){
							if (agent.environmentMemory.memoryMap1[lastDecision.length()-decisionIndex-1][i][j]*lastDecision.correlationC[i][j][0]>0){
								lastDecision.pattern[i][j]=0;
								lastDecision.correlationC[i][j][0]=0;
								lastDecision.correlationC[i][j][1]=0;
							}
						}
					}
				}
			}
			
			// stop decision cycle
			decisionIndex=-1;
			lastDecision.setPathFail();
			System.out.println(" last action failed ");
		}
		
		
		///////////////////////////////////////////////////////////////////////////////////////////
		// if saccade completed, check decision
		if (decisionIndex>=0 && saccadeIndex==-1){
			
			saccadeIndex=-2;
			
			float predict=lastDecision.prediction(agent.environmentMemory.memoryMap2);
			System.out.println("predict "+predict);
			if (predict<0){
				decisionIndex=-1; 
			}
		}
		
		
		///////////////////////////////////////////////////////////////////////////////////////////
		// selection of a new interaction
		if (decisionIndex==-1 && saccadeIndex<0){
			
			// select a new interaction
			if (decisionIndex==-1){
				ArrayList<Composite> candidates=agent.sequenceMemory.getCandidates();
				lastDecision=selectInteraction(candidates);
				decisionIndex=lastDecision.length()-1;
				System.out.println("Interaction selected : "+lastDecision.name());
			}
			
			// check if a saccade is needed
			isSaccade=false;
			float[][] missing=agent.environmentMemory.getMissingEnv(lastDecision);
			saccade=agent.spaceMemory.getMissingSaccade(missing);
			if (saccade!=null){
				saccadeIndex=saccade.length()-1;
				System.out.println("saccade needed : "+saccade.name());
			}
		}
		
		
		///////////////////////////////////////////////////////////////////////////////////////////

		//agent.observer.trace();
		
		// get the next intended primitive interaction
		if (saccadeIndex>=0){				// enact saccade
			isSaccade=true;
			System.out.println("%%%%%%%%%%%% action from saccade");
			intention=saccade.get(saccadeIndex);
			saccadeIndex--;
			System.out.println("%%%%%%%%%%%% action from saccade");
		}
		else{								// enact the selected interaction
			isSaccade=false;
			System.out.println("%%%%%%%%%%%% action from space memory");
			intention=lastDecision.get(decisionIndex);
			decisionIndex--;
			System.out.println("%%%%%%%%%%%% action from space memory : "+intention.getName());
		}
		
		////////////////////////////////////////////////////////
		// return the next primitive interaction of the sequence
		return intention;
	}
	
	
	////////////////////////////////////////////////////////////////////////////////////
	// get the result of enaction
	public void learn(PrimitiveInteraction inter){
		
		System.out.println("enacted : "+inter.getName());
		enacted=inter;
		
		if (inter.isEqual(intention)) failed=false;
		else failed=true;
	}
	
	
	// select the best interaction in the list of candidates
	private Composite selectInteraction(ArrayList<Composite> candidates){
		Composite ret=candidates.get(0);
		float max=-1000;
		
		for (int l=0;l<candidates.size();l++){
			float sum=0;
			
			// first detect interactions that are related to themselves (interactions contained in their signatures)
			for (int i=0;i<InteractionList.length1;i++){
				for (int j=0;j<InteractionList.length2;j++){
					sum+=Math.abs(candidates.get(l).pattern[i][j]*candidates.get(l).prediction[i][j]);
				}
			}
			
			// select the interaction with the highest valence
			if (sum<=0 || candidates.get(l).getValence()>0){
				if ( candidates.get(l).getValence()>max){
					max=candidates.get(l).getValence();
					ret=candidates.get(l);
				}
			}
		}

		return ret;
	}
	
	
	/////////////////////////////////////////////////////////////////
	
	public boolean failed(){
		return failed;
	}
	
	public Composite getLastDecision(){
		return lastDecision;
	}
	
	public PrimitiveInteraction getEnacted(){
		return enacted;
	}
	
	public PrimitiveInteraction getIntention(){
		return intention;
	}
}

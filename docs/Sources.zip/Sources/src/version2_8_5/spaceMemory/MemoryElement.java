package version2_8_5.spaceMemory;

/**
 * A memory element contains a tracked interaction and the initially detected interaction
 * @author simon gay
 */
import java.util.ArrayList;

import version2_8_5.Interface.PrimitiveInteraction;

public class MemoryElement {

	private Composite composite;				// current interaction
	private Composite initialComposite;			// initially detected interaction
	
	public MemoryElement(Composite p){
		composite=p;
		initialComposite=p;
	}
	
	public MemoryElement(Composite p, Composite pi){
		composite=p;
		initialComposite=pi;
	}
	
	public boolean isEqual(MemoryElement mElt){
		return this.composite.isEqual(mElt.composite);
	}
	
	// update the interaction (if possible)
	public MemoryElement nextStep(PrimitiveInteraction inter, ArrayList<Composite> patternList){
		if (composite.getNext(inter,patternList)!=null){
			return new MemoryElement(composite.getNext(inter,patternList), initialComposite);
		}
		else return null;
	}
	
	public Composite composite(){
		return composite;
	}
	
	public Composite initial(){
		return initialComposite;
	}
	
}

package version2_8_5.environment;

/**
 * representation of a physical agent in its environment
 * @author simon gay
 */
public class Robot {

	private Environment env;

	private float px;								// position (x,y) in grid cell unit
	private float py;
	
	private float rz;								// orientation rz in radius
	
	//////////////////////////////////////////////////////////////////////
	// sensors and "leds"
	public boolean bump;
	public boolean touch;
	public boolean wall;
	public boolean[] display;
	//--------------------------------------------------------------------
	
	public Robot(){
		
		// initialization of sensors
		bump=false;
		touch=false;
		wall=false;
		
		display=new boolean[3];
		display[0]=false;
		display[1]=false;
		display[2]=false;
	}
	
	public void setEnvironment(Environment e){
		env=e;
	}
	
	// activate the robot
	public void move(double[] act){
		
		////////////////////////////////////////////////////////////////////
		// movements
		double orientation=rz;
		
		px+=  act[0]*Math.sin(orientation)+act[1]*Math.cos(orientation);
		py+=  act[0]*Math.cos(orientation)+act[1]*Math.sin(orientation);
		
		rz+=act[2];
		if (rz<0) rz+=2*Math.PI;
		if (rz>=2*Math.PI) rz-=2*Math.PI;
		
		touch=false;
		bump=false;
		wall=false;
		
		////////////////////////////////////////////////////////////////////
		// collisions
		
		int i=Math.round(px);
		int j=Math.round(py);
		
		// north blocks
		if (py>env.m_h-1) py-=py-(env.m_h-1);
		if (j+1<env.m_h){
			if (!env.isWalkthroughable(i,j+1) && (j-py<0) ){
				py-=py-j;
				if (rz>=  Math.PI/4 && rz<3*Math.PI/4){
					bump=true;
				}
			}
		}
				
		// south blocks
		if (py<=0) py=0;
		if (j-1>=0){
			if (!env.isWalkthroughable(i,j-1) && (py-j<0) ){
				py+=j-py;
				if (rz>=5*Math.PI/4 && rz<7*Math.PI/4){
					bump=true;
				}
			}
		}
				
		// east blocks
		if (px>env.m_w-1) px-=px-(env.m_w-1);
		if (i+1<env.m_w){
			if (!env.isWalkthroughable(i+1,j) && (i-px<0) ){
				px-=px-i;
				if (rz>=7*Math.PI/4 || rz<  Math.PI/4){
					bump=true;
				}
			}
		}
		
		// West blocks
		if (px<=0) px=0;
		if (i-1>=0){
			if (!env.isWalkthroughable(i-1,j) && (px-i<0) ){
				px+=i-px;
				if (rz>=3*Math.PI/4 && rz<5*Math.PI/4){
					bump=true;
				}
			}
		}	
		
		if (bump){
			try{Thread.currentThread();
				Thread.sleep(20);}
			catch(Exception ie){}
		}/**/
		
		////////////////////////////////////////////////////////////////////
		// feel neighbor blocks
		display[0]=false;
		display[1]=false;
		display[2]=false;
		if (act[3]==1){                    // feel forward
			if (rz>=  Math.PI/4 && rz<3*Math.PI/4){ if (env.isWall(i,j+1)) touch=true;}
			if (rz>=5*Math.PI/4 && rz<7*Math.PI/4){ if (env.isWall(i,j-1)) touch=true;}
			if (rz>=7*Math.PI/4 || rz<  Math.PI/4){ if (env.isWall(i+1,j)) touch=true;}
			if (rz>=3*Math.PI/4 && rz<5*Math.PI/4){ if (env.isWall(i-1,j)) touch=true;}
			display[0]=true;
		}
		if (act[3]==2){                    // feel left
			if (rz>=  Math.PI/4 && rz<3*Math.PI/4){ if (env.isWall(i-1,j)) touch=true;}
			if (rz>=5*Math.PI/4 && rz<7*Math.PI/4){ if (env.isWall(i+1,j)) touch=true;}
			if (rz>=7*Math.PI/4 || rz<  Math.PI/4){ if (env.isWall(i,j+1)) touch=true;}
			if (rz>=3*Math.PI/4 && rz<5*Math.PI/4){ if (env.isWall(i,j-1)) touch=true;}
			display[1]=true;
		}
		if (act[3]==3){                    // feel right
			if (rz>=  Math.PI/4 && rz<3*Math.PI/4){ if (env.isWall(i+1,j)) touch=true;}
			if (rz>=5*Math.PI/4 && rz<7*Math.PI/4){ if (env.isWall(i-1,j)) touch=true;}
			if (rz>=7*Math.PI/4 || rz<  Math.PI/4){ if (env.isWall(i,j-1)) touch=true;}
			if (rz>=3*Math.PI/4 && rz<5*Math.PI/4){ if (env.isWall(i,j+1)) touch=true;}
			display[2]=true;
		}
		
		// uncomment for delay when the agent uses "touch" interaction
		/*if (act[3]>0){
			try{Thread.currentThread();
				Thread.sleep(1);}
			catch(Exception ie){}
		}/**/
	}
	
	
	// finalize the movement and round position
	public void center(){
		px=Math.round(px);
		py=Math.round(py);
		
		if (rz>=  Math.PI/4 && rz<3*Math.PI/4){
			rz=(float) (  Math.PI/2);
			if (env.isWall(px,py+1) ){
				wall=true;
			}
		}
		if (rz>=3*Math.PI/4 && rz<5*Math.PI/4){
			rz=(float) (  Math.PI  );
			if (env.isWall(px-1,py) ){
				wall=true;
			}
		}
		if (rz>=5*Math.PI/4 && rz<7*Math.PI/4){
			if (env.isWall(px,py-1) ){
				wall=true;
			}
		}
		if (rz>=7*Math.PI/4 || rz<  Math.PI/4){
			rz= 0;
			if (env.isWall(px+1,py) ){
				wall=true;
			}
		}
	}
	
	
	///////////////////////////////////////////////////////////////////////////////
	
	public float getpx(){ return px;}
	public float getpy(){ return py;}
	public float getrz(){ return rz;}
	
	public void setPosition(float x, float y, float theta){
		px=x;
		py=y;
		rz=theta;
	}
}

package version2_8_5.environment;

import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.File;

import javax.swing.JFileChooser;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import version2_8_5.platform.PrintableFrame;

/**
 * Display the environment
 * @author simon gay, olivier georgeon
 */
public class EnvironnementFrame extends PrintableFrame implements ActionListener{
	
	private static final long serialVersionUID = 1L;
	
	private Environment m_env;
	private EnvironnementPanel m_envp;
	
	
	/////////////////////////////////////////////////
	private final JMenu m_file 		= new JMenu("File");
	private final JMenuItem m_loadBoard           		= new JMenuItem("Choose Board...");

	private final JFileChooser m_chooser 			= new JFileChooser();
	private final JFileChooser m_boardChooser 		= new JFileChooser(); // Uses specific chooser so that it remembers the path
	
	private final MyFileFilter m_fileFilter 		= new MyFileFilter();
	//////////////////////////////////////////
	
	
    public EnvironnementFrame(Environment env,EnvironnementPanel panel){
    	super();
    	this.setTitle(Environment.WindowTitle);
    	this.setSize(670, 610);
    	this.setLocationRelativeTo(null);               
    	this.setVisible(true);
    	printable=true;
    	m_env=env;
    	m_envp = panel;

    	getContentPane().add(m_envp);
    	configureMenu();

		indexImage=0;
		
		getContentPane().repaint();
		m_envp.repaint();

    }
    
	/**
	 * Draw the Menus
	 * @author mchohen
	 * @author mfriedrich
	 * @author ogeorgeon 
	 */
	private void configureMenu()
	{
		// mnemonics...
		m_file.setMnemonic(KeyEvent.VK_F);
		m_loadBoard.setMnemonic(KeyEvent.VK_L);

		// file menu...
		m_file.add(m_loadBoard);
		m_loadBoard.addActionListener(this);

		// menu bar...
		JMenuBar bar = new JMenuBar();
		bar.add(m_file);
		this.setJMenuBar(bar);
		
		
		// bottom panel
		JPanel buttonPanel = new JPanel();

		buttonPanel.addKeyListener(this);

		m_chooser.setFileFilter(m_fileFilter);
		m_boardChooser.setFileFilter(m_fileFilter);
	}
    
    
	
	public void drawPDF(Graphics g){
		m_envp.drawPDF(g);
	}
	
    public void repaint(){
    	m_envp.repaint();
    }

	public void actionPerformed(ActionEvent e){
		// Load Board
		if (e.getSource() == m_loadBoard)
		{
			m_fileFilter.set(".TXT", "Board Files");
			m_boardChooser.setVisible(true);
			int returnVal = m_boardChooser.showOpenDialog(this);
			if(returnVal == JFileChooser.APPROVE_OPTION) 
			{
				try
				{
					File boardFile = m_boardChooser.getSelectedFile();
					
					m_env.platform().resetList();
					
					m_env.init(boardFile.getAbsolutePath()); 
				}
				catch (Exception ex)
				{
				JOptionPane.showMessageDialog(this, 
					"Invalid board file!\n" + 
					ex.getClass().toString() + ": " + ex.getMessage(),
					"Error!", 
					JOptionPane.ERROR_MESSAGE);
				}
			}			
		}
	}

}

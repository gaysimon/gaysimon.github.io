package version2_8_6.Interface;

import java.util.ArrayList;

/**
 * This class define the initial set of primitive interactions
 * @author simon gay
 */
public class InteractionList {

	private ArrayList<PrimitiveInteraction> primitiveList;
	
	public static int length1=3;		// nb of primitive interactions
	public static int length2=2;
	
	public InteractionList(){
		
		primitiveList=new ArrayList<PrimitiveInteraction>();
		
		primitiveList.add(new PrimitiveInteraction("-",":"));
		primitiveList.add(new PrimitiveInteraction("-","|"));
		
		primitiveList.add(new PrimitiveInteraction("\\",":"));
		primitiveList.add(new PrimitiveInteraction("\\","|"));
		
		primitiveList.add(new PrimitiveInteraction("/",":"));
		primitiveList.add(new PrimitiveInteraction("/","|"));
		
		primitiveList.add(new PrimitiveInteraction("v","'"));
		primitiveList.add(new PrimitiveInteraction("v","!"));
		
		primitiveList.add(new PrimitiveInteraction("^","'"));
		primitiveList.add(new PrimitiveInteraction("^","!"));
		
		primitiveList.add(new PrimitiveInteraction(">","O"));
		primitiveList.add(new PrimitiveInteraction(">","X"));
		
		//////////////////////////////////
		// predefined alternative groups
		for (int i=0;i<this.primitiveList.size();i++){
			for (int j=0;j<this.primitiveList.size();j++){
				if (i!=j && primitiveList.get(i).getAction().equals(primitiveList.get(j).getAction())){
					primitiveList.get(i).addAlternate(primitiveList.get(j));
				}
			}
		}
		//////////////////////////////////
	}
	
	public int nbInteraction(){
		return primitiveList.size();
	}
	
	public PrimitiveInteraction getInteraction(int i){
		return primitiveList.get(i);
	}
	
	
	/**
	 * define the valence for each interaction
	 * @param a, p primitive action and perception of an interaction
	 * @return valence of interaction (a,p)
	 */
	public static float valence(String a, String p){
		
		float valence=0;
		
		if (a.equals(">")){
			if (p.equals("O")) valence= 5;          // move forward
			if (p.equals("X")) valence=-10;			// bump
		}
		
		if (a.equals("^") || a.equals("v")){
			if (p.equals("'")) valence= -3;         // turn toward empty
			if (p.equals("!")) valence= -4;			// turn toward wall
		}
		
		if (a.equals("-") || a.equals("/") || a.equals("\\")){
			if (p.equals(":")) valence= -1;         // touch an empty square
			if (p.equals("|")) valence= -2;			// touch a wall square
		}
		
		return valence;
	}
}

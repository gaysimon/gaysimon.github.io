package version2_8_6.Interface;

import version2_8_6.platform.Agent;

/**
 * This class controls the main simulation loop of the agent :
 * it gets the decision of the agent, enact the interaction through the body
 * and update decision modules once cycle is completed.
 * @author simon gay
 */
public class Action {

	private boolean acting;    			// is the agent acting
	private PrimitiveInteraction lastAct;	// last action signal
	private PrimitiveInteraction enacted;	// last enacted interaction
	private Agent agent;
	
	private int state;         			// 0=stop or step mode, 1=run
	private boolean step;					// move one step
	
	private int stepNb;					// number of completed decision cycle
	private int subStep=0;					// substep counter
	
	private static int nbSubStep=10;		// define the number of substep per step
	
	public Action(Agent a){
		acting=false;
		lastAct=null;
		enacted=null;
		
		agent=a;
		state=0;
		step=false;
		
		stepNb=0;
	}
	
	public void act(){
		
		// if action interrupted, select new action
		if (!acting && (state==1 || step)){
			
			System.out.println("==================== step #"+stepNb+" =========================================================");
			lastAct=agent.decision.decision();

			acting=true;
			
			// initiate a cycle of 10 simulation loops
			subStep=nbSubStep;
		}
		
		///////////////////////////////////////////////////
		// end of a decision cycle
		if (subStep==0){
			
			if (acting || step){
			
				//%%%%%%%%%%%%%%%%% specific to simulators %%%%%%%%%%%%%%%%%%%%%%%
				agent.body.center();
				//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

				enacted=recognizeEnacted(lastAct.getAction());

				// update decision system
				agent.decision.learn(recognizeEnacted(lastAct.getAction()) );
				agent.spaceMemory.nextStep(recognizeEnacted(lastAct.getAction()));
				agent.observer.updateObserver(enacted);

				stepNb++;
			}
			
			acting=false;
			step=false;
			
		}
		else{
			// define the command to be sent to the body
			double[] command=new double[4];
			command[0]=0;
			command[1]=0;
			command[2]=0;
			command[3]=0;
			if (lastAct.getAction().equals(">")) command[1]= 0.99/(float)nbSubStep;
			if (lastAct.getAction().equals("^")) command[2]= (1/(float)nbSubStep)*Math.PI/2;
			if (lastAct.getAction().equals("v")) command[2]=(-1/(float)nbSubStep)*Math.PI/2;

			if (lastAct.getAction().equals("-")) command[3]=1;
			if (lastAct.getAction().equals("/" )) command[3]=2;
			if (lastAct.getAction().equals("\\" )) command[3]=3;

			agent.body.move(command);
			subStep--;
		}
		
		// stop cycle when the agent hit a wall
		if (agent.body.bump){
			subStep=0;
		}
		
		//-------------------------------------------------
	}
	
	// define the enacted interaction
	public PrimitiveInteraction recognizeEnacted(String action){

		if (action.equals("-")){
			if (!agent.body.touch) return agent.interactionList.getInteraction(0);
			else 				   return agent.interactionList.getInteraction(1);
		}
		else if (action.equals("\\")){
			if (!agent.body.touch) return agent.interactionList.getInteraction(2);
			else				   return agent.interactionList.getInteraction(3);
		}
		else if (action.equals("/")){
			if (!agent.body.touch) return agent.interactionList.getInteraction(4);
			else				   return agent.interactionList.getInteraction(5);
		}
		else if (action.equals("v")){
			if (!agent.body.wall)  return agent.interactionList.getInteraction(6);
			else				   return agent.interactionList.getInteraction(7);
		}
		else if (action.equals("^")){
			if (!agent.body.wall)  return agent.interactionList.getInteraction(8);
			else				   return agent.interactionList.getInteraction(9);
		}
		else{
			if (!agent.body.bump)   return agent.interactionList.getInteraction(10);
			else 				    return agent.interactionList.getInteraction(11);
		}
	}
	
	/////////////////////////////////////////////
	// start, stop and allow one decision cycle
	public void start(){
		state=1;
	}
	public void stop(){
		state=0;
	}
	public void step(){
		step=true;
	}
	
	/////////////////////////////////////////////
	
	public int getNbStep(){
		return stepNb;
	}
	
	public void setNbstep(int i){
		stepNb=i;
	}
	
	public int getState(){
		return state;
	}

	public boolean isStopped(){
		return state==0 && subStep==0 && !step;
	}
	
}

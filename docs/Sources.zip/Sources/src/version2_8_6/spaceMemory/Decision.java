package version2_8_6.spaceMemory;

import java.util.ArrayList;

import version2_8_6.Interface.InteractionList;
import version2_8_6.Interface.PrimitiveInteraction;
import version2_8_6.platform.Agent;

/**
 * Decision system.
 * This class selects the next intended interactions
 * @author simon
 */
public class Decision {

	private Agent agent;

	private Composite lastDecision;				// last selected composite interaction
	private int decisionIndex;					// index of lastDecision's execution
	public int decisionType1=0;				// used to define if the last selection was done
	public int decisionType2=0;				// for learning or for exploitation
	
	private int optimizationLock;				// lock the optimization process
	
	private Composite saccade;					// last selected epistemic interaction
	private int saccadeIndex;					// index of epistemic interaction's execution
	
	private boolean failed;						// result of the last enaction
	private PrimitiveInteraction enacted;
	private PrimitiveInteraction intention;
	
	private boolean isSaccade;					// define if the last enacted interaction is an epistemic interaction
	private boolean isOptimization;				// define if the last intended interaction is tested with optimization process
	
	public Decision(Agent a){
		agent=a;

		lastDecision=null;
		decisionIndex=-1;
		decisionType1=0;
		decisionType2=0;
		
		optimizationLock=0;
		
		saccade=null;
		saccadeIndex=-1;
		
		isSaccade=false;
		isOptimization=false;
	}
	
	/**
	 * decision of the next action
	 * @return the intended interaction
	 */
	public PrimitiveInteraction decision(){
		
		System.out.println();System.out.println();

		
		///////////////////////////////////////////////////////////////////////////////////////////
		// if last intended interaction failed, stop decision cycle
		if (failed){
			if (!isSaccade){
				// if the intended interaction was not completed, the error mays come from an incoherence in memory,
				// as the path is supposed to be enactable
				if (decisionIndex>-1){
					resetReliability();
					lastDecision.setPathFail();
				}
				
				// if the intended interaction is considered as always true, and was considered as enactable, then
				// the signature is wrong. Thus, disconnect signature inputs related to active input of the context
				if (lastDecision.isStillTrue() && lastDecision.getReliabilityT()>1){
					lastDecision.resetReliability(0);
					if (lastDecision.prediction(agent.environmentMemory.map[lastDecision.length()-decisionIndex-1])>0){
						for (int i=0;i<InteractionList.length1;i++){
							for (int j=0;j<InteractionList.length2;j++){
								if (agent.environmentMemory.map[lastDecision.length()-decisionIndex-1][i][j]!=0){
									lastDecision.pattern[i][j]=0;
									lastDecision.correlationC[i][j][0]=0;
									lastDecision.correlationC[i][j][1]=0;
								}
							}
						}
					}
				}
				decisionIndex=-1;
				System.out.println(" last action failed ");
			}
			
			// the optimization process is locked for 20 steps, during which the agent is expected to move to an other context
			if (isOptimization) optimizationLock=20;
		}
		
		if (optimizationLock>0) optimizationLock--;
		isOptimization=false;
		
		
		///////////////////////////////////////////////////////////////////////////////////////////
		// auto-optimization process
		// this process consists in replacing the end of the current intended composite interaction
		// with a possible primitive interaction with a greater valence in order to learn and test
		// a new interaction with a high valence
		///////////////////////////////////////////////////////////////////////////////////////////
		
		// if one primitive interaction remains in the current sequence, try auto-optimization
		if (optimizationLock==0 && decisionIndex==0 && lastDecision.length()>1 && !isSaccade ){
			float satisfaction=lastDecision.get(0).valence();
			
			Composite max=getBestComposite(satisfaction);
			if (max!=null){
				// check if the possible new interaction is not already known
				boolean found=false;
				int l=0;
				while (l<agent.spaceMemory.compositeList.size() && !found){
					if (agent.spaceMemory.compositeList.get(l).isEqual(lastDecision, max.get(0))) found=true;
					l++;
				}
				
				if (!found){
					// check if the possible new sequence does not end with an always true interaction
					boolean endWithAT=false;
					l=0;
					while(l<agent.spaceMemory.compositeList.size() && !endWithAT){
						if (agent.spaceMemory.compositeList.get(l).isStillTrue()){
							if (lastDecision.endWith(agent.spaceMemory.compositeList.get(l), max.get(0))) endWithAT=true;
						}
						l++;
					}
					
					if (!endWithAT){
						System.out.println("change for "+max.getName());
						lastDecision=max;
						decisionType1=2;
						isOptimization=true;
					}
				}
			}
		}
		
		
		///////////////////////////////////////////////////////////////////////////////////////////
		// if saccade completed, check decision
		if (saccadeIndex==-1 && decisionIndex>-1){
			
			saccadeIndex=-2;
			
			if (lastDecision!=null){
				float prediction=lastDecision.prediction(agent.environmentMemory.memoryMap3);

				// if the last decision is now expected as a failure with high certitude, last decision is canceled
				if (  (lastDecision.isReliable() || lastDecision.isAlwaysTrue())
				   && (prediction<0 || lastDecision.isInvalide(agent.sequenceMemory.sequencesF[2])) ) {
					decisionIndex=-1;
					lastDecision.setPathFail();
				}
				else{
					// else, the system checks if the last decision is still compatible with the new context, and cancels it otherwise
					if ( lastDecision.isInvalide(agent.sequenceMemory.sequencesF[2])
						||(prediction<=0 && lastDecision.getReliabilityF()==10 && lastDecision.getReliabilityT()<10)
					    ||(prediction>=0 && lastDecision.getReliabilityT()==10 && lastDecision.getReliabilityF()<10 
					      && lastDecision.getNbSuccess()!=lastDecision.getNbTest()) ){
							decisionIndex=-1;
							lastDecision.setPathFail();
							System.out.println("----- last decision interrupted (non reliable case) "+prediction);
					}
				}
			}
		}
		
		
		///////////////////////////////////////////////////////////////////////////////////////////
		// selection of a new interaction
		if (decisionIndex==-1 && saccadeIndex<0){
			
			// select a new interaction
			if (decisionIndex==-1){
				
				// "learning" selection process
				ArrayList<Composite> candidates=agent.sequenceMemory.getCandidates1();
				
				isSaccade=false;
				
				if (!candidates.isEmpty()){
					lastDecision=candidates.get(0);
					decisionIndex=lastDecision.length()-1;
					System.out.println("Interaction selected from candidates 1 : "+lastDecision.getName());
					decisionType1=1;
				}
				else{
					// "exploitation" selection process
					candidates=agent.sequenceMemory.getCandidates2();
					
					lastDecision=selectInteraction(candidates);
					
					decisionIndex=lastDecision.length()-1;
					System.out.println("Interaction selected from candidates 2 : "+lastDecision.getName());
					decisionType1=2;
					
					// define an epistemic interaction if needed
					float[][] missing=agent.environmentMemory.getMissingEnv(lastDecision);
					setSaccade(agent.spaceMemory.getMissingSaccade(missing, lastDecision));
				}
				
			}
			agent.sequenceMemory.memoryBackup();
		}
		
		
		///////////////////////////////////////////////////////////////////////////////////////////

		//agent.observer.trace();
		
		// get the next intended primitive interaction
		if (saccadeIndex>=0){				// enact saccade
			isSaccade=true;
			System.out.println("%%%%%%%%%%%% action from saccade");
			intention=saccade.get(saccadeIndex);
			saccadeIndex--;
			System.out.println("%%%%%%%%%%%% action from saccade");
			decisionType2=0;
		}
		else{								// enact the selected interaction
			isSaccade=false;
			System.out.println("%%%%%%%%%%%% action from space memory");
			intention=lastDecision.get(decisionIndex);
			decisionIndex--;
			System.out.println("%%%%%%%%%%%% action from space memory : "+intention.getName());
			decisionType2=1;
		}
		
		////////////////////////////////////////////////////////
		// return the next primitive interaction of the sequence
		return intention;
	}
	
	
	////////////////////////////////////////////////////////////////////////////////////
	// get the result of enaction
	public void learn(PrimitiveInteraction inter){
		
		System.out.println("enacted : "+inter.getName());
		enacted=inter;
		
		if (inter.isEqual(intention)) failed=false;
		else failed=true;
	}
	
	// set an epistemic interaction to enact before the intended interaction
	public void setSaccade(Composite s){
		saccade=s;
		if (saccade!=null){
			saccadeIndex=saccade.length()-1;
			System.out.println("saccade needed : "+saccade.getName());
		}
	}
	
	// select the best interaction in the list of candidates
	private Composite selectInteraction(ArrayList<Composite> candidates){
		Composite ret=candidates.get(0);
		float max=-1000;
		
		for (int l=0;l<candidates.size();l++){
			float sum=0;
			
			// first detect interactions that are related to themselves (interactions contained in their signatures)
			for (int i=0;i<InteractionList.length1;i++){
				for (int j=0;j<InteractionList.length2;j++){
					sum+=Math.abs(candidates.get(l).pattern[i][j]*candidates.get(l).prediction[i][j]);
				}
			}
			
			// select the interaction with the highest valence
			float satisfaction=candidates.get(l).getValence();
			if (sum<=0 || satisfaction>0){
				if ( satisfaction>max){
					max=satisfaction;
					ret=candidates.get(l);
				}
			}
		}

		return ret;
	}
	
	// reset the reliability values of interactions in which incoherences are detected
	private void resetReliability(){

		// get the composite interaction that failed
		Composite failedPath=agent.spaceMemory.getCompositeOf(lastDecision.getSubPath(decisionIndex+1));
		System.out.println("++++ failed path : "+failedPath.getName()+"  from "+lastDecision.getName());
		
		// get the interactions that generated wrong context and reset their reliability
		System.out.println("################ reset Reliability ##########");
		for (int l=0;l<agent.sequenceMemory.backupTSize();l++){
			float prediction=0;
			for (int i=0;i<InteractionList.length1;i++){
				for (int j=0;j<InteractionList.length2;j++){
					prediction+= failedPath.pattern[i][j]
					            *agent.sequenceMemory.getBackup_T(l).composite().pattern[i][j];
				}
			}
			
			if (prediction>0){
				if (agent.sequenceMemory.getBackup_T(l).composite().knowledgeMin>0.8 && agent.sequenceMemory.getBackup_T(l).composite().getNbTest()>=99)
					agent.sequenceMemory.getBackup_T(l).composite().resetReliability(9);
				else agent.sequenceMemory.getBackup_T(l).composite().resetReliability(0);
				
				if (agent.sequenceMemory.getBackup_T(l).initial().knowledgeMin>0.8 && agent.sequenceMemory.getBackup_T(l).initial().getNbTest()>=99)
					agent.sequenceMemory.getBackup_T(l).initial().resetReliability(9);
				else agent.sequenceMemory.getBackup_T(l).initial().resetReliability(0);
				
				System.out.println(" --- T : "+agent.sequenceMemory.getBackup_T(l).composite().name()+" } "
											  +agent.sequenceMemory.getBackup_T(l).initial().name());
			}
		}
		
		for (int l=0;l<agent.sequenceMemory.backupFSize();l++){
			float prediction=0;
			for (int i=0;i<InteractionList.length1;i++){
				for (int j=0;j<InteractionList.length2;j++){
					prediction+= failedPath.pattern[i][j]
					            *agent.sequenceMemory.getBackup_F(l).composite().pattern[i][j];
				}
			}
			
			if (prediction<0){
				if (agent.sequenceMemory.getBackup_F(l).composite().knowledgeMin>0.8 && agent.sequenceMemory.getBackup_F(l).composite().getNbTest()>=99)
					agent.sequenceMemory.getBackup_F(l).composite().resetReliability(9);
				else
					agent.sequenceMemory.getBackup_F(l).composite().resetReliability(0);
				
				if (agent.sequenceMemory.getBackup_F(l).initial().knowledgeMin>0.8 && agent.sequenceMemory.getBackup_F(l).initial().getNbTest()>=99)
					agent.sequenceMemory.getBackup_F(l).initial().resetReliability(9);
				else
					agent.sequenceMemory.getBackup_F(l).initial().resetReliability(0);
				
				System.out.println(" --- F : "+agent.sequenceMemory.getBackup_F(l).composite().name()+" } "
											  +agent.sequenceMemory.getBackup_F(l).initial().name());
			}
		}
	}
	
	// return the interaction considered as enactable for which the valence is the greatest, if greater than m
	// for now, we limit the selection to interactions of length 1
	private Composite getBestComposite(float m){
		Composite ret=null;
		
		float max=m;
		for (int i=0;i<agent.spaceMemory.compositeList.size();i++){
			if (agent.spaceMemory.compositeList.get(i).length()==1 
			 && agent.spaceMemory.compositeList.get(i).isReliable()
			 && agent.spaceMemory.compositeList.get(i).get(0).valence()>max ){
				
				if (agent.spaceMemory.compositeList.get(i).prediction(agent.environmentMemory.memoryMap2)>0.8){
					ret=agent.spaceMemory.compositeList.get(i);
					max=agent.spaceMemory.compositeList.get(i).get(0).valence();
				}
			}
		}
		
		return ret;
	}
	
	/////////////////////////////////////////////////////////////////
	
	public boolean failed(){
		return failed;
	}
	
	public Composite getLastDecision(){
		return lastDecision;
	}
	
	public PrimitiveInteraction getEnacted(){
		return enacted;
	}
	
	public PrimitiveInteraction getIntention(){
		return intention;
	}
}

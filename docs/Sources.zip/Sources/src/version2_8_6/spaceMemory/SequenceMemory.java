package version2_8_6.spaceMemory;

import java.util.ArrayList;

import version2_8_6.Interface.PrimitiveInteraction;
import version2_8_6.platform.Agent;

/**
 * This class manage the True List and the False List.
 * @author simon gay
 */
public class SequenceMemory {

	private Agent agent;

	public ArrayList<MemoryElement>[] sequencesT; 		// list of detected and tracked interactions
	public ArrayList<MemoryElement>[] sequencesF;
	
	private ArrayList<Composite>[] activeT;  			// active interaction
	private ArrayList<Composite>[] activeF;
	
	public ArrayList<MemoryElement>[] memoryT;  		// list of memorized sequences after interaction
	public ArrayList<MemoryElement>[] memoryF;
	
	private ArrayList<MemoryElement> memoryBackupT; 	// previous memory state, used to reset reliability
	private ArrayList<MemoryElement> memoryBackupF; 	// when incoherence is detected
	
	public SequenceMemory(Agent a){
		agent=a;

		sequencesT=new ArrayList[3];
		sequencesF=new ArrayList[3];
		activeT=new ArrayList[3];
		activeF=new ArrayList[3];
		memoryT=new ArrayList[3];
		memoryF=new ArrayList[3];
		
		memoryBackupT=new ArrayList<MemoryElement>();
		memoryBackupF=new ArrayList<MemoryElement>();
		
		for (int i=0;i<3;i++){
			sequencesT[i]=new ArrayList<MemoryElement>();
			sequencesF[i]=new ArrayList<MemoryElement>();
			activeT[i]=new ArrayList<Composite>();
			activeF[i]=new ArrayList<Composite>();
			memoryT[i]=new ArrayList<MemoryElement>();
			memoryF[i]=new ArrayList<MemoryElement>();
		}
	}
	
	////////////////////////////////////////////////////////////////////////////////
	// Update the interaction lists
	public void updateSequences(ArrayList<Composite> compositeList,
								 ArrayList<Float[]> predictions){

		// update memory 0
		sequencesT[0].clear();
		sequencesF[0].clear();
		
		activeT[0].clear();
		activeF[0].clear();
		
		//********************************************************************
		// detects and add composites in active lists and add their sequences in sequence lists
		for (int i=0;i<compositeList.size();i++){
			// recognized composites
			int match=compositeList.get(i).matchMap(agent.environmentMemory.memoryMap2);
			if (  ( predictions.get(i)[0]> 0.8 && predictions.get(i)[1]>=0 && predictions.get(i)[2]>=0
				  )
				&& match>0
				&& (compositeList.get(i).isReliable() || compositeList.get(i).isAlwaysTrue() )
				&& compositeList.get(i).isPathReliable(agent.spaceMemory.compositeList)
				&& compositeList.get(i).isEndReliable(agent.spaceMemory.compositeList)
				&& !compositeList.get(i).isFalseAT(compositeList)
				){
				activeT[0].add(compositeList.get(i));
				sequencesT[0].add(new MemoryElement(compositeList.get(i)));
			}
			if (  ( predictions.get(i)[0]<-0.8 && predictions.get(i)[1]<=0 && predictions.get(i)[2]<=0
				  )
				&& (compositeList.get(i).isReliable() || compositeList.get(i).isAlwaysTrue() )
				&& compositeList.get(i).isPathReliable(agent.spaceMemory.compositeList)
				&& compositeList.get(i).isEndReliable(agent.spaceMemory.compositeList)
				&& !compositeList.get(i).isFalseAT(compositeList)
				){
				activeF[0].add(compositeList.get(i));
				sequencesF[0].add(new MemoryElement(compositeList.get(i)));
			}
		}

		//********************************************************************
		// add sequences from the sequence memories
		for (int i=0;i<memoryT[0].size();i++){
			boolean found=false;
			for (int j=0;j<sequencesT[0].size();j++){
				if (memoryT[0].get(i).isEqual(sequencesT[0].get(j))) found=true;
			}
			if (!found) sequencesT[0].add(memoryT[0].get(i));
		}
		for (int i=0;i<memoryF[0].size();i++){
			boolean found=false;
			for (int j=0;j<sequencesF[0].size();j++){
				if (memoryF[0].get(i).isEqual(sequencesF[0].get(j))) found=true;
			}
			if (!found) sequencesF[0].add(memoryF[0].get(i));
		}

		//********************************************************************
		System.out.println("=================== final first level sequences");		
		for (int i=0;i<sequencesT[0].size();i++) System.out.println(" T : "+sequencesT[0].get(i).composite().getName());
		for (int i=0;i<sequencesF[0].size();i++) System.out.println(" F : "+sequencesF[0].get(i).composite().getName());
		System.out.println("===============================================");
		/**/
		
		//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		

		// update memory 1
		sequencesT[1].clear();
		sequencesF[1].clear();
		
		activeT[1].clear();
		activeF[1].clear();
		
		//********************************************************************
		// detects new composites in active lists
		//System.out.println("=================== detect new sequences 2:");
		for (int i=0;i<compositeList.size();i++){
			// recognized composites
			int match=compositeList.get(i).matchMap(agent.environmentMemory.memoryMap2);
			if ( (  (predictions.get(i)[1]> 0.8 && predictions.get(i)[2]>=0)
				  ||(predictions.get(i)[0]> 0.8 && predictions.get(i)[1]>=0 && predictions.get(i)[2]>=0)
				 )
				 && match>0
				 && (compositeList.get(i).isPathReliable(agent.spaceMemory.compositeList))
				 && (compositeList.get(i).isEndReliable(agent.spaceMemory.compositeList))
				 && !compositeList.get(i).isFalseAT(compositeList)
			    ){
				activeT[1].add(compositeList.get(i));
				sequencesT[1].add(new MemoryElement(compositeList.get(i)));
			}
			if ( (  (predictions.get(i)[1]<-0.8 && predictions.get(i)[2]<=0)
				  ||(predictions.get(i)[0]<-0.8 && predictions.get(i)[1]<=0 && predictions.get(i)[2]<=0)
				 )
				 && (compositeList.get(i).isPathReliable(agent.spaceMemory.compositeList))
				 && (compositeList.get(i).isEndReliable(agent.spaceMemory.compositeList))
				 && !compositeList.get(i).isFalseAT(compositeList)
				){
				activeF[1].add(compositeList.get(i));
				sequencesF[1].add(new MemoryElement(compositeList.get(i)));
			}
		}

		//********************************************************************
		// add sequences from the sequence memories
		for (int i=0;i<memoryT[1].size();i++){
			boolean found=false;
			for (int j=0;j<sequencesT[1].size();j++){
				if (memoryT[1].get(i).isEqual(sequencesT[1].get(j))) found=true;
			}
			if (!found) sequencesT[1].add(memoryT[1].get(i));
		}
		for (int i=0;i<memoryF[1].size();i++){
			boolean found=false;
			for (int j=0;j<sequencesF[1].size();j++){
				if (memoryF[1].get(i).isEqual(sequencesF[1].get(j))) found=true;
			}
			if (!found) sequencesF[1].add(memoryF[1].get(i));
		}
		
		//********************************************************************
		System.out.println("=================== final second level sequences");		
		for (int i=0;i<sequencesT[1].size();i++) System.out.println(" T : "+sequencesT[1].get(i).composite().getName());
		for (int i=0;i<sequencesF[1].size();i++) System.out.println(" F : "+sequencesF[1].get(i).composite().getName());
		System.out.println("===============================================");
		/**/
		
		
		//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		
		// update memory 2
		sequencesT[2].clear();
		sequencesF[2].clear();
		
		activeT[2].clear();
		activeF[2].clear();
		
		//********************************************************************
		// detects new composites in active lists
		//System.out.println("=================== detect new sequences 2:");
		for (int i=0;i<compositeList.size();i++){
			// recognized composites
			int match=compositeList.get(i).matchMap(agent.environmentMemory.memoryMap2);
			if ( (  predictions.get(i)[2]> 0.8 
				 ||(predictions.get(i)[1]> 0.8 && predictions.get(i)[2]>=0)
				 ||(predictions.get(i)[0]> 0.8 && predictions.get(i)[1]>=0 && predictions.get(i)[2]>=0)
				 )
				 && match>0
				 && (compositeList.get(i).isPathReliable(agent.spaceMemory.compositeList) || compositeList.get(i).knowledgeMin>0.8)
				 && (compositeList.get(i).isEndReliable(agent.spaceMemory.compositeList) || compositeList.get(i).knowledgeMin>0.8)
				 && !compositeList.get(i).isFalseAT(compositeList)
				){
				activeT[2].add(compositeList.get(i));
				sequencesT[2].add(new MemoryElement(compositeList.get(i)));
			}
			if ( (  predictions.get(i)[2]<-0.8 
				 ||(predictions.get(i)[1]<-0.8 && predictions.get(i)[2]<=0) 
				 ||(predictions.get(i)[0]<-0.8 && predictions.get(i)[1]<=0 && predictions.get(i)[2]<=0)
				 )
				 && (compositeList.get(i).isPathReliable(agent.spaceMemory.compositeList) || compositeList.get(i).knowledgeMin>0.8)
				 && (compositeList.get(i).isEndReliable(agent.spaceMemory.compositeList) || compositeList.get(i).knowledgeMin>0.8)
				 && !compositeList.get(i).isFalseAT(compositeList)
				){
				activeF[2].add(compositeList.get(i));
				sequencesF[2].add(new MemoryElement(compositeList.get(i)));
			}
		}

		//********************************************************************
		// add sequences from the sequence memories
		for (int i=0;i<memoryT[2].size();i++){
			boolean found=false;
			for (int j=0;j<sequencesT[2].size();j++){
				if (memoryT[2].get(i).isEqual(sequencesT[2].get(j))) found=true;
			}
			if (!found) sequencesT[2].add(memoryT[2].get(i));
		}
		for (int i=0;i<memoryF[2].size();i++){
			boolean found=false;
			for (int j=0;j<sequencesF[2].size();j++){
				if (memoryF[2].get(i).isEqual(sequencesF[2].get(j))) found=true;
			}
			if (!found) sequencesF[2].add(memoryF[2].get(i));
		}
		
		//********************************************************************
		System.out.println("=================== final third level sequences");		
		for (int i=0;i<sequencesT[2].size();i++) System.out.println(" T : "+sequencesT[2].get(i).composite().getName());
		for (int i=0;i<sequencesF[2].size();i++) System.out.println(" F : "+sequencesF[2].get(i).composite().getName());
		System.out.println("===============================================");
		/**/
	}


	
	////////////////////////////////////////////////////////////////////////////////
	//  update the list of sequences stored in memories
	////////////////////////////////////////////////////////////////////////////////
	public void updateMemory(PrimitiveInteraction inter){
		
		for (int k=0;k<3;k++){
			memoryT[k].clear();
			memoryF[k].clear();
			
			
			for (int i=0;i<sequencesT[k].size();i++){
				MemoryElement temp=sequencesT[k].get(i).nextStep(inter, agent.spaceMemory.compositeList);
				if (temp!=null){
					memoryT[k].add(temp);
				}
			}
			
			for (int i=0;i<sequencesF[k].size();i++){
				MemoryElement temp=sequencesF[k].get(i).nextStep(inter, agent.spaceMemory.compositeList);
				if (temp!=null){
					memoryF[k].add(temp);
				}
			}
			
		}

		//********************************************************************
		/*System.out.println("=================== memory 3");		
		for (int i=0;i<memoryT[2].size();i++) System.out.println(" T : "+memoryT[2].get(i).composite().name());
		for (int i=0;i<memoryF[2].size();i++) System.out.println(" F : "+memoryF[2].get(i).composite().name());
		System.out.println("===============================================");
		/**/
	}

	public void memoryBackup(){
		memoryBackupT.clear();
		memoryBackupF.clear();
		for (int i=0;i<sequencesT[1].size();i++) memoryBackupT.add(sequencesT[1].get(i));
		for (int i=0;i<sequencesF[1].size();i++) memoryBackupF.add(sequencesF[1].get(i));
	}
	
	
	public int backupTSize(){
		return memoryBackupT.size();
	}
	
	public MemoryElement getBackup_T(int i){
		return memoryBackupT.get(i);
	}
	
	public int backupFSize(){
		return memoryBackupF.size();
	}
	
	public MemoryElement getBackup_F(int i){
		return memoryBackupF.get(i);
	}
	
	
	////////////////////////////////////////////////////////////////////////////////
	// get possible sequences
	////////////////////////////////////////////////////////////////////////////////

	// select an interaction that can be tested
	public ArrayList<Composite> getCandidates1(){
		ArrayList<Composite> candidates=new ArrayList<Composite>();
		
		int minR=15;
		int minR2=-1;
		int imin=-1;
		
		// propose first an interaction that can be done immediately
		for (int l=0;l<agent.spaceMemory.compositeList.size();l++){
			if (isCandidate1_1(l)){
				
				float predict=agent.spaceMemory.compositeList.get(l).prediction(agent.environmentMemory.map[0]);

				if ( (predict> 0 && predict<1.99 && (   agent.spaceMemory.compositeList.get(l).isLessRT() 
						            || (agent.spaceMemory.compositeList.get(l).getNbSuccess()>10 && agent.spaceMemory.compositeList.get(l).isStillTrue() ))
				   ||(predict< 0 && predict>-1.99 && (agent.spaceMemory.compositeList.get(l).isLessRF()) ) )
				){
					
					if (     Math.max(agent.spaceMemory.compositeList.get(l).getReliabilityF(),agent.spaceMemory.compositeList.get(l).getReliabilityT())< minR
					   ||(   Math.max(agent.spaceMemory.compositeList.get(l).getReliabilityF(),agent.spaceMemory.compositeList.get(l).getReliabilityT())==minR)
					      && Math.min(agent.spaceMemory.compositeList.get(l).getReliabilityF(),agent.spaceMemory.compositeList.get(l).getReliabilityT())< minR2){
								
								minR=Math.max(agent.spaceMemory.compositeList.get(l).getReliabilityF(),
										      agent.spaceMemory.compositeList.get(l).getReliabilityT());
								imin=l;
								minR2=Math.min(agent.spaceMemory.compositeList.get(l).getReliabilityF(),
									           agent.spaceMemory.compositeList.get(l).getReliabilityT());
					}
				}
			}
		}
		if (imin>-1){
			candidates.add(agent.spaceMemory.compositeList.get(imin));
		}
		else{

			minR=15;
			minR2=-1;
			imin=-1;
			// then propose a sequence that need an epistemic interaction
			for (int l=0;l<agent.spaceMemory.compositeList.size();l++){
				if (isCandidate1_2(l)){
					
					float predict=agent.spaceMemory.compositeList.get(l).prediction(agent.environmentMemory.memoryMap2);

					if ( (predict>=0 && (   agent.spaceMemory.compositeList.get(l).isLessRT() 
								        || (agent.spaceMemory.compositeList.get(l).getReliabilityT()>1 && agent.spaceMemory.compositeList.get(l).isStillTrue() ))
					   ||(predict<=0 && (agent.spaceMemory.compositeList.get(l).isLessRF()) ) )
						   && ((agent.spaceMemory.compositeList.get(l).getReliabilityT()<10 && agent.spaceMemory.compositeList.get(l).getReliabilityF()<10)
							  ||agent.spaceMemory.compositeList.get(l).isUnlocked())
					){
							
						if (     Math.max(agent.spaceMemory.compositeList.get(l).getReliabilityF(),agent.spaceMemory.compositeList.get(l).getReliabilityT())< minR
						   ||(   Math.max(agent.spaceMemory.compositeList.get(l).getReliabilityF(),agent.spaceMemory.compositeList.get(l).getReliabilityT())==minR)
							  && Math.min(agent.spaceMemory.compositeList.get(l).getReliabilityF(),agent.spaceMemory.compositeList.get(l).getReliabilityT())< minR2){
								
							minR=Math.max(agent.spaceMemory.compositeList.get(l).getReliabilityF(),
										  agent.spaceMemory.compositeList.get(l).getReliabilityT());
							imin=l;
							minR2=Math.min(agent.spaceMemory.compositeList.get(l).getReliabilityF(),
										   agent.spaceMemory.compositeList.get(l).getReliabilityT());
						}
					}
				}
			}
			if (imin>-1){
				candidates.add(agent.spaceMemory.compositeList.get(imin));
					
				// compute saccade
				float[][] missing=agent.environmentMemory.getMissingEnv(agent.spaceMemory.compositeList.get(imin));
				agent.decision.setSaccade(agent.spaceMemory.getMissingSaccade(missing, agent.spaceMemory.compositeList.get(imin)));
					
			}
		}
		return candidates;
	}

	/////////////////////////////////////////////////////
	// select the list of interactions that can be enacted
	public ArrayList<Composite> getCandidates2(){
		ArrayList<Composite> candidates=new ArrayList<Composite>();
		
		for (int i=0;i<agent.spaceMemory.compositeList.size();i++){
			
			if (!agent.spaceMemory.compositeList.get(i).isUncorrelated()
			&&  (agent.spaceMemory.compositeList.get(i).isValide(sequencesT[2])
				|| (agent.spaceMemory.compositeList.get(i).isStillTrue() && agent.spaceMemory.compositeList.get(i).getReliabilityT()>=5)
				)
			){
				float predict=agent.spaceMemory.compositeList.get(i).prediction(agent.environmentMemory.memoryMap3);
				
				if (predict >=0){
					System.out.println(" candidate for selection 2.1 : "+agent.spaceMemory.compositeList.get(i).getName()+"  : "+predict);
					candidates.add(agent.spaceMemory.compositeList.get(i));
				}
			}
		}

		if (candidates.isEmpty()){
			for (int i=0;i<agent.spaceMemory.compositeList.size();i++){
				if (agent.spaceMemory.compositeList.get(i).length()==1){
					
					System.out.println(" candidate for selection 2.3 : "+agent.spaceMemory.compositeList.get(i).getName());
					candidates.add(agent.spaceMemory.compositeList.get(i));
				}
						
			}
		}
		return removeIncompatibleComposites(candidates);
	}


	//////////////////////////////////////////////
	private boolean isCandidate1_1(int l){
		return !agent.spaceMemory.compositeList.get(l).isUncorrelated()
			&& !agent.spaceMemory.compositeList.get(l).isAlwaysTrue()
			&& !agent.spaceMemory.compositeList.get(l).isReliable()
			&& ((!agent.spaceMemory.compositeList.get(l).isInvalide(sequencesF[2])
					&& ( agent.spaceMemory.compositeList.get(l).isUnlocked() 
						|| (agent.spaceMemory.compositeList.get(l).isStillTrue()
								&&agent.spaceMemory.compositeList.get(l).getReliabilityT()>1
								)))
		 	 ||(agent.spaceMemory.compositeList.get(l).isValide(sequencesT[2]))
		 	 )
			&&  agent.spaceMemory.compositeList.get(l).isPathReliable(agent.spaceMemory.compositeList)
			&& (agent.spaceMemory.compositeList.get(l).isEndReliable(agent.spaceMemory.compositeList))
			;
	}
	
	//////////////////////////////////////////////
	private boolean isCandidate1_2(int l){
		return !agent.spaceMemory.compositeList.get(l).isUncorrelated()
		 	&& !agent.spaceMemory.compositeList.get(l).isAlwaysTrue()
		 	&& !agent.spaceMemory.compositeList.get(l).isReliable()
		 	&& ((!agent.spaceMemory.compositeList.get(l).isInvalide(sequencesF[2])
		 			&& ( agent.spaceMemory.compositeList.get(l).isUnlocked()
		 				|| (agent.spaceMemory.compositeList.get(l).isStillTrue()
		 						&&agent.spaceMemory.compositeList.get(l).getReliabilityT()>1
		 						)))
		 	 ||(agent.spaceMemory.compositeList.get(l).isValide(sequencesT[2]))
		 	 )
		 	&&  agent.spaceMemory.compositeList.get(l).isPathReliableAndCorrelated(agent.spaceMemory.compositeList)
		 	&& (agent.spaceMemory.compositeList.get(l).isEndReliable(agent.spaceMemory.compositeList))
		 	;
	}
	
	/////////////////////////////////////////////////
	// remove composites with incompatible composites
	private ArrayList<Composite> removeIncompatibleComposites(ArrayList<Composite> list){
		
		ArrayList<Composite> ret=new ArrayList<Composite>();
		
		for (int i=0;i<list.size();i++){
				
			if (list.get(i).length()==1) ret.add(list.get(i));
			else{
				boolean compatible=true;
				int j=0;
				while (j<list.size() && compatible){
					if (list.get(i).length()>list.get(j).length()){
						if (list.get(i).beginWith(list.get(j))){
							if (!list.get(i).isCompatible(list.get(j))) compatible=false;
						}
					}
					j++;
				}
				if (compatible) ret.add(list.get(i));
			}
		}
		return ret;
	}
}

package version2_8_6.display;

import version2_8_6.platform.Agent;

/**
 * Display signatures of composite interactions
 * @author simon gay
 */

/* - inherited from EnvFrame :
 *   Agent agent      : pointer to the agent
 *   EnvPanel panel   : panel of this frame
 *   
 * - inherited from PrintableFrame :
 *   boolean printable   : define if the frame can be printed
 *   int indexImage      : counter for image name
 */
public class ColliculusFrame extends EnvFrame{
	
	private static final long serialVersionUID = 1L;

	public ColliculusFrame(Agent a){
		super(a);
		this.setTitle("Colliculus connections");
    	this.setSize(1200, 800);
    	this.setLocationRelativeTo(null);               
    	this.setVisible(true);
    	this.setFocusable(true);

    	panel=new ColliculusPanel(a);

    	printable=true;
    	
    	this.setContentPane(panel);
	}
}


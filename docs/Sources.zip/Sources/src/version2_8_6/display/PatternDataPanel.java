package version2_8_6.display;

import java.awt.Color;
import java.awt.Graphics;

import version2_8_6.platform.Agent;
import version2_8_6.platform.Observer;
import version2_8_6.spaceMemory.SpaceMemory;

/**
 * Display information about signatures
 * @author simon gay
 */

/* - inherited from EnvPanel :
 *   Agent agent      : pointer to the agent
 */
public class PatternDataPanel extends EnvPanel{

	private static final long serialVersionUID = 1L;
	
	private static final int h=750;
	private static final int w=Observer.nbStep;
	
	private float height;
	
	public PatternDataPanel(Agent a){
		super(a);
		
		int nb=12*10;
		for (int i=0;i<SpaceMemory.timeSize-2;i++){
			nb=nb*9;
		}
		height=(float)h/(float)nb;
	}
	
	
	public void paintComponent(Graphics g){
		g.setColor(Color.white);
		
		g.fillRect(0, 0, w+50, h+50);
		
		g.setColor(Color.black);
		g.drawLine(0, h, w, h);
		
		g.setColor(Color.lightGray);
		int n=1;
		while(n*height*50<h){
			g.drawLine(0, h-(int)(n*height*50), w, h-(int)(n*height*50) );
			n++;
		}

		
		for (int i=0;i<w;i++){
			
			if (i!=agent.observer.indexPattern){
			
				// display the number of interaction
				g.setColor(Color.gray);
				g.drawLine((w-agent.observer.indexPattern+i)%w   , (int)(h-agent.observer.timelineNbPattern[((w-1)+i  )%(w-1)][0]*height),
						   (w-agent.observer.indexPattern+(i-1))%w,(int)(h-agent.observer.timelineNbPattern[((w-1)+i-1)%(w-1)][0]*height));
				
				
				int nbReliable0=0;
				int nbReliable1=0;
				int nbUncorr0=0;
				int nbUncorr1=0;
				
				int nbCorrect0=0;
				int nbCorrect1=0;
				
				for (int j=0;j<SpaceMemory.timeSize;j++){
					nbReliable0+=agent.observer.timelineNbReliableP[((w-1)+i)%(w-1)][j]+agent.observer.timelineNbATrueP[((w-1)+i)%(w-1)][j]+agent.observer.timelineNbUncorrelatedP[((w-1)+i)%(w-1)][j];
					nbReliable1+=agent.observer.timelineNbReliableP[((w-1)+i-1)%(w-1)][j]+agent.observer.timelineNbATrueP[((w-1)+i-1)%(w-1)][j]+agent.observer.timelineNbUncorrelatedP[((w-1)+i-1)%(w-1)][j];
					
					nbUncorr0+=agent.observer.timelineNbUncorrelatedP[((w-1)+i)%(w-1)][j];
					nbUncorr1+=agent.observer.timelineNbUncorrelatedP[((w-1)+i-1)%(w-1)][j];
				}
				
				nbCorrect0=agent.observer.timelineNbCorrect[((w-1)+i)%(w-1)];
				nbCorrect1=agent.observer.timelineNbCorrect[((w-1)+i-1)%(w-1)];
				
				// display the number of reliable interactions
				g.setColor(Color.green);
				g.drawLine((w-agent.observer.indexPattern+i)%w    , (int)(h-nbReliable0*height),
						   (w-agent.observer.indexPattern+(i-1))%w, (int)(h-nbReliable1*height));
				
				// display the number of uncorrelated interactions
				g.setColor(Color.red);
				g.drawLine((w-agent.observer.indexPattern+i )%w   , (int)(h-nbUncorr0*height),
						   (w-agent.observer.indexPattern+(i-1))%w, (int)(h-nbUncorr1*height));
				
				// display the number of interactions with correct signature
				g.setColor(Color.cyan);
				g.drawLine((w-agent.observer.indexPattern+i )%w   , (int)(h-nbCorrect0*height),
						   (w-agent.observer.indexPattern+(i-1))%w, (int)(h-nbCorrect1*height));

			}
			
			
			// draw decision type (black for epistemic, blue for learning and green for exploitation)
			// each column display the decision type of 5 decision cycle
			for (int j=0;j<Observer.stepSize;j++){
				if (agent.observer.decisionType[i][j]==0) g.setColor(Color.black);
				else
					if (agent.observer.decisionType[i][j]==1) g.setColor(Color.blue);
					else
						if (agent.observer.decisionType[i][j]==2) g.setColor(Color.green);
				g.drawLine((w-agent.observer.indexPattern+i)%w, h+5+j*3,
						   (w-agent.observer.indexPattern+i)%w, h+5+j*3+2);
			}
		}
	}
	
}

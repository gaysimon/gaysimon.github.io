package version2_8_6.display;

import version2_8_6.platform.Agent;

/**
 * Display information about signatures
 * @author simon gay
 */
 
/* - inherited from EnvFrame :
 *   Agent agent      : pointer to the agent
 *   EnvPanel panel   : panel of this frame
 *   
 * - inherited from PrintableFrame :
 *   boolean printable   : define if the frame can be printed
 *   int indexImage      : counter for image name
 */
public class PatternDataFrame extends EnvFrame{

	private static final long serialVersionUID = 1L;

	public PatternDataFrame(Agent a){
		super(a);
		printable=true;
		this.setTitle("Patterns Data");
    	this.setSize(1000, 800);
    	this.setLocationRelativeTo(null);               
    	this.setVisible(true);
    	panel=new PatternDataPanel(a);
    	this.setContentPane(panel);
	}
}


package version7_2_2_2.display;

import java.awt.Color;
import java.awt.Graphics;

import version7_2_2_2.platform.Agent;


/**
 * Display the probe input
 * @author simon gay
 */

/* - inherited from EnvPanel :
 *   Agent agent      : pointer to the agent
 */
public class ProbePanel extends EnvPanel{
	
	private static final long serialVersionUID = 1L;

	public ProbePanel(Agent a){
		super(a);
	}
	
	public void paintComponent(Graphics g){
		
		g.setColor(Color.black);
		g.fillRect(0, 0, 720, 225);
		
		// draw background
		g.setColor(Color.blue);
		g.fillRect(0, 0, 720, 100);
		
		g.setColor(Color.orange);
		g.fillRect(0,100, 720, 100);
		
		// draw visual features
		for (int i=90;i<270;i++){
			double d=100/ (Math.max(0.1,agent.probe.distRetina[i]/10.));
			g.setColor(agent.probe.colRetina[i]);
			g.fillRect(i*4-360, (int)( 100- d/2 ), 4, (int)(d));
		}

		// draw bloc limits
		g.setColor(Color.black);
		for (int i=90;i<270;i++){
			double d=100/ (Math.max(0.1,agent.probe.distRetina[i]/10.));
			if (agent.probe.corner[i]==1) g.drawLine(i*4-360, (int)( 100- d/2 ), i*4-360, 199-(int)( 100- d/2 ));
			if (agent.probe.corner[i]==2) g.drawLine(i*4+4-360,(int)( 100- d/2 ), i*4+4-360, 199-(int)( 100- d/2 ));
		}

		// draw image perceived by retina
		for (int i=0;i<36;i++){
			g.setColor(agent.visual.color[i]);
			g.fillRect((i*5+90)*4-360,180, 20, 20);
		}
		
		// draw simulated optic flow
		g.setColor(Color.red);
		for (int i=0;i<36;i++){
			if (agent.visual.opticFlow[i]!=0) g.fillOval((i*5+90)*4-360-2, 90-2-(int)(agent.visual.opticFlow[i]*2), 5, 5);
		}
	}
}

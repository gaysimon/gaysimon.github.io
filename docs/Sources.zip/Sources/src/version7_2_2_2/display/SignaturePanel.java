package version7_2_2_2.display;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import version7_2_2_2.platform.Agent;
import version7_2_2_2.Interface.InteractionList;
import version7_2_2_2.agnosticMemory.Signature;

/**
 * Frame to display signatures of interactions
 * @author simon gay
 */

/* - inherited from EnvPanel :
 *   Agent agent      : pointer to the agent
 */
public class SignaturePanel extends EnvPanel implements MouseListener{

	private static final long serialVersionUID = 1L;
	
	private int clic_x=0;
	private int clic_y=0;
	
	private int selected_color=0;
	
	private int pixel=7;
	
	private int size1=InteractionList.size1;
	private int size2=InteractionList.size2;
	
	private boolean threshold=false;
	
	public SignaturePanel(Agent a){
		super(a);
		addMouseListener(this);
	}
	
	public void setAgent(Agent a){
		agent=a;
	}
	
	public void paintComponent(Graphics g){
		g.setColor(Color.white);
		
		g.fillRect(0, 0, 1050, 900);
		
		//////////////////////////////////////////////////////////////
		// draw interactional context
		
		// dynamic features
		int offset=0;
		for (int n=0;n<6;n++){
			offset=n*120;
			for (int i=0;i<size1;i++){
				for (int j=0;j<size2;j++){
					
					g.setColor(new Color(agent.environmentContext.enactedEnsembles[0][i*size2*3+j*3+n*size1*size2*3+2],
										 agent.environmentContext.enactedEnsembles[0][i*size2*3+j*3+n*size1*size2*3  ],
										 agent.environmentContext.enactedEnsembles[0][i*size2*3+j*3+n*size1*size2*3+1] ));
					
					g.fillRect(20+i*pixel, (120-j*pixel)+offset, pixel, pixel);
					
					if (i*size2*3+j*3+n*size1*size2*3+selected_color==agent.observer.getSelectedNode()){
						g.setColor(Color.white);
						g.drawRect(20+i*pixel, (120-j*pixel)+offset, pixel, pixel);
					}
					
				}
			}
			
		}
		
		// primitive interactions
		for (int i=0;i<7;i++){
			g.setColor(new Color(1-(agent.environmentContext.enactedEnsembles[0][InteractionList.nbDF+i]/2+0.5f),
								    agent.environmentContext.enactedEnsembles[0][InteractionList.nbDF+i]/2+0.5f,0));

			g.fillRect(20+i*20, 750, 10, 10);
			
			if (InteractionList.nbDF+i==agent.observer.getSelectedNode()){
				g.setColor(Color.black);
				g.drawRect(19+i*20, 749, 11, 11);
			}
		}
		
		// color selection
		g.setColor(Color.green);
		g.fillRect(260, 30, 10, 10);
		g.setColor(Color.blue);
		g.fillRect(260, 50, 10, 10);
		g.setColor(Color.red);
		g.fillRect(260, 70, 10, 10);
		
		g.setColor(Color.black);
		g.drawRect(259, 29+20*selected_color, 11, 11);
		
		if (threshold) g.setColor(Color.red);
		else g.setColor(Color.black);
		g.fillRect(260, 120, 10, 10);
		
		
		///////////////////////////////////////////////////////////////////////////////
		// draw signature
		if (agent.observer.getSelectedNode()!=-1){
			// dynamic features
			offset=0;
			Signature sig=agent.signatureList.get(agent.observer.getSelectedNode());
			float max1=sig.maxPattern1;
			float max2=sig.maxPattern2;
			
			if (max1!=0){
				for (int n=0;n<6;n++){
					offset=n*120;
					for (int i=0;i<size1;i++){
						for (int j=0;j<size2;j++){
							
							if (threshold){
								float red,green,blue;
								if (Math.abs(sig.signature[i*size2*3+j*3+n*size1*size2*3+2])>max1*0.1 && Math.abs(sig.signature[i*size2*3+j*3+n*size1*size2*3+2])>=0.1) 
									red=  (sig.signature[i*size2*3+j*3+n*size1*size2*3+2]/max1+1)/2;
								else red=0.5f;
								if (Math.abs(sig.signature[i*size2*3+j*3+n*size1*size2*3  ])>max1*0.1 && Math.abs(sig.signature[i*size2*3+j*3+n*size1*size2*3  ])>=0.1) 
									green=(sig.signature[i*size2*3+j*3+n*size1*size2*3  ]/max1+1)/2;
								else green=0.5f;
								if (Math.abs(sig.signature[i*size2*3+j*3+n*size1*size2*3+1])>max1*0.1 && Math.abs(sig.signature[i*size2*3+j*3+n*size1*size2*3+1])>=0.1) 
									blue= (sig.signature[i*size2*3+j*3+n*size1*size2*3+1]/max1+1)/2;
								else blue=0.5f;
								g.setColor(new Color(red,green,blue));
							}
							else{
								g.setColor(new Color(Math.min(1, Math.max(0, (sig.signature[i*size2*3+j*3+n*size1*size2*3+2]/max1+1)/2)),
													 Math.min(1, Math.max(0, (sig.signature[i*size2*3+j*3+n*size1*size2*3  ]/max1+1)/2)),
													 Math.min(1, Math.max(0, (sig.signature[i*size2*3+j*3+n*size1*size2*3+1]/max1+1)/2)) ));
							}
							g.fillRect(300+i*pixel, (120-j*pixel)+offset, pixel, pixel);
						}
					}
					
				}
			}
			
			// primitive interactions
			if (max2!=0){
				for (int i=0;i<8;i++){
					
					g.setColor(new Color(Math.min(1, Math.max(0, 1-((sig.signature[InteractionList.nbDF+i]/max2/2)+0.5f))),
										 Math.min(1, Math.max(0,   ((sig.signature[InteractionList.nbDF+i]/max2/2)+0.5f))),
										 0));
	
					g.fillRect(300+i*20, 750, 10, 10);
				}
			}
		}

		///////////////////////////////////////////////////////////
		// draw predicted context
		// dynamic features
		offset=0;
		for (int n=0;n<6;n++){
			offset=n*120;
			for (int i=0;i<InteractionList.size1;i++){
				for (int j=0;j<InteractionList.size2;j++){
					
					g.setColor(new Color(Math.min(1, Math.max(0, agent.environmentContext.predictedContext[i*size2*3+j*3+n*size1*size2*3+2])),
										 Math.min(1, Math.max(0, agent.environmentContext.predictedContext[i*size2*3+j*3+n*size1*size2*3  ])),
										 Math.min(1, Math.max(0, agent.environmentContext.predictedContext[i*size2*3+j*3+n*size1*size2*3+1]))));
					
					g.fillRect(550+i*pixel, (120-j*pixel)+offset, pixel, pixel);
				}
			}
			
		}
		
		// primitive interactions
		for (int i=0;i<7;i++){
			g.setColor(new Color(1-Math.min(1,Math.max(0,(agent.environmentContext.predictedContext[InteractionList.nbDF+i]/2+0.5f))),
								   Math.min(1,Math.max(0,(agent.environmentContext.predictedContext[InteractionList.nbDF+i]/2+0.5f))),0));
			g.fillRect(550+i*20, 750, 10, 10);
		}
		
		
		///////////////////////////////////////////////////////////
		// draw improved interactional context
		// dynamic features
		offset=0;
		for (int n=0;n<6;n++){
			offset=n*120;
			for (int i=0;i<size1;i++){
				for (int j=0;j<size2;j++){
					
					g.setColor(new Color(Math.min(1, Math.max(0, agent.environmentContext.improvedContext[i*size2*3+j*3+n*size1*size2*3+2])),
										 Math.min(1, Math.max(0, agent.environmentContext.improvedContext[i*size2*3+j*3+n*size1*size2*3  ])),
										 Math.min(1, Math.max(0, agent.environmentContext.improvedContext[i*size2*3+j*3+n*size1*size2*3+1]))));
					
					g.fillRect(800+i*pixel, (120-j*pixel)+offset, pixel, pixel);
				}
			}
			
		}
		
		// primitive interactions
		for (int i=0;i<7;i++){
			g.setColor(new Color(1-(Math.min(1, Math.max(0, agent.environmentContext.improvedContext[InteractionList.nbDF+i]/2+0.5f))),
								    Math.min(1, Math.max(0, agent.environmentContext.improvedContext[InteractionList.nbDF+i]/2+0.5f)),0));

			g.fillRect(800+i*20, 750, 10, 10);
		}
	}
	
	
	
	///////////////////////////////////////////////////////////////////////////
	public void mouseClicked(MouseEvent e) {

		clic_x=e.getX();
		clic_y=e.getY();
		
		float dmin=1000;
		float d=10;
		
		//selected_interaction=-1;

		int offset=0;
		for (int n=0;n<6;n++){
			offset=n*120;
			for (int i=0;i<InteractionList.size1;i++){
				for (int j=0;j<InteractionList.size2;j++){
					d=(clic_x-(20+i*pixel))*(clic_x-(20+i*pixel) ) + (clic_y - (120-j*pixel+offset))*(clic_y - (120-j*pixel+offset));
					if (d<dmin){
						dmin=d;
						agent.observer.setSelectedNode(i*size2*3 + j*3 + n*size1*size2*3 + selected_color);
					}
				}
			}
			
		}

		for (int i=0;i<7;i++){
			d=(clic_x-(25+i*20))*(clic_x-(25+i*20) ) + (clic_y - 755)*(clic_y - 755);
			if (d<dmin){
				dmin=d;
				agent.observer.setSelectedNode(InteractionList.nbDF + i);
			}
		}
		
		
		
		for (int i=0;i<3;i++){
			d=(clic_x-(265))*(clic_x-(265) ) + (clic_y - (35+20*i))*(clic_y - (35+20*i));
			if (d<dmin){
				dmin=d;
				selected_color=i;
			}
		}
		
		d=(clic_x-(265))*(clic_x-(265) ) + (clic_y - (125))*(clic_y - (125));
		if (d<dmin){
			threshold=!threshold;
		}

		System.out.println("+++++ "+agent.observer.getSelectedNode()+" : "
				+agent.signatureList.get(agent.observer.getSelectedNode()).prediction(agent.environmentContext.enactedEnsembles[0])+" ; "
				+agent.signatureList.get(agent.observer.getSelectedNode()).average_delta1+" ; "+agent.signatureList.get(agent.observer.getSelectedNode()).average_delta2);
		
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {}
	public void mouseReleased(MouseEvent e) {}

}

package version7_2_2_2.display;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import version7_2_2_2.agnosticMemory.AgnosticMemory;
import version7_2_2_2.agnosticMemory.Simplified;
import version7_2_2_2.platform.Agent;
import version7_2_2_2.Interface.InteractionList;

/**
 * Frame to display images of signatures
 * @author simon
 */

/* - inherited from EnvPanel :
 *   Agent agent      : pointer to the agent
 */
public class MovementPanel extends EnvPanel implements MouseListener{

	private static final long serialVersionUID = 1L;
	
	private Simplified[] maps;						// sequence of signature images
	private float[][] maps2;
	
	private int[] selection;
	private int color;
	private int nbStep=AgnosticMemory.length;
	
	private float[] maximums;
	
	private int clic_x=0;
	private int clic_y=0;
	
	private int size1=InteractionList.size1;
	private int size2=InteractionList.size2;
	
	public MovementPanel(Agent a){
		super(a);
		addMouseListener(this);
		
		maps=new Simplified[nbStep];
		maps2=new float[nbStep][InteractionList.length];
		
		selection=new int[nbStep];
		
		for (int i=0;i<nbStep;i++){
			selection[i]=0;
			maps[i]=new Simplified();
		}
		

		maximums=new float[nbStep];
		for (int i=0;i<nbStep;i++){
			maximums[i]=1;
		}
		
		color=0;

		fillMap(false);
	}
	
	public void setAgent(Agent a){
		agent=a;
	}
	
	public void paintComponent(Graphics g){
		g.setColor(Color.white);
		
		g.fillRect(0, 0, 1160, 705);
		
		
		// draw color selector
		for (int j=0;j<3;j++){
			if (color==j) g.setColor(Color.red);
			else g.setColor(Color.black);
			
			g.fillRect(20, 200 + 20*j, 10, 10);
		}
		
		for (int i=0;i<nbStep;i++){
			
			// draw selector
			for (int j=0;j<7;j++){
				if (i==0 || j<6){
					if (selection[i]==j) g.setColor(Color.red);
					else g.setColor(Color.black);
					g.fillRect(20+220*i, 50 + 20*j, 10, 10);
				}
			}
			
			
			// draw maps
			for (int n=0;n<6;n++){
				for (int j=0;j<size1;j++){
					for (int k=0;k<size2;k++){
						//g.setColor(new Color(Math.min(1, Math.max(0, (maps[i][n][j][k][2]/maximums[i]/2+0.5f))),
						//		 			 Math.min(1, Math.max(0, (maps[i][n][j][k][0]/maximums[i]/2+0.5f))),
						//		 			 Math.min(1, Math.max(0, (maps[i][n][j][k][1]/maximums[i]/2+0.5f)))));
						
						g.setColor(new Color(Math.min(1, Math.max(0, (maps2[i][n*size1*size2*3+j*size2*3+k*3+2]/maximums[i]/2+0.5f))),
											 Math.min(1, Math.max(0, (maps2[i][n*size1*size2*3+j*size2*3+k*3  ]/maximums[i]/2+0.5f))),
											 Math.min(1, Math.max(0, (maps2[i][n*size1*size2*3+j*size2*3+k*3+1]/maximums[i]/2+0.5f)))));
											 
						
						g.fillRect(40+220*i+6*j, 10+(size2*6- 6*k) +100*n,6,6);
					}
				}
			}
		}
	}
	
	
	public void fillMap(boolean visual){
		
		if (!visual){
			
			// get initial signature
			maps[0]=agent.agnosticMemory.patternList[InteractionList.nbDF+selection[0]].clone();
			maps2[0]=maps[0].convert();
			
			maximums[0]=maps[0].getMax();
			
			// compute prediction of the current signature image
			float predict=maps[0].predict(agent.environmentContext.enactedEnsembles[0]);
			System.out.println("--- "+predict);
		}
		
		// generate moved signatures
		
		for (int a=1;a<nbStep;a++){
			
			float nb=0;
			float sum=0;
			
			// reset map
			maps[a].clear();
			
			for (int i=0;i<maps[a-1].size();i++){
				
				if (maps[a-1].getIndex(i)>=selection[a]*size1*size2*3 && maps[a-1].getIndex(i)<(selection[a]+1)*size1*size2*3){

					Simplified sig=agent.agnosticMemory.patternList[maps[a-1].getIndex(i)];
					float max=sig.getMax();
					
					if (sig.size()>0) nb++;
					sum++;
					
					for (int j=0;j<sig.size();j++){
						if (sig.getIndex(j)<InteractionList.nbDF){
							maps[a].insert(sig.getIndex(j), maps[a-1].getWeight(i) * sig.getWeight(j) /max );
						}
					}
				}
			}
			
			if (nb/sum<1) maps[a].clear();
			
			maximums[a]=maps[a].getMax();
			
			if (!visual && maps[a-1].size()>0) maps[a].insert(InteractionList.length-1, maps[a-1].getWeight(maps[a-1].size()-1));
			
			maps2[a]=maps[a].convert();
			
			float predict=maps[a].predict(agent.environmentContext.enactedEnsembles[0]);
			System.out.println("--- "+predict);
		}
		System.out.println("///////////////////////////");
	}
	
	
	///////////////////////////////////////////////////////////////////////////
	public void mouseClicked(MouseEvent e) {

		clic_x=e.getX();
		clic_y=e.getY();

		boolean found=false;
		
		for (int i=0;i<nbStep;i++){
			for (int j=0;j<7;j++){
				if (i==0 || j<6){
					if (clic_x>=18+220*i && clic_x<52+220*i && clic_y>=48+20*j && clic_y<62+20*j){
						selection[i]=j;
						found=true;
					}
				}
			}
		}

		for (int j=0;j<3;j++){
			if (clic_x>=18 && clic_x<52 && clic_y>=198+20*j && clic_y<212+20*j){
				color=j;
				found=true;
			}
		}

		
		boolean visual=false;
		if (!found){
			int x=0,y=0;
			for (int i=0;i<size1;i++){
				for (int j=0;j<size2;j++){
					if (clic_x>=40+6*i && clic_x<47+6*i && clic_y>=10+(size2*6-6*j) && clic_y<17+(size2*6-6*j)){
						x=i;
						y=j;
						found=true;
					}
				}
			}
			if (found){
				visual=true;
				maximums[0]=1;
				
				maps[0].clear();
				for (int n=0;n<6;n++){
					maps[0].insert(n*size1*size2*3+x*size2*3+y*3+color, 1);
				}
				maps2[0]=maps[0].convert();
			}
		}
		fillMap(visual);
	}

	@Override
	public void mouseEntered(MouseEvent e){}
	public void mouseExited(MouseEvent e){}
	public void mousePressed(MouseEvent e){}
	public void mouseReleased(MouseEvent e){}
}

package version7_2_2_2.display;

import version7_2_2_2.platform.Agent;

/**
 * frame to display the links between positions
 * @author simon
 */

/* - inherited from EnvFrame :
 *   Agent agent      : pointer to the agent
 *   EnvPanel panel   : panel of this frame
 *   
 * - inherited from PrintableFrame :
 *   boolean printable   : define if the frame can be printed
 *   int indexImage      : counter for image name
 */
public class MemoryFrame extends EnvFrame{
	
	private static final long serialVersionUID = 1L;

	public MemoryFrame(Agent a){
		super(a);
		this.setTitle("Memory construction");
    	this.setSize(1200, 1000);
    	this.setLocationRelativeTo(null);               
    	this.setVisible(true);
    	this.setFocusable(true);
    	panel=new MemoryPanel(a);
    	this.setContentPane(panel);
	}

}


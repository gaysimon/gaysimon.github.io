package version7_2_2_2.display;

import version7_2_2_2.platform.Agent;

/**
 * Frame to display images of signatures
 * @author simon
 */

/* - inherited from EnvFrame :
 *   Agent agent      : pointer to the agent
 *   EnvPanel panel   : panel of this frame
 *   
 * - inherited from PrintableFrame :
 *   boolean printable   : define if the frame can be printed
 *   int indexImage      : counter for image name
 */
public class InstanceFrame extends EnvFrame{

	private static final long serialVersionUID = 1L;

	public InstanceFrame(Agent a){
		super(a);
		this.setTitle("Instances");
    	this.setSize(1500, 700);
    	this.setLocationRelativeTo(null);               
    	this.setVisible(true);
    	this.setFocusable(true);
    	panel=new InstancePanel(a);
    	this.setContentPane(panel);
	}
}


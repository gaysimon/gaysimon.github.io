package version7_2_2_2.display;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import version7_2_2_2.Interface.InteractionList;
import version7_2_2_2.platform.Agent;

/**
 * Panel to display the links between positions
 * @author simon
 */

/* - inherited from EnvPanel :
 *   Agent agent      : pointer to the agent
 */
public class MemoryPanel extends EnvPanel implements MouseListener{

	private static final long serialVersionUID = 1L;
	
	private int clic_x=0;
	private int clic_y=0;
	
	private boolean[] display;
	
	public static int gap=8;			// distance between nodes
	
	public MemoryPanel(Agent a){
		super(a);
		addMouseListener(this);

		display=new boolean[6];
		for (int i=0;i<6;i++) display[i]=true;
	}
	
	public void setAgent(Agent a){
		agent=a;
	}
	
	public void paintComponent(Graphics g){
		g.setColor(Color.white);
		
		g.fillRect(0, 0, 1200, 1000);
		
		for (int i=0;i<6;i++){
			if (display[i]) g.setColor(Color.red);
			else g.setColor(Color.black);
			g.fillRect(1100, 600+20*i, 10, 10);
		}
		
		int nbPos=InteractionList.size1*InteractionList.size2*3;
		
		// draw nodes		
		for (int i=0; i<nbPos;i++){
			g.setColor(Color.black);
			g.fillOval(100+(int)(agent.nodeList.get(i).x*gap)-1, 100+(int)(agent.nodeList.get(i).y*gap)-1, 2, 2);
		}
		
		for (int l=0;l<6;l++){	
			if (display[l]){
				for (int i=2; i<nbPos;i+=3){

					if (i%3==0) g.setColor(Color.green);
					if (i%3==1) g.setColor(Color.blue);
					if (i%3==2) g.setColor(Color.red);
					
					g.fillOval(100+(int)(agent.nodeList.get(i+l*nbPos).x*gap)-3,
							   100+(int)(agent.nodeList.get(i+l*nbPos).y*gap)-3, 5, 5);
				}
			}
		}
		
		g.setColor(Color.black);
		for (int i=0; i<7;i++){
			g.fillOval(100+(int)(agent.nodeList.get(i+InteractionList.nbDF).x*gap)-3,
					   100+(int)(agent.nodeList.get(i+InteractionList.nbDF).y*gap)-3, 5, 5);
		}
		
		g.setColor(Color.black);
		
		if (!agent.nodeList.mesh){
			// draw links between each interaction and the barycentre of its signature
			for (int l=0;l<6;l++){
				
				if (display[l]){
					for (int i=2; i<nbPos;i+=3){
	
						// for each node, draw links between this node and average position of high weights
						float x=0;
						float y=0;
						float n=0;
						
						for (int k=0;k<6;k++){
							for (int j=1; j<nbPos;j++){
								if (agent.signatureList.get(i+l*nbPos).signature[j+k*nbPos]>4){	
									x+=agent.nodeList.get(j).x * agent.signatureList.get(i+l*nbPos).signature[j+k*nbPos];
									y+=agent.nodeList.get(j).y * agent.signatureList.get(i+l*nbPos).signature[j+k*nbPos];
									n+=agent.signatureList.get(i+l*nbPos).signature[j+k*nbPos];
								}
							}
						}
						
						if (n>0){
							x=x/n;
							y=y/n;
							g.drawLine(100+(int)(agent.nodeList.get(i).x*gap),
								   	   100+(int)(agent.nodeList.get(i).y*gap),
								   	   100+(int)(x*gap),
								   	   100+(int)(y*gap));
						}
					}
				}
			}
		}
		else{
			// draw mesh
			g.setColor(Color.black);
			for (int l=0;l<6;l++){
				if (display[l]){
					for (int i=0;i<InteractionList.size2;i++){
						for (int j=0;j<InteractionList.size1;j++){
							
							for (int c=2;c<3;c+=3){
								
							// connect each node of a row with the next node
								if (j<InteractionList.size1-1){
									if ((agent.nodeList.get(l*nbPos+3*i+InteractionList.size2*3* j   +c).x*gap<730 || agent.nodeList.get(l*nbPos+3*i+InteractionList.size2*3* j   +c).y*gap<420)
									&&  (agent.nodeList.get(l*nbPos+3*i+InteractionList.size2*3*(j+1)+c).x*gap<730 || agent.nodeList.get(l*nbPos+3*i+InteractionList.size2*3*(j+1)+c).y*gap<420)){
										g.drawLine(100+(int)(agent.nodeList.get(l*nbPos + 3*i + InteractionList.size2*3*j +c).x*gap),
											   	   100+(int)(agent.nodeList.get(l*nbPos + 3*i + InteractionList.size2*3*j +c).y*gap),
											   	   100+(int)(agent.nodeList.get(l*nbPos + 3*i + InteractionList.size2*3*(j+1) +c).x*gap),
											   	   100+(int)(agent.nodeList.get(l*nbPos + 3*i + InteractionList.size2*3*(j+1) +c).y*gap));
									}
								}
								
								// and each node of a column with the next
								if (i<InteractionList.size2-1){
									if ((agent.nodeList.get(l*nbPos+3* i   +InteractionList.size2*3*j+c).x*gap<730 || agent.nodeList.get(l*nbPos+3* i   +InteractionList.size2*3*j+c).y*gap<420)
									&&  (agent.nodeList.get(l*nbPos+3*(i+1)+InteractionList.size2*3*j+c).x*gap<730 || agent.nodeList.get(l*nbPos+3*(i+1)+InteractionList.size2*3*j+c).y*gap<420)){
										g.drawLine(100+(int)(agent.nodeList.get(l*nbPos + 3*i + InteractionList.size2*3*j +c).x*gap),
											   	   100+(int)(agent.nodeList.get(l*nbPos + 3*i + InteractionList.size2*3*j +c).y*gap),
											   	   100+(int)(agent.nodeList.get(l*nbPos + 3*(i+1) + InteractionList.size2*3*j +c).x*gap),
											   	   100+(int)(agent.nodeList.get(l*nbPos + 3*(i+1) + InteractionList.size2*3*j +c).y*gap));
									}
								}
							}
						}
					}
				}
			}
		}
	}
	
	
	///////////////////////////////////////////////////////////////////////////
	public void mouseClicked(MouseEvent e) {

		clic_x=e.getX();
		clic_y=e.getY();
		
		float dmin=1000;
		float d=10;
		
		agent.observer.setSelectedNode(-1);
		
		for (int i=0;i<agent.nodeList.size();i++){
			d=(clic_x-(100+agent.nodeList.get(i).x*8-3)) * (clic_x-(100+agent.nodeList.get(i).x*8-3)) 
			+ (clic_y-(100+agent.nodeList.get(i).y*8-3)) * (clic_y-(100+agent.nodeList.get(i).y*8-3));
			if (d<dmin){
				dmin=d;
				agent.observer.setSelectedNode(i);
			}
		}
		
		int index=-1;
		for (int i=0;i<6;i++){
			d=(clic_x-1105)*(clic_x-1105) + (clic_y-(600+20*i+5))*(clic_y-(600+20*i+5));
			if (d<dmin){
				dmin=d;
				index=i;
			}
		}
		if (index>=0) display[index]=!display[index];
	}

	@Override
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {}
	public void mouseReleased(MouseEvent e) {}

}

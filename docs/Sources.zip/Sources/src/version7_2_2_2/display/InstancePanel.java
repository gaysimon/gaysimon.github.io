package version7_2_2_2.display;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import version7_2.environment.Environment;
import version7_2_2_2.platform.Agent;
import version7_2_2_2.Interface.InteractionList;

/**
 * Frame to display images of signatures
 * @author simon
 */

/* - inherited from EnvPanel :
 *   Agent agent      : pointer to the agent
 */
public class InstancePanel extends EnvPanel implements MouseListener{

	private static final long serialVersionUID = 1L;
	
	private int clic_x=0;
	private int clic_y=0;
	
	private int size1=InteractionList.size1;
	private int size2=InteractionList.size2;
	
	private int selectedObj=0;
	private int selectedPath=0;
	
	private float[] pattern;
	
	public InstancePanel(Agent a){
		super(a);
		addMouseListener(this);
		
		pattern=new float[InteractionList.length];
		for (int i=0;i<InteractionList.length;i++){
			pattern[i]=0;
		}
	}
	
	public void setAgent(Agent a){
		agent=a;
	}
	
	public void paintComponent(Graphics g){
		g.setColor(Color.white);
		
		g.fillRect(0, 0, 1500, 1000);
		
		// draw "internal" image
		for (int o=0;o<3;o++){
			for (int n=0;n<6;n++){
				for (int i=0;i<size1;i++){
					for (int j=0;j<size2;j++){
							g.setColor(new Color(Math.min(1, Math.max(0, agent.agnosticMemory.imageMap[o][n*size1*size2*3+i*size2*3+j*3+2]/1000+0.5f)),
						 			 			 Math.min(1, Math.max(0, agent.agnosticMemory.imageMap[o][n*size1*size2*3+i*size2*3+j*3  ]/1000+0.5f)),
						 			 			 Math.min(1, Math.max(0, agent.agnosticMemory.imageMap[o][n*size1*size2*3+i*size2*3+j*3+1]/1000+0.5f))));
				
							g.fillRect(450+130*o+4*i, 10+(size2*4- 4*j) +65*n,4,4);
					}
				}
			}
		}
		
		///////////////////////////////////////////////////////////////////////////////////////
		// draw center of object instances
		
		// draw environment
		for (int i=0;i<agent.getMain().env.getWidth();i++){
			for (int j=0;j<agent.getMain().env.getHeight();j++){
				
				if (agent.getMain().env.isWall(i, j)) g.setColor(Environment.WALL1);
				else if (agent.getMain().env.isFood(i, j)) g.setColor(Environment.FISH1);
				else if (agent.getMain().env.isAlga(i, j)) g.setColor(Environment.ALGA1);
				else g.setColor(Environment.FIELD_COLOR);
				
				g.fillRect(10+40*i, 10+40*(agent.getMain().env.getHeight()-1-j), 40, 40);
			}	
		}
		
		// draw agent's position and orientation
		g.setColor(Color.gray);
		g.fillOval((int)(10+40*agent.body.getpx()+10), (int)(10+40*(agent.getMain().env.getHeight()-1-agent.body.getpy())+10), 20, 20);
		
		float dx= 20*(float)Math.cos(agent.body.getrz());
		float dy= 20*(float)Math.sin(-agent.body.getrz());
		g.drawLine((int)(10+40*agent.body.getpx()+20),
				   (int)(10+40*(agent.getMain().env.getHeight()-1-agent.body.getpy())+20),
				   (int)(10+40*agent.body.getpx()+20+dx),
				   (int)(10+40*(agent.getMain().env.getHeight()-1-agent.body.getpy())+20+dy));
		
		//draw center of object instances
		for (int o=0;o<3;o++){
			
			for (int i=0;i<agent.agnosticMemory.pathMemory[o].size();i++){
				
				if (o==0) g.setColor(Color.red);
				if (o==1) g.setColor(Color.green);
				if (o==2) g.setColor(Color.blue);
				
				float x=agent.body.getpx();
				float y=agent.body.getpy();
				float rz=agent.body.getrz();
				
				for (int j=agent.agnosticMemory.pathMemory[o].get(i).length()-1;j>0;j--){
					
					if (agent.agnosticMemory.pathMemory[o].get(i).get(j)<=1){
						// move forward
						dx= 1*(float)Math.cos(rz);
						dy= 1*(float)Math.sin(rz);
						
						x+=dx;
						y+=dy;
					}
					else if (agent.agnosticMemory.pathMemory[o].get(i).get(j)==2){
						// turn right 90°
						rz-=Math.PI/2;
					}
					else if (agent.agnosticMemory.pathMemory[o].get(i).get(j)==3){
						// turn left 90°
						rz+=Math.PI/2;
					}
					else if (agent.agnosticMemory.pathMemory[o].get(i).get(j)==4){
						// turn right 45°
						rz-=Math.PI/4;
					}
					else if (agent.agnosticMemory.pathMemory[o].get(i).get(j)==5){
						// turn left 45°
						rz+=Math.PI/4;
					}
				}	

				g.drawOval((int)(10+40*x+15), (int)(10+40*(agent.getMain().env.getHeight()-1-y)+15), 10, 10);

				dx= 10*(float)Math.cos(rz);
				dy= 10*(float)Math.sin(-rz);
				g.drawLine((int)(10+40*x+20)+o,
						   (int)(10+40*(agent.getMain().env.getHeight()-1-y)+20)+o,
						   (int)(10+40*x+20+dx)+o,
						   (int)(10+40*(agent.getMain().env.getHeight()-1-y)+20+dy)+o);
				
				
				
				// draw selected path and signature
				if (selectedObj==o && selectedPath==i){
					g.setColor(Color.black);
					g.drawOval((int)(10+40*x+12), (int)(7+40*(agent.getMain().env.getHeight()-1-y)+15), 16, 16);
					
					for (int w=0;w<InteractionList.length;w++){
						pattern[w]=0;
					}
					
					float max=1;
					for (int j=0;j<agent.agnosticMemory.pathMemory[o].get(i).patternSize();j++){
						pattern[agent.agnosticMemory.pathMemory[o].get(i).getPatternIndex(j)]=agent.agnosticMemory.pathMemory[o].get(i).getWeight(j);
						if (Math.abs(agent.agnosticMemory.pathMemory[o].get(i).getWeight(j))>max) max=Math.abs(agent.agnosticMemory.pathMemory[o].get(i).getWeight(j));
					}
					
					for (int n=0;n<6;n++){
						for (int k=0;k<size1;k++){
							for (int l=0;l<size2;l++){
								for (int c=0;c<3;c++){
									g.setColor(new Color(Math.min(1, Math.max(0, pattern[n*size1*size2*3+k*size2*3+l*3+2]/max/2+0.5f)),
					 			 			 			 Math.min(1, Math.max(0, pattern[n*size1*size2*3+k*size2*3+l*3  ]/max/2+0.5f)),
					 			 			 			 Math.min(1, Math.max(0, pattern[n*size1*size2*3+k*size2*3+l*3+1]/max/2+0.5f))));
									
									g.fillRect(10+4*k+130*n, 450+4*(size2-l), 4, 4);
								}
							}
						}
					}
				}
			}
		}
		
		
		// draw list of paths
		for (int o=0;o<3;o++){
			for (int p=0;p<agent.agnosticMemory.pathMemory[o].size();p++){
				
				if (selectedObj==o && selectedPath==p) g.setColor(Color.red);
				else g.setColor(Color.black);
				g.fillRect(900+150*o, 10+15*p, 5, 5);
				
				g.setColor(Color.black);
				g.drawString(agent.agnosticMemory.pathMemory[o].get(p).name(), 905+150*o, 15+15*p);
			}
		}
	}
	
	
	///////////////////////////////////////////////////////////////////////////
	public void mouseClicked(MouseEvent e) {

		clic_x=e.getX();
		clic_y=e.getY();

		int obj=-1;
		int path=-1;
		
		for (int o=0;o<3;o++){
			if (clic_x>=898+150*o && clic_x<907+150*o) obj=o;
		}
		
		if (obj!=-1){
			for (int p=0;p<agent.agnosticMemory.pathMemory[obj].size();p++){
				if (clic_y>=8+15*p && clic_y<17+15*p) path=p;
			}
		}
		
		selectedObj=obj;
		selectedPath=path;
		
		this.repaint();
	}

	@Override
	public void mouseEntered(MouseEvent e){}
	public void mouseExited(MouseEvent e){}
	public void mousePressed(MouseEvent e){}
	public void mouseReleased(MouseEvent e){}
}

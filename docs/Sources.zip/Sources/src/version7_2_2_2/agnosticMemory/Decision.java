package version7_2_2_2.agnosticMemory;

import version7_2_2_2.Interface.InteractionList;
import version7_2_2_2.Interface.PrimitiveInteraction;
import version7_2_2_2.platform.Agent;

/**
 * Decision system.
 * This class selects the intended interactions
 * @author simon
 */
public class Decision {

	private Agent agent;
	
	private PrimitiveInteraction intention;

	public Decision(Agent a){
		agent=a;
	}
	
	/**
	 * decision of the next interaction
	 * @return the intended enact
	 */
	public PrimitiveInteraction decision(){
		System.out.println();System.out.println();
		
		int imin=-1;
		float min=10;

		// a candidate interaction must be valid and not predicted as a failure with high certitude,
		// and must be a primary interaction or being predicted with a sufficient certitude to avoid unpredictable interactions
		for (int i=0;i<agent.signatureList.size();i++){
			if (agent.signatureList.isValid(i) && agent.signatureList.get(i).prediction>-0.9
			 && (i>=InteractionList.nbDF || Math.abs(agent.signatureList.get(i).prediction)>0.5)){
				if (Math.abs(agent.signatureList.get(i).prediction)<min){
					imin=i;
					min=Math.abs(agent.signatureList.get(i).prediction);
				}
			}
		}
		
		System.out.println("Select interaction "+imin+" : "+agent.signatureList.get(imin).interaction().getName()+" ; "+min);
		intention=agent.signatureList.get(imin).interaction();

		return intention;
	}

	/**
	 * Get the last intended interaction
	 * @return the last selected intended interaction
	 */
	public PrimitiveInteraction getIntention(){
		return intention;
	}

}

package version7_2_2_2.agnosticMemory;

import java.util.ArrayList;

public class Path {

	private byte[] path;
	
	private Simplified pattern;

	public ArrayList<Integer> redundantList;
	
	public Path(int id, byte[] p, Simplified s){

		int l=0;
		while (l<p.length && p[l]>-1) l++;
		
		path=new byte[l];
		for (int i=0;i<l;i++) path[i]=p[i];
		pattern=s.clone();

		redundantList=new ArrayList<Integer>();
	}
	
	public int length(){
		return path.length;
	}
	
	public int patternSize(){
		return pattern.size();
	}
	
	public int get(int i){
		return path[i];
	}
	
	public byte[] getpath(){
		return path;
	}
	
	public Simplified getPattern(){
		return pattern;
	}
	
	public int getPatternIndex(int i){
		return pattern.getIndex(i);
	}
	
	public float getWeight(int i){
		return pattern.getWeight(i);
	}
	
	public float getPrediction(){
		return pattern.getPrediction();
	}
	
	// return true if the sequence of interaction is the same, excepted the first element (object)
	public boolean isEqual(Path p){
		if (path.length!= p.length()) return false;
		else{
			boolean equal=true;
			for (int i=1;i<path.length;i++){
				if (path[i]!=p.get(i)) equal=false;
			}
			return equal;
		}
	}
	
	public void addRedundant(int p){
		redundantList.add(p);
	}
	
	public String name(){
		String ret="[";		
		
		switch (path[0]){
			case -1: ret+=".  "; break;
			case 0 : ret+=">0 "; break;
			case 1 : ret+=">X "; break;
			case 2 : ret+=">F "; break;
			case 3 : ret+="v  "; break;
			case 4 : ret+="^  "; break;
			case 5 : ret+="\\  ";break;
			case 6 : ret+="/  "; break;
			default: ret+="   "; break;
		}
		ret+="]";
		
		for (int i=1;i<path.length;i++){
			switch (path[i]){
				case 0 : ret+=">0 "; break;
				case 1 : ret+=">F "; break;
				case 2 : ret+="v  "; break;
				case 3 : ret+="^  "; break;
				case 4 : ret+="\\  ";break;
				case 5 : ret+="/  "; break;
				default : ret+="   ";break;
			}
		}
		
		return ret;
	}
	
}

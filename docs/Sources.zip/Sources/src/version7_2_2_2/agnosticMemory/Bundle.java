package version7_2_2_2.agnosticMemory;

import java.util.ArrayList;

public class Bundle {

	public ArrayList<Path> list;
	private int id;
	
	public Bundle(int i, Path p){
		id=i;
		list=new ArrayList<Path>();
		list.add(p);
		//list.get(0).setBundle(this);
	}
	
	public int getId(){
		return id;
	}
	
	public ArrayList<Path> getList(){
		return list;
	}
	
	public void add(ArrayList<Path> l){
		for (int i=0;i<l.size();i++){
			//l.get(i).setBundle(this);
			list.add(l.get(i));
		}
	}
	
	public int size(){
		return list.size();
	}
	
	public Path get(int i){
		return list.get(i);
	}
	
	public String name(){
		String ret=""+id+" : ";
		for (int i=0;i<list.size();i++){
			ret+=list.get(i)+" ";
		}
		return ret;
	}
	
}

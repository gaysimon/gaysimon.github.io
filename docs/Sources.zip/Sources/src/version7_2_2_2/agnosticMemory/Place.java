package version7_2_2_2.agnosticMemory;

public class Place {

	private int inter;
	private int distance;
	private float certitude;
	
	public Place(int d, int i, float p){
		inter=i;
		distance=d;
		certitude=p;
	}
	
	public int getDistance(){
		return distance;
	}
	
	public float getCertitude(){
		return certitude;
	}
	
	public int getInteraction(){
		return inter;
	}
	
	public void insertCertitude(float c){
		if (c>certitude) certitude=c;
	}
	
	public boolean isObject(int d, int i){
		return d==distance && i==inter;
	}
	
	public String display(){
		String ret="(";
		
		switch(inter){
			case -1: ret+=".  ";break;
			case 0 : ret+=">0 ";break;
			case 1 : ret+=">F ";break;
			case 2 : ret+="v  ";break;
			case 3 : ret+="^  ";break;
			case 4 : ret+="\\  ";break;
			case 5 : ret+="/  ";break;
			default : break;
		}
		
		ret+=", "+distance+" ; "+certitude+")";
		
		return ret;
	}
	
}

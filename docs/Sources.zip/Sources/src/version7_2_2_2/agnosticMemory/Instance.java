package version7_2_2_2.agnosticMemory;

import java.util.ArrayList;

public class Instance {

	
	public static float coef=0.99f;		// decrease of object influence according to their distance
	
	private ArrayList<Path> pathList;
	private ArrayList<Place> placeList;
	private int object;
	private int id;
	
	public Instance(int o, int i){
		pathList=new ArrayList<Path>();
		placeList=new ArrayList<Place>();
		object=o;
		id=i;
	}
	
	public void addPath(Path p){
		pathList.add(p);
	}
	
	public int nbPlace(){
		return placeList.size();
	}
	
	public void print(boolean paths, boolean places){
		System.out.println();
		System.out.println("=================================================");
		System.out.print("=== instance "+id+" of ");
		switch(object){
		case 0 : System.out.println(">0"); break;
		case 1 : System.out.println(">X"); break;
		case 2 : System.out.println(">F"); break;
		case 3 : System.out.println("v "); break;
		case 4 : System.out.println("^ "); break;
		case 5 : System.out.println("\\ ");break;
		case 6 : System.out.println("/ "); break;
		default : break;
		}
		System.out.println("=================================================");
		
		if (paths){
			System.out.println("--- paths ---");
			for (int i=0;i<pathList.size();i++){
				System.out.println(pathList.get(i).name());
			}
		}
		if (places){
			System.out.println("--- places ---");
			for (int i=0;i<placeList.size();i++){
				System.out.println("  "+placeList.get(i).display());
			}
		}
		System.out.println("=================================================");
	}
	
	public void definePlace(){
		for (int p=0;p<pathList.size();p++){
			
			int d=pathList.get(p).length()-1;
			int inter=-1;
			if (d!=0) inter=pathList.get(p).get(d);
			
			int i=0;
			boolean found=false;
			while (i<placeList.size() && !found){
				if (placeList.get(i).isObject(d, inter))
					found=true;
				else i++;
			}
			
			if (found) placeList.get(i).insertCertitude(pathList.get(p).getPrediction());
			else{
				placeList.add(new Place(d, inter, pathList.get(p).getPrediction()));
			}
		}
	}
	
	public void removeRedundant(){
		for (int i=0;i<placeList.size();i++){
			boolean found=false;
			for (int j=0;j<placeList.size();j++){
				
				if (i!=j){
					
					int delta=placeList.get(i).getDistance()-placeList.get(j).getDistance();
					
					if ( (delta>=0 && placeList.get(i).getCertitude()                    < placeList.get(j).getCertitude())
					   ||(delta> 0 && placeList.get(i).getCertitude()*Math.pow(coef,delta)<=placeList.get(j).getCertitude())){
						found=true;
					}		
				}
			}
			if (found){
				
				// remove related paths
				int dist=placeList.get(i).getDistance();
				int inter=placeList.get(i).getInteraction();
				
				for (int p=pathList.size()-1;p>=0;p--){
					if (pathList.get(p).length()-1==dist && pathList.get(p).get(pathList.get(p).length()-1)==inter){
						pathList.remove(p);
					}
				}
				
				// remove place
				placeList.remove(i);
				i--;
			}
		}
	}
	
}

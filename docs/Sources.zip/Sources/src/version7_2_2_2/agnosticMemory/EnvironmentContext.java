package version7_2_2_2.agnosticMemory;

import version7_2_2_2.Interface.InteractionList;
import version7_2_2_2.Interface.PrimitiveInteraction;
import version7_2_2_2.platform.Agent;

/**
 * Environmental context.
 * This class can also generate a predicted and an improved context
 * @author simon gay
 */
public class EnvironmentContext{
	
	private Agent agent;
	
	public float[][] enactedEnsembles;				// enacted ensembles E_t and E_{t-1}
	
	public float[] predictedContext;				// predicted context E_{t+1}
	public float[] improvedContext;				// completed current context E'_t
	
	private boolean predict=false;
	private boolean improve=false;
	
	public EnvironmentContext(Agent a){
		
		agent = a;
		
		enactedEnsembles=new float[2][InteractionList.length];
		for (int i=0;i<InteractionList.length;i++){
			enactedEnsembles[0][i]=0;
			enactedEnsembles[1][i]=0;
		}
		
		predictedContext=new float[InteractionList.length];
		improvedContext=new float[InteractionList.length];
	}
	
	
	/**
	 * update the environmental context
	 * @param inter : last enacted primitive interaction
	 */
	public void updateContext(PrimitiveInteraction inter, float[] enacted){
		
		// update timeline
		for (int i=0;i<InteractionList.length;i++){
			enactedEnsembles[1][i]=enactedEnsembles[0][i];
			enactedEnsembles[0][i]=enacted[i];
		}
		
		// update signatures
		agent.signatureList.learn(enactedEnsembles[1],enactedEnsembles[0] , inter);
		
		// compute predictions
		agent.signatureList.setPredictions(enactedEnsembles[0]);
		
		////////////////////////////////////////////////////////////////////////////////
		// predict current context with previous environmental context
		float max=0;
		
		if (predict){
			
			for (int i=0;i<InteractionList.length-1;i++){
				predictedContext[i]=0;
			}
			for (int i=0;i<InteractionList.length-1;i++){
				if (agent.signatureList.get(i).average_delta1<0.7 && agent.signatureList.get(i).average_delta2<0.7){
					float prediction=agent.signatureList.get(i).prediction(enactedEnsembles[0]);
					predictedContext[i]=prediction;
				}
			}
		}
		
		////////////////////////////////////////////////////////////////////////////////
		// improve interactional context
		if (improve){
			float prediction=0;
			
			max=0;
			
			// reset improved context
			for (int e=0;e<InteractionList.length-1;e++){
				improvedContext[e]=0;
			}
				
			// for each primitive interaction
			for (int e=0;e<InteractionList.length-1;e++){
				
				// get the prediction in current context
				prediction=agent.signatureList.get(e).prediction(enactedEnsembles[0]);
				
				for (int i=0;i<InteractionList.length-1;i++){
					if (agent.signatureList.get(e).signature[i]>7)
						improvedContext[i]+= prediction * agent.signatureList.get(e).signature[i];
					
					if (Math.abs(improvedContext[i])>max) max=Math.abs(improvedContext[i]);
				}
			}
			
			if (max>1){
				for (int e=0;e<InteractionList.length-1;e++){
					improvedContext[e]=improvedContext[e]/(max/5);
				}
			}
		}
	}
	
}

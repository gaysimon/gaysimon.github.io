package version7_2_2_2.agnosticMemory;

import java.util.ArrayList;

import version7_2_2_2.Interface.InteractionList;

public class Simplified {

	private ArrayList<Integer> index;
	private ArrayList<Float> weights;
	
	private float prediction;
	
	public Simplified(){
		index=new ArrayList<Integer>();
		weights=new ArrayList<Float>();
		prediction=0;
	}

	
	public Simplified(float[] pattern){
		index=new ArrayList<Integer>();
		weights=new ArrayList<Float>();
		
		float max=0;
		for (int i=0;i<InteractionList.length-1;i++){
			if (Math.abs(pattern[i])>max) max=Math.abs(pattern[i]);
		}
		
		for (int i=0;i<InteractionList.length-1;i++){
			if (Math.abs(pattern[i])>max/3 && Math.abs(pattern[i])>5){
				index.add(i);
				weights.add(pattern[i]);
			}
		}
		if (index.size()>0){
			index.add(InteractionList.length-1);
			weights.add(pattern[InteractionList.length-1]);
		}
	}
	
	public Simplified clone(){
		Simplified ret=new Simplified();
		for (int i=0;i<size();i++) ret.insert(this.index.get(i), this.weights.get(i));
		return ret;
	}
	
	public float[] convert(){
		float[] pattern=new float[InteractionList.length];
		for (int i=0;i<index.size();i++){
			pattern[index.get(i)]=weights.get(i);
		}
		return pattern;
	}
	
	public int size(){
		return index.size();
	}
	
	public int getIndex(int i){
		return index.get(i);
	}
	
	public int getIndexOf(int id){
		if (index.size()==0) return -1;
		else{
			int i=0;
			while (id>index.size() && id>index.get(i)) i++;
			
			if (id==index.get(i)) return i;
			else return -1;
		}
	}
	
	public float getWeight(int i){
		return weights.get(i);
	}
	
	
	public float getMax(){
		float max=0;
		for (int i=0;i<index.size()-1;i++){
			if (Math.abs(weights.get(i))>max && index.get(i)<InteractionList.nbDF-1) max=Math.abs(weights.get(i));
		}
		return max;
	}
	
	public void set(int id, float w){
		int i=0;
		while (i<index.size() && id>index.get(i)) i++;
		if (i==index.size()){
			index.add(id);
			weights.add(w);
		}
		else{
			if (id==index.get(i)){
				weights.set(i, w);
			}
			else{
				index.add(i, id);
				weights.add(i,w);
			}
		}
	}
	
	
	public int insert(int id, float w){
		
		if (index.size()==0){
			index.add(id);
			weights.add(w);
			return 0;
		}
		else{
			int i=0;
			while (i<index.size() && id>index.get(i)) i++;
			
			if (i==index.size()){
				index.add(id);
				weights.add(w);
			}
			else{
				if (id==index.get(i)){
					weights.set(i, weights.get(i)+w);
				}
				else{
					index.add(i, id);
					weights.add(i,w);
				}
			}
			return i;
		}
	}
	
	
	public float predict(float[] img){
		float ret=0;
		
		// the signature must contain at least one non-null weight
		if (index.size()>1){
			for (int i=0;i<size();i++){
				ret+= weights.get(i) * img[index.get(i)];
			}
			ret= (float) ( 1 / (1+Math.exp(-ret)))*2-1;
		}
		
		prediction=ret;
		
		return ret;
	}
	
	public float getPrediction(){
		return prediction;
	}
	
	public void print(){
		System.out.println("////////////////////");
		for (int i=0;i<size();i++){
			System.out.println(index.get(i)+" ; "+weights.get(i));
		}
		System.out.println("--------------------");
	}
	
	public void clear(){
		index.clear();
		weights.clear();
	}
	
}

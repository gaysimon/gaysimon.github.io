package version7_2_2_2.agnosticMemory;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;

import version7_2_2_2.Interface.InteractionList;
import version7_2_2_2.platform.Agent;
import version7_2_2_2.platform.Observer;

/**
 * Space memory.
 * This class can also generate a predicted and an improved context
 * @author simon gay
 */
public class AgnosticMemory{
	
	private Agent agent;
	
	public static byte length=7;
	
	private Simplified[] maps;
	
	public float[][] imageMap;
	
	public Simplified[] patternList;
	
	public ArrayList<Path>[] pathMemory;			// list of current paths
	public ArrayList<Path>[] pathList;				// list of all possible paths
	
	public ArrayList<ArrayList<Integer>> bundles;
	public ArrayList<Instance> instanceList;
	
	public AgnosticMemory(Agent a){
		agent = a;
		
		imageMap=new float[3][InteractionList.length];
		maps=new Simplified[length];
		
		for (int i=0;i<length;i++){
			maps[i]=new Simplified();
		}
		
		patternList=new Simplified[InteractionList.length-1];
		for (int i=0;i<InteractionList.length-1;i++){
			patternList[i]=new Simplified(agent.signatureList.get(i).signature);
		}
		
		pathMemory=new ArrayList[3];
		pathList=new ArrayList[3];
		for (int i=0;i<3;i++){
			pathMemory[i]=new ArrayList<Path>();
			pathList[i]=new ArrayList<Path>();
		}
		
		bundles=new ArrayList<ArrayList<Integer>>();
		instanceList=new ArrayList<Instance>();
		
		load();
		//generatePath();
	}
	
	
	/**
	 * update the components of the Space Memory
	 * @param inter : last enacted primitive interaction
	 */
	public void updateMemory(){

		// detect object instances
		for (byte o=0;o<3;o++) pathMemory[o].clear();
		
		detect();
		
		System.out.println("//////////////////////////////////////////");

		removeIncompatibles();
		
		removeRedundant();
		
		
		// fill image map
		for (byte o=0;o<3;o++){
			for (int i=0;i<InteractionList.length;i++) imageMap[o][i]=0;
			
			for (int i=0;i<pathMemory[o].size();i++){
				for (int j=0;j<pathMemory[o].get(i).getPattern().size();j++){
					imageMap[o][pathMemory[o].get(i).getPattern().getIndex(j)]+=pathMemory[o].get(i).getPattern().getWeight(j);
				}
			}
		}
		
		// display sequence and prediction
		System.out.println("//////////////////////////////////////////");
		for (byte o=0;o<3;o++){
			for (int i=0;i<pathMemory[o].size();i++){
				System.out.println(pathMemory[o].get(i).name()+" ; "+pathMemory[o].get(i).getPrediction());
			}
		}
		
		generateBundles2(0.2f);
	}
	
	//////////////////////////////////////////////////////////////////////
	// generate the list of possible paths
	public void generatePath(){
		
		System.out.println("********** generate the list of paths ************");
		
		for (byte o=0;o<3;o++){
			
			System.out.println("*********** paths related to object "+o+" ************");
			
			// generate a set of sequences of movements
			byte[] sequence=new byte[length+1];
			for (int i=0;i<length+1;i++){
				sequence[i]=-1;
			}
			sequence[0]=o;
			
			boolean stop=false;
			int count=0;
			while (!stop){

				if (count%1000==0) System.out.println(count);
				count++;
				
				pathList[o].add(new Path(count-1,sequence,getImage(sequence)));

				sequence[1]++;
				for (int i=1;i<length-1;i++){
					if (sequence[i]>5){
						sequence[i]=0;
						sequence[i+1]++;
					}
				}
				if (sequence[length-1]>5) stop=true;
			}
		}
		
		System.out.println("********** path list generated ************");
	}
	
	
	public Simplified getImage(byte[] seq){

		// get initial signature
		maps[0]=patternList[InteractionList.nbDF+seq[0]].clone();

		// generate moved signatures
		byte a=1;
		float nb=0;
		float sum=0;
		float max=1;
		while (a<length && seq[a]!=-1){
			
			nb=0;
			sum=0;

			// reset map
			maps[a].clear();

			// compute map
			for (int i=0;i<maps[a-1].size();i++){

				// select secondary interaction associated to this part of the path
				if (maps[a-1].getIndex(i)>=seq[a]*InteractionList.size1*InteractionList.size2*3 && maps[a-1].getIndex(i)<(seq[a]+1)*InteractionList.size1*InteractionList.size2*3){

					Simplified sig=patternList[maps[a-1].getIndex(i)];
					max=sig.getMax();
					
					if (sig.size()>0) nb++;
					sum++;
					
					for (int j=0;j<sig.size();j++){
						if (sig.getIndex(j)<InteractionList.nbDF){
							maps[a].insert(sig.getIndex(j), maps[a-1].getWeight(i) * sig.getWeight(j) /max );
						}
					}
				}
			}
			
			// add the bias
			if (maps[a-1].size()>0){
				maps[a].insert(InteractionList.length-1, maps[a-1].getWeight(maps[a-1].size()-1));
			}

			// clear the pattern if a part is out of the interactional set
			if (nb/sum<1) maps[a].clear();
			
			a++;
		}
		
		return maps[a-1];
	}
	
	
	///////////////////////////////////////////////////////////////////////
	// detect object instances
	public void detect(){
		
		System.out.println();
		System.out.println("////////////// object detection //////////////");
		
		for (int o=0;o<3;o++){
			for (int i=0;i<InteractionList.length;i++) imageMap[o][i]=0;
		}
		
		float[] prediction= new float[3];
		
		for (int i=0;i<pathList[0].size();i++){
			
			for (byte o=0;o<3;o++){
				prediction[o]=pathList[o].get(i).getPattern().predict(agent.environmentContext.enactedEnsembles[0]);
			}
			
			for (byte o=0;o<3;o++){
				// interactions >0, >X, >F are opposite (considered as already learned)
				if (prediction[o]>0.9 && prediction[(o+1)%3]<-0.9 && prediction[(o+2)%3]<-0.9){
				
					//save the path and the image of signature
					pathMemory[o].add(pathList[o].get(i));
					
					// display sequence and prediction
					System.out.println(pathMemory[o].get(pathMemory[o].size()-1).name()+" ; "+prediction[o]);
					
					for (int j=0;j<pathList[o].get(i).getPattern().size();j++){
						imageMap[o][pathList[o].get(i).getPattern().getIndex(j)]+=pathList[o].get(i).getPattern().getWeight(j);
					}
				}
			}
		}
	}
	
	
	public void removeIncompatibles(){
		
		boolean remove=false;
		float in=0;
		float sum=0;
		boolean found=false;
		
		int o1,o2;
		int i,j,w1,w2;
		int w=0;
		
		for (o1=0;o1<3;o1++){
			System.out.println("--- "+o1);
			
			for (i=pathMemory[o1].size()-1;i>=0;i--){
					
				remove=false;
				//System.out.println("--- "+i);
				for (o2=o1+1;o2<3;o2++){
						
					for (j=pathMemory[o2].size()-1;j>=0;j--){
						
						in=0;
						sum=pathMemory[o1].get(i).patternSize()+pathMemory[o2].get(j).patternSize();
						w=0;
						
						for (w1=0;w1<pathMemory[o1].get(i).patternSize();w1++){
							
							w2=w;
							found=false;
							while (w2<pathMemory[o2].get(j).patternSize() && !found){
								if (pathMemory[o1].get(i).getPatternIndex(w1)<pathMemory[o2].get(j).getPatternIndex(w2)){
									found=true;
									w=w2;
								}
								else{
									if (pathMemory[o1].get(i).getPatternIndex(w1)==pathMemory[o2].get(j).getPatternIndex(w2)){
										found=true;
										if (pathMemory[o1].get(i).getWeight(w1) * pathMemory[o2].get(j).getWeight(w2)<0){
											in++;
										}
										w=w2+1;
									}
									else w2++;
								}
							}
						}
						
						if (in/sum>0.2){
							pathMemory[o2].remove(j);
							remove=true;
						}
						
					}
				}
				if (remove) pathMemory[o1].remove(i);
			}
		}
	}
	
	public void removeRedundant(){
		
		float in=0;
		float sum=0;
		boolean found=false;
		
		byte o;
		int i,j,w1,w2;
		int w=0;
		
		for (o=0;o<3;o++){
			System.out.println("%%% "+o);
			
			for (i=pathMemory[o].size()-1;i>=0;i--){
				//System.out.println("%%% "+i);
				for (j=pathMemory[o].size()-1;j>i;j--){
					
					if (pathMemory[o].get(i).length()+1<=pathMemory[o].get(j).length()){
						
						in=0;
						sum=0;
						w=0;
						
						for (w1=0;w1<pathMemory[o].get(j).patternSize();w1++){
							
							w2=w;
							found=false;
							while (w2<pathMemory[o].get(i).patternSize() && !found){
								if (pathMemory[o].get(i).getPatternIndex(w2)>pathMemory[o].get(j).getPatternIndex(w1)){
									found=true;
									w=w2;
								}
								else{
									if (pathMemory[o].get(i).getPatternIndex(w2)==pathMemory[o].get(j).getPatternIndex(w1)){
										found=true;
										if ( (pathMemory[o].get(i).getWeight(w2)* pathMemory[o].get(j).getWeight(w1)>0) ){
											in++;
										}
										w=w2+1;
									}
									else w2++;
								}
							}
							sum++;
						}
						
						if (in/sum>0.8){
							pathMemory[o].remove(j);
						}
					}
				}
			}
		}
	}
	
	
	public void generateBundles2(float t){
		
		float in=0;
		float sum=0;
		boolean found=false;
		
		int i,j,w1,w2;
		int w=0;
		
		for (byte o=0;o<3;o++){
			System.out.println("=== "+o);
			bundles.clear();
	
			// prepare bundle list
			for (i=0;i<pathMemory[o].size();i++){
				bundles.add(new ArrayList<Integer>());
				bundles.get(i).add(i);
			}
			
			for (i=pathMemory[o].size()-1;i>=0;i--){
				//System.out.println("=== "+i);
				for (j=pathMemory[o].size()-1;j>i;j--){
	
					in=0;
					sum=0;
					w=0;
					
					for (w1=0;w1<pathMemory[o].get(j).patternSize();w1++){
						
						w2=w;
						found=false;
						while (w2<pathMemory[o].get(i).patternSize() && !found){
							if (pathMemory[o].get(i).getPatternIndex(w2)>pathMemory[o].get(j).getPatternIndex(w1)){
								found=true;
								w=w2;
							}
							else{
								if (pathMemory[o].get(i).getPatternIndex(w2)==pathMemory[o].get(j).getPatternIndex(w1)){
									found=true;
									if (pathMemory[o].get(i).getWeight(w2) * pathMemory[o].get(j).getWeight(w1)>0){
										in++;
									}
									w=w2+1;
								}
								else w2++;
							}
						}
						sum++;
					}
					
					// if overlap, bundle the two paths together
					if (in/sum>0.2){
						
						// find the bundle of the first path
						int a=0;
						int b=0;
						int k1=0;
						int k2=0;
						found=false;
						while (a<bundles.size() && !found){
							k1=0;
							while (k1<bundles.get(a).size() && !found){
								if (bundles.get(a).get(k1)==i) found=true;
								else k1++;
							}
							a++;
						}
						a--;
						
						found=false;
						while (b<bundles.size() && !found){	
							k2=0;
							while (k2<bundles.get(b).size() && !found){
								if (bundles.get(b).get(k2)==j) found=true;
								else k2++;
							}
							b++;
						}
						b--;
						
						// merge bundles A and B and remove B
						if (a!=b){
							for (int k=0;k<bundles.get(b).size();k++){
								bundles.get(a).add(bundles.get(b).get(k));
							}
							bundles.remove(b);
						}
					}
				}
			}
			
			// display bundles
			for (i=0;i<bundles.size();i++){
				System.out.println("################# bundle "+i+" , "+bundles.get(i).size()+" elements");
				for (j=0;j<bundles.get(i).size();j++){
					System.out.println(" +++ "+pathMemory[o].get(bundles.get(i).get(j)).name()+" ; "+pathMemory[o].get(bundles.get(i).get(j)).getPrediction());
				}
			}
			System.out.println("####################################################");
			
			// generate places
			instanceList.clear();
			
			for (int b=0;b<bundles.size();b++){
				
				// create instance of object
				instanceList.add(new Instance(o,b));
				
				// set the list of Paths
				for (int p=0;p<bundles.get(b).size();p++){
					instanceList.get(instanceList.size()-1).addPath(pathMemory[o].get(bundles.get(b).get(p)));
				}
			}
			
			for (i=0;i<instanceList.size();i++){
				
				// define the set of places that contain this instance
				instanceList.get(i).definePlace();
				instanceList.get(i).print(false, true);
			}
			
			System.out.println("####################################################");
			System.out.println("#### final list of places                       ####");
			System.out.println("####################################################");
			
			for (i=0;i<instanceList.size();i++){
				
				// remove redundant places
				instanceList.get(i).removeRedundant();
				instanceList.get(i).print(true, true);
			}
		}
	}
	
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void save(){
		System.out.println("=====================prepare to save path list...======================");
		
		String fileName = Observer.path+"spaceMemory/pathListV7_2_2_2 "+length+" "+agent.getIdent()+".txt";
		
		try {
			PrintWriter file  = new PrintWriter(new FileWriter(fileName));
			
			// save path list
			for (int o=0;o<3;o++){
				for (int i=0;i<pathList[o].size();i++){
					
					// save the sequence
					for (int k=0;k<pathList[o].get(i).length();k++){
						file.print(pathList[o].get(i).get(k)+" ");
					}
					file.println();
					
					// save the simplified pattern
					if (pathList[o].get(i).patternSize()==0) file.println("0");
					else{
						for (int k=0;k<pathList[o].get(i).patternSize();k++){
							file.print(pathList[o].get(i).getPatternIndex(k)+" "
									  +pathList[o].get(i).getWeight(k)+" ");
						}
						file.println();
					}
					
					// save incompatible list
					/*for (int j=0;j<3;j++){
						if (j!=o){
							for (int k=0;k<pathList[o].get(i).incompatibleList[j].size();k++){
								file.print(pathList[o].get(i).incompatibleList[j].get(k)+" ");
							}
							file.println();
						}
					}*/
					
					// save redundancy list
					/*for (int k=0;k<pathList[o].get(i).redundantList.size();k++){
						file.print(pathList[o].get(i).redundantList.get(k)+" ");
					}
					file.println();*/
					/*
					// save bundle list
					for (int k=0;k<pathList[o].get(i).bundleList.size();k++){
						file.print(pathList[o].get(i).bundleList.get(k)+" ");
					}
					file.println();*/
				}
				file.println("+++");
			}
			file.close();
			System.out.println("path list saved");
		}
		catch (Exception e) {e.printStackTrace();}
	}
	
	
	
	public void load(){
		String fileName = Observer.path+"spaceMemory/pathListV7_2_2_2 "+length+" "+agent.getIdent()+".txt";
		
		String[] elements;
		
		System.out.println("load file");
		
		try {
			InputStream ips=new FileInputStream(fileName); 
			InputStreamReader ipsr=new InputStreamReader(ips);
			BufferedReader br=new BufferedReader(ipsr);
			String line;
			
			byte[] seq=new byte[length];
			Simplified pattern=new Simplified();

			// load paths
			int i=0;
			for (int o=0;o<3;o++){
				i=0;

				while (!(line=br.readLine()).endsWith("+++")){
					elements=line.split(" ");

					// get the sequence
					for (int k=0;k<length;k++){
						if (k<elements.length) seq[k]=(byte)Integer.parseInt(elements[k]);
						else seq[k]=-1;
					}
					
					// get the pattern
					line=br.readLine();
					elements=line.split(" ");
					pattern.clear();
					if (elements.length>1){
						for (int k=0;k<elements.length;k+=2){
							pattern.insert(Integer.parseInt(elements[k]), Float.parseFloat(elements[k+1]));
						}
					}
					pathList[o].add(new Path(i,seq,pattern));
					
					// get the incompatible list
					/*for (int j=0;j<3;j++){
						if (j!=o){
							line=br.readLine();
							if (!line.equals("")){
								elements=line.split(" ");
								for (int k=0;k<elements.length;k++){
									pathList[o].get(pathList[o].size()-1).addIncompatible(j, Integer.parseInt(elements[k]));
								}
							}
						}
					}

					// get the redundant list
					line=br.readLine();
					if (!line.equals("")){
						elements=line.split(" ");
						for (int k=0;k<elements.length;k++){
							pathList[o].get(pathList[o].size()-1).addRedundant(Integer.parseInt(elements[k]));
						}
					}

					// get the bundle list
					line=br.readLine();
					if (!line.equals("")){
						elements=line.split(" ");
						for (int k=0;k<elements.length;k++){
							pathList[o].get(pathList[o].size()-1).addBundle(Integer.parseInt(elements[k]));
						}
					}*/

					if (i%100==0) System.out.println("*** "+o+ " ; "+i);
					i++;
				}
			}

		} 
		catch (Exception e) {
			System.out.println("no file found");
			generatePath();
		}
	}
}

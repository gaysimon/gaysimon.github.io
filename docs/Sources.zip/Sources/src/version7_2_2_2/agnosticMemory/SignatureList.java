package version7_2_2_2.agnosticMemory;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;

import version7_2_2_2.Interface.InteractionList;
import version7_2_2_2.Interface.PrimitiveInteraction;
import version7_2_2_2.platform.Agent;
import version7_2_2_2.platform.Observer;

/**
 * List of signatures
 * @author simon
 */
public class SignatureList {

	private Agent agent;
	
	public ArrayList<Signature> signatureList;

	public static boolean load=true;				// load signatures
	
	public SignatureList(Agent a){
		agent=a;

		signatureList=new ArrayList<Signature>();
		for (int i=0;i<InteractionList.length-1;i++){
			signatureList.add(new Signature( getInteractionOfIndex(i)));
		}
		
		if (load) load();
	}
	
	public Signature get(int i){
		return signatureList.get(i);
	}
	
	public int size(){
		return signatureList.size();
	}
	
	/**
	 * integrate the last result of enaction cycle
	 * @param input : environemental context E_{t-1} (context before enaction)
	 * @param output: environemental context E_t (interactions defined as a success)
	 * @param enacted : enacted primary interaction
	 */
	public void learn(float[] input, float[] output, PrimitiveInteraction enacted){

		int inter=-1;
		if (enacted.getAction().getName().equals(">")){
			if (enacted.getPerception().getId()==1) inter=-1;
			else if (enacted.getPerception().getId()==2) inter=1;
			else inter=0;
		}
		else if (enacted.getAction().getName().equals("v")) inter=2;
		else if (enacted.getAction().getName().equals("^")) inter=3;
		else if (enacted.getAction().getName().equals("\\"))inter=4;
		else if (enacted.getAction().getName().equals("/")) inter=5;
		
		if (inter>=0){
			// learn dynamic features if corresponding primitive interaction is enacted
			int min=inter*InteractionList.size1*InteractionList.size2*3;
			int max=(inter+1)*InteractionList.size1*InteractionList.size2*3;
			for (int i=min;i<max;i++){
				if (agent.environmentContext.enactedEnsembles[0][i]==1) signatureList.get(i).learn(agent.environmentContext.enactedEnsembles[1],1);
				else signatureList.get(i).learn(agent.environmentContext.enactedEnsembles[1],-1);
			}
		}
		
		// learn primitive interaction if success or fail
		for (int i=InteractionList.nbDF;i<InteractionList.length-1;i++){
			if (agent.environmentContext.enactedEnsembles[0][i]!=0){
				signatureList.get(i).learn(agent.environmentContext.enactedEnsembles[1],agent.environmentContext.enactedEnsembles[0][i]);

				// learn alternative interactions
				if (inter==-1){
					signatureList.get(0+InteractionList.nbDF).learn(agent.environmentContext.enactedEnsembles[1],-1);
					signatureList.get(2+InteractionList.nbDF).learn(agent.environmentContext.enactedEnsembles[1],-1);
				}
				if (inter==0){
					signatureList.get(1+InteractionList.nbDF).learn(agent.environmentContext.enactedEnsembles[1],-1);
					signatureList.get(2+InteractionList.nbDF).learn(agent.environmentContext.enactedEnsembles[1],-1);
				}
				if (inter==1){
					signatureList.get(0+InteractionList.nbDF).learn(agent.environmentContext.enactedEnsembles[1],-1);
					signatureList.get(1+InteractionList.nbDF).learn(agent.environmentContext.enactedEnsembles[1],-1);
				}
			}
		}
	}
	
	public void setPredictions(float[] img){
		for (int i=0;i<signatureList.size();i++){
			if (isValid(i)){
				signatureList.get(i).setPrediction(img);
			}
		}
	}
	
	
	// return true if the interaction can be tested (true if primary)
	public boolean isValid(int id){
		if (id>=InteractionList.nbDF) return true;
		else{
			if (signatureList.get(id).nbTest>0){
				if (id>=0 && id<InteractionList.size1*InteractionList.size2*3){
					return signatureList.get(InteractionList.nbDF).isAccurate() && signatureList.get(InteractionList.nbDF).prediction>0.8;
				}
				else if (id>=InteractionList.size1*InteractionList.size2*3 && id<2*InteractionList.size1*InteractionList.size2*3){
					return signatureList.get(InteractionList.nbDF+2).isAccurate() && signatureList.get(InteractionList.nbDF+2).prediction>0.8;
				}
				else if (id>=2*InteractionList.size1*InteractionList.size2*3 && id<3*InteractionList.size1*InteractionList.size2*3){
					return signatureList.get(InteractionList.nbDF+3).isAccurate() && signatureList.get(InteractionList.nbDF+3).prediction>0.8;
				}
				else if (id>=3*InteractionList.size1*InteractionList.size2*3 && id<4*InteractionList.size1*InteractionList.size2*3){
					return signatureList.get(InteractionList.nbDF+4).isAccurate() && signatureList.get(InteractionList.nbDF+4).prediction>0.8;
				}
				else if (id>=4*InteractionList.size1*InteractionList.size2*3 && id<5*InteractionList.size1*InteractionList.size2*3){
					return signatureList.get(InteractionList.nbDF+5).isAccurate() && signatureList.get(InteractionList.nbDF+5).prediction>0.8;
				}
				else{
					return signatureList.get(InteractionList.nbDF+6).isAccurate() && signatureList.get(InteractionList.nbDF+6).prediction>0.8;
				}
			}
			else return false;
		}
	}
	
	
	// get the id of the associated primary interaction
	public PrimitiveInteraction getInteractionOfIndex(int id){
		int ret=0;
		if (id>=InteractionList.nbDF){
			ret=id-InteractionList.nbDF;
		}
		else{
			if (id>=0 && id<InteractionList.size1*InteractionList.size2*3) ret=0;
			else if (id>=  InteractionList.size1*InteractionList.size2*3 && id<2*InteractionList.size1*InteractionList.size2*3) ret=2;
			else if (id>=2*InteractionList.size1*InteractionList.size2*3 && id<3*InteractionList.size1*InteractionList.size2*3) ret=3;
			else if (id>=3*InteractionList.size1*InteractionList.size2*3 && id<4*InteractionList.size1*InteractionList.size2*3) ret=4;
			else if (id>=4*InteractionList.size1*InteractionList.size2*3 && id<5*InteractionList.size1*InteractionList.size2*3) ret=5;
			else if (id>=5*InteractionList.size1*InteractionList.size2*3 && id<6*InteractionList.size1*InteractionList.size2*3) ret=6;
		}

		return agent.interactionList.getInteraction(ret);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void save(){
		System.out.println("=====================prepare to save agnostic memory...======================");
		
		// save second level patterns
		
		String fileName = Observer.path+"spaceMemory/spaceMemoryV7_2_2_2 "+agent.getIdent()+".txt";
		
		try {
			PrintWriter file  = new PrintWriter(new FileWriter(fileName));
			
			// save signatures
			for (int i=0;i<agent.signatureList.signatureList.size();i++){
				for (int k=0;k<InteractionList.length;k++){
					file.print(agent.signatureList.signatureList.get(i).signature[k]+" ");
				}
				file.println(agent.signatureList.signatureList.get(i).average_delta1+" "+agent.signatureList.signatureList.get(i).average_delta2);
				if (i%1000==0) System.out.println((float)i/(float)agent.signatureList.signatureList.size()*100+"%");
			}
			file.close();
			System.out.println("memory file saved");
		}
		catch (Exception e) {e.printStackTrace();}
	}
	
	public void load(){
		String fileName = Observer.path+"spaceMemory/spaceMemoryV7_2_2_2 "+agent.getIdent()+".txt";
		String[] elements;
		System.out.println("load file");
		try {
			InputStream ips=new FileInputStream(fileName); 
			InputStreamReader ipsr=new InputStreamReader(ips);
			BufferedReader br=new BufferedReader(ipsr);
			String line;
			// load signatures
			int i=0;
			while ((line=br.readLine())!=null){
				elements=line.split(" ");
				// get condition pattern
				float max=0;

				if (signatureList.size()<=i) signatureList.add(new Signature(getInteractionOfIndex(signatureList.size())));
				for (int k=0;k<InteractionList.length;k++){

					signatureList.get(i).signature[k]=Float.parseFloat(elements[k]);
					if (Math.abs(Float.parseFloat(elements[k]))>max) max=Math.abs(Float.parseFloat(elements[k]));
				}
				
				if (elements.length==InteractionList.length+2){
					signatureList.get(i).average_delta1=Float.parseFloat(elements[InteractionList.length]);
					signatureList.get(i).average_delta2=Float.parseFloat(elements[InteractionList.length+1]);
				}
				
				if (max>1){
					signatureList.get(i).nbTest=1;
					signatureList.get(i).accurate=6;
				}
				
				signatureList.get(i).maxPattern1=max;
				signatureList.get(i).maxPattern2=max;
				if (i%1000==0) System.out.println(i);
				i++;
			}
		} 
		catch (Exception e) {
			System.out.println("no file found : space memory");
		}
	}
	
}

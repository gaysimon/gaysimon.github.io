package version7_2_2_2.Interface;

/**
 * Definition of a primitive interaction
 * @author simon
 */
public class PrimitiveInteraction{

	private PrimitiveAction action;
	private PrimitivePerception perception;

	private float valence;
	
	private int index;							// index of the primary interaction
	
	// primary interaction
	public PrimitiveInteraction(PrimitiveAction act, PrimitivePerception obs){
		action=act;
		perception=obs;
		
		int a=0;
		if (action.getName().equals(">")) a=0;
		if (action.getName().equals("v")) a=1;
		if (action.getName().equals("^")) a=2;
		if (action.getName().equals("\\"))a=3;
		if (action.getName().equals("/")) a=4;
		
		if (a==0) index=perception.getId();
		else      index=2+a;
		
		
		valence=InteractionList.valence(act, obs);
		
	}
	
	
	public boolean isEqual(PrimitiveInteraction inter){
		return this.action.isEqual(inter.action) && this.perception.isEqual(inter.perception);
	}
	
	// return true if inter is composed with the same action
	public boolean isAlternate(PrimitiveInteraction inter){
		return this.action.isEqual(inter.action);
	}
	
	/////////////////////////////////////////
	public PrimitiveAction getAction(){
		return action;
	}

	public PrimitivePerception getPerception(){
		return perception;
	}
	
	public float valence(){
		return valence;
	}
	
	public int getIndex(){
		return index;
	}
	
	public String getName(){
		return action.getName()+perception.getName();
	}
	
}

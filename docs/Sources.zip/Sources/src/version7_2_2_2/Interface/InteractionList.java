package version7_2_2_2.Interface;

import java.util.ArrayList;

/**
 * This class define the initial set of primitive interactions
 * @author simon gay
 */
public class InteractionList {
	
	private ArrayList<PrimitiveAction> actions;
	private ArrayList<PrimitivePerception> perception;
	
	private ArrayList<PrimitiveInteraction> primitiveList;
	
	public static int size1=30;					// width of visual system
	public static int size2=15;					// depth of visual system
	
	public static int nbDF=size1*size2 *6 *3;		// number of secondary (visual) interactions
	public static int length=nbDF +8;				// 7 "primary" interactions >O, >X, >F, v, ^, \ ,/ + 1 bias
	
	public InteractionList(){
		
		// define here the possible actions
		actions=new ArrayList<PrimitiveAction>();
		actions.add(new PrimitiveAction(">",0));
		actions.add(new PrimitiveAction("v",1));
		actions.add(new PrimitiveAction("^",2));
		actions.add(new PrimitiveAction("\\",3));
		actions.add(new PrimitiveAction("/",4));
		
		// define the perception vector(s)
		perception=new ArrayList<PrimitivePerception>();
		perception.add(new PrimitivePerception("O",0));
		perception.add(new PrimitivePerception("X",1));
		perception.add(new PrimitivePerception("F",2));
		
		// define the set of primitive interactions
		primitiveList=new ArrayList<PrimitiveInteraction>();
		primitiveList.add(new PrimitiveInteraction(actions.get(0),perception.get(0)));
		primitiveList.add(new PrimitiveInteraction(actions.get(0),perception.get(1)));
		primitiveList.add(new PrimitiveInteraction(actions.get(0),perception.get(2)));
		
		primitiveList.add(new PrimitiveInteraction(actions.get(1),perception.get(0)));
		primitiveList.add(new PrimitiveInteraction(actions.get(2),perception.get(0)));
		primitiveList.add(new PrimitiveInteraction(actions.get(3),perception.get(0)));
		primitiveList.add(new PrimitiveInteraction(actions.get(4),perception.get(0)));
	}
	
	public int nbInteraction(){
		return primitiveList.size();
	}
	
	public PrimitiveInteraction getInteraction(int i){
		return primitiveList.get(i);
	}
	
	public ArrayList<PrimitiveInteraction> getList(){
		return primitiveList;
	}
		
	/**
	 *  define the valence for each interaction
	 * @param a, p primitive action and perception of an interaction
	 * @return valence of interaction (a,p)
	 */
	public static float valence(PrimitiveAction a, PrimitivePerception p){
		
		float valence=0;
		
		if (a.getId()==0){
			if (p.getId()==0) valence=2;
			if (p.getId()==1) valence=-5;
			if (p.getId()==2) valence=50;
			
		}
		else valence=-3;
		
		return valence;
	}
}

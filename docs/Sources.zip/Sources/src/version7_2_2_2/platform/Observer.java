package version7_2_2_2.platform;

import version7_2_2_2.Interface.PrimitiveInteraction;

/**
 * This class extract data about agents' behaviors for an external observer
 * @author simon gay
 */
public class Observer {

	private Agent agent;
	
	private int counter;								// number of completed decision cycle
	
	public PrimitiveInteraction[] timelinePrimitive;	// sequence of enacted interactions (limited to the "length" last interactions)
	
	public static int length=200;						// length of the timeline
	
	//////////////////////////////////////////////////////
	
	public float[][] trace;							// sequence of previous positions of the agent
	public int[] interactionType;
	public static int pathLength=30;					//length of the trace
	
	//////////////////////////////////////////////////////
	private boolean picture=false;					// if true, frames associated to the agent can be saved as jpeg images (if allowed)
	private int frame;									// index of captured images
	
	private static int capture_delay=200;				// nb of decision cycles between two image captures
	public static String path=System.getProperty("user.home") +"/IDEAL/version7_2_2_2/";

	//////////////////////////////////////////////////////
	private int selected_node=0;						// store the selected interaction (used by display devices)
	
	//////////////////////////////////////////////////////
	private XMLStreamTracer m_tracer;
	
	//////////////////////////////////////////////////////
	
	public Observer(Agent a){
		agent=a;
		
		timelinePrimitive=new PrimitiveInteraction[length];
		for (int i=0;i<length;i++){
			timelinePrimitive[i]=null;
		}
			
		// trace
		trace=new float[pathLength][2];
		interactionType=new int[pathLength];
		
		frame=0;
		counter=0;
		
		/*
		m_tracer=new XMLStreamTracer("http://134.214.128.53/abstract/lite/php/stream/",
				                     "dsyRyrlVFmaeVjpOdSDCeNPsGcmfwr");
		/**/
		
		/*
		m_tracer=new XMLStreamTracer("http://localhost/alite/php/stream/",
				                     "LUAsNP-QqEAStUfzDFwewQIPcwRlnM");
		/**/
	}
	
	public void updateObserver(PrimitiveInteraction inter){
		
		/////////////////////////////////////////////////////////////
		// update timeline
		/////////////////////////////////////////////////////////////
		for (int i=length-1;i>0;i--){
			timelinePrimitive[i]=timelinePrimitive[i-1];
		}
		timelinePrimitive[0]=inter;
		
		
		/////////////////////////////////////////////////////////////
		// update trace
		/////////////////////////////////////////////////////////////
		for (int i=pathLength-1;i>0;i--){
			trace[i][0]=trace[i-1][0];
			trace[i][1]=trace[i-1][1];
			interactionType[i]=interactionType[i-1];
		}
		trace[0][0]=agent.body.getpx();
		trace[0][1]=agent.body.getpy();
		
		if (inter.getAction().getId()==0) interactionType[0]=inter.getPerception().getId();	
		else 						   interactionType[0]=2+inter.getAction().getId();
		
		
		/////////////////////////////////////////////////////////////
		// screen shot
		/////////////////////////////////////////////////////////////
		
		if (picture){
			frame++;
			if (frame>=capture_delay){
				frame=0;
				agent.saveImage(Observer.path);
			}
		}
		
		/////////////////////////////////////////////////////////////
		// update node position
		/////////////////////////////////////////////////////////////
		agent.nodeList.moveNode();
	}
	
	//////////////////////////////////////////////////////
	public void setSelectedNode(int n){
		selected_node=n;
	}
	public int getSelectedNode(){
		return selected_node;
	}
	
	//////////////////////////////////////////////////////
	// send data to Abstract-Lite module
	public void trace(){
		
		// abstract lite trace
		m_tracer.startNewEvent(counter);
		
		m_tracer.addEventElement("Source", "VacuumSG");
		m_tracer.addEventElement("clock", ""+counter);
		
		// intended interaction
		if (agent.decision.getIntention()!=null)
			m_tracer.addEventElement("primitive_intended_act", agent.decision.getIntention().getName());
		
		counter++;
		
		m_tracer.finishEvent();
	}
	
	// initialize every position of the trace to (x,y)
	public void setPosition(float x,float y){
		for (int i=0;i<pathLength;i++){
			trace[i][0]=x;
			trace[i][1]=y;
		}
	}
	
	// clear trace
	public void clearTrace(){
		setPosition(agent.body.getpx(),agent.body.getpy());
		for (int i=0;i<pathLength;i++){
			interactionType[i]=0;
		}
	}
	
}

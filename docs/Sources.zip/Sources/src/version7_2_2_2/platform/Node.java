package version7_2_2_2.platform;


public class Node {

	public float x;
	public float y;
	
	public int type;
	
	public int index;
	
	public Node(int t, int i){
		type=t;
		index=i;
		
		x=(float) (Math.random()*100+140);
		y=(float) (Math.random()*100+80);
	}
	
	public Node(int t, int i, float px, float py){
		type=t;
		index=i;
		
		x=px;
		y=py;
	}
	
	
}

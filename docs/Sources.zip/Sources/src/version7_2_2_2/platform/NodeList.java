package version7_2_2_2.platform;

import java.util.ArrayList;

import version7_2_2_2.Interface.InteractionList;
import version7_2_2_2.platform.Agent;

public class NodeList {

	private ArrayList<Node> nodeList;
	private Agent agent;
	
	public boolean mesh=false;			// true : display meshes correspondences. false : display interaction transformations
	
	public NodeList(Agent a){
		
		agent=a;
		nodeList=new ArrayList<Node>();
		
		
		int index=0;
		
		if (mesh){
			// if mesh display, the position of nodes is defined randomly (except for the first group of interactions)
			for (int i=0;i<InteractionList.size1;i++){
				for (int j=0;j<InteractionList.size2;j++){
					nodeList.add(new Node(0,index,2+ 3*i, 3 + 3*j));
					index++;
					nodeList.add(new Node(0,index,2+ 3*i, 3 + 3*j));
					index++;
					nodeList.add(new Node(0,index,2+ 3*i, 3 + 3*j));
					index++;
				}
			}
			for (int t=1;t<6;t++){
				for (int i=0;i<InteractionList.size1*InteractionList.size2*3;i++){
					nodeList.add(new Node(t,index));
					index++;
				}
			}
		}
		else{
			// else, the position of nodes is defined to match the real position of nodes
			for (int t=0;t<6;t++){
				for (int i=0;i<InteractionList.size1;i++){
					for (int j=0;j<InteractionList.size2;j++){
						nodeList.add(new Node(0,index,2+ 3*i, 3 + 3*j));
						index++;
						nodeList.add(new Node(0,index,2+ 3*i, 3 + 3*j));
						index++;
						nodeList.add(new Node(0,index,2+ 3*i, 3 + 3*j));
						index++;
					}
				}
			}/**/
		}
		
		// nodes of primary interactions
		nodeList.add(new Node(0,index  ));  // move forward
		nodeList.add(new Node(6,index+1));  // bump		 
		nodeList.add(new Node(1,index+2));  // eat
		nodeList.add(new Node(2,index+3));  // turn left 90
		nodeList.add(new Node(3,index+4));  // turn right 90
		nodeList.add(new Node(4,index+5));  // turn left 45
		nodeList.add(new Node(5,index+6));  // turn right 45
		nodeList.add(new Node(7,index+7));  // bias input
	}
	
	
	public void moveNode(){

		if (mesh){
			// move nodes
			float d=0;
			for (int a=0;a<10;a++){
				for (int i=0;i<InteractionList.length-7;i++){
					
					// attraction force
					//nodeList.get(i).gatherNodes(agent);
					for (int n=0;n<InteractionList.size1*InteractionList.size2*3;n++){
						if (agent.signatureList.get(i).signature[n]>5){
							
							// gather nodes
							for (int k=InteractionList.size1*InteractionList.size2*3;k<InteractionList.length-7;k++){
								if (agent.signatureList.get(i).signature[k]>5){
									d=(float) Math.sqrt((get(n).x-get(k).x)*(get(n).x-get(k).x)
						                               +(get(n).y-get(k).y)*(get(n).y-get(k).y));
					
									if (d>0.01){
										get(k).x+= 0.01 * agent.signatureList.get(i).signature[k]* (get(n).x-get(k).x)/d;
										get(k).y+= 0.01 * agent.signatureList.get(i).signature[k]* (get(n).y-get(k).y)/d;
									}
								}
							}
						}
					}
		
				}
				
				agent.getMain().display.repaint();
			}
			
			
			for (int i=0;i<InteractionList.length;i++){
				if (nodeList.get(i).x<0  ) nodeList.get(i).x=0;
				if (nodeList.get(i).x>130) nodeList.get(i).x=130;
				if (nodeList.get(i).y<0  ) nodeList.get(i).y=0;
				if (nodeList.get(i).y>100) nodeList.get(i).y=100;
			}
		}
	}
	
	//////////////////////////////////////////////////////////
	
	public Node get(int i){
		return nodeList.get(i);
	}
	
	public int size(){
		return nodeList.size();
	}
	
}

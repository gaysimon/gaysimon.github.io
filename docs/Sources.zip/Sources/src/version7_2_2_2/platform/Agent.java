package version7_2_2_2.platform;

import version7_2_2_2.Interface.*;
import version7_2_2_2.display.*;
import version7_2_2_2.environment.*;
import version7_2_2_2.sensorySystem.*;
import version7_2_2_2.agnosticMemory.*;
import version7_2_2_2.Main;

/**
 * whole learning mechanism
 * This class is used as a bridge between modules
 * @author simon gay
 */
public class Agent {

	public Action action;
	public Perception sensors;
	public InteractionList interactionList;
	
	public Robot body;
	public Observer observer;
	public EnvironmentContext environmentContext;
	public AgnosticMemory agnosticMemory;
	public SignatureList signatureList;
	
	public NodeList nodeList;
	
	//%%%%%%%%%%%%%%%%% specific to simulators %%%%%%%%%%%%%%%%%%%%%%%
	public Probe probe;
	public VisualSystem visual;
	//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	public Decision decision;
	
	private Main main;
	
	private int ident;
	
	public Agent(int id, Main m){

		action=new Action(this);
		sensors=new Perception(this);
		interactionList=new InteractionList();
		
		body=new Robot();
		decision=new Decision(this);
		observer=new Observer(this);
		signatureList=new SignatureList(this);
		environmentContext=new EnvironmentContext(this);
		agnosticMemory=new AgnosticMemory(this);


		nodeList=new NodeList(this);

		
		//%%%%%%%%%%%%%%%%% specific to simulators %%%%%%%%%%%%%%%%%%%%%%%
		probe=new Probe(this);
		visual=new VisualSystem(this);
		//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

		ident=id;
		
		main=m;
		
	}
	
	// enact a simulation substep
	public void act(){
		action.act();
	}
	
	public boolean isStopped(){
		return action.isStopped();
	}
	
	public int getIdent(){
		return ident;
	}
	
	public Main getMain(){
		return main;
	}
	
	//%%%%%%%%%%%%%%%%% specific to simulators %%%%%%%%%%%%%%%%%%%%%%%
	public void setPosition(float x, float y, float theta){
		body.setPosition(x,y,theta);
		observer.setPosition(x,y);
	}
	
	public void setEnvironment(Environment e){
		body.setEnvironment(e);
		probe.setEnvironment(e);
	}
	//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	
	// initialize the set of panels related to the agent
	public void setDisplay(){
		
		boolean probeDisplay=false;
		boolean signatures=true;
		boolean memory=false;
		boolean movement=true;
		boolean instance=true;
		
		int size;
		int i;
		boolean found;

		//////////////////////
		if (probeDisplay){
			size=main.display.nbFrame();
			i=0;
			found=false; 
			while (i<size && !found){
				if (main.display.get(i).getClass().getName().equals("version7_2_2_2.display.ProbeFrame")) found=true;
				i++;
			}
			if (!found) main.display.addFrame(new ProbeFrame(this));
			else        
				((ProbeFrame)main.display.get(i-1)).setAgent(this);
		}
		
		//////////////////////
		if (signatures){
			size=main.display.nbFrame();
			i=0;
			found=false;
			while (i<size && !found){
				if (main.display.get(i).getClass().getName().equals("version7_2_2_2.display.SignatureFrame")) found=true;
				i++;
			}
			if (!found) main.display.addFrame(new SignatureFrame(this));
			else
				((SignatureFrame)main.display.get(i-1)).setAgent(this);
		}
		
		//////////////////////
		if (memory){
			size=main.display.nbFrame();
			i=0;
			found=false;
			while (i<size && !found){
				if (main.display.get(i).getClass().getName().equals("version7_2_2_2.display.MemoryFrame")) found=true;
				i++;
			}
			if (!found) main.display.addFrame(new MemoryFrame(this));
			else        
				((MemoryFrame)main.display.get(i-1)).setAgent(this);
		}
		
		//////////////////////
		if (movement){
			size=main.display.nbFrame();
			i=0;
			found=false;
			while (i<size && !found){
				if (main.display.get(i).getClass().getName().equals("version7_2_2_2.display.MovementFrame")) found=true;
				i++;
			}
			if (!found) main.display.addFrame(new MovementFrame(this));
			else        
				((MovementFrame)main.display.get(i-1)).setAgent(this);
		}
		
		//////////////////////
		if (instance){
			size=main.display.nbFrame();
			i=0;
			found=false;
			while (i<size && !found){
				if (main.display.get(i).getClass().getName().equals("version7_2_2_2.display.InstanceFrame")) found=true;
				i++;
			}
			if (!found) main.display.addFrame(new InstanceFrame(this));
			else        
				((InstanceFrame)main.display.get(i-1)).setAgent(this);
		}
	}

	// save modules data
	public void save() {
		//signatureList.save();
		agnosticMemory.save();
	}
	
	// save images from displayers
	public void saveImage(String path){
		main.saveImage(path);
	}
	
}

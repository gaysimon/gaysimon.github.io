package version7_2.environment;

/**
 * representation of a physical agent in its environment
 * @author simon gay
 */
public class Robot {

	private Environment env;
	private static boolean eatPrey=true;			// if true, a prey disappears when the agent "eats" it
	private static boolean replacePrey=true;		// if true, a new prey is added when the agent enacts "eat"

	private float px;								// position (x,y) in grid cell unit
	private float py;
	
	private float rz;								// orientation rz in radius
	
	//////////////////////////////////////////////////////////////////////
	// sensors and "leds"
	public int[] sensors;   // [0] bump , [1] turn , [2] touch , [3] left , [4] right , [5] reach
	public boolean[] display;
	//--------------------------------------------------------------------
	
	public Robot(){
		
		// initialization of sensors
		sensors=new int[6];
		for(int i=0;i<6;i++){
			sensors[i]=0;
		}
		
		display=new boolean[3];
		display[0]=false;
		display[1]=false;
		display[2]=false;
	}
	
	public void setEnvironment(Environment e){
		env=e;
	}
	
	// activate the robot
	public void move(double[] act){
		
		////////////////////////////////////////////////////////////////////
		// movements
		double orientation=rz;
		
		px+=  act[0]*Math.sin(orientation)+act[1]*Math.cos(orientation);
		py+=  act[0]*Math.cos(orientation)+act[1]*Math.sin(orientation);
		
		rz+=act[2];
		if (rz<0) rz+=2*Math.PI;
		if (rz>=2*Math.PI) rz-=2*Math.PI;
		
		for(int k=0;k<6;k++){
			sensors[k]=0;
		}
		if (act[0]!=0 || act[1]!=0) sensors[0]=1;
		
		////////////////////////////////////////////////////////////////////
		// collisions
		
		int i=Math.round(px);
		int j=Math.round(py);
		
		
		for (int w=-1;w<=1;w++){
			for (int h=-1;h<=1;h++){
				if (i!=0 && j!=0){
					
					if (i+w>=0 && i+w<env.m_w && j+h>=0 && j+h<env.m_h){
						if (!env.isWalkthroughable(i+w,j+h)){
							// case lateral block
							if (w==0){
								if ((j+h - py)*h<1){
									py-= h*(1 - h*(j+h - py));
									sensors[0]=2;
								}
							}
							else{ 
								if (h==0){
									if ((i+w - px)*w<1){
										px-= w*(1 - w*(i+w - px));
										sensors[0]=2;
									}
								}
								else{
									// case corner block
									float x2= (i+w)-w*0.5f;
									float y2= (j+h)-h*0.5f;
									
									double dist=Math.sqrt((px-x2)*(px-x2)+(py-y2)*(py-y2));

									if (dist<0.5){
										sensors[0]=2;
										px+= (px-x2) * (0.5-(dist-0.05)) /0.5;
										py+= (py-y2) * (0.5-(dist-0.05)) /0.5;
									}
								}
							}
						}
					}
					
				}
			}
		}	
		
		if (sensors[0]==2){
			try{Thread.currentThread();
				Thread.sleep(20);}
			catch(Exception ie){}
		}/**/
		
		////////////////////////////////////////////////////////////////////
		// feel neighbor blocks
		display[0]=false;
		display[1]=false;
		display[2]=false;
		if (act[3]==1){                    // feel forward
			if (rz>=  Math.PI/4 && rz<3*Math.PI/4){ if (env.isWall(i,j+1)) sensors[2]=2;}
			if (rz>=5*Math.PI/4 && rz<7*Math.PI/4){ if (env.isWall(i,j-1)) sensors[2]=2;}
			if (rz>=7*Math.PI/4 || rz<  Math.PI/4){ if (env.isWall(i+1,j)) sensors[2]=2;}
			if (rz>=3*Math.PI/4 && rz<5*Math.PI/4){ if (env.isWall(i-1,j)) sensors[2]=2;}
			if (sensors[2]==0) sensors[2]=1;
			display[0]=true;
		}
		if (act[3]==2){                    // feel left
			if (rz>=  Math.PI/4 && rz<3*Math.PI/4){ if (env.isWall(i-1,j)) sensors[2]=2;}
			if (rz>=5*Math.PI/4 && rz<7*Math.PI/4){ if (env.isWall(i+1,j)) sensors[2]=2;}
			if (rz>=7*Math.PI/4 || rz<  Math.PI/4){ if (env.isWall(i,j+1)) sensors[2]=2;}
			if (rz>=3*Math.PI/4 && rz<5*Math.PI/4){ if (env.isWall(i,j-1)) sensors[2]=2;}
			if (sensors[2]==0) sensors[2]=1;
			display[1]=true;
		}
		if (act[3]==3){                    // feel right
			if (rz>=  Math.PI/4 && rz<3*Math.PI/4){ if (env.isWall(i+1,j)) sensors[2]=2;}
			if (rz>=5*Math.PI/4 && rz<7*Math.PI/4){ if (env.isWall(i-1,j)) sensors[2]=2;}
			if (rz>=7*Math.PI/4 || rz<  Math.PI/4){ if (env.isWall(i,j-1)) sensors[2]=2;}
			if (rz>=3*Math.PI/4 && rz<5*Math.PI/4){ if (env.isWall(i,j+1)) sensors[2]=2;}
			if (sensors[2]==0) sensors[2]=1;
			display[2]=true;
		}
		
		// uncomment for delay when the agent uses "touch" interaction
		/*if (act[3]>0){
			try{Thread.currentThread();
				Thread.sleep(1);}
			catch(Exception ie){}
		}/**/
	}
	
	
	// finalize the movement
	public void center(){
		
		// feel block under the agent
		for (int i=-1;i<=1;i++){
			for (int j=-1;j<=1;j++){
				
				if (env.isFood(Math.round(px)+i,Math.round(py)+j)){
					double d=Math.sqrt( (Math.round(px)+i-px )*(Math.round(px)+i-px )
							            +(Math.round(py)+j-py )*(Math.round(py)+j-py ));
					
					// if the agent reach a prey
					if (d<=0.8){
						
						// set the "eat" sensor
						sensors[5]=1;
						
						// remove the prey
						if (eatPrey)
							env.setBlock(Math.round(px)+i,Math.round(py)+j,Environment.empty);
						
						// place randomly a new prey
						if (replacePrey){
							int rx=(int) (Math.random()*env.m_w);
							int ry=(int) (Math.random()*env.m_h);
							
							while (!env.isEmpty(rx,ry)){
								rx=(int) (Math.random()*env.m_w);
								ry=(int) (Math.random()*env.m_h);
							}
							env.setBlock(rx,ry,Environment.fish);
						}
					}
				}
			}
		}
	}
	
	
	///////////////////////////////////////////////////////////////////////////////
	
	public float getpx(){ return px;}
	public float getpy(){ return py;}
	public float getrz(){ return rz;}
	
	public void setPosition(float x, float y, float theta){
		px=x;
		py=y;
		rz=theta;
	}
	
	public void reset(){
		for(int k=0;k<6;k++){
			sensors[k]=0;
		}
	}
}

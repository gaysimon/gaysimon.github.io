package version7_2.spaceMemory;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;

import version7_2.platform.Agent;
import version7_2.platform.Observer;
import version7_2.Interface.InteractionList;
import version7_2.Interface.PrimitiveInteraction;


/**
 * Main class of the space memory mechanism
 * @author simon gay
 */
public class SpaceMemory {

	private Agent agent;
	
	public float[][] enactedEnsembles;				// sequence of the last 'timesize' last enacted ensembles

	public float[][][] spaceMap;					// map used by the memory mechanism
	
	private ArrayList<Float[][][]> predictionMap;	// map predicted for each primitive interaction
	private ArrayList<Float> additional;			// utility values added to satisfaction values
	
	private ArrayList<Composite> interactionList;	// list of known composite interactions
	
	private PrimitiveInteraction[] timeline;		// timeline of the last enacted primary interactions
	
	public static int timeSize=1;
	
	public static float memoryCoef = 0.05f;    	// influence coefficient of the space memory
	public static float objectCoef = 0.4f;     	// influence of objects according to their distances

	public static boolean load=false;			// if true, load an agent file
	
	
	public SpaceMemory(Agent a){
		agent=a;
		
		enactedEnsembles=new float[timeSize+1][InteractionList.length];

		spaceMap=new float[InteractionList.size1][InteractionList.size2*2][3];
		
		predictionMap=new ArrayList<Float[][][]>();
		additional=new ArrayList<Float>();
		
		for (int i=0;i<InteractionList.size1;i++){
			for (int j=0;j<InteractionList.size2*2;j++){
				for (int k=0;k<3;k++){
					spaceMap[i][j][k]=0;
				}
			}
		}
		
		interactionList=new ArrayList<Composite>();

		timeline=new PrimitiveInteraction[timeSize];
		for (int i=0;i<timeSize;i++){
			timeline[i]=null;
		}

		if (load) loadFile();
		else load();
	}
	
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////
	// main space memory update function
	public void updateMemory(PrimitiveInteraction inter, float[] enacted){
		
		System.out.println("SpaceMemory observed primitive "+inter.getName());
		
		// update timeline
		for (int i=timeSize-1;i>0;i--){
			timeline[i]=timeline[i-1];
		}
		timeline[0]=inter;
		
		
		// display timeline
		System.out.print("time line : ");
		for (int i=timeSize-1;i>=0;i--){
			if (timeline[i]!=null) System.out.print(timeline[i].getName()+", ");
			else System.out.print("null , ");
		}
		System.out.println();
		
		
		// update global map
		float[][][] oldMap=new float[InteractionList.size1][InteractionList.size2*2][3];
		for (int i=0;i<InteractionList.size1;i++){
			for (int j=0;j<InteractionList.size2*2;j++){
				for (int k=0;k<3;k++){
					oldMap[i][j][k]=spaceMap[i][j][k];
					spaceMap[i][j][k]=0;
				}
			}
		}
		
		for (int i=0;i<InteractionList.size1;i++){
			for (int j=0;j<InteractionList.size2*2;j++){
				int x=Math.round(inter.vectorFlow[i][j][0]);
				int y=Math.round(inter.vectorFlow[i][j][1]);
				if (x>=0 && x<InteractionList.size1 && y>2 && y<InteractionList.size2*2){
					for (int k=0;k<3;k++){
						if (Math.abs(oldMap[x][y][k])>Math.abs(spaceMap[i][j][k]) && Math.abs(oldMap[x][y][k])>0.5){
							spaceMap[i][j][k]=0.99f*oldMap[x][y][k];
						}
					}
				}
			}
		}
		
		
		// update observed map
		for (int t=SpaceMemory.timeSize;t>0;t--){
			enactedEnsembles[t]=enactedEnsembles[t-1];
		}
		enactedEnsembles[0]=enacted;
		
		for (int i=0;i<InteractionList.size1;i++){
			for (int j=0;j<InteractionList.size2;j++){
				for (int k=0;k<3;k++){
					if (Math.abs(enactedEnsembles[0][ i*InteractionList.size2*3 + j*3 + k])>Math.abs(spaceMap[i][j+InteractionList.size2][k]))
						spaceMap[i][j+InteractionList.size2][k]=enactedEnsembles[0][ i*InteractionList.size2*3 + j*3 + k];
				}
			}
		}
		
		
		// read timeline and learn new sequences
		int t=0;
		while (t<timeSize && timeline[t]!=null){
			PrimitiveInteraction[] temp=new PrimitiveInteraction[t+1];
			for (int i=0;i<=t;i++) temp[i]=timeline[i];
			learn(temp);
			t++;
		}
		
		for (int i=0;i<interactionList.size();i++){
			
			if (interactionList.get(i).checkSequence(timeline)!=0){
				interactionList.get(i).pattern.learn(
						enactedEnsembles[interactionList.get(i).size()],
						interactionList.get(i).checkSequence(timeline)
						);
				interactionList.get(i).blur.generateBlur(getInteraction(i).pattern);
			}
			interactionList.get(i).setPrediction(enactedEnsembles[0]);
		}
		
		// generate predicted memories
		prediction();
		
		// compute global proximity values for each interaction
		for (int i=0;i<interactionList.size();i++){
			interactionList.get(i).setPrediction1(agent.interactionList.nbInteraction(),spaceMap);
			interactionList.get(i).setPrediction2(predictionMap);
		}
		
		// compute the additional satisfaction value
		for (int i=0;i<agent.interactionList.nbInteraction();i++){
			additional.set(i,0f);
			if (interactionList.get(i).getPrediction()>=0){
				for (int j=0;j<7;j++){
					if (i!=j && interactionList.get(j).predictions1.get(i)!=0){
						additional.set(i,additional.get(i)
								        + interactionList.get(j).getValence()
						                 *(interactionList.get(j).predictions2.get(i)-interactionList.get(j).predictions1.get(i))
						               );
					}
				}
			}
		}
	}
	
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// add new Composite interaction
	private int learn(PrimitiveInteraction[] seq){

		// sequences and patterns
		int found=-1;
		int i=0;
		while (i<interactionList.size() && found==-1){
			if (interactionList.get(i).size()==seq.length){
				if (interactionList.get(i).isEqual(seq)) found=i;
			}
			i++;
		}
		
		if (found==-1){
			interactionList.add(new Composite(seq));
			additional.add(0f);
			found=interactionList.size()-1;
		}

		return found;
	}
	
	// generate the predicted memories
	private void prediction(){
		
		// reset prediction maps
		for (int m=0;m<agent.interactionList.nbInteraction();m++){
			for (int i=0;i<InteractionList.size1;i++){
				for (int j=0;j<InteractionList.size2*2;j++){
					for (int k=0;k<3;k++){
						predictionMap.get(m)[i][j][k]=0f;
					}
				}
			}	
		}
		
		// generate prediction maps
		for (int m=0;m<agent.interactionList.nbInteraction();m++){
			for (int i=0;i<InteractionList.size1;i++){
				for (int j=0;j<InteractionList.size2*2;j++){
					int x=(int)(agent.interactionList.getInteraction(m).vectorFlow[i][j][0]);
					int y=(int)(agent.interactionList.getInteraction(m).vectorFlow[i][j][1]);
					if (x>=0 && x<InteractionList.size1 && y>=0 && y<InteractionList.size2*2){
						for (int k=0;k<3;k++){
							if (Math.abs(spaceMap[x][y][k])>Math.abs(predictionMap.get(m)[i][j][k])){
								predictionMap.get(m)[i][j][k]=spaceMap[x][y][k];
							}
						}
					}
				}
			}
		}
	}
	
	public int nbInteraction(){
		return interactionList.size();
	}
	
	public Composite getInteraction(int i){
		return interactionList.get(i);
	}
	
	public float getPredictionMap(int m, int i, int j, int c){
		return predictionMap.get(m)[i][j][c];
	}
	
	public float getAdditional(int i){
		return additional.get(i);
	}
	
	public PrimitiveInteraction getTimeline(int i){
		return timeline[i];
	}
	
	/////////////////////////////////////////////////////////////////////
	public void save() {
		System.out.println("=====================prepare to save...======================");
		
		// save second level patterns
		
		String fileName = Observer.path+"spaceMemory/spaceMemoryV7_2 ("+timeSize+") "+agent.getIdent()+".txt";
		
		try {
			PrintWriter file  = new PrintWriter(new FileWriter(fileName));
			
			// save counter
			file.println(agent.action.getNbStep());
			file.println("***");
			
			// save patterns
			for (int i=0;i<interactionList.size();i++){
				
				// save the sequence
				for (int j=0;j<interactionList.get(i).size();j++){
					for (int k=0;k<agent.interactionList.nbInteraction();k++){
						if (interactionList.get(i).sequence[j].isEqual(agent.interactionList.getInteraction(k))) file.print(k+" ");
					}
					file.println();
					
					// save condition pattern
					for (int k=0;k<InteractionList.length;k++){
						file.print(interactionList.get(i).pattern.pattern[k]+" ");
					}
					file.println();
				}
			}
			file.close();
			System.out.println("memory file saved");
		}
		catch (Exception e) {e.printStackTrace();}
	}
	
	
	private void load(){

		PrimitiveInteraction[] temp=new PrimitiveInteraction[1];
		for (int i=0;i<agent.interactionList.nbInteraction();i++){
			temp[0]=agent.interactionList.getInteraction(i);
			interactionList.add(new Composite(temp));
			
			predictionMap.add(new Float[InteractionList.size1][InteractionList.size2*2][3]);
			for (int l=0;l<InteractionList.size1;l++){
				for (int j=0;j<InteractionList.size2*2;j++){
					for (int k=0;k<3;k++){
						predictionMap.get(predictionMap.size()-1)[l][j][k]=0f;
					}
				}
			}
			additional.add(0f);
		}
		
	}
	
	public void loadFile(){
		String fileName = Observer.path+"spaceMemory/spaceMemoryV7_2 ("+timeSize+") "+agent.getIdent()+".txt";
		String[] elements;

		try {
			InputStream ips=new FileInputStream(fileName); 
			InputStreamReader ipsr=new InputStreamReader(ips);
			BufferedReader br=new BufferedReader(ipsr);
			String line;
			
			// set agent's step counter
			line=br.readLine();
			agent.action.setNbstep(Integer.parseInt(line));

			// separator
			line=br.readLine();
			
			// load patterns
			while ((line=br.readLine())!=null){
				elements=line.split(" ");
				// build sequences
				PrimitiveInteraction[] temp=new PrimitiveInteraction[elements.length];
				for (int i=0;i<elements.length;i++){
					temp[i]=agent.interactionList.getInteraction(Integer.parseInt(elements[i]));
				}
				learn(temp);
				
				line=br.readLine();
				elements=line.split(" ");

				// get condition pattern
				float max=0;
				for (int i=0;i<elements.length;i++){
					interactionList.get(interactionList.size()-1).pattern.pattern[i]=Float.parseFloat(elements[i]);
					if (Math.abs(Float.parseFloat(elements[i]))>max) max=Math.abs(Float.parseFloat(elements[i]));
				}
				interactionList.get(interactionList.size()-1).pattern.maxPattern=max;
				interactionList.get(interactionList.size()-1).pattern.maxPattern1=max;
				interactionList.get(interactionList.size()-1).pattern.maxPattern2=max;
				
				predictionMap.add(new Float[InteractionList.size1][InteractionList.size2*2][3]);
				for (int l=0;l<InteractionList.size1;l++){
					for (int j=0;j<InteractionList.size2*2;j++){
						for (int k=0;k<3;k++){
							predictionMap.get(predictionMap.size()-1)[l][j][k]=0f;
						}
					}
				}
				additional.add(0f);
			}
		} 
		catch (Exception e) {
			System.out.println("no file found");
			load();
		}
	}
}

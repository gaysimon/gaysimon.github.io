package version7_2.sensorySystem;

/**
 * interface between visual information and visual interactions
 * @author simon
 */
import java.awt.Color;

import version7_2.Interface.PrimitiveInteraction;
import version7_2.platform.Agent;

public class VisualSystem {

	private Agent agent;
	
	public Color[] color;
	public float[] opticFlow;
	
	public VisualSystem(Agent a){
		agent=a;

		color=new Color[36];
		opticFlow=new float[36];
	}
	
	// simulate an optic flow
	public void opticFlow(PrimitiveInteraction inter){
		
		float optic;
		if (inter.getAction().getName().equals(">")){
			for (int i=0;i<36;i++){

				opticFlow[i]= 99;
				
				if (agent.body.sensors[0]!=2){
					for (int j=-2;j<=2;j++){
						optic=0.8f*(float) ((agent.probe.distRetina[i*5+2+j+ 90]));
						
						optic=Math.max(-49, Math.min(49, optic));
						if (Math.abs(optic)<Math.abs(opticFlow[i])){
							opticFlow[i]=optic;
							color[i]=agent.probe.colRetina[i*5+2+j+90];
						}
					}
				}
			}
		}
		else{
			if (inter.getAction().getName().equals("^")){
				
				for (int i=0;i<36;i++){

					opticFlow[i]= 99;
					
					for (int j=-2;j<=2;j++){
						optic=0.8f*(float) ((agent.probe.distRetina[i*5+2+j+ 90]));
						if (Math.abs(optic)<Math.abs(opticFlow[i])){
							opticFlow[i]=optic;
							color[i]=agent.probe.colRetina[i*5+2+j+90];
						}
					}
				}
			}
			else{
				if (inter.getAction().getName().equals("v")){
					
					for (int i=0;i<36;i++){

						opticFlow[i]= 99;
						
						for (int j=-2;j<=2;j++){
							optic=0.8f*(float) ((agent.probe.distRetina[i*5+2+j+ 90]));
							if (Math.abs(optic)<Math.abs(opticFlow[i])){
								opticFlow[i]=optic;
								color[i]=agent.probe.colRetina[i*5+2+j+90];
							}
						}
					}
				}
				else{
					for (int i=0;i<36;i++){

						opticFlow[i]= 99;
						
						for (int j=-2;j<=2;j++){
							optic=0.8f*(float) ((agent.probe.distRetina[i*5+2+j+ 90]));
							if (Math.abs(optic)<Math.abs(opticFlow[i])){
								opticFlow[i]=optic;
								color[i]=agent.probe.colRetina[i*5+2+j+90];
							}
						}
					}
				}
			}
		}
	}
	
}
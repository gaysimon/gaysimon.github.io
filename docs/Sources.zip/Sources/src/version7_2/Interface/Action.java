package version7_2.Interface;

import version7_2.platform.Agent;

/**
 * This class controls the main simulation loop of the agent :
 * it gets the decision of the agent, enact the interaction through the body
 * and update decision modules once cycle is completed.
 * @author simon gay
 */
public class Action {

	private boolean acting;    			// is the agent acting
	private PrimitiveInteraction lastAct;	// last action signal
	private PrimitiveInteraction enacted;	// last enacted interaction
	private Agent agent;
	
	private int state;         			// 0=stop or step mode, 1=run
	private boolean step;					// move one step
	
	private int stepNb;					// number of completed decision cycle
	private int subStep=0;					// substep counter
	
	private static int nbSubStep=10;		// define the number of substep per step
	
	public Action(Agent a){
		acting=false;
		lastAct=null;
		enacted=null;
		
		agent=a;
		state=0;
		step=false;
		
		stepNb=0;
	}
	
	public void act(){
		
		// if action interrupted, select new action
		if (!acting && (state==1 || step)){
			
			System.out.println("==================== step #"+stepNb+" =========================================================");
			lastAct=agent.decision.decision();

			acting=true;
			
			// initiate a cycle of 10 simulation loops
			subStep=nbSubStep;
		}
		
		///////////////////////////////////////////////////
		// end of a decision cycle
		if (subStep==0){
			
			if (acting || step){
			
				//%%%%%%%%%%%%%%%%% specific to simulators %%%%%%%%%%%%%%%%%%%%%%%
				agent.body.center();
				agent.probe.rendu();
				agent.visual.opticFlow(lastAct);
				//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
				
				agent.sensors.update();
				agent.body.reset();
				
				enacted=agent.sensors.recognize(lastAct);

				// update decision system
				agent.observer.updateObserver(enacted);
				agent.decision.check(enacted);
				agent.spaceMemory.updateMemory(enacted, agent.sensors.recognizeEnactedEnsemble(enacted));

				stepNb++;
			}
			
			acting=false;
			step=false;
			
		}
		else{
			// define the command to be sent to the body
			double[] command=new double[4];
			command[0]=0;
			command[1]=0;
			command[2]=0;
			command[3]=0;
			if (lastAct.getAction().getName().equals(">")) command[1]= 0.99/(float)nbSubStep;
			if (lastAct.getAction().getName().equals("^")) command[2]= (1/(float)nbSubStep)*Math.PI/2;
			if (lastAct.getAction().getName().equals("v")) command[2]=(-1/(float)nbSubStep)*Math.PI/2;
			if (lastAct.getAction().getName().equals("/")) command[2]= (1/(float)nbSubStep)*Math.PI/4;
			if (lastAct.getAction().getName().equals("\\"))command[2]=(-1/(float)nbSubStep)*Math.PI/4;

			agent.body.move(command);
			
			//%%%%%%%%%%%%%%%% specific to render function %%%%%%%%%%%%%%%%%%%
			agent.probe.rendu();
			agent.visual.opticFlow(lastAct);
			//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
				
			agent.sensors.update();
			subStep--;
		}
		
		if (agent.body.sensors[0]==2){
			subStep=0;
		}
		
		//-------------------------------------------------
	}
	
	/////////////////////////////////////////////
	// start, stop and allow one decision cycle
	public void start(){
		state=1;
	}
	public void stop(){
		state=0;
	}
	public void step(){
		step=true;
	}
	
	/////////////////////////////////////////////
	
	public int getNbStep(){
		return stepNb;
	}
	
	public void setNbstep(int i){
		stepNb=i;
	}
	
	public int getState(){
		return state;
	}

	public boolean isStopped(){
		return state==0 && subStep==0 && !step;
	}
	
}

package version7_2.Interface;

/**
 * Definition of a primitive perception
 * @author simon
 */
public class PrimitivePerception {

	// define a primitive perception
	private String name;
	private int id;
	
	public PrimitivePerception(String n,  int i){
		name=n;
		id=i;
	}
	
	public boolean isEqual(PrimitivePerception a){
		return this.id==a.id;
	}
	
	public int getId(){
		return id;
	}
	
	public String getName(){
		return name;
	}
}

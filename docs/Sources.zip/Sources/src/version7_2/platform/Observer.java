package version7_2.platform;

import version7_2.Interface.PrimitiveInteraction;

/**
 * This class extract data about agents' behaviors for an external observer
 * @author simon gay
 */
public class Observer {

	private Agent agent;
	
	private int counter;								// number of completed decision cycle
	
	public PrimitiveInteraction[] timelinePrimitive;	// sequence of enacted interactions (limited to the "length" last interactions)
	
	public static int length=200;						// length of the timeline
	
	//////////////////////////////////////////////////////
	// compute the average valence. t1 to t4 give four time windows
	private int t1=1;
	private int t2=10;
	private int t3=50;
	private int t4=100;
	public int[] timelineEfficiency1;
	public int[] timelineEfficiency2;
	public int[] timelineEfficiency3;
	public int[] timelineEfficiency4;
	
	//////////////////////////////////////////////////////
	
	public int index=0;
	public float[][] timelinePrediction;
	
	//////////////////////////////////////////////////////
	
	public float[][] trace;							// sequence of previous positions of the agent
	public int[] interactionType;
	public static int pathLength=30;					//length of the trace
	
	//////////////////////////////////////////////////////
	private boolean picture=false;					// if true, frames associated to the agent can be saved as jpeg images (if allowed)
	private int frame;									// index of captured images
	
	private static int capture_delay=200;				// nb of decision cycles between two image captures
	public static String path=System.getProperty("user.home") +"/IDEAL/version7_2/";	// path of the saved images
	
	//////////////////////////////////////////////////////
	private XMLStreamTracer m_tracer;
	
	//////////////////////////////////////////////////////
	
	public Observer(Agent a){
		agent=a;

		timelineEfficiency1=new int[length];
		timelineEfficiency2=new int[length];
		timelineEfficiency3=new int[length];
		timelineEfficiency4=new int[length];
		for (int i=0;i<length;i++){
			timelineEfficiency1[i]=0;
			timelineEfficiency2[i]=0;
			timelineEfficiency3[i]=0;
			timelineEfficiency4[i]=0;
		}
		
		timelinePrimitive=new PrimitiveInteraction[length];
		for (int i=0;i<length;i++){
			timelinePrimitive[i]=null;
		}
		
		timelinePrediction=new float[length][7];
		for (int i=0;i<length;i++){
			for (int j=0;j<7;j++){
				timelinePrediction[i][j]=0;
			}
		}
		
		// trace
		trace=new float[pathLength][2];
		interactionType=new int[pathLength];
		
		frame=0;
		counter=0;
		
		/*
		m_tracer=new XMLStreamTracer("http://134.214.128.53/abstract/lite/php/stream/",
				                     "dsyRyrlVFmaeVjpOdSDCeNPsGcmfwr");
		/**/
		
		/*
		m_tracer=new XMLStreamTracer("http://localhost/alite/php/stream/",
				                     "LUAsNP-QqEAStUfzDFwewQIPcwRlnM");
		/**/
	}
	
	public void updateObserver(PrimitiveInteraction inter){
		
		/////////////////////////////////////////////////////////////
		// update timeline
		/////////////////////////////////////////////////////////////
		for (int i=length-1;i>0;i--){
			timelinePrimitive[i]=timelinePrimitive[i-1];
		}
		timelinePrimitive[0]=inter;
		
		
		/////////////////////////////////////////////////////////////
		// update trace
		/////////////////////////////////////////////////////////////
		for (int i=pathLength-1;i>0;i--){
			trace[i][0]=trace[i-1][0];
			trace[i][1]=trace[i-1][1];
			interactionType[i]=interactionType[i-1];
		}
		trace[0][0]=agent.body.getpx();
		trace[0][1]=agent.body.getpy();
		
		if (inter.getAction().getId()==0) interactionType[0]=inter.getPerception().getId();	
		else 						   interactionType[0]=2+inter.getAction().getId();

		/////////////////////////////////////////////////////////////
		// get the average valence
		/////////////////////////////////////////////////////////////
		float sum1=0;
		float sum2=0;
		float sum3=0;
		float sum4=0;
		
		for (int i=0;i<t4;i++){
			if (i<t1){
				if (timelinePrimitive[i]!=null) sum1+=timelinePrimitive[i].valence();
			}
			if (i<t2){
				if (timelinePrimitive[i]!=null) sum2+=timelinePrimitive[i].valence();
			}
			if (i<t3){
				if (timelinePrimitive[i]!=null) sum3+=timelinePrimitive[i].valence();
			}
			if (timelinePrimitive[i]!=null) sum4+=timelinePrimitive[i].valence();
		}
		
		for (int i=200-1;i>0;i--){
			timelineEfficiency1[i]=timelineEfficiency1[i-1];
			timelineEfficiency2[i]=timelineEfficiency2[i-1];
			timelineEfficiency3[i]=timelineEfficiency3[i-1];
			timelineEfficiency4[i]=timelineEfficiency4[i-1];
		}
		timelineEfficiency1[0]=(int) (sum1*10/t1);
		timelineEfficiency2[0]=(int) (sum2*10/t2);
		timelineEfficiency3[0]=(int) (sum3*10/t3);
		timelineEfficiency4[0]=(int) (sum4*10/t4);
		
		for (int i=0;i<7;i++){
			timelinePrediction[index][i]=Math.abs(agent.spaceMemory.getInteraction(i).getPrediction());
		}
		
		index++;
		if (index>=length) index=0;
		
		
		/////////////////////////////////////////////////////////////
		// screen shot
		/////////////////////////////////////////////////////////////
		
		if (picture){
			frame++;
			if (frame>=capture_delay){
				frame=0;
				agent.saveImage(Observer.path);
			}
		}
		
	}
	
	// send data to Abstract-Lite module
	public void trace(){
		
		// abstract lite trace
		m_tracer.startNewEvent(counter);
		
		m_tracer.addEventElement("Source", "VacuumSG");
		m_tracer.addEventElement("clock", ""+counter);
		
		// intended interaction
		if (agent.decision.getIntention()!=null)
			m_tracer.addEventElement("primitive_intended_act", agent.decision.getIntention().getName());
		
		// enacted interaction
		m_tracer.addEventElement("primitive_enacted_act", agent.spaceMemory.getTimeline(0).getName());
		
		// valence
		m_tracer.addEventElement("satisfaction", ""+agent.spaceMemory.getTimeline(0).valence());
		
		counter++;
		
		m_tracer.finishEvent();
	}
	
	// initialize every position of the trace to (x,y)
	public void setPosition(float x,float y){
		for (int i=0;i<pathLength;i++){
			trace[i][0]=x;
			trace[i][1]=y;
		}
	}
	
	// clear trace
	public void clearTrace(){
		setPosition(agent.body.getpx(),agent.body.getpy());
		for (int i=0;i<pathLength;i++){
			interactionType[i]=0;
		}
	}
	
}

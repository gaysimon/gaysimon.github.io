package version7_2.platform;

import version7_2.Interface.*;
import version7_2.display.*;
import version7_2.environment.*;
import version7_2.sensorySystem.*;
import version7_2.spaceMemory.*;
import version7_2.Main;

/**
 * whole learning mechanism
 * This class is used as a bridge between modules
 * @author simon gay
 */
public class Agent {

	public Action action;
	public Perception sensors;
	public InteractionList interactionList;
	
	public Robot body;
	public Observer observer;
	public SpaceMemory spaceMemory;
	
	//%%%%%%%%%%%%%%%%% specific to simulators %%%%%%%%%%%%%%%%%%%%%%%
	public Probe probe;
	public VisualSystem visual;
	//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	public Decision decision;
	
	private Main main;
	
	private int ident;
	
	public Agent(int id, Main m){

		action=new Action(this);
		sensors=new Perception(this);
		interactionList=new InteractionList();
		
		body=new Robot();
		decision=new Decision(this);
		observer=new Observer(this);
		spaceMemory=new SpaceMemory(this);
		
		//%%%%%%%%%%%%%%%%% specific to simulators %%%%%%%%%%%%%%%%%%%%%%%
		probe=new Probe(this);
		visual=new VisualSystem(this);
		//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

		ident=id;
		
		main=m;
		
	}
	
	// enact a simulation substep
	public void act(){
		action.act();
	}
	
	public boolean isStopped(){
		return action.isStopped();
	}
	
	public int getIdent(){
		return ident;
	}
	
	public Main getMain(){
		return main;
	}
	
	//%%%%%%%%%%%%%%%%% specific to simulators %%%%%%%%%%%%%%%%%%%%%%%
	public void setPosition(float x, float y, float theta){
		body.setPosition(x,y,theta);
		observer.setPosition(x,y);
	}
	
	public void setEnvironment(Environment e){
		body.setEnvironment(e);
		probe.setEnvironment(e);
	}
	//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	
	// initialize the set of panels related to the agent
	public void setDisplay(){
		
		boolean efficiency=true;
		boolean probeDisplay=true;
		boolean spaceMemory=true;
		boolean prediction=true;
		
		int size;
		int i;
		boolean found;

		//////////////////////
		if (efficiency){
			size=main.display.nbFrame();
			i=0;
			found=false; 
			while (i<size && !found){
				if (main.display.get(i).getClass().getName().equals("version7_2.display.EfficiencyFrame")) found=true;
				i++;
			}
			if (!found) main.display.addFrame(new EfficiencyFrame(this));
			else        
				((EfficiencyFrame)main.display.get(i-1)).setAgent(this);
		}
		
		//////////////////////
		if (probeDisplay){
			size=main.display.nbFrame();
			i=0;
			found=false; 
			while (i<size && !found){
				if (main.display.get(i).getClass().getName().equals("version7_2.display.ProbeFrame")) found=true;
				i++;
			}
			if (!found) main.display.addFrame(new ProbeFrame(this));
			else
				((ProbeFrame)main.display.get(i-1)).setAgent(this);
		}
		
		//////////////////////
		if (spaceMemory){
			size=main.display.nbFrame();
			i=0;
			found=false; 
			while (i<size && !found){
				if (main.display.get(i).getClass().getName().equals("version7_2.display.SpaceFrame")) found=true;
				i++;
			}
			if (!found) main.display.addFrame(new SpaceFrame(this));
			else        
				((SpaceFrame)main.display.get(i-1)).setAgent(this);
		}
		
		//////////////////////
		if (prediction){
			size=main.display.nbFrame();
			i=0;
			found=false;
			while (i<size && !found){
				if (main.display.get(i).getClass().getName().equals("version7_2.display.PredictionFrame")) found=true;
				i++;
			}
			if (!found) main.display.addFrame(new PredictionFrame(this));
			else        
				((PredictionFrame)main.display.get(i-1)).setAgent(this);
		}
	}

	// save modules data
	public void save() {
		spaceMemory.save();
	}
	
	// save images from displayers
	public void saveImage(String path){
		main.saveImage(path);
	}
	
}

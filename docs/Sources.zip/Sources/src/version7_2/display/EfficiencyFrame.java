package version7_2.display;

import version7_2.platform.Agent;

/**
 * Display the efficiency (average valence) of the system
 * @author simon gay
 */

/* - inherited from EnvFrame :
 *   Agent agent      : pointer to the agent
 *   EnvPanel panel   : panel of this frame
 *   
 * - inherited from PrintableFrame :
 *   boolean printable   : define if the frame can be printed
 *   int indexImage      : counter for image name
 */
public class EfficiencyFrame extends EnvFrame{

	private static final long serialVersionUID = 1L;

	public EfficiencyFrame(Agent a){
		super(a);
		printable=true;
		this.setTitle("Efficiency");
    	this.setSize(1000, 400);
    	this.setLocationRelativeTo(null);               
    	this.setVisible(true);
    	panel=new EfficiencyPanel(a);
    	this.setContentPane(panel);
	}
}


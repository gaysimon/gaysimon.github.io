package version7_2.display;

import version7_2.platform.Agent;

/**
 * Display the certitude values of interactions
 * @author simon
 */

/* - inherited from EnvFrame :
 *   Agent agent      : pointer to the agent
 *   EnvPanel panel   : panel of this frame
 *   
 * - inherited from PrintableFrame :
 *   boolean printable   : define if the frame can be printed
 *   int indexImage      : counter for image name
 */
public class PredictionFrame extends EnvFrame{

	private static final long serialVersionUID = 1L;

	public PredictionFrame(Agent a){
		super(a);
		printable=true;
		this.setTitle("Predictions");
    	this.setSize(1000, 800);
    	this.setLocationRelativeTo(null);               
    	this.setVisible(true);
    	panel=new PredictionPanel(a);
    	this.setContentPane(panel);
	}
}


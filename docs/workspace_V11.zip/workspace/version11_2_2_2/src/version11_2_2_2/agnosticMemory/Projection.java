package version11_2_2_2.agnosticMemory;

import java.util.ArrayList;

public class Projection {

	public ArrayList<ArrayList<Short>>[] map;
	
	public Projection(short id, EnvironmentContext env){
		map=new ArrayList[EnvironmentContext.length];
		
		for (int i=0;i<EnvironmentContext.length;i++){
			map[i]=new ArrayList<ArrayList<Short>>();
		}
		
		
		// get the highest weight of the signature of interaction id
		int ident=-1;
		float max=0;
		for (int i=0;i<EnvironmentContext.length;i++){
			if (Math.abs(env.interactionList[id].signature.signature[i])>max){
				ident=i;
				max=Math.abs(env.interactionList[id].signature.signature[i]);
			}
		}
		
		if (ident!=-1 && max>0.2){
			ArrayList<Short> sequence=new ArrayList<Short>();
			map[ident].add(sequence);
			
			// projection
			for (int p=0;p<env.interactionList[id].predecessors.size();p++){
				int pred=env.interactionList[id].predecessors.get(p);
				
				if (env.interactionList[pred].isChange()){
					project(pred, ident, sequence, (short)1, env);
				}
				else{
					for (int p1=0;p1<env.interactionList[pred].predecessors.size();p1++){
						int pred1=env.interactionList[pred].predecessors.get(p1);
						
						project(pred1, ident, sequence, 1, env);
					}
				}
			}
		}
		
	}
	
	
	public void project(int id_pred, int id_point, ArrayList<Short> sequence, int level, EnvironmentContext env){
		
		// get the highest weight of the signature of visual interaction id_point
		int ident=-1;
		float max=0;
		for (int i=0;i<env.interactionList[id_pred].secondarySignatures[id_point].nbWeights;i++){
			if (Math.abs(env.interactionList[id_pred].secondarySignatures[id_point].signature[i])>max){
				ident=i;
				max=Math.abs(env.interactionList[id_pred].secondarySignatures[id_point].signature[i]);
			}
		}
		
		if (ident!=-1 && max>0.4){
			ArrayList<Short> sequence_copy=new ArrayList<Short>();
			for (int i=0;i<sequence.size();i++) sequence_copy.add(sequence.get(i));
			sequence_copy.add((short)id_pred);
			map[env.interactionList[id_pred].secondarySignatures[id_point].weightList[ident]].add(sequence_copy);
			
			// projection
			if (level<2){
				
				for (int p=0;p<env.interactionList[id_pred].predecessors.size();p++){
					int pred=env.interactionList[id_pred].predecessors.get(p);
					
					if (env.interactionList[pred].isChange()){
						project(pred, ident, sequence_copy, level+1, env);
					}
					else{
						for (int p1=0;p1<env.interactionList[pred].predecessors.size();p1++){
							int pred1=env.interactionList[pred].predecessors.get(p1);
							
							project(pred1, ident, sequence_copy, level+1, env);
						}
					}
				}
				
				/*for (int p=0;p<env.interactionList[id_pred].predecessors.size();p++){
					int pred=env.interactionList[id_pred].predecessors.get(p);
					if (env.interactionList[pred])
					project(env.interactionList[id_pred].predecessors.get(p), ident, sequence_copy, (short)(level+1), env);
				}*/
			}
		}
		
		
	}
	
}

package version11_2_2_2.agnosticMemory;

import java.util.ArrayList;

import version11_2_2_2.Interface.ContinuousInteraction;
import version11_2_2_2.platform.Agent;

public class SpaceMemory {

	public Agent agent;
	
	public Backmove[] backmoveList;
	
	public ArrayList<float[]> patterns;
	
	public float actionMap[][];
	
	public boolean projectionMap[][];
	public float projectionMap2[][];
	
	public SpaceMemory(Agent a){
		
		agent=a;
		
		backmoveList=new Backmove[agent.environmentContext.interactionList.length];
		
		for (int i=0;i<agent.environmentContext.interactionList.length;i++){
			if (agent.environmentContext.interactionList[i]==null
			 || agent.environmentContext.interactionList[i].signature.getBias()>=-0.2
			 ||!agent.environmentContext.interactionList[i].isChange()) backmoveList[i]=null;
			else{
				backmoveList[i]=new Backmove();
				backmoveList[i].backmove((short)i, agent.environmentContext);
			}
		}
		
		patterns=new ArrayList<float[]>();
		
		actionMap=new float[12][10];
		projectionMap=new boolean[12][10];
		projectionMap2=new float[12][10];
	}
	
	public void setPredictions(){
		
		for (int b=0;b<backmoveList.length;b++){
			if (backmoveList[b]!=null){
				backmoveList[b].setPredictions(agent.environmentContext.interactionList[b], agent.environmentContext);
			}
		}
	}
	
	public void updatePatterns(){
		patterns.clear();
		patterns.add(new float[agent.environmentContext.interactionList.length]);
		
		for (int b=0;b<backmoveList.length;b++){
			if (backmoveList[b]!=null){
				for (int p=0;p<backmoveList[b].bundlePatterns.size();p++){
					for (int i=0;i<backmoveList[b].bundlePatterns.get(p).length;i++){
						patterns.get(0)[i]+=backmoveList[b].bundlePatterns.get(p)[i];
					}
				}
			}
		}
		
		float max=0;
		for (int i=0;i<EnvironmentContext.length;i++){
			if (Math.abs(patterns.get(0)[i])>max) max=Math.abs(patterns.get(0)[i]);
		}
		if (max>0.1){
			for (int i=0;i<EnvironmentContext.length;i++){
				patterns.get(0)[i]=patterns.get(0)[i]/max;
			}
		}
	}
	
	public void updateActions(){
		
		int delay=0;
		boolean found=false;
		while (!found && delay<10){
			if (agent.environmentContext.enactedActions[delay]!=0) found=true;
			else delay++;
		}
		
		for (int i=0;i<12;i++){
			for (int j=0;j<10;j++){
				projectionMap[i][j]=false;
				projectionMap2[i][j]=0;
			}
		}
		projection(agent.environmentContext.id1, delay, 0, true);
		
		
		for (int i=0;i<12;i++){
			for (int j=0;j<10;j++){
				actionMap[i][j]=0;
			}
		}
		
		for (int b=0;b<backmoveList.length;b++){
			if (backmoveList[b]!=null){
				float valence=ContinuousInteraction.valence(agent.environmentContext.interactionList[b]);
				
				for (int i=0;i<backmoveList[b].bundlePlaces.size();i++){
					for (int j=0;j<backmoveList[b].bundlePlaces.get(i).size();j++){
						int index=backmoveList[b].bundlePlaces.get(i).get(j).interaction;
						
						int act=agent.environmentContext.interactionList[index].events.get(0)[0];
						delay=-(agent.environmentContext.interactionList[index].events.get(0)[1]-backmoveList[b].bundlePlaces.get(i).get(j).delay);
						
						if (actionMap[act][delay]==0 || actionMap[act][delay]> valence) actionMap[act][delay]=valence;
					}
				}
			}
		}
	}
	
	
	public void projection(int id, int delay, int level, boolean next){
		
		if (level+delay<10 && next){
			
			for (int v=0;v<12;v++){
				if (agent.environmentContext.interactionList[id].variations(v)!=null){
					float prediction=agent.environmentContext.interactionList[agent.environmentContext.interactionList[id].variations(v).successor].prediction(agent.environmentContext.visual[delay], false);
					
					projectionMap2[v][level]=prediction;
					
					if (prediction>=0){
						
						projectionMap[v][level]=true;
						
						projection(agent.environmentContext.interactionList[id].variations(v).successor, delay, level+1, v==0);
					}
					
					projectionMap[v][level]=true;
				}
			}
		}
	}
	
}

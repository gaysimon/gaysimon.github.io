package version11_2_2_2.agnosticMemory;

import java.util.ArrayList;

import version11_2_2_2.Interface.ContinuousInteraction;

public class Backmove {

	public final static int RANGE=10;
	
	public ArrayList<Sequence> seqList;
	
	public ArrayList<Sequence> detected;
	
	public ArrayList<ArrayList<Integer>> bundles;
	public ArrayList<float[]> bundlePatterns;
	public ArrayList<ArrayList<Place>> bundlePlaces;
	
	public Backmove(){
		seqList=new ArrayList<Sequence>();
		detected=new ArrayList<Sequence>();
		
		bundles=new ArrayList<ArrayList<Integer>>();
		bundlePatterns=new ArrayList<float[]>();
		bundlePlaces=new ArrayList<ArrayList<Place>>();
	}

	public void backmove(short id, EnvironmentContext env){
		
		// get the pattern
		float[] pattern=new float[EnvironmentContext.length];
		float max=0;
		for (int i=0;i<EnvironmentContext.length;i++){
			if (env.interactionList[id].signature.signature[i]*env.interactionList[id].signature.getBias()<0
			&& Math.abs(env.interactionList[id].signature.signature[i])>0.5*env.interactionList[id].signature.maxPattern1){
				pattern[i]=env.interactionList[id].signature.signature[i];
				if (Math.abs(pattern[i])>max) max=Math.abs(pattern[i]);
			}
			else pattern[i]=0;
		}
		// normalize pattern
		if (max>0.1){
			for (int i=0;i<EnvironmentContext.length;i++){
				pattern[i]=pattern[i]/max;
			}

			// generate the sequence
			Sequence current=new Sequence(id, null, pattern, env);
			seqList.add(current);
			pattern=null;
			
			// backmove the sequence
			if (env.interactionList[id].previousDefaultTrue(env) && env.interactionList[id].signature.delta_s<1 && env.interactionList[id].signature.delta_f<1){
				for (int p=0;p<env.interactionList[id].predecessors.size();p++){
					int predecessor=env.interactionList[id].predecessors.get(p);
					if (env.interactionList[predecessor].signature.getBias()>=0 && env.interactionList[predecessor].previousDefaultTrue(env)){
						backmove((short)predecessor, current, env, (short)1);
					}
				}
			}
		}
		
		// remove sequence with empty patterns
		for (int i=0;i<seqList.size();i++){
			if (seqList.get(i).patternWeights.size()==0){
				seqList.remove(i);
				i--;
			}
			else{
				max=0;
				for (int j=0;j<seqList.get(i).patternWeights.size();j++){
					if (Math.abs(seqList.get(i).patternVal.get(j))>max) max=Math.abs(seqList.get(i).patternVal.get(j));
				}
				if (max<=0.1){
					seqList.remove(i);
					i--;
				}
			}
		}
	}
	
	private void backmove(short id, Sequence pred, EnvironmentContext env, short level){
		
		Sequence current=null;
		boolean project=true;
		
		if (env.interactionList[id].isChange()){
		
			// backmove pattern
			float[] pattern=new float[EnvironmentContext.length];
			float max=0;
			for (int w=0;w<pred.patternVal.size();w++){
				for (int i=0;i<env.interactionList[id].secondarySignatures[pred.patternWeights.get(w)].nbWeights;i++){

					if (Math.abs(env.interactionList[id].secondarySignatures[pred.patternWeights.get(w)].signature[i])>0.5*env.interactionList[id].secondarySignatures[pred.patternWeights.get(w)].maxPattern1){
						pattern[env.interactionList[id].secondarySignatures[pred.patternWeights.get(w)].weightList[i]]
					        +=env.interactionList[id].secondarySignatures[pred.patternWeights.get(w)].signature[i]*pred.patternVal.get(w);
						if (Math.abs(pattern[env.interactionList[id].secondarySignatures[pred.patternWeights.get(w)].weightList[i]])>max) max=Math.abs(pattern[env.interactionList[id].secondarySignatures[pred.patternWeights.get(w)].weightList[i]]);
					}
				}
			}
			// normalize pattern
			if (max>0.1){
				for (int i=0;i<EnvironmentContext.length;i++){
					if (Math.abs(pattern[i])>0.5) pattern[i]=pattern[i]/max;
					else pattern[i]=0;
				}
			
				// generate the sequence
				current=new Sequence(id, pred, pattern, env);
				seqList.add(current);
				pattern=null;
			}
			else project=false;
		}
		else current=pred;
		
		// backmove the sequence
		if (level<RANGE && project){
			if (env.interactionList[id].previousDefaultTrue(env) && env.interactionList[id].signature.delta_s<1 && env.interactionList[id].signature.delta_f<1){
				for (int p=0;p<env.interactionList[id].predecessors.size();p++){
					int predecessor=env.interactionList[id].predecessors.get(p);
					if (env.interactionList[predecessor].signature.getBias()>=0 && env.interactionList[predecessor].previousDefaultTrue(env)){
						backmove((short)predecessor, current, env, (short)(level+1));
					}
				}
			}
		}
	}
	
	public void clear(){		
		seqList.clear();
	}
	
	
	public float[] getPatternOf(int id){
		return seqList.get(id).getPattern();
	}
	public float[] getPatternOfDetected(int id){
		return detected.get(id).getPattern();
	}
	
	public float[][] getPatterns(int i){
		// initialization
		float[][] pattern=new float[seqList.get(i).length][EnvironmentContext.length];
		
		Sequence current=seqList.get(i);
		
		int l=0;
		while (current!=null){
			pattern[l]=current.getPattern();
			current=current.predecessor;
			l++;
		}
		
		return pattern;
	}
	public float[][] getPatternsDetected(int i){
		// initialization
		float[][] pattern=new float[detected.get(i).length][EnvironmentContext.length];
		
		Sequence current=detected.get(i);
		
		int l=0;
		while (current!=null){
			pattern[l]=current.getPattern();
			current=current.predecessor;
			l++;
		}
		
		return pattern;
	}
	
	public void setPredictions(ContinuousInteraction inter, EnvironmentContext env){
		
		detected.clear();
		for (int i=0;i<seqList.size();i++){
			seqList.get(i).prediction(inter, env);
			if (seqList.get(i).detected) detected.add(seqList.get(i));
		}
		
		// filter detected sequences
		// remove long sequences
		for (int i=0;i<seqList.size();i++){
			if (seqList.get(i).prediction>0.7){
				for (int j=0;j<detected.size();j++){
					if ((int)(seqList.get(i).length+seqList.get(i).offset)<(int)(detected.get(j).length+detected.get(j).offset) //-1
						//|| ((int)seqList.get(i).length<(int)detected.get(j).length && seqList.get(i).prediction<detected.get(j).prediction)
					){
						int k1=0;
						boolean intersect=false;
						while (!intersect && k1<seqList.get(i).patternWeights.size()){
							if (detected.get(j).patternWeights.contains(seqList.get(i).patternWeights.get(k1))) intersect=true;
							k1++;
						}
						if (intersect){
							detected.remove(j);
							j--;
						}
					}
				}
			}
		}
		// remove redundant sequences
		for (int i=0;i<detected.size();i++){
			int j=i+1;
			boolean found=false;
			while (!found && j<detected.size()){
				if ((int)(detected.get(j).length+detected.get(j).offset)==(int)(detected.get(i).length+detected.get(i).offset) 
				 && (int)detected.get(i).id==(int)detected.get(j).id){
					int k1=0;
					boolean intersect=false;
					while (!intersect && k1<detected.get(i).patternWeights.size()){
						if (detected.get(j).patternWeights.contains(detected.get(i).patternWeights.get(k1))) intersect=true;
						k1++;
					}
					if (intersect){
						if (detected.get(i).prediction>detected.get(j).prediction){
							detected.remove(j);
							j--;
						}
						if (detected.get(i).prediction<detected.get(j).prediction){
							detected.remove(i);
							i--;
							found=true;
						}
					}
				}
				j++;
			}
		}
		
		// generate bundles
		bundles.clear();
		ArrayList<Integer> list=new ArrayList<Integer>();
		for (int i=0;i<detected.size();i++) list.add(i);
		while (list.size()>0){
			int index=bundles.size();
			bundles.add(new ArrayList<Integer>());
			bundles.get(index).add(list.get(0));
			list.remove(0);
			
			for (int j=0;j<list.size();j++){
				boolean found=false;
				int k=0;
				while (!found && k<bundles.get(index).size()){
					int k1=0;
					while (!found && k1<detected.get(list.get(j)).patternWeights.size()){
						if (detected.get(bundles.get(index).get(k)).patternWeights.contains(detected.get(list.get(j)).patternWeights.get(k1))) found=true;
						k1++;
					}
					k++;
					if (found){
						bundles.get(index).add(list.get(j));
						list.remove(j);
						j=-1;	// reset detection counters
					}
				}
			}
		}
		
		// generate bundle patterns
		bundlePatterns.clear();
		for (int i=0;i<bundles.size();i++){
			int index=bundlePatterns.size();
			bundlePatterns.add(new float[env.interactionList.length]);
			for (int j=0;j<bundles.get(i).size();j++){
				for (int w=0;w<detected.get(bundles.get(i).get(j)).patternWeights.size();w++){
					bundlePatterns.get(index)[detected.get(bundles.get(i).get(j)).patternWeights.get(w)]+=detected.get(bundles.get(i).get(j)).patternVal.get(w);
				}
			}
			float max=0;
			for (int k=0;k<env.interactionList.length;k++){
				if (Math.abs(bundlePatterns.get(index)[k])>max) max=Math.abs(bundlePatterns.get(index)[k]);
			}
			if (max>0.1){
				for (int k=0;k<env.interactionList.length;k++){
					bundlePatterns.get(index)[k]=bundlePatterns.get(index)[k]/max;
					if (Math.abs(bundlePatterns.get(index)[k])<0.5) bundlePatterns.get(index)[k]=0;
				}
			}
		}
		
		// define places of each bundle
		bundlePlaces.clear();
		for (int i=0;i<bundles.size();i++){
			int index=bundlePlaces.size();
			bundlePlaces.add(new ArrayList<Place>());
			for (int j=0;j<bundles.get(index).size();j++){
				bundlePlaces.get(index).add(new Place(detected.get(bundles.get(index).get(j)).id, 
						 							  detected.get(bundles.get(index).get(j)).offset,
						 							  detected.get(bundles.get(index).get(j)).length));
			}
		}
	}
	
	public float getPrediction(int seq, int t){
		if (t==(int)seqList.get(seq).offset) return seqList.get(seq).prediction;
		else return 0;
	}
	public float getPredictionDetected(int seq, int t){
		if (t==(int)detected.get(seq).offset) return detected.get(seq).prediction;
		else return 0;
	}
	
	public ArrayList<Short> getSeqence(int i){
		return seqList.get(i).getSequence();
	}
	public ArrayList<Short> getDetected(int i){
		return detected.get(i).getSequence();
	}
	
	public int getIndex(int i){
		return seqList.get(i).id;
	}
	public int getIndexDetected(int i){
		return detected.get(i).id;
	}
	
	public int getLength(int i){
		return seqList.get(i).length;
	}
	public int getLengthDetected(int i){
		return detected.get(i).length;
	}
	
	public int getDelay(int i){
		return seqList.get(i).offset;
	}
	public int getDelayDetected(int i){
		return detected.get(i).offset;
	}
	
	public int[] getEventList(int i, short offset, EnvironmentContext env){
		return seqList.get(i).getEventList(offset, env);
	}
	public int[] getEventListDetected(int i, short offset, EnvironmentContext env){
		return detected.get(i).getEventList(offset, env);
	}
	
	public boolean isDetected(int i){
		return seqList.get(i).detected;
	}
	public boolean isAbsent(int i){
		return seqList.get(i).absent;
	}
	
	public void printWeights(int i){
		for (int k=0;k<detected.get(i).patternWeights.size();k++){
			System.out.print(detected.get(i).patternWeights.get(k)+", ");
		}
		System.out.println();
	}
	
	// fast exp function approximation
	public static double exp(double val) {
	    final long tmp = (long) (1512775 * val + (1072693248 - 60801));
	    return Double.longBitsToDouble(tmp << 32);
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////
	//
	//////////////////////////////////////////////////////////////////////////////////////////
	private class Sequence{
		
		public short id;
		public Sequence predecessor;
		public ArrayList<Float> patternVal;
		public ArrayList<Short> patternWeights;
		
		public float prediction;
		public byte offset;
		//public float[] predictions;
		public boolean detected;
		public boolean absent;
		public short length;
		
		public Sequence(short ident, Sequence pred, float[] pattern, EnvironmentContext env){
			id=ident;
			predecessor=pred;
			
			//predictions=new float[10];
			detected=false;
			absent=false;
			
			patternVal=new ArrayList<Float>();
			patternWeights=new ArrayList<Short>();
			
			for (short i=0;i<pattern.length;i++){
				if (pattern[i]!=0){
					patternVal.add(pattern[i]);
					patternWeights.add(i);
				}
			}
			
			setLength(env);
		}
		
		public ArrayList<Short> getSequence(){
			ArrayList<Short> seq=new ArrayList<Short>();
			seq.add(0,id);
			
			if (predecessor!=null){
				Sequence seq2=predecessor;
				
				while (seq2!=null){
					seq.add(0, seq2.id);
					seq2=seq2.predecessor;
				}
			}
			return seq;
		}
		
		public int[] getEventList(short offset, EnvironmentContext env){
			int[] list=new int[RANGE*10];
			
			int t1=env.interactionList[id].events.get(1)[1];
			int t=10 - t1 + offset+1; // t_0 is on index 10
			
			if (t>=0){
			list[t]=env.interactionList[id].events.get(1)[0];
			t+=env.interactionList[id].events.get(1)[1];
			
			Sequence seq=this;
			
			while (seq.predecessor!=null){

				list[t]=env.interactionList[seq.predecessor.id].events.get(1)[0];
				t+=env.interactionList[seq.predecessor.id].events.get(1)[1];
				
				seq=seq.predecessor;
			}
			list[t]=env.interactionList[seq.id].events.get(0)[0]+100;
			}
			return list;
		}
		
		public float[] getPattern(){
			float[] pattern=new float[EnvironmentContext.length];
			for (int i=0;i<patternWeights.size();i++){
				pattern[patternWeights.get(i)]=patternVal.get(i);
			}
			
			return pattern;
		}
		
		private void setLength(EnvironmentContext env){
			/*byte ret=1;
			if (predecessor!=null){
				Sequence seq2=predecessor;
				
				while (seq2!=null){
					ret++;
					seq2=seq2.predecessor;
				}
			}
			length=ret;*/
			
			length=1;
			
			Sequence seq=this;
			
			while (seq.predecessor!=null){
				length+=env.interactionList[seq.predecessor.id].events.get(1)[1];
				seq=seq.predecessor;
			}
		}
		
		public void prediction(ContinuousInteraction inter, EnvironmentContext env){

			float max=inter.signature.maxPattern1;
			
			offset=(byte) env.getOffset(id);
			
			detected=false;
			absent=false;
			
			prediction=0;
			
			if (offset>=0){
	
				for (int i=0;i<patternWeights.size();i++){
					prediction+= (patternVal.get(i)*max) * env.visual[offset][patternWeights.get(i)];
				}
				//bias
				prediction+=inter.signature.getBias();
				
				// activation function
				prediction= (float) ( 1 / (1+exp(-prediction)))*2-1;
	
				if (prediction> 0.5) detected=true;
				if (prediction<-0.5) absent=true;
			}
		}
	}
}

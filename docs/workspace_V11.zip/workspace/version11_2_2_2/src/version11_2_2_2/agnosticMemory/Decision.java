package version11_2_2_2.agnosticMemory;

import version11_2_2_2.platform.Agent;

/**
 * Decision system.
 * This class selects the intended interactions
 * @author simon
 */
public class Decision {

	private Agent agent;

	public int counter=0;
	
	public int timer=4;
	
	public PredictionNode predictionNode;
	
	public float actionMap[][];
	public float exploitationMap[][];
	
	public float lastLearningVal;
	public int lastDecisionType;
	
	
	///////////////////////////////////////////////////////////
	public Decision(Agent a){
		agent=a;
		predictionNode=null;
		actionMap=new float[12][11];
		exploitationMap=new float[12][11];
	}
	
	/**
	 * decision of the next interaction
	 * @return the intended enact
	 */
	public int decision(){
		
		int ret=0;
		
		
		// define prediction of variations through signatures
		agent.environmentContext.predictNextStep();
		
		boolean found=false;
		int i=0;
		
		//////////////////////////////////////////////////////////////////
		// if there are too many events on the timeline: wait
		if (agent.environmentContext.nbEvent7>=2 || agent.environmentContext.nbEvent10>=3){
			ret=0;
			System.out.println("##### too many events");
			//lastDecisionType=0;
		}
		else{
			//////////////////////////////////////////////////////////////////
			// check for non tested variations
			while (!found && i<12){
				if (agent.environmentContext.id1>=0 && agent.environmentContext.interactionList[agent.environmentContext.id1].nbIntention[i]==0) found=true;
				else i++;
			}
			if (found){
				ret=i;			// if a variation was not tested before, enact it
				System.out.println("##### sensorimotor discovering");
				lastDecisionType=1;
			}
			else{
				//////////////////////////////////////////////////////////////////
				// otherwise, find the less known sequence of interaction
				if (agent.environmentContext.id1>=0){
					System.out.println("##### sensorimotor learning");
					
					// reset action map
					for (int v=0;v<12;v++){
						for (int j=0;j<11;j++){
							actionMap[v][j]=10;
						}
					}
					LearningNode node=new LearningNode(agent.environmentContext,agent.environmentContext.id1,0, false, actionMap);
					
					node.getMinReliable();
					
					if (node.vmin>=0){
						lastLearningVal=node.min;
						lastDecisionType=2;
					}
					
					if (node.min>0.3){
						System.out.print(node.min);
						node=new LearningNode(agent.environmentContext,agent.environmentContext.id1,0, true, actionMap);
						node.getMinReliable();
						System.out.println(" replaced by visual learning : "+node.min);
						if (node.vmin>=0){
							lastLearningVal=node.min;
							lastDecisionType=3;
						}
					}
					ret=node.vmin;
					
					System.out.println(" -> "+ret+" ; "+node.min);/**/
					
					// if there are no decision at this point, a random variation is selected
					if (ret==-1){
						lastDecisionType=4;
						ret=(int)(Math.random()*11+1);
					}
				}
				else ret=0;
			}
		}
		
		if (agent.environmentContext.id1>=0) agent.environmentContext.interactionList[agent.environmentContext.id1].setIntention(ret);
		System.out.println(" set variation "+ret+" to interaction "+agent.environmentContext.id1);
		
		agent.observer.updateDecisionTrace(lastDecisionType, lastLearningVal, 0);
		
		return ret;
		
	}
}

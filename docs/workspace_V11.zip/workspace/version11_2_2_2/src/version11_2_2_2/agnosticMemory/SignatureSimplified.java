package version11_2_2_2.agnosticMemory;

public class SignatureSimplified {

	public float[] signature;
	public short[] weightList;
	public byte nbWeights;
	
	public float bias;
	
	public float maxPattern1;					// maximum weight (used to normalize values in displayer)
	
	private float prediction=0;
	
	public float delta_s=2;
	public float delta_f=2;
	
	public byte tests=0;
	
	public byte test_s=0;
	public byte test_f=0;
	//public short test_s2=0;
	//public short test_f2=0;
	
	public SignatureSimplified(){
		weightList=new short[50];
		signature=new float[50];
		bias=0;
		maxPattern1=0;
		
		for (short i=0;i<50;i++){
			weightList[i]=-1;
			signature[i]=0;
		}
		nbWeights=0;
	}
	
	/**
	 * predict the result of an interaction in a given context
	 * @param img : environmental context
	 * @return the certitude of success (1->absolute certitude of success, -1-> absolute certitude of failure 
	 */
	public float prediction(float[] img, boolean write){
		float result=0;
		for (int i=0;i<nbWeights;i++){
			result+=signature[i]*img[weightList[i]];
		}
		//bias
		result+=bias;
		
		// activation function
		result= (float) ( 1 / (1+exp(-result)))*2-1;
		
		if (write) prediction=result;
		
		return result;
	}
	
	/**
	 * integrate the result of enaction cycle
	 * @param img : environmental context E_{t-1} 
	 * @param output result of enaction (success->1, failure->-1)
	 */
	public void learn(float[] img, float result){

		float delta=result-prediction;

		if (result>0){
			if (delta_s==2) delta_s=delta;
			else            delta_s=(delta_s*9+delta)/10;
		}
		else{
			if (delta_f==2) delta_f=-delta;
			else            delta_f=(delta_f*9-delta)/10;
		}
		
		// add new weights
		if (result>0){
			short j=0;
			while (j<EnvironmentContext.length && nbWeights<50){
				if (img[j]>0){
					addWeight(j);
				}
				j++;
			}
		}

		if ( (result>0 && (tests<1)) || (result<0 && (tests>-1)) ){	
			maxPattern1=0;
			for (int i=0;i<nbWeights;i++){
				signature[i]+=0.05 * delta * img[weightList[i]];
				if (signature[i]<-0.02){
					remove(i);
					i--;
				}
				else{
					if (Math.abs(signature[i])>maxPattern1) maxPattern1=Math.abs(signature[i]);
				}
			}
			// bias
			bias+= 0.05 * delta * 1;
			
			if (result>0 && tests< 1) tests++;
			if (result<0 && tests>-1) tests--;
			
			if (result>0){
				if (test_s<125) test_s++;
			}
			else{
				if (test_f<125) test_f++;
			}
		}
	}
	
	public void shareLearn(float[] img, float result){

		if (bias!=0){
			float delta=result-prediction(img,false);
	
			if ( (result>0 && (tests<1)) || (result<0 && (tests>-1)) ){	
				maxPattern1=0;
				int counter=0;
				for (int i=0;i<nbWeights;i++){
					if (img[weightList[i]]>0){
						signature[i]+=0.01 * delta * img[weightList[i]];
						counter++;
					}
					if (Math.abs(signature[i])>maxPattern1) maxPattern1=Math.abs(signature[i]);
				}
				// bias
				if (counter>0){
					bias+= 0.01 * delta * 1;
				
					if (result>0 && tests< 1) tests++;
					if (result<0 && tests>-1) tests--;
					
					if (result>0){
						if (test_s<125) test_s++;
					}
					else{
						if (test_f<125) test_f++;
					}
					
					//if (result>0) test_s2++;
					//else test_f2++;
				}
			}
		}
	}
	
	public float getPrediction(){
		return prediction;
	}
	
	private void addWeight(short id){

		short i=0;
		boolean found=false;
		
		while (!found && weightList[i]!=-1 && weightList[i]<=id && i<50){
			if (weightList[i]==id){
				found=true;
			}
			else i++;
		}
		
		if (!found){
			for (int j=49;j>i;j--){
				weightList[j]=weightList[j-1];
				signature[j]=signature[j-1];
			}
			weightList[i]=id;
			signature[i]=0;
			nbWeights++;
			//System.out.println("****** weight added : "+id);
		}
	}
	
	
	public void remove(int id){
		if (id==nbWeights-1){
			weightList[id]=-1;
			signature[id]=0;
			nbWeights--;
		}
		else{
			weightList[id]=weightList[nbWeights-1];
			signature[id]=signature[nbWeights-1];
			weightList[nbWeights-1]=-1;
			signature[nbWeights-1]=0;
			nbWeights--;
		}
	}
	
	public boolean getDistance(int i1, int i2){
		if (i1%3==i2%3){
			int x1=((int)(i1/3))/EnvironmentContext.size2;
			int y1=((int)(i1/3))%EnvironmentContext.size2;
			int x2=((int)(i2/3))/EnvironmentContext.size2;
			int y2=((int)(i2/3))%EnvironmentContext.size2;
			
			//if (x1>=x2-1 && x1<=x2+1 && y1>=y2-1 && y1<=y2+1) System.out.println("######### "+i1+" and "+i2+" ######################################################################");
			
			return (x1>=x2-1 && x1<=x2+1 && y1>=y2-1 && y1<=y2+1);
		}
		else return false;
	}
	
	public boolean isContext(int id, short nbW){
		int i=0;
		boolean found=false;
		while (i<nbW && !found){
			if (getDistance(weightList[i],id)) found=true;
			i++;
		}
		return found;
	}
	
	// fast exp function approximation
	public static double exp(double val) {
	    final long tmp = (long) (1512775 * val + (1072693248 - 60801));
	    return Double.longBitsToDouble(tmp << 32);
	}
	
}

package version11_2_2_2.agnosticMemory;

public class LearningNode {

	public float[] predictions;
	public int[] nbTests;
	
	public LearningNode nextNode=null;
	
	public int id;
	
	public int vmin;
	public float min;
	
	public LearningNode(EnvironmentContext e, int ident, int level, boolean secondary, float[][] actionMap){
		predictions=new float[12];
		nbTests=new int[12];
		
		id=ident;
		
		for (int i=0;i<12;i++){

			if (e.interactionList[id].variations(i)!=null && e.interactionList[id].length-1-level>=0 				// context still in the past
			 && e.interactionList[id].variations(i).successor!=id){
				int successor=e.interactionList[id].variations(i).successor;
				
				if (e.interactionList[successor].signature.learned){
					predictions[i]=e.interactionList[successor].prediction(e.visual[e.interactionList[id].length-1-level], false);
				}
				else{
					predictions[i]=1;
				}
				
				//if (e.interactionList[id].nbIntention[i]<8) nbTests[i]=(e.interactionList[successor].nbEnaction+1)*(e.interactionList[id].nbIntention[i]+1);
				//else predictions[i]=1000;	// remove if tested without success

				// if prediction of the primary interaction is reliable enough, try with the associated secondary interactions
				if (secondary && predictions[i]>0.3){
					for (int j=0;j<EnvironmentContext.length;j++){
						if (e.interactionList[successor].secondarySignatures[j].maxPattern1<0.4){
							float prediction=e.interactionList[successor].secondarySignatures[j].prediction(e.visual[e.interactionList[id].length-1-level], false);
							if (Math.abs(prediction)>0.1 && Math.abs(prediction)<Math.abs(predictions[i])){
								predictions[i]=Math.abs(prediction);
							}
						}
					}
				}
				if (e.interactionList[id].nbIntention[i]<8) nbTests[i]=(e.interactionList[successor].nbEnaction+1)*(e.interactionList[id].nbIntention[i]+1);
				else predictions[i]=1000;	// remove if tested without success
			}
			else predictions[i]=1000; // cannot be defined
		}
		

		// if a variation is predicted as a success with a high certitude, remove opposite
		if (predictions[0]>0.6 && predictions[4]<0.6 && predictions[5]<0.6){  // {}
			if (predictions[4]<1000 && e.interactionList[e.interactionList[id].variations(4).successor].signature.test_f>e.interactionList[e.interactionList[id].variations(4).successor].signature.test_s) predictions[4]=1000;	// X
			if (predictions[5]<1000 && e.interactionList[e.interactionList[id].variations(5).successor].signature.test_f>e.interactionList[e.interactionList[id].variations(5).successor].signature.test_s) predictions[5]=1000;	// F
		}
		else if (predictions[4]>0.6 && predictions[0]<0.6 && predictions[5]<0.6){  // X
			if (predictions[0]<1000 && e.interactionList[e.interactionList[id].variations(0).successor].signature.test_f>e.interactionList[e.interactionList[id].variations(0).successor].signature.test_s) predictions[0]=1000;	// {}
			if (predictions[5]<1000 && e.interactionList[e.interactionList[id].variations(5).successor].signature.test_f>e.interactionList[e.interactionList[id].variations(5).successor].signature.test_s) predictions[5]=1000;	// F
		}
		else if (predictions[5]>0.6 && predictions[0]<0.6 && predictions[4]<0.6){  // F
			if (predictions[4]<1000 && e.interactionList[e.interactionList[id].variations(4).successor].signature.test_f>e.interactionList[e.interactionList[id].variations(4).successor].signature.test_s) predictions[4]=1000;	// X
			if (predictions[0]<1000 && e.interactionList[e.interactionList[id].variations(0).successor].signature.test_f>e.interactionList[e.interactionList[id].variations(0).successor].signature.test_s) predictions[0]=1000;	// {}
		}
			
		if (predictions[1]>0.6 && predictions[6]<0.6 && predictions[7]<0.6){  // >
			if (predictions[6]<1000 && e.interactionList[e.interactionList[id].variations(6).successor].signature.test_f>e.interactionList[e.interactionList[id].variations(6).successor].signature.test_s) predictions[6]=1000;	// >X
			if (predictions[7]<1000 && e.interactionList[e.interactionList[id].variations(7).successor].signature.test_f>e.interactionList[e.interactionList[id].variations(7).successor].signature.test_s) predictions[7]=1000;	// >F
		}
		else if (predictions[6]>0.6 && predictions[1]<0.6 && predictions[7]<0.6){  // >X
			if (predictions[1]<1000 && e.interactionList[e.interactionList[id].variations(1).successor].signature.test_f>e.interactionList[e.interactionList[id].variations(1).successor].signature.test_s) predictions[1]=1000;	// >
			if (predictions[7]<1000 && e.interactionList[e.interactionList[id].variations(7).successor].signature.test_f>e.interactionList[e.interactionList[id].variations(7).successor].signature.test_s) predictions[7]=1000;	// >F
		}
		else if (predictions[7]>0.6 && predictions[1]<0.6 && predictions[6]<0.6){  // >F
			if (predictions[1]<1000 && e.interactionList[e.interactionList[id].variations(1).successor].signature.test_f>e.interactionList[e.interactionList[id].variations(1).successor].signature.test_s) predictions[1]=1000;	// >
			if (predictions[6]<1000 && e.interactionList[e.interactionList[id].variations(6).successor].signature.test_f>e.interactionList[e.interactionList[id].variations(6).successor].signature.test_s) predictions[6]=1000;	// >X
		}
		
		if (predictions[2]>0.6 && predictions[8]<0.6 && predictions[9]<0.6){  // ^
			if (predictions[8]<1000 && e.interactionList[e.interactionList[id].variations(8).successor].signature.test_f>e.interactionList[e.interactionList[id].variations(8).successor].signature.test_s) predictions[8]=1000;	// ^X
			if (predictions[9]<1000 && e.interactionList[e.interactionList[id].variations(9).successor].signature.test_f>e.interactionList[e.interactionList[id].variations(9).successor].signature.test_s) predictions[9]=1000;	// ^F
		}
		else if (predictions[8]>0.6 && predictions[2]<0.6 && predictions[9]<0.6){  // ^X
			if (predictions[2]<1000 && e.interactionList[e.interactionList[id].variations(2).successor].signature.test_f>e.interactionList[e.interactionList[id].variations(2).successor].signature.test_s) predictions[2]=1000;	// ^
			if (predictions[9]<1000 && e.interactionList[e.interactionList[id].variations(9).successor].signature.test_f>e.interactionList[e.interactionList[id].variations(9).successor].signature.test_s) predictions[9]=1000;	// ^F
		}
		else if (predictions[9]>0.6 && predictions[2]<0.6 && predictions[8]<0.6){  // ^F
			if (predictions[2]<1000 && e.interactionList[e.interactionList[id].variations(2).successor].signature.test_f>e.interactionList[e.interactionList[id].variations(2).successor].signature.test_s) predictions[2]=1000;	// ^
			if (predictions[8]<1000 && e.interactionList[e.interactionList[id].variations(8).successor].signature.test_f>e.interactionList[e.interactionList[id].variations(8).successor].signature.test_s) predictions[8]=1000;	// ^X
		}
		
		if (predictions[3]>0.6 && predictions[10]<0.6 && predictions[11]<0.6){  // v
			if (predictions[10]<1000 && e.interactionList[e.interactionList[id].variations(10).successor].signature.test_f>e.interactionList[e.interactionList[id].variations(10).successor].signature.test_s) predictions[10]=1000;	// vX
			if (predictions[11]<1000 && e.interactionList[e.interactionList[id].variations(11).successor].signature.test_f>e.interactionList[e.interactionList[id].variations(11).successor].signature.test_s) predictions[11]=1000;	// vF
		}
		else if (predictions[10]>0.6 && predictions[3]<0.6 && predictions[11]<0.6){  // vX
			if (predictions[ 3]<1000 && e.interactionList[e.interactionList[id].variations(3).successor].signature.test_f>e.interactionList[e.interactionList[id].variations(3).successor].signature.test_s) predictions[3]=1000;		// v
			if (predictions[11]<1000 && e.interactionList[e.interactionList[id].variations(11).successor].signature.test_f>e.interactionList[e.interactionList[id].variations(11).successor].signature.test_s) predictions[11]=1000;	// vF
		}
		else if (predictions[11]>0.6 && predictions[3]<0.6 && predictions[10]<0.6){  // vF
			if (predictions[ 3]<1000 && e.interactionList[e.interactionList[id].variations(3).successor].signature.test_f>e.interactionList[e.interactionList[id].variations(3).successor].signature.test_s) predictions[3]=1000;		// v
			if (predictions[10]<1000 && e.interactionList[e.interactionList[id].variations(10).successor].signature.test_f>e.interactionList[e.interactionList[id].variations(10).successor].signature.test_s) predictions[10]=1000;	// vX
		}
		
		for (int i=0;i<12;i++){
			actionMap[i][level]=Math.abs(predictions[i]);
		}
		
		// projection if variation {} predicted as a success
		if (predictions[0]>-0.1 && predictions[0]<2 && level<10){
			nextNode=new LearningNode(e,e.interactionList[id].variations(0).successor,level+1, secondary, actionMap);
		}
	}
	
	public void getMinReliable(){
		
		vmin=-1;
		min=100000;
		
		getProjection();
		
		for (int i=0;i<12;i++){
			if (Math.abs(predictions[i]*nbTests[i])<min && Math.abs(predictions[i])<=1){
				vmin=i;
				min=Math.abs(predictions[i]*nbTests[i]);
			}
			System.out.println(" --- "+predictions[i]*nbTests[i]+ " ; "+nbTests[i]+ " ; "+predictions[i]);
		}
		System.out.println("learning node propose "+vmin+" with reliability "+min);
	}
	
	protected float getProjection(){
		
		if (nextNode!=null && predictions[0]>0 && predictions[0]<2){
			predictions[0]=Math.min(Math.abs(predictions[0]), nextNode.getProjection());
		}
		
		float min=1;
		for (int i=0;i<12;i++){
			if (Math.abs(predictions[i])<min){
				min=Math.abs(predictions[i]);
			}
		}
		
		return min;
	}
	
}

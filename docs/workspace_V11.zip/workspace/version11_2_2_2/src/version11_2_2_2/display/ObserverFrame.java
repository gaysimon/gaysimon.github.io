package version11_2_2_2.display;

import version11_2_2_2.platform.Agent;

/**
 * Frame to display signatures of interactions
 * @author simon
 */

/* - inherited from EnvFrame :
 *   Agent agent      : pointer to the agent
 *   EnvPanel panel   : panel of this frame
 *   
 * - inherited from PrintableFrame :
 *   boolean printable   : define if the frame can be printed
 *   int indexImage      : counter for image name
 */
public class ObserverFrame extends EnvFrame{

	private static final long serialVersionUID = 1L;

	public ObserverFrame(Agent a){
		super(a);
		this.setTitle("Space Memory");
    	this.setSize(1010, 760);
    	this.setLocationRelativeTo(null);               
    	this.setVisible(true);
    	this.setFocusable(true);
    	panel=new ObserverPanel(a);
    	this.setContentPane(panel);
	}
}


package version11_2_2_2.display;

import version11_2_2_2.platform.Agent;

/**
 * Frame to display signatures of interactions
 * @author simon
 */

/* - inherited from EnvFrame :
 *   Agent agent      : pointer to the agent
 *   EnvPanel panel   : panel of this frame
 *   
 * - inherited from PrintableFrame :
 *   boolean printable   : define if the frame can be printed
 *   int indexImage      : counter for image name
 */
public class SignaturesFrame extends EnvFrame{

	private static final long serialVersionUID = 1L;

	public SignaturesFrame(Agent a){
		super(a);
		this.setTitle("Signatures");
    	this.setSize(1700, 800);
    	this.setLocationRelativeTo(null);               
    	this.setVisible(true);
    	this.setFocusable(true);
    	panel=new SignaturesPanel(a);
    	this.setContentPane(panel);
	}
}


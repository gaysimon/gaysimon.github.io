package version11_2_2_2.display;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import version11_2_2_2.platform.Agent;

/**
 * Frame to display signatures of interactions
 * @author simon gay
 */

/* - inherited from EnvPanel :
 *   Agent agent      : pointer to the agent
 */
public class ObserverPanel extends EnvPanel implements MouseListener{

	private static final long serialVersionUID = 1L;
	
	private int clic_x=0;
	private int clic_y=0;
	
	public ObserverPanel(Agent a){
		super(a);
		addMouseListener(this);
	}
	
	public void setAgent(Agent a){
		agent=a;
	}
	
	public void paintComponent(Graphics g){
		g.setColor(Color.white);
		
		g.fillRect(0, 0, 1600, 900);
	
		for (int i=0;i<1000;i++){
			if (agent.observer.decisionType[i]==0) g.setColor(Color.gray);
			else if (agent.observer.decisionType[i]==1) g.setColor(Color.red);
			else if (agent.observer.decisionType[i]==2) g.setColor(Color.blue);
			else if (agent.observer.decisionType[i]==3) g.setColor(Color.green);
			else if (agent.observer.decisionType[i]==4) g.setColor(Color.yellow);
			
			g.drawLine(5+i, 700, 5+i, 720);
		}
		
		//g.setColor(Color.black);
		//for (int i=1;i<1000;i++){
		//	g.drawLine(i+5, 680-(int)(agent.observer.decisionValues[0][i-1]*2), i+6, 680-(int)(agent.observer.decisionValues[0][i]*2));
		//}
		
		for (int i=1;i<1000;i++){
			g.setColor(Color.red);
			g.drawLine(i+5, 680-(int)(agent.observer.nbInteractions[0][i-1]), i+6, 680-(int)(agent.observer.nbInteractions[0][i]));
			g.setColor(Color.blue);
			g.drawLine(i+5, 680-(int)(agent.observer.nbInteractions[1][i-1]), i+6, 680-(int)(agent.observer.nbInteractions[1][i]));
			g.setColor(Color.green);
			g.drawLine(i+5, 680-(int)(agent.observer.nbInteractions[2][i-1]), i+6, 680-(int)(agent.observer.nbInteractions[2][i]));
		}
		
	}
	
	
	
	///////////////////////////////////////////////////////////////////////////
	public void mouseClicked(MouseEvent e) {

		clic_x=e.getX();
		clic_y=e.getY();
		
		
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {}
	public void mouseReleased(MouseEvent e) {}

}

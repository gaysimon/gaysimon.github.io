package version11_2_2_2.display;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import version11_2_2_2.agnosticMemory.EnvironmentContext;
import version11_2_2_2.platform.Agent;

/**
 * Frame to display signatures of interactions
 * @author simon gay
 */

/* - inherited from EnvPanel :
 *   Agent agent      : pointer to the agent
 */
public class SignaturesPanel extends EnvPanel implements MouseListener{

	private static final long serialVersionUID = 1L;
	
	private int clic_x=0;
	private int clic_y=0;
	
	private int selected_interaction=-1;
	private int selected_pixel=-1;
	private int selected_color=0;
	
	private boolean threshold_1=false;
	private boolean threshold_2=false;
	
	private int pixel=5;
	
	private int size2=EnvironmentContext.size2;
	
	public SignaturesPanel(Agent a){
		super(a);
		addMouseListener(this);
	}
	
	public void setAgent(Agent a){
		agent=a;
	}
	
	public void paintComponent(Graphics g){
		g.setColor(Color.white);
		
		g.fillRect(0, 0, this.getWidth(), this.getHeight());
		
		
		
		// draw enacted interaction
		g.setColor(Color.black);
		g.fillRect(10, 14, 660, 6);
		for (int i=0;i<11;i++){
			for (int j=0;j<11;j++){
				if ((i+j)%2==0) g.setColor(Color.darkGray);
				else g.setColor(Color.gray);
				g.fillRect(10+60*j , 20+60*i , 60, 60);
			}
		}

				
		for (int i=0;i<111*110;i++){
			if (agent.environmentContext.interactionList[i]!=null && agent.environmentContext.interactionList[i].getNbVar()>0){

				if (agent.environmentContext.interactionList[i].signature.delta_f==2 || agent.environmentContext.interactionList[i].signature.delta_s==2)
					g.setColor(Color.LIGHT_GRAY);
				
				else{
					float val=Math.max(agent.environmentContext.interactionList[i].signature.delta_f, agent.environmentContext.interactionList[i].signature.delta_s)/2;
					g.setColor(new Color(val, 1-val,0));
					
				}
				int x1=i%110;
				int y1=i/110;
				g.fillOval(10+6*x1, 15+6*y1, 6, 6);
			}
		}
		
		int x=-1;
		int y=-1;
				
		
		
		for (int i=0;i<12210;i++){
			int x1=i%110;
			int y1=i/110;
			
			if (i==selected_interaction){
				
				g.setColor(Color.green);
	
				
				if (agent.environmentContext.interactionList[i]!=null && agent.environmentContext.interactionList[i].getNbVar()>0){
					g.fillOval(10+6*x1+2, 20+6*y1-3, 2, 2);
					
					if (agent.environmentContext.interactionList[i].getNbVar()>1){
						for (int j=0;j<12;j++){
							
							if (agent.environmentContext.interactionList[i].variations(j)!=null){
							
								int x2=agent.environmentContext.interactionList[i].variations(j).successor%110;
								int y2=agent.environmentContext.interactionList[i].variations(j).successor/110;
								g.drawLine(10+6*x1+3, 20+6*y1-3, 10+6*x2+3, 20+6*y2-3);
							}
						}
					}
				}
			}
		}
		
		g.setColor(Color.red);
		for (int t=10;t>0;t--){
			int x1=agent.environmentContext.timeline[t]%110;
			int y1=agent.environmentContext.timeline[t]/110;
			int x2=agent.environmentContext.timeline[t-1]%110;
			int y2=agent.environmentContext.timeline[t-1]/110;
			g.drawLine(10+6*x1+3, 20+6*y1-3, 10+6*x2+3, 20+6*y2-3);
		}
		
		if (agent.environmentContext.id1!=-1 && agent.environmentContext.interactionList[agent.environmentContext.id1].events.size()>0){
			x=(agent.environmentContext.interactionList[agent.environmentContext.id1].events.get(0)[0]-1)*10+agent.environmentContext.interactionList[agent.environmentContext.id1].events.get(0)[1];
			y=-1;
			if (agent.environmentContext.interactionList[agent.environmentContext.id1].getSize()>1){
				y=(agent.environmentContext.interactionList[agent.environmentContext.id1].events.get(1)[0]-1)*10+agent.environmentContext.interactionList[agent.environmentContext.id1].events.get(1)[1];
			}
			
			g.setColor(Color.blue);
			g.fillRect(10+6*x, 20+6*y, 6, 6);
		}
		
		if (selected_interaction!=-1 && agent.environmentContext.interactionList[selected_interaction]!=null){
			g.setColor(Color.black);
			
			g.drawString(selected_interaction+" = "+agent.environmentContext.interactionList[selected_interaction].name(), 10, 700);
			
			for (int i=0;i<agent.environmentContext.interactionList[selected_interaction].predecessors.size();i++){
				g.drawString(""+agent.environmentContext.interactionList[selected_interaction].predecessors.get(i), 290, 730+12*i);
			}
		}
		
		// draw visual context
		for (int i=0;i<EnvironmentContext.size1;i++){
			for (int j=0;j<EnvironmentContext.size2;j++){
				if (selected_interaction!=-1 && agent.environmentContext.interactionList[selected_interaction]!=null){
					
					int id = (i*EnvironmentContext.size2+j)*3+selected_color;
					if (agent.environmentContext.interactionList[selected_interaction].secondarySignatures[id].maxPattern1>0.4) g.setColor(Color.green);
					else if (agent.environmentContext.interactionList[selected_interaction].secondarySignatures[id].maxPattern1>0.3) g.setColor(Color.yellow);
					else if (agent.environmentContext.interactionList[selected_interaction].secondarySignatures[id].maxPattern1>0.1) g.setColor(Color.orange);
					else g.setColor(Color.red);
					
				}
				else{
					g.setColor(new Color(Math.max(0,agent.environmentContext.visual[0][i*size2*3+j*3+2]),
							 Math.max(0,agent.environmentContext.visual[0][i*size2*3+j*3  ]),
							 Math.max(0,agent.environmentContext.visual[0][i*size2*3+j*3+1]) ));
				}

				
				g.fillOval(700+i*15,240-j*15,15,15);
				
				if (selected_pixel/3==i*EnvironmentContext.size2+j){
					g.setColor(Color.magenta);
					g.drawOval(700+i*15,240-j*15,15,15);
					g.drawOval(701+i*15,241-j*15,13,13);
				}
			}	
		}
		
		// color selection
		g.setColor(Color.green);
		g.fillOval(720, 300, 20, 20);
		g.setColor(Color.blue);
		g.fillOval(750, 300, 20, 20);
		g.setColor(Color.red);
		g.fillOval(780, 300, 20, 20);
		g.setColor(Color.black);
		g.drawOval(720+30*selected_color, 300, 20, 20);
		
		// threshold selector
		if (threshold_1) g.setColor(Color.red);
		else g.setColor(Color.black);
		g.fillRect(1100, 350, 20, 20);
		if (threshold_2) g.setColor(Color.red);
		else g.setColor(Color.black);
		g.fillRect(1100, 380, 20, 20);
		
		
		// draw signatures
		if (selected_interaction!=-1 && agent.environmentContext.interactionList[selected_interaction]!=null){
			
			// draw signature of the selected interaction
			float max=0.1f;
			if (max>=0.1) max=agent.environmentContext.interactionList[selected_interaction].signature.maxPattern1;
			
			for (int j=EnvironmentContext.size2-1;j>=0;j--){
				for (int i=0;i<EnvironmentContext.size1;i++){
					
					if (!threshold_1){
						g.setColor(new Color(Math.max(0, Math.min(1,agent.environmentContext.interactionList[selected_interaction].signature.signature[i*size2*3+j*3+2]/max/2+0.5f)),
											 Math.max(0, Math.min(1,agent.environmentContext.interactionList[selected_interaction].signature.signature[i*size2*3+j*3  ]/max/2+0.5f)),
											 Math.max(0, Math.min(1,agent.environmentContext.interactionList[selected_interaction].signature.signature[i*size2*3+j*3+1]/max/2+0.5f)) ));
					}
					else{
						float red=0.5f;
						float green=0.5f;
						float blue=0.5f;
						float bias=agent.environmentContext.interactionList[selected_interaction].signature.getBias();
						
						if (agent.environmentContext.interactionList[selected_interaction].signature.signature[i*size2*3+j*3+2]*bias<0
						&&  Math.abs(agent.environmentContext.interactionList[selected_interaction].signature.signature[i*size2*3+j*3+2])>0.5*agent.environmentContext.interactionList[selected_interaction].signature.maxPattern1){
							red=Math.max(0, Math.min(1,agent.environmentContext.interactionList[selected_interaction].signature.signature[i*size2*3+j*3+2]/max/2+0.5f));
						}
						if (agent.environmentContext.interactionList[selected_interaction].signature.signature[i*size2*3+j*3  ]*bias<0
						&&  Math.abs(agent.environmentContext.interactionList[selected_interaction].signature.signature[i*size2*3+j*3  ])>0.5*agent.environmentContext.interactionList[selected_interaction].signature.maxPattern1){
							green=Math.max(0, Math.min(1,agent.environmentContext.interactionList[selected_interaction].signature.signature[i*size2*3+j*3  ]/max/2+0.5f));
						}
						if (agent.environmentContext.interactionList[selected_interaction].signature.signature[i*size2*3+j*3+1]*bias<0
						&&  Math.abs(agent.environmentContext.interactionList[selected_interaction].signature.signature[i*size2*3+j*3+1])>0.5*agent.environmentContext.interactionList[selected_interaction].signature.maxPattern1){
							blue=Math.max(0, Math.min(1,agent.environmentContext.interactionList[selected_interaction].signature.signature[i*size2*3+j*3+1]/max/2+0.5f));
						}
						g.setColor(new Color(red,green,blue));
					}
					
					g.fillRect(1200+i*pixel*3, 10+(EnvironmentContext.size2-j)*pixel*3, pixel*3, pixel*3);
				}
			}
			// draw bias
			int length=EnvironmentContext.size2*EnvironmentContext.size1*3;
			g.setColor(new Color(Math.max(0, Math.min(1,1-(agent.environmentContext.interactionList[selected_interaction].signature.signature[length]/3/2+0.5f))),
								 Math.max(0, Math.min(1,   agent.environmentContext.interactionList[selected_interaction].signature.signature[length]/3/2+0.5f)),0));
			
			g.fillOval(1170, 10+pixel*4, pixel*4, pixel*4);
			
			// draw signature of the selected secondary interaction
			if (selected_pixel!=-1){
				
				g.setColor(new Color(128,128,128));
				g.fillRect(1200, 260, 300, 150);
				g.fillRect(1200, 420, 300, 150);
				g.fillRect(1200, 580, 300, 150);
				
				// draw signature of the selected interaction
				max=0.1f;
				if (max>=0.1) max=agent.environmentContext.interactionList[selected_interaction].secondarySignatures[selected_pixel].maxPattern1;
				
				short i=0;
				while (i<50 && i<agent.environmentContext.interactionList[selected_interaction].secondarySignatures[selected_pixel].nbWeights){
					
					int id=agent.environmentContext.interactionList[selected_interaction].secondarySignatures[selected_pixel].weightList[i];
					
					int c=0;
					int px=0;
					int py=0;

					c=id%3;
					px=(id/3)/EnvironmentContext.size2;
					py=(id/3)%EnvironmentContext.size2;
					
					float val=0.5f;
					if (!threshold_2 || Math.abs(agent.environmentContext.interactionList[selected_interaction].secondarySignatures[selected_pixel].signature[i])>0.5*agent.environmentContext.interactionList[selected_interaction].secondarySignatures[selected_pixel].maxPattern1){
						val=Math.max(0, Math.min(1,agent.environmentContext.interactionList[selected_interaction].secondarySignatures[selected_pixel].signature[i]/max/2+0.5f));
					}
					g.setColor(new Color(val,val,val));
					g.fillRect(1200+px*10, 400-py*10+160*c, 10, 10);
					
					i++;
				}
				
				//draw bias
				g.setColor(new Color(Math.max(0, Math.min(1,1-(agent.environmentContext.interactionList[selected_interaction].secondarySignatures[selected_pixel].bias/max/2+0.5f))),
									 Math.max(0, Math.min(1,   agent.environmentContext.interactionList[selected_interaction].secondarySignatures[selected_pixel].bias/max/2+0.5f)),0));
				
				g.fillOval(1170, 260+pixel*4, pixel*4, pixel*4);
			}
		}
	}
	
	
	
	///////////////////////////////////////////////////////////////////////////
	public void mouseClicked(MouseEvent e) {

		clic_x=e.getX();
		clic_y=e.getY();
		
		for (int i=0;i<110;i++){
			for (int j=0;j<111;j++){
				if (clic_x>=10+i*6 && clic_x<16+i*6 && clic_y>=15+j*6 && clic_y<21+j*6){
					selected_interaction=j*110+i;
					System.out.println("selected : "+selected_interaction);
				}
			}
		}
		if (selected_interaction>=0 && agent.environmentContext.interactionList[selected_interaction]==null) selected_interaction=-1;
		
		for (int i=0;i<EnvironmentContext.size1;i++){
			for (int j=0;j<EnvironmentContext.size2;j++){
				if (clic_x>=700+i*15 && clic_x<715+i*15 && clic_y>=240-j*15 && clic_y<255-j*15){
					selected_pixel=i*EnvironmentContext.size2*3+j*3+selected_color;
					System.out.println("selected pixel : "+selected_pixel);
				}
			}
		}
		
		for (int c=0;c<3;c++){
			if (clic_x>=720+30*c && clic_x<=740+30*c && clic_y>=300 && clic_y<=330){
				selected_color=c;
				selected_pixel=(int)(selected_pixel/3)*3+selected_color;
			}
		}
		
		if (clic_x>=1100 && clic_x<=1120 && clic_y>=350 && clic_y<=370) threshold_1=!threshold_1;
		if (clic_x>=1100 && clic_x<=1120 && clic_y>=380 && clic_y<=400) threshold_2=!threshold_2;
	}

	@Override
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {}
	public void mouseReleased(MouseEvent e) {}

}

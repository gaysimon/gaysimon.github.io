package version11_2_2_2.sensorySystem;

/**
 * interface between visual information and visual interactions
 * @author simon
 */
import java.awt.Color;

import version11_2_2_2.Interface.Variation;
import version11_2_2_2.platform.Agent;

public class VisualSystem {

	private Agent agent;
	
	public Color[] color;
	public float[] opticFlow;
	
	public VisualSystem(Agent a){
		agent=a;

		color=new Color[36];
		opticFlow=new float[36];
	}
	
	// simulate an optic flow
	public void opticFlow(int inter){
		
		float optic;
		if (Variation.getAction(inter)==1){
			for (int i=0;i<36;i++){

				opticFlow[i]= 99;
				
				//if (agent.body.sensors[0]!=2){
					for (int j=-2;j<=2;j++){
						optic=1f*(float) ((agent.probe.distRetina[i*5+2+j+ 90]));
						
						//optic=Math.max(-49, Math.min(49, optic));
						if (Math.abs(optic)<Math.abs(opticFlow[i])){
							opticFlow[i]=optic;
							color[i]=agent.probe.colRetina[i*5+2+j+90];
						}
					}
				//}
			}
		}
		else{
			if (Variation.getAction(inter)==2){
				
				for (int i=0;i<36;i++){

					opticFlow[i]= 99;
					
					for (int j=-2;j<=2;j++){
						optic=1f*(float) ((agent.probe.distRetina[i*5+2+j+ 90]));
						if (Math.abs(optic)<Math.abs(opticFlow[i])){
							opticFlow[i]=optic;
							color[i]=agent.probe.colRetina[i*5+2+j+90];
						}
					}
				}
			}
			else{
				if (Variation.getAction(inter)==3){
					
					for (int i=0;i<36;i++){

						opticFlow[i]= 99;
						
						for (int j=-2;j<=2;j++){
							optic=1f*(float) ((agent.probe.distRetina[i*5+2+j+ 90]));
							if (Math.abs(optic)<Math.abs(opticFlow[i])){
								opticFlow[i]=optic;
								color[i]=agent.probe.colRetina[i*5+2+j+90];
							}
						}
					}
				}
				else{
					for (int i=0;i<36;i++){

						opticFlow[i]= 99;
						
						for (int j=-2;j<=2;j++){
							optic=1f*(float) ((agent.probe.distRetina[i*5+2+j+ 90]));
							if (Math.abs(optic)<Math.abs(opticFlow[i])){
								opticFlow[i]=optic;
								color[i]=agent.probe.colRetina[i*5+2+j+90];
							}
						}
					}
				}
			}
		}
	}
	
}
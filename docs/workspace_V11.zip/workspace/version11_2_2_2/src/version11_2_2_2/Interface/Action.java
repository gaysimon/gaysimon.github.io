package version11_2_2_2.Interface;

import version11_2_2_2.platform.Agent;

/**
 * This class controls the main simulation loop of the agent :
 * it gets the decision of the agent, enact the interaction through the body
 * and update decision modules once cycle is completed.
 * @author simon gay
 */
public class Action {

	//private PrimitiveInteraction lastAct;	// last action signal
	//private PrimitiveInteraction enacted;	// last enacted interaction
	private int lastAct;
	private int enacted;
	private Agent agent;
	
	private int state;         			// 0=stop or step mode, 1=run
	private boolean step;					// move one step
	
	private int stepNb;					// number of completed decision cycle
	
	private static int nbSubStep=5;		// define the number of substep per step
	
	public Action(Agent a){
		//acting=false;
		lastAct=0;
		enacted=0;
		
		agent=a;
		state=0;
		step=false;
		
		stepNb=0;
	}
	
	public void act(){
		
		step=false;
		
		System.out.println("==================== step #"+stepNb+" =========================================================");
		
		// get agent's decision
		
		int lastAct_temp=agent.decision.decision();
		
		double[] command=new double[3];
		command[0]=0;
		command[1]=0;
		command[2]=0;
		
		lastAct=lastAct_temp;
		if (Variation.getAction(lastAct)==1) command[1]= 0.99/(float)nbSubStep;
		if (Variation.getAction(lastAct)==2) command[2]= (1/(float)nbSubStep)*Math.PI/2;
		if (Variation.getAction(lastAct)==3) command[2]=(-1/(float)nbSubStep)*Math.PI/2;
		
		System.out.println("command : ("+command[1]+", "+command[2]+")");
		
		agent.body.setSpeed(command);
		
		agent.body.move();
		
		//%%%%%%%%%%%%%%%% specific to render function %%%%%%%%%%%%%%%%%%%
		agent.probe.rendu();
		agent.visual.opticFlow(lastAct);
		//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			
		agent.sensors.update();
		
		//%%%%%%%%%%%%%%%%% specific to simulators %%%%%%%%%%%%%%%%%%%%%%%
		agent.body.center();
		agent.probe.rendu();
		agent.visual.opticFlow(lastAct);
		//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		
		agent.sensors.update();
		agent.body.reset();
		
		enacted=agent.sensors.recognize(lastAct);
		
		// update decision system
		agent.observer.updateObserver(enacted);
		
		agent.environmentContext.updateContext(enacted, agent.sensors.recognizePerceptions());

		stepNb++;
		
		try{Thread.currentThread();
		Thread.sleep(10);}
		catch(Exception ie){}
		
		
		//-------------------------------------------------
	}
	
	/////////////////////////////////////////////
	// start, stop and allow one decision cycle
	public void start(){
		state=1;
	}
	public void stop(){
		state=0;
	}
	
	public void step(){
		step=true;
	}
	
	/////////////////////////////////////////////
	
	public int getNbStep(){
		return stepNb;
	}
	
	public void setNbstep(int i){
		stepNb=i;
	}
	
	public int getState(){
		return state;
	}

	public boolean isStopped(){
		return state==0 && !step;
	}
	
}

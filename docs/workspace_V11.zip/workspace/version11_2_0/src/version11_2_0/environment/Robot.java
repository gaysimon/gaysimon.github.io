package version11_2_0.environment;


/**
 * representation of a physical agent in its environment
 * @author simon gay
 */
public class Robot {

	private Environment env;
	private static boolean eatPrey=true;			// if true, a prey disappears when the agent "eats" it
	private static boolean replacePrey=true;		// if true, a new prey is added when the agent enacts "eat"

	private float px;								// position (x,y) in grid cell unit
	private float py;
	
	private float rz;								// orientation rz in radius
	
	private float vx;
	private float vy;
	private float vz;
	
	public float last_vx;
	public float last_vy;
	public float last_vt;
	
	
	//////////////////////////////////////////////////////////////////////
	// sensors and "leds"
	public int[] sensors;   // [0] bump , [1] turn , [2] touch , [3] left , [4] right , [5] reach
	public boolean[] display;
	//--------------------------------------------------------------------
	
	public Robot(){
		
		// initialization of sensors
		sensors=new int[6];
		for(int i=0;i<6;i++){
			sensors[i]=0;
		}
		
		display=new boolean[3];
		display[0]=false;
		display[1]=false;
		display[2]=false;
	}
	
	public void setEnvironment(Environment e){
		env=e;
	}
	
	public void setSpeed(double[] act){
		vx=(float) Math.max(vx,act[0]);
		vy=(float) Math.max(vy,act[1]);
		vz+=act[2];
		vz=(float) Math.max(-Math.PI/10, Math.min(Math.PI/10, vz));
	}

	// activate the robot
	public void move(){
		
		System.out.println("movement : ("+vx+", "+vy+", "+vz+")");
		
		////////////////////////////////////////////////////////////////////
		// movements
		double orientation=rz;
		
		px+=  vx*Math.sin(orientation)+vy*Math.cos(orientation);
		py+=  vx*Math.cos(orientation)+vy*Math.sin(orientation);
		
		rz+=vz;
		if (rz<0) rz+=2*Math.PI;
		if (rz>=2*Math.PI) rz-=2*Math.PI;
		
		for(int k=0;k<6;k++){
			sensors[k]=0;
		}
		if (vx!=0 || vy!=0) sensors[0]=1;
		
		////////////////////////////////////////////////////////////////////
		// collisions
		
		int i=Math.round(px);
		int j=Math.round(py);
		
		
		for (int w=-1;w<=1;w++){
			for (int h=-1;h<=1;h++){
				if (i!=0 && j!=0){
					
					if (i+w>=0 && i+w<env.m_w && j+h>=0 && j+h<env.m_h){
						if (!env.isWalkthroughable(i+w,j+h)){
							// case lateral block
							if (w==0){
								if ((j+h - py)*h<1){
									py-= h*(1 - h*(j+h - py));
									sensors[0]=2;
								}
							}
							else{ 
								if (h==0){
									if ((i+w - px)*w<1){
										px-= w*(1 - w*(i+w - px));
										sensors[0]=2;
									}
								}
								else{
									// case corner block
									float x2= (i+w)-w*0.5f;
									float y2= (j+h)-h*0.5f;
									
									double dist=Math.sqrt((px-x2)*(px-x2)+(py-y2)*(py-y2));

									if (dist<0.5){
										sensors[0]=2;
										px+= (px-x2) * (0.5-(dist-0.05)) /0.5;
										py+= (py-y2) * (0.5-(dist-0.05)) /0.5;
									}
								}
							}
						}
					}
					
				}
			}
		}	
		
		if (sensors[0]==2){
			try{Thread.currentThread();
				Thread.sleep(20);}
			catch(Exception ie){}
		}/**/
		
		last_vx=vx;
		last_vy=vy;
		last_vt=vz;
		
		vx=vx-0.02f;
		vy=vy-0.02f;
		
		if (Math.abs(vz)>0.01){
			if (vz>=0) vz=vz-(float)(0.02*(Math.PI/2));
			else 	   vz=vz+(float)(0.02*(Math.PI/2));
		}
		
		if (vx<=0.01) vx=0;
		if (vy<=0.01) vy=0;
		if (Math.abs(vz)<=0.0314) vz=0;
		
		if (sensors[0]==2){
			vx=0;
			vy=0;
			
			last_vx=0;
			last_vy=0;
		}
	}
	
	
	// finalize the movement
	public void center(){
		
		// feel block under the agent
		for (int i=-1;i<=1;i++){
			for (int j=-1;j<=1;j++){
				
				if (env.isFood(Math.round(px)+i,Math.round(py)+j)){
					double d=Math.sqrt( (Math.round(px)+i-px )*(Math.round(px)+i-px )
							            +(Math.round(py)+j-py )*(Math.round(py)+j-py ));
					
					// if the agent reach a prey
					if (d<=0.8){
						
						// set the "eat" sensor
						sensors[5]=1;
						
						// remove the prey
						if (eatPrey)
							env.setBlock(Math.round(px)+i,Math.round(py)+j,Environment.empty);
						
						// place randomly a new prey
						if (replacePrey){
							int rx=(int) (Math.random()*env.m_w);
							int ry=(int) (Math.random()*env.m_h);
							
							while (!env.isEmpty(rx,ry)){
								rx=(int) (Math.random()*env.m_w);
								ry=(int) (Math.random()*env.m_h);
							}
							env.setBlock(rx,ry,Environment.fish);
						}
					}
				}
			}
		}
	}
	
	
	
	///////////////////////////////////////////////////////////////////////////////
	
	public static float[] computeMovement(int[] eventList){
		
		
		float x1=0;
		float y1=0;
		float theta1=0;
		
		float vit_y=0;
		float rot_z=0;
		
		int t=0;
		while (eventList[t]<100 && t<10*10){
			
			// set speed
			if (eventList[t]==1 || eventList[t]==7)	vit_y=Math.max(vit_y, 0.2f);		// > and >F
			else if (eventList[t]==2 || eventList[t]==9){								// ^ and ^F
				rot_z+=0.2*Math.PI/2;
				rot_z=(float) Math.max(-Math.PI/10, Math.min(Math.PI/10, rot_z));
			}
			else if (eventList[t]==3 || eventList[t]==11){								// v and vF
				rot_z-=0.2*Math.PI/2;
				rot_z=(float) Math.max(-Math.PI/10, Math.min(Math.PI/10, rot_z));
			}
			else if (eventList[t]==4 || eventList[t]==6 || eventList[t]==8 || eventList[t]==10) vit_y=0;	// X, >X, ^X and vX 
			
			
			// movements
			if (t>=10){
				double orientation=theta1;
				
				x1+=  vit_y*Math.cos(orientation);
				y1+=  vit_y*Math.sin(orientation);
				
				theta1+=rot_z;
				if (theta1<0) theta1+=2*Math.PI;
				if (theta1>=2*Math.PI) theta1-=2*Math.PI;
				
				//System.out.println(" {"+x1+", "+y1+", "+theta1+"} ; {"+vit_y+", "+rot_z+"}");
			}
			
			// update speed
			vit_y=vit_y-0.02f;
			if (Math.abs(rot_z)>0.01){
				if (rot_z>=0) rot_z=rot_z-(float)(0.02*(Math.PI/2));
				else 	   rot_z=rot_z+(float)(0.02*(Math.PI/2));
			}
			if (vit_y<=0.01) vit_y=0;
			if (Math.abs(rot_z)<=0.0314) rot_z=0;
			
			t++;
		}
		
		float[] ret={x1,y1,theta1};
		return ret;
	}
	
	///////////////////////////////////////////////////////////////////////////////
	
	public float getpx(){ return px;}
	public float getpy(){ return py;}
	public float getrz(){ return rz;}
	
	public float getvx(){ return vx;}
	public float getvy(){ return vy;}
	public float getvz(){ return vz;}
	
	public void setPosition(float x, float y, float theta){
		px=x;
		py=y;
		rz=theta;
	}
	
	public void reset(){
		for(int k=0;k<6;k++){
			sensors[k]=0;
		}
	}
}

package version11_2_0.Interface;

import version11_2_0.spaceMemory.EnvironmentContext;
import version11_2_0.environment.Environment;
import version11_2_0.platform.Agent;

/**
 * convert signals from the robot into interactions
 * @author simon
 */
public class Perception {

	private Agent agent;

	private int size=3;       						// nb of status
	private boolean[] status;
	
	public Perception(Agent a){
		agent=a;
		
		// "physical" robot input
		status=new boolean[size];
		for (int i=0;i<size;i++){
			status[i]=false;
		}
	}

	
	public void update(){
		
		//%%%%%%%%%%%%%%%% specific to render function %%%%%%%%%%%%%%%%%%%
		agent.probe.rendu();
		//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		
		// get the input vector
		for (int i=0;i<size;i++) status[i]=false;
		if (agent.body.sensors[0]==1) status[0]=true;
		if (agent.body.sensors[0]==2) status[1]=true;
		if (agent.body.sensors[5]==1) status[2]=true;
	}
	
	
	// interpretation of enacted interaction according to action and inputs
	public int recognize(int intended){
		
		int a=0;
		
		if (intended==0 || intended==4 || intended==5){	// nop
			if (status[2]) 		a=5;
			else if (status[1])a=4;
			else a=0;
		}
		if (intended==1 || intended==6 || intended==7){	// >
			if (status[2]) 		a=7;
			else if (status[1])a=6;
			else a=1;
		}
		if (intended==2 || intended==8 || intended==9){	// ^
			if (status[2]) 		a=9;
			else if (status[1])a=8;
			else a=2;
		}
		if (intended==3 || intended==10 || intended==11){	// v
			if (status[2]) 		a=11;
			else if (status[1])a=10;
			else a=3;
		}

		return a;
	}
	
	public float[] recognizePerceptions(){

		float[] perceptions=new float[EnvironmentContext.size1*EnvironmentContext.size2*3+2];
		
		// initialize enacted ensemble
		for (int i=0;i<EnvironmentContext.size1*EnvironmentContext.size2*3+2;i++){
			perceptions[i]=0;
		}
		
		// bump and eat stimuli
		if (status[1]) perceptions[EnvironmentContext.size1*EnvironmentContext.size2*3  ]=1;
		if (status[2]) perceptions[EnvironmentContext.size1*EnvironmentContext.size2*3+1]=1;
		
		// set visual stimuli
		for (int i=0;i<agent.visual.color.length;i++){
			if (agent.visual.opticFlow[i]!=0 && agent.visual.opticFlow[i]<200){
				int col=0;
				if (agent.visual.color[i].equals(Environment.WALL1)) col=1;
				else if (agent.visual.color[i].equals(Environment.FISH1)) col=2;
				else if (agent.visual.color[i].equals(Environment.ALGA1)) col=3;
				
				if (col!=0){

					float theta=(float) Math.toRadians((i*5)-90);
					
					float x= (float) ( (agent.visual.opticFlow[i]/3)*Math.sin(theta))+(EnvironmentContext.size1/2);
					float y= (float) ( (agent.visual.opticFlow[i]/3)*Math.cos(theta));

					if (x>=0 && x<EnvironmentContext.size1 && y>=0 && y<EnvironmentContext.size2){
						int n= ((int)x * EnvironmentContext.size2*3 + (int)y*3 + (col-1)); 
						perceptions[n]=1;
					}
				}
			}
		}

		return perceptions;
	}
	
	
}

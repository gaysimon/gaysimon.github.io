package version11_2_0.Interface;

public class Variation {

	public int delta;
	public int successor;
	
	public Variation(int id, int pos){
		delta=id;
		successor=pos;
	}
	
	public String getName(){
		String ret="{";
		if (delta==1) ret+=">";
		if (delta==2) ret+="v";
		if (delta==3) ret+="^";
		if (delta==4) ret+="X";
		if (delta==5) ret+="F";
		if (delta==6) ret+=">, X";
		if (delta==7) ret+=">, F";
		if (delta==8) ret+="^, X";
		if (delta==9) ret+="^, F";
		if (delta==10)ret+="v, X";
		if (delta==11)ret+="v, F";
		ret+="} -> "+successor;
		return ret;
	}

	
	public boolean isEqual(Variation v){
		return this.delta==v.delta;
	}
	
	// partially hard-coded
	public boolean isAlternative(Variation var){
		
		boolean ret=false;
		
		if (this.delta==0 || this.delta==4 || this.delta==5){
			ret= (var.delta==0 || var.delta==4 || var.delta==5);
		}
		else if (this.delta==1 || this.delta==6 || this.delta==7){
			ret= (var.delta==1 || var.delta==6 || var.delta==7);
		}
		else if (this.delta==2 || this.delta==8 || this.delta==9){
			ret= (var.delta==2 || var.delta==8 || var.delta==9);
		}
		else if (this.delta==3 || this.delta==10|| this.delta==11){
			ret= (var.delta==3 || var.delta==10|| var.delta==11);
		}
		
		return ret;
	}
	
	// 0 -> nop, 1 -> > , 2 -> ^ , 3 -> v
	public static int getAction(int id){
		if (id==1 || id==6 || id==7) return 1;
		else if (id==2 || id==8 || id==9 ) return 2;
		else if (id==3 || id==10|| id==11) return 3;
		else return 0;
	}
	
}

package version11_2_0.display;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import version11_2_0.spaceMemory.EnvironmentContext;
import version11_2_0.platform.Agent;

/**
 * Frame to display signatures of interactions
 * @author simon gay
 */

/* - inherited from EnvPanel :
 *   Agent agent      : pointer to the agent
 */
public class ContextPanel extends EnvPanel implements MouseListener{

	private static final long serialVersionUID = 1L;
	
	private int clic_x=0;
	private int clic_y=0;
	
	private int selected_interaction=-1;
	
	private int pixel=2;
	
	private int size2=EnvironmentContext.size2;
	
	public ContextPanel(Agent a){
		super(a);
		addMouseListener(this);
	}
	
	public void setAgent(Agent a){
		agent=a;
	}
	
	public void paintComponent(Graphics g){
		g.setColor(Color.white);
		
		g.fillRect(0, 0, this.getWidth(), this.getHeight());
		
		//////////////////////////////////////////////////////////////
		// draw interactional context
		
		// draw actions
		
		for (int t=10;t>=0;t--){
			g.setColor(Color.black);
			if (agent.environmentContext.enactedActions[t]==1 
			 || agent.environmentContext.enactedActions[t]==6 || agent.environmentContext.enactedActions[t]==7){
				g.drawString(">", 20, 60*t+25);
			}
			if (agent.environmentContext.enactedActions[t]==2 
			 || agent.environmentContext.enactedActions[t]==8 || agent.environmentContext.enactedActions[t]==9){
				g.drawString("^", 20, 60*t+25);
			}
			if (agent.environmentContext.enactedActions[t]==3 
			 || agent.environmentContext.enactedActions[t]==10|| agent.environmentContext.enactedActions[t]==11){
				g.drawString("v", 20, 60*t+25);
			}
			
			if (agent.environmentContext.enactedActions[t]==4 || agent.environmentContext.enactedActions[t]==6 
			 || agent.environmentContext.enactedActions[t]==8 || agent.environmentContext.enactedActions[t]==10){
				g.setColor(Color.green);
				g.fillOval(35, 60*t+15, 15, 15);
			}
			if (agent.environmentContext.enactedActions[t]==5 || agent.environmentContext.enactedActions[t]==7 
			 || agent.environmentContext.enactedActions[t]==9 || agent.environmentContext.enactedActions[t]==11){
				g.setColor(Color.blue);
				g.fillOval(50, 60*t+15, 15, 15);
			}
			
			g.setColor(Color.black);
			g.drawString(""+agent.environmentContext.timeline[t], 85, 60*t+25);
		}
		
		for (int t=10;t>=0;t--){
			for (int j=EnvironmentContext.size2-1;j>=0;j--){
				for (int i=0;i<EnvironmentContext.size1;i++){
					if (agent.environmentContext.visual[t][i*size2*3+j*3+2]>0 ||
						agent.environmentContext.visual[t][i*size2*3+j*3  ]>0 ||
						agent.environmentContext.visual[t][i*size2*3+j*3+1]>0){
						g.setColor(new Color(Math.max(0,agent.environmentContext.visual[t][i*size2*3+j*3+2]),
											 Math.max(0,agent.environmentContext.visual[t][i*size2*3+j*3  ]),
											 Math.max(0,agent.environmentContext.visual[t][i*size2*3+j*3+1]) ));
		
						g.fillOval(350+i*pixel-j*2, (EnvironmentContext.size2-j)*pixel/2+60*t, pixel, pixel);
					}
					else{
						g.setColor(Color.gray);
						g.fillOval(350+i*pixel-j*2, (EnvironmentContext.size2-j)*pixel/2+60*t, 1, 1);
					}
				}
			}
		}
		
		// draw enacted interaction
		g.setColor(Color.black);
		g.fillRect(700, 15, 550, 5);
		for (int i=0;i<11;i++){
			for (int j=0;j<11;j++){
				if ((i+j)%2==0) g.setColor(Color.darkGray);
				else g.setColor(Color.gray);
				g.fillRect(700+50*j , 20+50*i , 50, 50);
			}
		}

				
		for (int i=0;i<111*110;i++){
			if (agent.environmentContext.interactionList[i]!=null && agent.environmentContext.interactionList[i].getNbVar()>0){
				if (agent.environmentContext.interactionList[i].getNbVar()<=1) g.setColor(Color.red);
				else g.setColor(Color.green);
				int x1=i%110;
				int y1=i/110;
				g.fillOval(700+5*x1, 15+5*y1, 5, 5);
			}
		}
		
		int x=-1;
		int y=-1;
				
		
		
		for (int i=0;i<12210;i++){
			int x1=i%110;
			int y1=i/110;
			
			if (i==selected_interaction){
				
				g.setColor(Color.green);
	
				
				if (agent.environmentContext.interactionList[i]!=null && agent.environmentContext.interactionList[i].getNbVar()>0){
					g.fillOval(700+5*x1+2, 19+5*y1-3, 2, 2);
					
					if (agent.environmentContext.interactionList[i].getNbVar()>1){
						for (int j=0;j<12;j++){
							
							if (agent.environmentContext.interactionList[i].variations(j)!=null){
							
								int x2=agent.environmentContext.interactionList[i].variations(j).successor%110;
								int y2=agent.environmentContext.interactionList[i].variations(j).successor/110;
								g.drawLine(700+5*x1+3, 20+5*y1-3, 700+5*x2+3, 20+5*y2-3);
							}
						}
					}
				}
			}
		}
		
		g.setColor(Color.red);
		for (int t=10;t>0;t--){
			int x1=agent.environmentContext.timeline[t]%110;
			int y1=agent.environmentContext.timeline[t]/110;
			int x2=agent.environmentContext.timeline[t-1]%110;
			int y2=agent.environmentContext.timeline[t-1]/110;
			g.drawLine(700+5*x1+3, 20+5*y1-3, 700+5*x2+3, 20+5*y2-3);
		}
		
		if (agent.environmentContext.id1!=-1 && agent.environmentContext.interactionList[agent.environmentContext.id1].events.size()>0){
			x=(agent.environmentContext.interactionList[agent.environmentContext.id1].events.get(0)[0]-1)*10+agent.environmentContext.interactionList[agent.environmentContext.id1].events.get(0)[1];
			y=-1;
			if (agent.environmentContext.interactionList[agent.environmentContext.id1].getSize()>1){
				y=(agent.environmentContext.interactionList[agent.environmentContext.id1].events.get(1)[0]-1)*10+agent.environmentContext.interactionList[agent.environmentContext.id1].events.get(1)[1];
			}
			
			g.setColor(Color.blue);
			g.fillRect(700+5*x, 20+5*y, 5, 5);
		}
		
		if (selected_interaction!=-1 && agent.environmentContext.interactionList[selected_interaction]!=null){
			g.setColor(Color.black);
			
			g.drawString(agent.environmentContext.interactionList[selected_interaction].name(), 700, 600);
			
			for (int i=0;i<12;i++){
				
				g.drawString(""+agent.environmentContext.interactionList[selected_interaction].nbIntention[i], 700, 630+12*i);
				
				if (agent.environmentContext.interactionList[selected_interaction].variations(i)!=null){
				g.drawString(agent.environmentContext.interactionList[selected_interaction].variations(i).getName()
					  +" ; "+agent.environmentContext.interactionList[selected_interaction].length
					  +" ; "+agent.environmentContext.interactionList[selected_interaction].variations(i).delta
					  , 730, 630+12*i);
				
				int successor=agent.environmentContext.interactionList[selected_interaction].variations(i).successor;
				g.drawString(""+agent.environmentContext.interactionList[successor].signature.getPrediction(), 900, 630+12*i);
				}
			}
			
			for (int i=0;i<agent.environmentContext.interactionList[selected_interaction].predecessors.size();i++){
				int pred=agent.environmentContext.interactionList[selected_interaction].predecessors.get(i);
				g.drawString(""+pred, 1050, 630+12*i);
				g.drawString(agent.environmentContext.interactionList[pred].name(), 1150, 630+12*i);
				
			}
		}
		
		
		// draw signatures
		if (selected_interaction!=-1 && agent.environmentContext.interactionList[selected_interaction]!=null){
			int nb=0;
			
			// draw signature of the selected interaction
			float max=0.1f;
			if (max>0.1) max=agent.environmentContext.interactionList[selected_interaction].signature.maxPattern1;
			
			for (int j=EnvironmentContext.size2-1;j>=0;j--){
				for (int i=0;i<EnvironmentContext.size1;i++){
					
					
					g.setColor(new Color(Math.max(0, Math.min(1,agent.environmentContext.interactionList[selected_interaction].signature.signature[i*size2*3+j*3+2]/max/2+0.5f)),
										 Math.max(0, Math.min(1,agent.environmentContext.interactionList[selected_interaction].signature.signature[i*size2*3+j*3  ]/max/2+0.5f)),
										 Math.max(0, Math.min(1,agent.environmentContext.interactionList[selected_interaction].signature.signature[i*size2*3+j*3+1]/max/2+0.5f)) ));
					
					g.fillRect(1280+i*pixel, 10+(EnvironmentContext.size2-j)*pixel, pixel, pixel);
				}
			}
			// draw bias
			int length=EnvironmentContext.size2*EnvironmentContext.size1*3;
			g.setColor(new Color(Math.max(0, Math.min(1,1-(agent.environmentContext.interactionList[selected_interaction].signature.signature[length]/max/2+0.5f))),
								 Math.max(0, Math.min(1,   agent.environmentContext.interactionList[selected_interaction].signature.signature[length]/max/2+0.5f)),0));
			
			g.fillOval(1270, 10+pixel*3, pixel*3, pixel*3);
			
			// draw signature of possible successors
			for (int s=0;s<12;s++){
				
				if (agent.environmentContext.interactionList[selected_interaction]!=null && agent.environmentContext.interactionList[selected_interaction].variations(s)!=null){
				
					max=0.1f;
					int successor=agent.environmentContext.interactionList[selected_interaction].variations(s).successor;
					if (max>0.1) max=agent.environmentContext.interactionList[successor].signature.maxPattern1;
					
					for (int j=EnvironmentContext.size2-1;j>=0;j--){
						for (int i=0;i<EnvironmentContext.size1;i++){
							
							
							g.setColor(new Color(Math.max(0, Math.min(1,agent.environmentContext.interactionList[successor].signature.signature[i*size2*3+j*3+2]/max/2+0.5f)),
												 Math.max(0, Math.min(1,agent.environmentContext.interactionList[successor].signature.signature[i*size2*3+j*3  ]/max/2+0.5f)),
												 Math.max(0, Math.min(1,agent.environmentContext.interactionList[successor].signature.signature[i*size2*3+j*3+1]/max/2+0.5f)) ));
							
							g.fillRect(1280+i*pixel, 180+(EnvironmentContext.size2-j)*pixel+110*nb, pixel, pixel);
						}
					}
					// draw bias
					g.setColor(new Color(Math.max(0, Math.min(1,1-(agent.environmentContext.interactionList[successor].signature.signature[length]/max/2+0.5f))),
										 Math.max(0, Math.min(1,   agent.environmentContext.interactionList[successor].signature.signature[length]/max/2+0.5f)),0));
					
					g.fillOval(1270, 180+pixel*3+110*nb, pixel*3, pixel*3);
					
					nb++;
				}
			}
		}
	}
	
	
	
	///////////////////////////////////////////////////////////////////////////
	public void mouseClicked(MouseEvent e) {

		clic_x=e.getX();
		clic_y=e.getY();
		
		for (int i=0;i<110;i++){
			for (int j=0;j<111;j++){
				if (clic_x>=700+i*5 && clic_x<705+i*5 && clic_y>=15+j*5 && clic_y<20+j*5){
					selected_interaction=j*110+i;
					System.out.println("selected : "+selected_interaction);
				}
			}
		}
		if (selected_interaction>=0 && agent.environmentContext.interactionList[selected_interaction]==null) selected_interaction=-1;
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {}
	public void mouseReleased(MouseEvent e) {}

}

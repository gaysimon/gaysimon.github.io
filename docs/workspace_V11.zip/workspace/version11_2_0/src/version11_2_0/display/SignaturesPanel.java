package version11_2_0.display;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import version11_2_0.spaceMemory.EnvironmentContext;
import version11_2_0.platform.Agent;

/**
 * Frame to display signatures of interactions
 * @author simon gay
 */

/* - inherited from EnvPanel :
 *   Agent agent      : pointer to the agent
 */
public class SignaturesPanel extends EnvPanel implements MouseListener{

	private static final long serialVersionUID = 1L;
	
	private int clic_x=0;
	private int clic_y=0;
	
	private int selected_interaction=-1;
	
	private boolean threshold_1=false;
	
	private int pixel=5;
	
	private int size2=EnvironmentContext.size2;
	
	public SignaturesPanel(Agent a){
		super(a);
		addMouseListener(this);
	}
	
	public void setAgent(Agent a){
		agent=a;
	}
	
	public void paintComponent(Graphics g){
		g.setColor(Color.white);
		
		g.fillRect(0, 0, this.getWidth(), this.getHeight());
		
		
		
		// draw enacted interaction
		g.setColor(Color.black);
		g.fillRect(10, 14, 660, 6);
		for (int i=0;i<11;i++){
			for (int j=0;j<11;j++){
				if ((i+j)%2==0) g.setColor(Color.darkGray);
				else g.setColor(Color.gray);
				g.fillRect(10+60*j , 20+60*i , 60, 60);
			}
		}

				
		for (int i=0;i<111*110;i++){
			if (agent.environmentContext.interactionList[i]!=null && agent.environmentContext.interactionList[i].getNbVar()>0){

				if (agent.environmentContext.interactionList[i].signature.delta_f==2 || agent.environmentContext.interactionList[i].signature.delta_s==2)
					g.setColor(Color.LIGHT_GRAY);
				
				else{
					float val=Math.max(agent.environmentContext.interactionList[i].signature.delta_f, agent.environmentContext.interactionList[i].signature.delta_s)/2;
					if (agent.environmentContext.interactionList[i].signature.delta_f>0.8 || agent.environmentContext.interactionList[i].signature.delta_s>0.8)
						g.setColor(new Color(val, 1-val,1));
					else{
						g.setColor(new Color(val, 1-val,0));
					}
				}
				int x1=i%110;
				int y1=i/110;
				g.fillOval(10+6*x1, 15+6*y1, 6, 6);
			}
		}
		
		int x=-1;
		int y=-1;
				
		
		
		for (int i=0;i<12210;i++){
			int x1=i%110;
			int y1=i/110;
			
			if (i==selected_interaction){
				
				g.setColor(Color.green);
	
				
				if (agent.environmentContext.interactionList[i]!=null && agent.environmentContext.interactionList[i].getNbVar()>0){
					g.fillOval(10+6*x1+2, 20+6*y1-3, 2, 2);
					
					if (agent.environmentContext.interactionList[i].getNbVar()>1){
						for (int j=0;j<12;j++){
							
							if (agent.environmentContext.interactionList[i].variations(j)!=null){
							
								int x2=agent.environmentContext.interactionList[i].variations(j).successor%110;
								int y2=agent.environmentContext.interactionList[i].variations(j).successor/110;
								g.drawLine(10+6*x1+3, 20+6*y1-3, 10+6*x2+3, 20+6*y2-3);
							}
						}
					}
				}
			}
		}
		
		g.setColor(Color.red);
		for (int t=10;t>0;t--){
			int x1=agent.environmentContext.timeline[t]%110;
			int y1=agent.environmentContext.timeline[t]/110;
			int x2=agent.environmentContext.timeline[t-1]%110;
			int y2=agent.environmentContext.timeline[t-1]/110;
			g.drawLine(10+6*x1+3, 20+6*y1-3, 10+6*x2+3, 20+6*y2-3);
		}
		
		if (agent.environmentContext.id1!=-1 && agent.environmentContext.interactionList[agent.environmentContext.id1].events.size()>0){
			x=(agent.environmentContext.interactionList[agent.environmentContext.id1].events.get(0)[0]-1)*10+agent.environmentContext.interactionList[agent.environmentContext.id1].events.get(0)[1];
			y=-1;
			if (agent.environmentContext.interactionList[agent.environmentContext.id1].getSize()>1){
				y=(agent.environmentContext.interactionList[agent.environmentContext.id1].events.get(1)[0]-1)*10+agent.environmentContext.interactionList[agent.environmentContext.id1].events.get(1)[1];
			}
			
			g.setColor(Color.blue);
			g.fillRect(10+6*x, 20+6*y, 6, 6);
		}
		
		if (selected_interaction!=-1 && agent.environmentContext.interactionList[selected_interaction]!=null){
			g.setColor(Color.black);
			g.drawString(selected_interaction+" = "+agent.environmentContext.interactionList[selected_interaction].name(), 10, 700);

		}
		
		// draw visual context
		for (int i=0;i<EnvironmentContext.size1;i++){
			for (int j=0;j<EnvironmentContext.size2;j++){
				
				g.setColor(new Color(Math.max(0,agent.environmentContext.visual[0][i*size2*3+j*3+2]),
						 Math.max(0,agent.environmentContext.visual[0][i*size2*3+j*3  ]),
						 Math.max(0,agent.environmentContext.visual[0][i*size2*3+j*3+1]) ));

				
				g.fillRect(700+i*pixel,10+(EnvironmentContext.size2-j)*pixel,pixel,pixel);
			}	
		}
		
		// threshold selector
		if (threshold_1) g.setColor(Color.red);
		else g.setColor(Color.black);
		g.fillRect(1100, 350, 20, 20);
		
		// display average delta
		if (selected_interaction!=-1 && agent.environmentContext.interactionList[selected_interaction]!=null){
			
			// distances
			for (int i=0;i<12;i++){
				for (int j=0;j<11;j++){
					if (agent.decision.exploitationMap[i][j]<=0) g.setColor(Color.gray);
					else{
						float val=agent.environmentContext.interactionList[selected_interaction].blurPattern.variations[i][j]-agent.environmentContext.interactionList[selected_interaction].blurPattern.distance;
						val=Math.max(-10, Math.min(10, val))/10;
						g.setColor(new Color( 1-(val/2+0.5f), val/2+0.5f, 0) );
					}
					g.fillRect(700+21*i, 650-21*j, 20, 20);
				}
			}
			
			g.setColor(Color.black);
			for (int i=0;i<12;i++){
				if (agent.decision.exploitationMap[i][0]>0){
				g.drawString(""+agent.environmentContext.interactionList[selected_interaction].blurPattern.variations[i][0], 980, 500+15*i);
				}
				else g.drawString("--------------", 980, 500+15*i);
			}
		}
		
		

		
		// draw signatures
		if (selected_interaction!=-1 && agent.environmentContext.interactionList[selected_interaction]!=null){
			
			// draw signature of the selected interaction
			float max=0.1f;
			if (max>=0.1) max=agent.environmentContext.interactionList[selected_interaction].signature.maxPattern1;
			
			g.setColor(Color.black);
			g.drawString(""+max, 700,315);
			
			for (int j=EnvironmentContext.size2-1;j>=0;j--){
				for (int i=0;i<EnvironmentContext.size1;i++){
					
					if (!threshold_1){
						g.setColor(new Color(Math.max(0, Math.min(1,agent.environmentContext.interactionList[selected_interaction].signature.signature[i*size2*3+j*3+2]/max/2+0.5f)),
											 Math.max(0, Math.min(1,agent.environmentContext.interactionList[selected_interaction].signature.signature[i*size2*3+j*3  ]/max/2+0.5f)),
											 Math.max(0, Math.min(1,agent.environmentContext.interactionList[selected_interaction].signature.signature[i*size2*3+j*3+1]/max/2+0.5f)) ));
					}
					else{
						float red=0.5f;
						float green=0.5f;
						float blue=0.5f;
						float bias=agent.environmentContext.interactionList[selected_interaction].signature.getBias();
						
						if (agent.environmentContext.interactionList[selected_interaction].signature.signature[i*size2*3+j*3+2]*bias<0
						&&  Math.abs(agent.environmentContext.interactionList[selected_interaction].signature.signature[i*size2*3+j*3+2])>0.5*agent.environmentContext.interactionList[selected_interaction].signature.maxPattern1){
							red=Math.max(0, Math.min(1,agent.environmentContext.interactionList[selected_interaction].signature.signature[i*size2*3+j*3+2]/max/2+0.5f));
						}
						if (agent.environmentContext.interactionList[selected_interaction].signature.signature[i*size2*3+j*3  ]*bias<0
						&&  Math.abs(agent.environmentContext.interactionList[selected_interaction].signature.signature[i*size2*3+j*3  ])>0.5*agent.environmentContext.interactionList[selected_interaction].signature.maxPattern1){
							green=Math.max(0, Math.min(1,agent.environmentContext.interactionList[selected_interaction].signature.signature[i*size2*3+j*3  ]/max/2+0.5f));
						}
						if (agent.environmentContext.interactionList[selected_interaction].signature.signature[i*size2*3+j*3+1]*bias<0
						&&  Math.abs(agent.environmentContext.interactionList[selected_interaction].signature.signature[i*size2*3+j*3+1])>0.5*agent.environmentContext.interactionList[selected_interaction].signature.maxPattern1){
							blue=Math.max(0, Math.min(1,agent.environmentContext.interactionList[selected_interaction].signature.signature[i*size2*3+j*3+1]/max/2+0.5f));
						}
						g.setColor(new Color(red,green,blue));
					}
					
					g.fillRect(1220+i*pixel, 10+(EnvironmentContext.size2-j)*pixel, pixel, pixel);
				}
			}
			// draw bias
			int length=EnvironmentContext.size2*EnvironmentContext.size1*3;
			g.setColor(new Color(Math.max(0, Math.min(1,1-(agent.environmentContext.interactionList[selected_interaction].signature.signature[length]/3/2+0.5f))),
								 Math.max(0, Math.min(1,   agent.environmentContext.interactionList[selected_interaction].signature.signature[length]/3/2+0.5f)),0));
			
			g.fillOval(1200, 10+pixel, pixel, pixel);
			
			
			// write global distance
			g.setColor(Color.black);
			g.drawString("distance : "+agent.environmentContext.interactionList[selected_interaction].blurPattern.distance, 700,400);
		}
	}
	
	
	
	///////////////////////////////////////////////////////////////////////////
	public void mouseClicked(MouseEvent e) {

		clic_x=e.getX();
		clic_y=e.getY();
		
		for (int i=0;i<110;i++){
			for (int j=0;j<111;j++){
				if (clic_x>=10+i*6 && clic_x<16+i*6 && clic_y>=15+j*6 && clic_y<21+j*6){
					selected_interaction=j*110+i;
					System.out.println("selected : "+selected_interaction);
				}
			}
		}
		if (selected_interaction>=0 && agent.environmentContext.interactionList[selected_interaction]==null) selected_interaction=-1;
		
		if (clic_x>=1100 && clic_x<=1120 && clic_y>=350 && clic_y<=370) threshold_1=!threshold_1;
	}

	@Override
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {}
	public void mouseReleased(MouseEvent e) {}

}

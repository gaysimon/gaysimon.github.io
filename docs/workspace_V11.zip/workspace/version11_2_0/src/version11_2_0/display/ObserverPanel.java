package version11_2_0.display;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import version11_2_0.platform.Agent;
import version11_2_0.spaceMemory.EnvironmentContext;

/**
 * Frame to display signatures of interactions
 * @author simon gay
 */

/* - inherited from EnvPanel :
 *   Agent agent      : pointer to the agent
 */
public class ObserverPanel extends EnvPanel implements MouseListener{

	private static final long serialVersionUID = 1L;
	
	private int clic_x=0;
	private int clic_y=0;
	
	public ObserverPanel(Agent a){
		super(a);
		addMouseListener(this);
	}
	
	public void setAgent(Agent a){
		agent=a;
	}
	
	public void paintComponent(Graphics g){
		g.setColor(Color.white);
		
		g.fillRect(0, 0, 1600, 900);
	
		for (int i=0;i<1000;i++){
			if (agent.observer.decisionType[i]==0) g.setColor(Color.gray);
			else if (agent.observer.decisionType[i]==1) g.setColor(Color.red);
			else if (agent.observer.decisionType[i]==2) g.setColor(Color.blue);
			else if (agent.observer.decisionType[i]==3) g.setColor(Color.green);
			else if (agent.observer.decisionType[i]==4) g.setColor(Color.yellow);
			
			g.drawLine(5+i, 700, 5+i, 720);
		}
		
		g.setColor(Color.blue);
		for (int i=1;i<1000;i++){
			g.drawLine(i+5, 680-(int)(agent.observer.decisionValues[0][i-1]*200), i+6, 680-(int)(agent.observer.decisionValues[0][i]*200));
		}
		g.setColor(Color.green);
		for (int i=1;i<1000;i++){
			g.drawLine(i+5, 680-(int)(agent.observer.decisionValues[1][i-1]*200), i+6, 680-(int)(agent.observer.decisionValues[1][i]*200));
		}

		g.setColor(Color.magenta);
		for (int i=1;i<1000;i++){
			g.drawLine(i+5, 680-(int)(agent.observer.exploitation[i-1]*500), i+6, 680-(int)(agent.observer.exploitation[i]*500));
		}
		
	}
	
	
	
	///////////////////////////////////////////////////////////////////////////
	public void mouseClicked(MouseEvent e) {

		clic_x=e.getX();
		clic_y=e.getY();
		
		
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {}
	public void mouseReleased(MouseEvent e) {}

}

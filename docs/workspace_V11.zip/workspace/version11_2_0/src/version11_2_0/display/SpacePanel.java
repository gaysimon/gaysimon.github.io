package version11_2_0.display;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import version11_2_0.platform.Agent;
import version11_2_0.spaceMemory.EnvironmentContext;

/**
 * Frame to display signatures of interactions
 * @author simon gay
 */

/* - inherited from EnvPanel :
 *   Agent agent      : pointer to the agent
 */
public class SpacePanel extends EnvPanel implements MouseListener{

	private static final long serialVersionUID = 1L;
	
	private int clic_x=0;
	private int clic_y=0;
	
	private int var=0;
	private int dist=0;
	
	public SpacePanel(Agent a){
		super(a);
		addMouseListener(this);
	}
	
	public void setAgent(Agent a){
		agent=a;
	}
	
	public void paintComponent(Graphics g){
		g.setColor(Color.white);
		
		g.fillRect(0, 0, this.getWidth(), this.getHeight());
		
		// possible actions map
		for (int i=0;i<12;i++){
			for (int j=0;j<11;j++){
				if (agent.decision.actionMap[i][j]>1) g.setColor(Color.gray);
				else g.setColor(new Color( 1-agent.decision.actionMap[i][j], 0, 0) );

				g.fillRect(15+21*i, 230-21*j, 20, 20);
			}
		}
		
		// possible actions map
		for (int i=0;i<12;i++){
			for (int j=0;j<11;j++){
				if (agent.decision.exploitationMap[i][j]<=0) g.setColor(Color.gray);
				else g.setColor(new Color( 0, ((  agent.decision.exploitationMap[i][j])), 0) );

				g.fillRect(15+21*i, 500-21*j, 20, 20);
				
				if (i==var && j==dist){
					g.setColor(Color.red);
					g.drawRect(14+21*i, 499-21*j, 21, 21);
				}
			}
		}
		
		// utility map
		float max=1;
		for (int i=0;i<12;i++){
			for (int j=0;j<11;j++){
				if (Math.abs(agent.spaceMemory.utilityMap[i][j])>max) max=Math.abs(agent.spaceMemory.utilityMap[i][j]);
			}
		}
		for (int i=0;i<12;i++){
			for (int j=0;j<11;j++){
				if (agent.decision.exploitationMap[i][j]<=0) g.setColor(Color.gray);
				else g.setColor(new Color( 1-((agent.spaceMemory.utilityMap[i][j]/max)+1)/2, agent.spaceMemory.utilityMap[i][j]/max/2+0.5f, 0) );

				g.fillRect(15+21*i, 750-21*j, 20, 20);
			}
		}
		
		// space memory
		for (int i=0;i<EnvironmentContext.size1;i++){
			for (int j=0;j<EnvironmentContext.size2*2;j++){
				g.setColor(new Color(agent.spaceMemory.spaceMemory[i][j][2], agent.spaceMemory.spaceMemory[i][j][0], agent.spaceMemory.spaceMemory[i][j][1]));
				g.fillRect(350+3*i, 50+320-3*j, 3, 3);
			}
		}
		g.setColor(Color.black);
		for (int i=0;i<agent.spaceMemory.buff_x2.size();i++){
			g.drawString(""+agent.spaceMemory.buff_x2.get(i), 350, 400+20*i);
			g.drawString(""+agent.spaceMemory.buff_y2.get(i), 450, 400+20*i);
			g.drawString(""+agent.spaceMemory.buff_t2.get(i), 550, 400+20*i);
		}
		
		// temp space memory
		for (int i=0;i<EnvironmentContext.size1;i++){
			for (int j=0;j<EnvironmentContext.size2*2;j++){
				g.setColor(new Color(agent.spaceMemory.spaceMemory_temp[i][j][2],
						             agent.spaceMemory.spaceMemory_temp[i][j][0],
						             agent.spaceMemory.spaceMemory_temp[i][j][1]));
				g.fillRect(680+3*i, 50+320-3*j, 3, 3);
			}
		}
		g.setColor(Color.red);
		g.setColor(Color.black);
		for (int i=0;i<agent.spaceMemory.buff_x.size();i++){
			g.drawString(""+agent.spaceMemory.buff_x.get(i), 680, 400+20*i);
			g.drawString(""+agent.spaceMemory.buff_y.get(i), 780, 400+20*i);
			g.drawString(""+agent.spaceMemory.buff_t.get(i), 880, 400+20*i);
		}
		
		// predicted space memory
		for (int i=0;i<EnvironmentContext.size1;i++){
			for (int j=0;j<EnvironmentContext.size2*2;j++){
				g.setColor(new Color(agent.spaceMemory.predictedMemories[var][dist][i][j][2],
						             agent.spaceMemory.predictedMemories[var][dist][i][j][0],
						             agent.spaceMemory.predictedMemories[var][dist][i][j][1]));
				g.fillRect(1010+3*i, 50+320-3*j, 3, 3);
			}
		}
	}
	
	
	
	///////////////////////////////////////////////////////////////////////////
	public void mouseClicked(MouseEvent e) {

		clic_x=e.getX();
		clic_y=e.getY();
		
		// possible actions map
		for (int i=0;i<12;i++){
			for (int j=0;j<11;j++){
				if (clic_x>=15+21*i && clic_x<=35+21*i && clic_y>=500-21*j && clic_y<=520-21*j){
					var=i;
					dist=j;
				}
			}
		}
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {}
	public void mouseReleased(MouseEvent e) {}

}

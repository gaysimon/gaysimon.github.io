package version11_2_0.display;

import version11_2_0.platform.Agent;

/**
 * Frame to display signatures of interactions
 * @author simon
 */

/* - inherited from EnvFrame :
 *   Agent agent      : pointer to the agent
 *   EnvPanel panel   : panel of this frame
 *   
 * - inherited from PrintableFrame :
 *   boolean printable   : define if the frame can be printed
 *   int indexImage      : counter for image name
 */
public class ContextFrame extends EnvFrame{

	private static final long serialVersionUID = 1L;

	public ContextFrame(Agent a){
		super(a);
		this.setTitle("Context");
    	this.setSize(1500, 800);
    	this.setLocationRelativeTo(null);               
    	this.setVisible(true);
    	this.setFocusable(true);
    	panel=new ContextPanel(a);
    	this.setContentPane(panel);
	}
}


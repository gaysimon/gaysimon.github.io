package version11_2_0.platform;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import version11_2_0.Main;

/**
 * An interface for users
 * @author olivier georgeon, simon gay
 */
public class UserInterfaceFrame extends JFrame implements  ActionListener{

	private static final long serialVersionUID = 1L;

	private Main main;
	
	private final JLabel m_statusBar = new JLabel();
	private JButton m_save = new JButton("Save");
	private JButton m_run = new JButton("Play");
	private JButton m_stop = new JButton("Pause");
	private JButton m_reset = new JButton("Reset");
	
	private JButton m_clear = new JButton("Clear");
	
	private JButton m_arun = new JButton("Play agent");
	private JButton m_astop = new JButton("Pause Agent");
	
	
	public UserInterfaceFrame(Main m){
		
		main=m;
		
		this.setTitle("Interface");
    	this.setSize(900, 70);
    	this.setLocationRelativeTo(null);               
    	this.setVisible(true);
    	
		JPanel buttonPanel = new JPanel();
		
		buttonPanel.add(m_save);
		
		buttonPanel.add(m_arun);
		buttonPanel.add(m_astop);

		buttonPanel.add(m_reset);
		buttonPanel.add(m_clear);
		buttonPanel.add(m_run);
		buttonPanel.add(m_stop);
		
		setEnableButton();
		m_save.addActionListener(this);
		m_stop.addActionListener(this);
		m_run.addActionListener(this);
		m_reset.addActionListener(this);
		
		m_clear.addActionListener(this);
		
		m_astop.addActionListener(this);
		m_arun.addActionListener(this);
		
		JPanel statusPanel = new JPanel(new BorderLayout());
		statusPanel.add(m_statusBar, BorderLayout.CENTER);
		statusPanel.add(buttonPanel, BorderLayout.EAST);
		statusPanel.setBorder(BorderFactory.createRaisedBevelBorder());
		getContentPane().add(statusPanel, BorderLayout.SOUTH);


		//m_statusModel.pushPermStatus("Ready.");
		m_statusBar.setText("Ready.");
		m_statusBar.setPreferredSize(new Dimension(200, m_statusBar.getHeight()));
		
		addWindowListener(new java.awt.event.WindowAdapter() {
		    public void windowClosing(WindowEvent winEvt) {
		        main.stop();
		        System.exit(0); 
		    }
		});
		
	}

	public void actionPerformed(ActionEvent e) {

		// Run agents ******
		if (e.getSource() == m_run){
			for (int i=0;i<main.nbAgent();i++){
				main.selectAgent(i).action.start();
			}
		}
		
		// Stops agents *****
		else if (e.getSource() == m_stop){
			for (int i=0;i<main.nbAgent();i++){
				main.selectAgent(i).action.stop();
			}
		}
		
		// save agent *****
		if (e.getSource() == m_save){
			main.selectAgent(main.getAgentIndex()).save();
		}
		
		// Run selected agent ******
		if (e.getSource() == m_arun){
			main.selectAgent(main.getAgentIndex()).action.start();
		}
		
		// Stop selected agent *****
		else if (e.getSource() == m_astop){
			main.selectAgent(main.getAgentIndex()).action.stop();
		}
		
		// Reset the board ******
		else if (e.getSource() == m_reset){
			//%%%%%%%%%%%%%%%%% specific to simulators %%%%%%%%%%%%%%%%%%%%%%%
			try{ 
				main.resetList();
				main.env.setIndex(0);
				main.env.init(main.env.getBoardFileName());
				if (main.nbAgent()>0){
					main.selectAgent(0).setDisplay();
				}
			}
			catch (Exception ex){
				JOptionPane.showMessageDialog(this, 
					"Error while initializing the board! (Check picture file and board file)\n" + 
					e.getClass().toString() + ": " + ex.getMessage(),
					"Error!", 
					JOptionPane.ERROR_MESSAGE);
			}
			//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		}
		
		// clear agent trace
		else if (e.getSource() == m_clear){
			main.selectAgent(main.getAgentIndex()).observer.clearTrace();
		}

		setEnableButton();
		
	}
	
	// enable or disable buttons
	public void setEnableButton(){
		m_stop.setEnabled(!main.isStopped());
		m_run.setEnabled(!main.isStarted());
		m_reset.setEnabled(true);
		
		m_arun.setEnabled(main.isStopped(main.getAgentIndex()));
		m_astop.setEnabled(main.isStarted(main.getAgentIndex()));
	}
}

package version11_2_0.spaceMemory;

public class Place {
	
	public int interaction;
	public short delay;
	public short distance;
		
	public Place (int inter, short t, short d){
		interaction=inter;
		delay=t;
		distance=d;
	}
	
	public String name(EnvironmentContext env){
		return "{"+env.interactionList[interaction].name()+"; "+delay+"; "+distance+"}";
	}

}

package version11_2_0.spaceMemory;

import java.util.ArrayList;

public class PredictionNode {

	public int id;
	public String inter;
	public float prediction;
	public int level;
	
	public float[] context=null;
	
	public ArrayList<PredictionNode> nexts;
	public PredictionNode parent;
	
	public PredictionNode(int ident, float p, int l, PredictionNode par, EnvironmentContext env){
		id=ident;
		inter=env.interactionList[id].name();
		prediction=p;
		level=l;
		
		nexts=new ArrayList<PredictionNode>();
		parent=par;
		
		if (level==0){
			int t=env.interactionList[id].length;
			context=new float[EnvironmentContext.length];
			for (int i=0;i<EnvironmentContext.length;i++){
				context[i]=env.visual[t][i];
			}
		}
		else{
			if (env.interactionList[id].isChange()){
				context=new float[EnvironmentContext.length];
			}
		}
		
		if (level<15 && env.interactionList[id].signature.signature[EnvironmentContext.length]>=0){
		
			for (int i=0;i<12;i++){
				if (env.interactionList[id].variations(i)!=null && env.interactionList[id].variations(i).successor!=0 
				 //&& env.interactionList[env.interactionList[id].variations(i).successor].length-1-level>=0
				 ){
					
					float prediction=0;
					
					if (env.interactionList[env.interactionList[id].variations(i).successor].signature.learned){
						//prediction=env.interactionList[env.interactionList[id].variations(i).successor].prediction(env.visual[env.interactionList[id].length-1-level], false);
						prediction=env.interactionList[env.interactionList[id].variations(i).successor].prediction(this.getImage(), false);
					}
					else prediction=1;
					
					//System.out.println("### "+i+"; "+prediction);
					
					if (prediction>0.1){
						nexts.add(new PredictionNode(env.interactionList[id].variations(i).successor,prediction,level+1, this,env));
					}
					
				}
			}
		}
	}
	
	public float[] getImage(){
		if (context!=null) return context;
		else return parent.getImage();
	}
	
	/*public void print(){
		
		if (level!=0) System.out.print("   |---");
		for (int l=0;l<level;l++){
			System.out.print("-----");
		}
		System.out.println(inter+" ("+id+"; "+prediction+")");
		
		for (int n=0;n<nexts.size();n++){
			nexts.get(n).print();
		}
	}*/
}

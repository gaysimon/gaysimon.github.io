package version11_2_0.spaceMemory;


public class BlurPattern {

	public static float objectCoef = 0.05f;     	// influence of objects according to their distances
	
	private boolean learned;
	private short counter;
	
	public float[][][] pattern;
	
	public float distance;
	
	public float[][] variations;
	
	public BlurPattern(){
		pattern=new float[EnvironmentContext.size1][EnvironmentContext.size2*2][3];
		
		variations=new float[12][11];
		
		learned=false;
		counter=0;
	}
	
	public void generate(SignatureComponent signature){
		
		if (counter==5){
			
			// reset blur pattern
			for (int i=0;i<EnvironmentContext.size1;i++){
				for (int j=0;j<EnvironmentContext.size2*2;j++){
					for (int k=0;k<3;k++){
						pattern[i][j][k]=0;
					}
				}
			}
			
			for (int i=0;i<EnvironmentContext.size1;i++){
				for (int j=0;j<EnvironmentContext.size2;j++){
					for (int k=0;k<3;k++){
						
						if (Math.abs(signature.signature[i*EnvironmentContext.size2*3 + j*3 + k])>signature.maxPattern1*0.5){
	
							// set blur pattern
							for (int i2=-100;i2<=100;i2++){
								for (int j2=-100;j2<=100;j2++){
									if (i+i2>=0 && i+i2<EnvironmentContext.size1 && j+j2+EnvironmentContext.size2>=0 && j+j2+EnvironmentContext.size2<EnvironmentContext.size2*2){
										
										float d=(float) Math.sqrt(i2*i2+j2*j2);
										
										if (d<100){
											pattern[i+i2][j+j2+EnvironmentContext.size2][k]+= signature.signature[i*EnvironmentContext.size2*3 + j*3 + k] * Math.exp(-objectCoef*d);
										}
									}
								}
							}
						}
					}
				}
			}
			
			learned=true;
			counter=0;
		}
		else counter++;
	}
	
	public void computeCurrentDistance(float[][][] memory, float[][] actionMap, float[][][][][] predictedMems){
		
		if (learned){
		
			distance=0;
			
			for (int i=0;i<EnvironmentContext.size1;i++){
				for (int j=0;j<EnvironmentContext.size2*2;j++){
					for (int k=0;k<3;k++){
						if (memory[i][j][k]!=0) distance+=pattern[i][j][k]*memory[i][j][k];
					}
				}
			}
			
			for (int d=0;d<11;d++){
				for (int v=0;v<12;v++){
					
					variations[v][d]=0;
					
					if (actionMap[v][d]>0){
						
						for (int i=0;i<EnvironmentContext.size1;i++){
							for (int j=0;j<EnvironmentContext.size2*2;j++){
								for (int k=0;k<3;k++){
									if (predictedMems[v][d][i][j][k]!=0) variations[v][d]+=pattern[i][j][k]*predictedMems[v][d][i][j][k];
								}
							}
						}
						variations[v][d]-=distance;
					}
					
				}
			}
		}
	}
	
}

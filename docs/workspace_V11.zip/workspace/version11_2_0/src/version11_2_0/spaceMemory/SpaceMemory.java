package version11_2_0.spaceMemory;


import java.util.ArrayList;

import version11_2_0.platform.Agent;
import version11_2_0.Interface.ContinuousInteraction;

public class SpaceMemory {

	public Agent agent;
	
	public ArrayList<Float> buff_x;
	public ArrayList<Float> buff_y;
	public ArrayList<Float> buff_t;
	
	public ArrayList<Float> buff_x2;
	public ArrayList<Float> buff_y2;
	public ArrayList<Float> buff_t2;
	
	public float[][][] spaceMemory;
	public float[][][] spaceMemory_temp;
	
	public float[][][][][] predictedMemories;
	
	public float utilityMap[][];
	
	public float[] values;
	
	public SpaceMemory(Agent a){
		
		agent=a;
		
		buff_x=new ArrayList<Float>();
		buff_y=new ArrayList<Float>();
		buff_t=new ArrayList<Float>();
		
		buff_x2=new ArrayList<Float>();
		buff_y2=new ArrayList<Float>();
		buff_t2=new ArrayList<Float>();
		
		spaceMemory=new float[EnvironmentContext.size1][EnvironmentContext.size2*2][3];
		spaceMemory_temp=new float[EnvironmentContext.size1][EnvironmentContext.size2*2][3];
		
		predictedMemories=new float[12][11][EnvironmentContext.size1][EnvironmentContext.size2*2][3];
		
		utilityMap=new float[12][11];
		
		values=new float[12];
	}
	
	public void updateMemory(float[] visual, boolean valide){
		
		// add movement in buffer
		buff_x.add(agent.body.last_vx);
		buff_y.add(agent.body.last_vy);
		buff_t.add(agent.body.last_vt);
		
		// move elements in memory
		for (int i=0;i<EnvironmentContext.size1;i++){
			for (int j=0;j<EnvironmentContext.size2*2;j++){
				for (int c=0;c<3;c++){
					spaceMemory_temp[i][j][c]=0;
				}
			}
		}
		for (int i=0;i<EnvironmentContext.size1;i++){
			for (int j=0;j<EnvironmentContext.size2*2;j++){
				for (int c=0;c<3;c++){
					
					if (spaceMemory[i][j][c]>0){
						// position relative to the agent
						float x=i-EnvironmentContext.size1/2;
						float y=j-EnvironmentContext.size2;
						
						for (int m=0;m<buff_x.size();m++){
							x-=buff_x.get(m)*6;
							y-=buff_y.get(m)*6;
							
							double x2= x*Math.cos(-buff_t.get(m)) - y*Math.sin(-buff_t.get(m));
							double y2= x*Math.sin(-buff_t.get(m)) + y*Math.cos(-buff_t.get(m));
							
							x=(float)x2;
							y=(float)y2;
						}
						
						if (Math.round(x)+EnvironmentContext.size1/2>=0 && Math.round(x)+EnvironmentContext.size1/2<EnvironmentContext.size1
						 && Math.round(y)+EnvironmentContext.size2  >=0 && Math.round(y)+EnvironmentContext.size2  <EnvironmentContext.size1){
							
							spaceMemory_temp[Math.round(x)+EnvironmentContext.size1/2][Math.round(y)+EnvironmentContext.size2][c]=spaceMemory[i][j][c];
						}
					}
				}
			}
		}
		
		// remove prey when eaten
		if (agent.body.sensors[5]==1){
			for (int i2=-10;i2<=10;i2++){
				for (int j2=-10;j2<=10;j2++){
					spaceMemory_temp[EnvironmentContext.size1/2+i2][EnvironmentContext.size2+j2][1]=0;
				}
			}
		}
		
		
		if (valide){
			
			buff_x2.clear();
			buff_y2.clear();
			buff_t2.clear();
			for (int i=0;i<buff_x.size();i++){
				buff_x2.add(buff_x.get(i));
				buff_y2.add(buff_y.get(i));
				buff_t2.add(buff_t.get(i));
			}
			
			// copy elements from temp memory
			for (int i=0;i<EnvironmentContext.size1;i++){
				for (int j=0;j<EnvironmentContext.size2*2;j++){
					for (int c=0;c<3;c++){
						spaceMemory_temp[i][j][c]=0.95f*spaceMemory_temp[i][j][c];
						if (spaceMemory_temp[i][j][c]<0.1) spaceMemory_temp[i][j][c]=0;
						
						spaceMemory[i][j][c]=spaceMemory_temp[i][j][c];
					}
				}
			}
			
			// add new elements
			for (int i=0;i<EnvironmentContext.length;i++){
				
				if (visual[i]>0){
					
					int c=i%3;
					int pos=i/3;
					
					int x=pos/EnvironmentContext.size2;
					int y=pos%EnvironmentContext.size2+EnvironmentContext.size2;

					spaceMemory[x][y][c]=1;
					spaceMemory_temp[x][y][c]=1;
				}
			}
			
			buff_x.clear();
			buff_y.clear();
			buff_t.clear();
			
			// clean memory
			for (int i=0;i<EnvironmentContext.size1;i++){
				for (int j=0;j<EnvironmentContext.size2*2;j++){
					for (int c=0;c<3;c++){
						
						for (int i2=-2;i2<=2;i2++){
							for (int j2=-2;j2<=2;j2++){
								if ((i2!=0 || j2!=0) && i+i2>=0 && i+i2<EnvironmentContext.size1 && j+j2>=0 && j+j2<EnvironmentContext.size2*2){
									if (spaceMemory[i][j][c]>spaceMemory[i+i2][j+j2][c]){
										spaceMemory[i+i2][j+j2][c]=0;
										spaceMemory_temp[i+i2][j+j2][c]=0;
									}
								}
							}
						}
					}
				}
			}
		}
	}
	
	
	public void predictMemories(float[][] actionMap){
		
		float vx=agent.body.getvx();
		float vy=agent.body.getvy();
		float rz=agent.body.getvz();
		
		System.out.println(vx+" ; "+vy+" ; "+rz);
		
		ArrayList<Float> vx_buff=new ArrayList<Float>();
		ArrayList<Float> vy_buff=new ArrayList<Float>();
		ArrayList<Float> rz_buff=new ArrayList<Float>();
		
		int d=0;
		boolean end=false;
		
		while (!end && d<11){
		
			// >
			if (actionMap[1][d]>0){
				vx_buff.add(Math.max(vx,0));
				vy_buff.add(Math.max(vx,0.5f));
				rz_buff.add(rz);
			
				// generate map
				predictMemory(predictedMemories[1][d],vx_buff,vy_buff,rz_buff);
				
				vx_buff.remove(d);
				vy_buff.remove(d);
				rz_buff.remove(d);
			}
			else{
				for (int i=0;i<EnvironmentContext.size1;i++){
					for (int j=0;j<EnvironmentContext.size2*2;j++){
						for (int c=0;c<3;c++){
							predictedMemories[1][d][i][j][c]=0;
						}
					}
				}
			}

			// ^
			if (actionMap[2][d]>0){
				vx_buff.add(vx);
				vy_buff.add(vy);
				float rz2=rz+0.2f*(float)Math.PI/2;
				rz_buff.add((float)Math.max(-Math.PI/10, Math.min(Math.PI/10, rz2)));
			
				// generate map
				predictMemory(predictedMemories[2][d],vx_buff,vy_buff,rz_buff);
				
				vx_buff.remove(d);
				vy_buff.remove(d);
				rz_buff.remove(d);
			
			}
			else{
				for (int i=0;i<EnvironmentContext.size1;i++){
					for (int j=0;j<EnvironmentContext.size2*2;j++){
						for (int c=0;c<3;c++){
							predictedMemories[2][d][i][j][c]=0;
						}
					}
				}
			}
		
			// v
			if (actionMap[3][d]>0){
				vx_buff.add(vx);
				vy_buff.add(vy);
				float rz2=rz-0.2f*(float)Math.PI/2;
				rz_buff.add((float)Math.max(-Math.PI/10, Math.min(Math.PI/10, rz2)));
			
				// generate map
				predictMemory(predictedMemories[3][d],vx_buff,vy_buff,rz_buff);
				
				vx_buff.remove(d);
				vy_buff.remove(d);
				rz_buff.remove(d);
			
			}
			else{
				for (int i=0;i<EnvironmentContext.size1;i++){
					for (int j=0;j<EnvironmentContext.size2*2;j++){
						for (int c=0;c<3;c++){
							predictedMemories[3][d][i][j][c]=0;
						}
					}
				}
			}
			
			// X
			if (actionMap[4][d]>0){
				vx_buff.add(0f);
				vy_buff.add(0f);
				rz_buff.add(rz);
			
				// generate map
				predictMemory(predictedMemories[4][d],vx_buff,vy_buff,rz_buff);
				
				vx_buff.remove(d);
				vy_buff.remove(d);
				rz_buff.remove(d);
			}
			else{
				for (int i=0;i<EnvironmentContext.size1;i++){
					for (int j=0;j<EnvironmentContext.size2*2;j++){
						for (int c=0;c<3;c++){
							predictedMemories[4][d][i][j][c]=0;
						}
					}
				}
			}
			
			// F
			if (actionMap[5][d]>0){	
				vx_buff.add(vx);
				vy_buff.add(vx);
				rz_buff.add(rz);
			
				// generate map
				predictMemory(predictedMemories[5][d],vx_buff,vy_buff,rz_buff);
				
				vx_buff.remove(d);
				vy_buff.remove(d);
				rz_buff.remove(d);	
			}
			else{
				for (int i=0;i<EnvironmentContext.size1;i++){
					for (int j=0;j<EnvironmentContext.size2*2;j++){
						for (int c=0;c<3;c++){
							predictedMemories[5][d][i][j][c]=0;
						}
					}
				}
			}
			
			// >X
			if (actionMap[6][d]>0){
				vx_buff.add(0f);
				vy_buff.add(0f);
				rz_buff.add(rz);
			
				// generate map
				predictMemory(predictedMemories[6][d],vx_buff,vy_buff,rz_buff);
				
				vx_buff.remove(d);
				vy_buff.remove(d);
				rz_buff.remove(d);
			}
			else{
				for (int i=0;i<EnvironmentContext.size1;i++){
					for (int j=0;j<EnvironmentContext.size2*2;j++){
						for (int c=0;c<3;c++){
							predictedMemories[6][d][i][j][c]=0;
						}
					}
				}
			}
			
			// >F
			if (actionMap[7][d]>0){
				vx_buff.add(Math.max(vx,0));
				vy_buff.add(Math.max(vx,0.5f));
				rz_buff.add(rz);
			
				// generate map
				predictMemory(predictedMemories[7][d],vx_buff,vy_buff,rz_buff);
				
				vx_buff.remove(d);
				vy_buff.remove(d);
				rz_buff.remove(d);
			}
			else{
				for (int i=0;i<EnvironmentContext.size1;i++){
					for (int j=0;j<EnvironmentContext.size2*2;j++){
						for (int c=0;c<3;c++){
							predictedMemories[7][d][i][j][c]=0;
						}
					}
				}
			}
			
			// ^X
			if (actionMap[8][d]>0){
				vx_buff.add(0f);
				vy_buff.add(0f);
				float rz2=rz+0.2f*(float)Math.PI/2;
				rz_buff.add((float)Math.max(-Math.PI/10, Math.min(Math.PI/10, rz2)));
			
				// generate map
				predictMemory(predictedMemories[8][d],vx_buff,vy_buff,rz_buff);
				
				vx_buff.remove(d);
				vy_buff.remove(d);
				rz_buff.remove(d);
			}
			else{
				for (int i=0;i<EnvironmentContext.size1;i++){
					for (int j=0;j<EnvironmentContext.size2*2;j++){
						for (int c=0;c<3;c++){
							predictedMemories[8][d][i][j][c]=0;
						}
					}
				}
			}
			
			// ^F
			if (actionMap[9][d]>0){
				vx_buff.add(vx);
				vy_buff.add(vy);
				float rz2=rz+0.2f*(float)Math.PI/2;
				rz_buff.add((float)Math.max(-Math.PI/10, Math.min(Math.PI/10, rz2)));
			
				// generate map
				predictMemory(predictedMemories[9][d],vx_buff,vy_buff,rz_buff);
				
				vx_buff.remove(d);
				vy_buff.remove(d);
				rz_buff.remove(d);
			}
			else{
				for (int i=0;i<EnvironmentContext.size1;i++){
					for (int j=0;j<EnvironmentContext.size2*2;j++){
						for (int c=0;c<3;c++){
							predictedMemories[9][d][i][j][c]=0;
						}
					}
				}
			}
			
			// vX
			if (actionMap[10][d]>0){
				vx_buff.add(0f);
				vy_buff.add(0f);
				float rz2=rz-0.2f*(float)Math.PI/2;
				rz_buff.add((float)Math.max(-Math.PI/10, Math.min(Math.PI/10, rz2)));
			
				// generate map
				predictMemory(predictedMemories[10][d],vx_buff,vy_buff,rz_buff);
				
				vx_buff.remove(d);
				vy_buff.remove(d);
				rz_buff.remove(d);
			}
			else{
				for (int i=0;i<EnvironmentContext.size1;i++){
					for (int j=0;j<EnvironmentContext.size2*2;j++){
						for (int c=0;c<3;c++){
							predictedMemories[10][d][i][j][c]=0;
						}
					}
				}
			}
			
			// vF
			if (actionMap[11][d]>0){
				vx_buff.add(vx);
				vy_buff.add(vy);
				float rz2=rz-0.2f*(float)Math.PI/2;
				rz_buff.add((float)Math.max(-Math.PI/10, Math.min(Math.PI/10, rz2)));
			
				// generate map
				predictMemory(predictedMemories[11][d],vx_buff,vy_buff,rz_buff);
				
				vx_buff.remove(d);
				vy_buff.remove(d);
				rz_buff.remove(d);
			}
			else{
				for (int i=0;i<EnvironmentContext.size1;i++){
					for (int j=0;j<EnvironmentContext.size2*2;j++){
						for (int c=0;c<3;c++){
							predictedMemories[11][d][i][j][c]=0;
						}
					}
				}
			}
			
			// { }
			if (actionMap[0][d]>0){
				vx_buff.add(vx);
				vy_buff.add(vy);
				rz_buff.add(rz);
				
				// generate map
				predictMemory(predictedMemories[0][d],vx_buff,vy_buff,rz_buff);
			}
			else{
				for (int i=0;i<EnvironmentContext.size1;i++){
					for (int j=0;j<EnvironmentContext.size2*2;j++){
						for (int c=0;c<3;c++){
							predictedMemories[0][d][i][j][c]=0;
						}
					}
				}	
				end=true;
			}
			
			// update speed
			vx=vx-0.02f;
			vy=vy-0.02f;
			if (Math.abs(rz)>0.01){
				if (rz>=0) rz=rz-(float)(0.02*(Math.PI/2));
				else 	   rz=rz+(float)(0.02*(Math.PI/2));
			}
			
			if (vx<=0.01) vx=0;
			if (vy<=0.01) vy=0;
			if (Math.abs(rz)<=0.0314) rz=0;
			
			d++;
		}	
	}
	
	
	
	private void predictMemory(float[][][] mem, ArrayList<Float> buff_vx, ArrayList<Float> buff_vy, ArrayList<Float> buff_rz){
		
		// move elements in memory
		for (int i=0;i<EnvironmentContext.size1;i++){
			for (int j=0;j<EnvironmentContext.size2*2;j++){
				for (int c=0;c<3;c++){
					mem[i][j][c]=0;
				}
			}
		}
		for (int i=0;i<EnvironmentContext.size1;i++){
			for (int j=0;j<EnvironmentContext.size2*2;j++){
				for (int c=0;c<3;c++){
					
					if (spaceMemory_temp[i][j][c]>0){
						// position relative to the agent
						float x=i-EnvironmentContext.size1/2;
						float y=j-EnvironmentContext.size2;
						
						for (int m=0;m<buff_vx.size();m++){
							x-=buff_vx.get(m)*6;
							y-=buff_vy.get(m)*6;
							
							double x2= x*Math.cos(-buff_rz.get(m)) - y*Math.sin(-buff_rz.get(m));
							double y2= x*Math.sin(-buff_rz.get(m)) + y*Math.cos(-buff_rz.get(m));
							
							x=(float)x2;
							y=(float)y2;
						}
						
						if (Math.round(x)+EnvironmentContext.size1/2>=0 && Math.round(x)+EnvironmentContext.size1/2<EnvironmentContext.size1
						 && Math.round(y)+EnvironmentContext.size2  >=0 && Math.round(y)+EnvironmentContext.size2  <EnvironmentContext.size1){
							
							mem[Math.round(x)+EnvironmentContext.size1/2][Math.round(y)+EnvironmentContext.size2][c]=spaceMemory_temp[i][j][c];
						}
					}
				}
			}
		}
	}
	
	
	public void getUtilityMap(float[][] exploitationMap){
		for (int v=0;v<12;v++){
			for (int t=0;t<11;t++){
				
				utilityMap[v][t]=0;
				
				for (int i=0;i<agent.environmentContext.interactionList.length;i++){
					if (agent.environmentContext.interactionList[i]!=null && agent.environmentContext.interactionList[i].isChange()){
						utilityMap[v][t]+=(agent.environmentContext.interactionList[i].blurPattern.variations[v][t]
						                   *ContinuousInteraction.valence(agent.environmentContext.interactionList[i])
						                   )/(t+1);
					}
				}
			}
		}
		
		for (int v=0;v<12;v++){
			if (exploitationMap[v][0]>0){
				values[v]=utilityMap[v][0];
			}
			else values[v]=-10;
		}
		
		if (exploitationMap[0][0]>0){
			for (int v=0;v<12;v++){
				for (int t=1;t<11;t++){
					if (exploitationMap[v][0]>0 && utilityMap[v][t]>values[0]){
						values[0]=utilityMap[v][t];
					}
				}
			}
		}
	}
	
}

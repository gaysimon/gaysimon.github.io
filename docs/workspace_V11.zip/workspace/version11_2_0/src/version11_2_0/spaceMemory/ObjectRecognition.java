package version11_2_0.spaceMemory;

import java.util.ArrayList;

public class ObjectRecognition {

	ArrayList<ArrayList<Short>>[] map;
	
	public ObjectRecognition(Short id, EnvironmentContext env){
		map=new ArrayList[env.interactionList.length];
		for (int i=0;i<env.interactionList.length;i++){
			map[i]=new ArrayList<ArrayList<Short>>();
		}
		
		ArrayList<Short> sequence=new ArrayList<Short>();
		
		for (int v=0;v<12;v++){
			
			if (env.interactionList[id].variations(v)!=null){
				
				Short successor=(short) env.interactionList[id].variations(v).successor;
				
				// add sequence to map
				map[successor].add(sequence);
				
				// if interaction is a "default true", project it
				if (env.interactionList[successor].signature.signature[EnvironmentContext.length]>0){
					ArrayList<Short> sequence_copy=new ArrayList<Short>();
					sequence_copy.add(successor);
					project(successor, sequence_copy, env, 0);
				}
				
			}
		}
		
	}
	
	
	public void project(Short id, ArrayList<Short> sequence, EnvironmentContext env, int level){
		
		for (int v=0;v<12;v++){
			
			if (env.interactionList[id].variations(v)!=null){
				
				Short successor=(short) env.interactionList[id].variations(v).successor;
				
				// add sequence to map
				map[successor].add(sequence);
				
				// if interaction is a "default true", project it
				if (env.interactionList[successor].signature.signature[EnvironmentContext.length]>0 && level<50){
					ArrayList<Short> sequence_copy=new ArrayList<Short>();
					sequence_copy.add(successor);
					project(successor, sequence_copy, env, level+1);
				}
				
			}
		}
		
	}
}

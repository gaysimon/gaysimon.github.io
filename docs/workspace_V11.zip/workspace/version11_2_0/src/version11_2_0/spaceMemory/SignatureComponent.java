package version11_2_0.spaceMemory;

public class SignatureComponent {

	public float[] signature;					// weights of the signature component
	
	public boolean learned;
	
	public float maxPattern1;					// maximum weight (used to normalize values in displayer)
	
	private float prediction=0;
	
	public float delta_s=2;
	public float delta_f=2;
	
	public byte tests=0;
	
	public byte test_s=0;
	public byte test_f=0;
	//public byte test_s2=0;
	//public byte test_f2=0;
	
	public SignatureComponent(){
		signature=new float[EnvironmentContext.length+1];
		learned=false;
		for (int i=0;i<EnvironmentContext.length+1;i++) signature[i]=0;
		maxPattern1=0;
	}
	
	/**
	 * predict the result of an interaction in a given context
	 * @param img : environmental context
	 * @return the certitude of success (1->absolute certitude of success, -1-> absolute certitude of failure 
	 */
	public float prediction(float[] img, boolean write){
		float result=0;
		for (int i=0;i<EnvironmentContext.length;i++){
			result+=signature[i]*img[i];
		}
		//bias
		result+=signature[EnvironmentContext.length];
		
		// activation function
		result= (float) ( 1 / (1+exp(-result)))*2-1;
				
		if (write) prediction=result;
		
		return result;
	}
	
	/**
	 * integrate the result of enaction cycle
	 * @param img : environmental context E_{t-1} 
	 * @param output result of enaction (success->1, failure->-1)
	 */
	public void learn(float[] img, float result){

		float delta=result-prediction;

		if (result>0){
			if (delta_s==2) delta_s=delta;
			else            delta_s=(delta_s*9+delta)/10;
		}
		else{
			if (delta_f==2) delta_f=-delta;
			else            delta_f=(delta_f*9-delta)/10;
		}

		if ( (result>0 && ( tests<1)) || (result<0 && ( tests>-1)) ){	

			maxPattern1=0;
			
			for (int i=0;i<EnvironmentContext.length;i++){
				signature[i]+= 0.05 * delta * img[i];
				if (Math.abs(signature[i])>maxPattern1) maxPattern1=Math.abs(signature[i]);
			}
			// bias
			signature[EnvironmentContext.length]+= 0.05 * delta;
			
			if (result>0 && tests< 1) tests++;
			if (result<0 && tests>-1) tests--;
			
			if (result>0){
				if (test_s<125) test_s++;
			}
			else{
				if (test_f<125) test_f++;
			}
		}
		
		learned=true;
	}
	
	public void interpolation(SignatureComponent sig1, SignatureComponent sig2){
		for (int i=0;i<EnvironmentContext.length+1;i++){
			this.signature[i]=(sig1.signature[i]+sig2.signature[i])/2;
			if (Math.abs(signature[i])>maxPattern1 && i<EnvironmentContext.length) maxPattern1=Math.abs(signature[i]);
		}
		learned=true;
		delta_s=1.5f;
		delta_f=1.5f;
	}
	
	// use the continuity between interaction to share signature learning
	public void sharedLearn(float[] img, float result){

		float delta=result-prediction(img,false);

		if ( (result>0 && ( tests<1)) || (result<0 && ( tests>-1)) ){

			maxPattern1=0;
			
			//int counter=0;
			for (int i=0;i<EnvironmentContext.length;i++){
				
				//if (img[i]>0 && ( (sig1.signature[i]>0.1 && sig2.signature[i]>0.01) || (sig1.signature[i]<-0.1 && sig2.signature[i]<-0.01) )){
					signature[i]+= 0.01 * delta * img[i];
					//counter++;
				//}
				if (Math.abs(signature[i])>maxPattern1) maxPattern1=Math.abs(signature[i]);
			}
			// bias
			//if (counter>0){
				signature[EnvironmentContext.length]+= 0.01 * delta;
			
				if (result>0 && tests< 1) tests++;
				if (result<0 && tests>-1) tests--;
				
				if (result>0){
					if (test_s<125) test_s++;
				}
				else{
					if (test_f<125) test_f++;
				}
				
				//if (result>0) test_s2++;
				//else test_f2++;
				
				learned=true;
			//}
		}
	}
	
	public float getPrediction(){
		if (!learned) return 1;
		else return prediction;
	}
	
	public float getBias(){
		return signature[signature.length-1];
	}
	
	// fast exp function approximation
	public static double exp(double val) {
	    final long tmp = (long) (1512775 * val + (1072693248 - 60801));
	    return Double.longBitsToDouble(tmp << 32);
	}
	
}

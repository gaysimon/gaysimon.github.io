package main;

import java.awt.Color;
import java.awt.Graphics;

public class Robot {

	public Main main;
	
	public float x;
	public float y;
	public float theta;

	public float sensorL=0;
	public float sensorR=0;
	public float astrocyte1=10;
	public float astrocyte2=10;
	public float synapse_1_1=0;
	public float synapse_1_2=0;
	public float synapse_2_1=0;
	public float synapse_2_2=0;

	public float motorL=0;
	public float motorR=0;
	public float valueL=0;
	public float valueR=0;

	public float reward=0;
	public int count=0;
	public int countmax=100;

	public boolean bump=false;

	public int index=0;
	public int indexCount=0;
    
	public float[][] values;
	
	public int[][] timeline;
	public int time;

	
	public Robot(Main m){
		main=m;
		
		values=new float[400][10];
		
		timeline=new int[400][2];
		time=0;
	}
	
	public void initialize(int x0,int y0,float theta0){
	    x=x0;
	    y=y0;
	    theta=theta0;

	    sensorL=0;
	    sensorR=0;
	    astrocyte1=10;
	    astrocyte2=10;
	    synapse_1_1=0;
	    synapse_1_2=0;
	    synapse_2_1=0;
	    synapse_2_2=0;

	    motorL=0;
	    motorR=0;
	    valueL=0;
	    valueR=0;

	    reward=0;
	    count=0;
	    countmax=100;

	    bump=false;

	    index=0;
	    indexCount=0;
	    for(int i=0;i<400;i++){
	        for(int j=0;j<10;j++){
	            values[i][j]=0;
	        }
	    }
	}
	
	
	public void step(float[][] l,boolean lightPos,int xl,int yl){

	    float res1=0;
	    float res2=0;

	    double thetaRad=theta*3.14159f/180;

	    float sensorLx= (float) (18*Math.cos(thetaRad)- 20*Math.sin(thetaRad)+x);
	    float sensorLy=(float) (-18*Math.sin(thetaRad)- 20*Math.cos(thetaRad)+y);

	    float sensorRx= (float) (18*Math.cos(thetaRad)+ 20*Math.sin(thetaRad)+x);
	    float sensorRy=(float) (-18*Math.sin(thetaRad)+ 20*Math.cos(thetaRad)+y);

	    // indirect light
	    sensorL= (l[(int)sensorLx][(int)sensorLy]/10);
	    sensorR= (l[(int)sensorRx][(int)sensorRy]/10);

	    // direct light if light source on center
	    if (lightPos){
	        float distance= (float) Math.sqrt( (x-xl)*(x-xl)+(y-yl)*(y-yl) );

	        if (distance>0){
	            res1=((x-xl)/distance);
	            res2=((y-yl)/distance);
	            float LthetaRad= (float) ((theta-45)*3.14159f/180.);
	            float directL= (float) (  res1 * ( Math.sin(LthetaRad)) + res2 * (Math.cos(LthetaRad)) );

	            float RthetaRad= (float) ((theta+45)*3.14159f/180.);
	            float directR= (float) (  res1 * (-Math.sin(RthetaRad)) + res2 * (-Math.cos(RthetaRad)) );


	            if (directL>0) sensorL+=directL*5;
	            if (directR>0) sensorR+=directR*5;

	            if (sensorL>25) sensorL=25;
	            if (sensorR>25) sensorR=25;
	        }
	    }

	    // compute motor neurons
	    motorR= (float) (((sensorL*(synapse_1_1 + astrocyte1)) + (25-sensorL)*(synapse_1_2 +astrocyte1)) /500.);
	    motorL= (float) (((sensorR*(synapse_2_1 + astrocyte2)) + (25-sensorR)*(synapse_2_2 +astrocyte2)) /500.);

	    // update position
	    float d= (motorR+motorL)/2;
	    x+=d*Math.cos(thetaRad);
	    y+=d*(-Math.sin(thetaRad));

	    theta-= Math.tan( (motorL-motorR)/40)*180/3.14159;
	    if (theta>=360) theta-=360;
	    if (theta<   0) theta+=360;

	    // collision detection
	    bump=false;

	    if (x<40)  {
	        x=40;
	        if ( (theta>120)&&(theta<240) ) bump=true;
	    }
	    if (x>440) {
	        x=440;
	        if ( (theta>300)||(theta<60) ) bump=true;
	    }
	    if (y<40)  {
	        y=40;
	        if ( (theta>30)&&(theta<150) ) bump=true;
	    }
	    if (y>440) {
	        y=440;
	        if ( (theta>210)&&(theta<330) ) bump=true;
	    }
	    count++;

	    // fill values matrix
	    index=indexCount/5;
	    if (index>=400){
	        index=0;
	        indexCount=0;
	    }

	    values[index][0]=sensorL;
	    values[index][1]=sensorR;
	    values[index][2]=synapse_1_2;
	    values[index][3]=synapse_1_1;
	    values[index][4]=synapse_2_2;
	    values[index][5]=synapse_2_1;
	    values[index][6]=astrocyte1;
	    values[index][7]=astrocyte2;
	    values[index][8]=motorR;
	    values[index][9]=motorL;

	    indexCount++;
	    
	    // astrocyts computing
	    if (count>countmax){
	        count=0;
	        if (!bump){
	            if (motorR+reward>valueR){
	                synapse_1_1+= astrocyte1 * sensorL      /25.;
	                if (synapse_1_1>100) synapse_1_1=100;
	                synapse_1_2+= astrocyte1 * (25-sensorL)/25.;
	                if (synapse_1_2>100) synapse_1_2=100;
	            }
	            else{
	                synapse_1_1-= astrocyte1 * sensorL      /25.;
	                synapse_1_2-= astrocyte1 * (25-sensorL)/25.;
	            }

	            if (motorL+reward>valueL){
	                synapse_2_1+= astrocyte2 * sensorR      /25.;
	                if (synapse_2_1>100) synapse_2_1=100;
	                synapse_2_2+= astrocyte2 * (25-sensorR)/25.;
	                if (synapse_2_2>100) synapse_2_2=100;
	            }
	            else{
	                synapse_2_1-= astrocyte2 * sensorR      /25.;
	                synapse_2_2-= astrocyte2 * (25-sensorR)/25.;
	            }

	            if (astrocyte1>0) astrocyte1=-10;
	            else              astrocyte1= 10;

	            if (astrocyte2>0) astrocyte2=-10;
	            else              astrocyte2= 10;

	            valueR=motorR+reward;
	            valueL=motorL+reward;
	            countmax=100;
	        }
	        else{
	            valueR=-100;
	            valueL=-100;

	            synapse_1_1-= astrocyte1 * sensorL      /50.;
	            synapse_1_2-= astrocyte1 * (25-sensorL)/50.;

	            synapse_2_1-= astrocyte2 * sensorR      /50.;
	            synapse_2_2-= astrocyte2 * (25-sensorR)/50.;

	            if (astrocyte1>0) astrocyte1=-astrocyte1-20;
	            else              astrocyte1=-astrocyte1+20;

	            if (astrocyte2>0) astrocyte2=-astrocyte2-20;
	            else              astrocyte2=-astrocyte2+20;
	            countmax=10;
	        }
	        reward=0;
	    }
	    
	    timeline[time][0]=(int)x;
	    timeline[time][1]=(int)y;
	    time=(time+1)%400;
	    
	}
	
	public void setPosition(float x2,float y2){
	    x=x2;
	    y=y2;
	}
	
	public void setSynapse(int nb,float value){
	    switch(nb){
	            case 1 :synapse_1_1=value;
	                    break;
	            case 2 :synapse_1_2=value;
	                    break;
	            case 3 :synapse_2_1=value;
	                    break;
	            case 4 :synapse_2_2=value;
	                    break;
	            default:break;
	    }

	}

	public void setReward(int r){
	    reward=r;
	}
	
	public void drawRobot(Graphics g){

	    float thetaRad=(float) (theta*3.14159/180);

	    float res1,res2;
	    int   res3,res4;

	    ////////////////////////
	    // draw robot
	    ////////////////////////
	    g.setColor(new Color(150,150,150));
	    g.fillOval((int)x-20, (int)y-20, 40, 40);

	    // wheels
	    res1= (float) Math.cos(thetaRad);
	    res2= (float) Math.sin(thetaRad);
	    
	    g.setColor(new Color(50,70,50));
	    g.drawLine((int)(-5*res1-20*res2+x),(int)( 5*res2-20*res1 +y), (int)(5*res1-20*res2+x), (int)(-5*res2-20*res1 +y));
	    g.drawLine((int)(-5*res1+20*res2+x),(int)( 5*res2+20*res1 +y), (int)(5*res1+20*res2+x), (int)(-5*res2+20*res1 +y));

	    // light sensors
	    g.setColor(new Color(100,100,50));
	    g.drawLine((int)(20*res1- 5*res2+x),(int)(-20*res2- 5*res1 +y), (int)(15*res1-15*res2+x), (int)(-15*res2-15*res1 +y));
	    g.drawLine((int)(20*res1+ 5*res2+x),(int)(-20*res2+ 5*res1 +y), (int)(15*res1+15*res2+x), (int)(-15*res2+15*res1 +y));

	    // bumper
	    if (bump) g.setColor(new Color(250,0,0));
	    else g.setColor(new Color(50,70,50));
	    
	    g.fillOval((int)(x)-2, (int)(y)-2, 5, 5);
	    
	    ////////////////////////
	    // draw trace
	    ////////////////////////
	    g.setColor(Color.blue);
	    for (int t=0;t<Math.min(main.step,400);t++){
	    	if ((t+1)%400!=time) g.drawLine(timeline[t][0], timeline[t][1], timeline[(t+1)%400][0], timeline[(t+1)%400][1]);
	    }
	    

	    ////////////////////////
	    // draw network
	    ////////////////////////	    
	    
	    //bumper
	    if (bump) g.setColor(new Color(250,0,0));
	    else g.setColor(new Color(100,100,100));
	    g.fillRect(150, 500, 180, 10);

	    // light sensors
	    g.setColor(new Color(100,100,100));
	    g.fillRect( 30, 500, 100, 20);
	    g.fillRect(350, 500, 100, 20);
	    
	    g.setColor(new Color(200,200,0));
	    g.fillRect( 30, 500, (int)(sensorL*4), 20);
	    g.fillRect(450-(int)(sensorR*4), 500, (int)(sensorR*4), 20);

	    // neurons
	    g.setColor(new Color(Math.max(0, Math.min(255, (int)(125-motorR*22.5))),Math.max(0, Math.min(255, (int)(125+motorR*22.5))),0));
	    g.drawOval(50,690,60,60);
	    g.drawLine(110, 720, 160, 720);
	    
	    g.setColor(new Color(Math.max(0, Math.min(255, (int)(125-motorL*22.5))),Math.max(0, Math.min(255, (int)(125+motorL*22.5))),0));
	    g.drawOval(370,690,60,60);
	    g.drawLine(370, 720, 320, 720);

	    // astrocyts
	    g.setColor(new Color( Math.max(0,Math.min(125-(int)astrocyte1*2,250)) , Math.max(0,Math.min(125+(int)astrocyte1*2,250)) ,0));
	    g.drawOval(175,585,50,50);
	    g.setColor(new Color( Math.max(0,Math.min(125-(int)astrocyte2*2,250)) , Math.max(0,Math.min(125+(int)astrocyte2*2,250)) ,0));
	    g.drawOval(255,585,50,50);

	    // synaps
	    g.setColor(new Color(Math.max(0, Math.min(255,  (int)(125-synapse_1_1))) ,Math.max(0, Math.min(255, (int)(125+synapse_1_1))) , 0 ));
	    g.fillOval(25, 585, 30, 30);
	    
	    g.setColor(Color.black);
	    g.drawLine(20, 600, 60, 600);

	    g.setColor(new Color( Math.max(0,Math.min(125-(int)astrocyte1*2,250)) , Math.max(0,Math.min(125+(int)astrocyte1*2,250)) , 0));
	    g.drawOval(20, 580, 40, 40);
	    
	    g.setColor(new Color( Math.max(0, Math.min(255, (int)(125-synapse_1_2))) ,Math.max(0, Math.min(255, (int)(125+synapse_1_2) )), 0 ));
	    g.fillOval( 95, 625, 30, 30);

	    g.setColor(Color.black);
	    g.drawLine(90, 640, 130, 640);
	    
	    g.setColor(new Color( Math.max(0,Math.min(125-(int)astrocyte1*2,250)) , Math.max(0,Math.min(125+(int)astrocyte1*2,250)) , 0));
	    g.drawOval( 90, 620, 40, 40);
	    
	    g.setColor(new Color( Math.max(0, Math.min(255, (int)(125-synapse_2_1))) ,Math.max(0, Math.min(255, (int)(125+synapse_2_1))) , 0 ));
	    g.fillOval(425, 585, 30, 30);
	    
	    g.setColor(Color.black);
	    g.drawLine(420, 600, 460, 600);
	    
	    g.setColor(new Color( Math.max(0,Math.min(125-(int)astrocyte1*2,250)) , Math.max(0,Math.min(125+(int)astrocyte1*2,250)) , 0));
	    g.drawOval(420, 580, 40, 40);

	    g.setColor(new Color( Math.max(0, Math.min(255, (int)(125-synapse_2_2))) ,Math.max(0, Math.min(255, (int)(125+synapse_2_2))) , 0 ));
	    g.fillOval(355, 625, 30, 30);
	    
	    g.setColor(Color.black);
	    g.drawLine(350, 640, 390, 640);
	    
	    g.setColor(new Color( Math.max(0,Math.min(125-(int)astrocyte1*2,250)) , Math.max(0,Math.min(125+(int)astrocyte1*2,250)) , 0));
	    g.drawOval(350, 620, 40, 40);
	    
	    // motors
	    g.setColor(new Color(100,100,100));
	    g.fillRect(30,800,120,60);
	    g.fillRect(330,800,120,60);
	    
	    g.setColor(new Color(10,10,10));
	    g.drawLine( 32, (int)(830- motorL*5), 148, (int)(830 - motorL*5));
	    g.drawLine(332, (int)(830- motorR*5), 448, (int)(830 - motorR*5));

	    // connexions sensor-synapses
	    g.setColor(new Color( Math.max(0, Math.min(255, (int)(250-sensorL*10))) , Math.max(0, Math.min(255, (int)(sensorR*10))) ,0));
	    g.drawLine( 35, 520, 40, 585);
	    g.setColor(new Color( Math.max(0, Math.min(255, (int)(sensorL*10))) , Math.max(0, Math.min(255, (int)(250-sensorR*10))) ,0));
	    g.drawLine(125, 520,110, 625);
	    
	    g.setColor(new Color( Math.max(0, Math.min(255, (int)(250-sensorR*10))) , Math.max(0, Math.min(255, (int)(sensorL*10))) ,0));
	    g.drawLine(445, 520,440, 585);
	    g.setColor(new Color( Math.max(0, Math.min(255, (int)(sensorR*10))) , Math.max(0, Math.min(255, (int)(250-sensorL*10))) ,0));
	    g.drawLine(355, 520,370, 625);

	    // connexions synapses-neurons
	    g.setColor(new Color( Math.max(0, Math.min(255, (int)(125-sensorL*(synapse_1_1 + astrocyte1)/22))) , Math.max(0, Math.min(255, (int)(125+sensorL*(synapse_1_1+astrocyte1)/22))) , 0 ));
	    g.drawLine( 40, 615, 50, 710);
	    g.setColor(new Color(Math.max(0, Math.min(255,  (int)(125-sensorL*(synapse_1_2 + astrocyte1)/22))) ,Math.max(0, Math.min(255,  (int)(125+sensorL*(synapse_1_2+astrocyte1)/22))) , 0 ));
	    g.drawLine(110, 655,110, 710);
	    
	    g.setColor(new Color( Math.max(0, Math.min(255, (int)(125-sensorR*(synapse_2_1 + astrocyte1)/22))) , Math.max(0, Math.min(255, (int)(125+sensorR*(synapse_2_1+astrocyte1)/22))) , 0 ));
	    g.drawLine(440, 615,430, 710);
	    g.setColor(new Color( Math.max(0, Math.min(255, (int)(125-sensorR*(synapse_2_2 + astrocyte1)/22))) , Math.max(0, Math.min(255, (int)(125+sensorR*(synapse_2_2+astrocyte1)/22))) , 0 ));
	    g.drawLine(370, 655,370, 710);

	    // connexions astrocytes-synapses
	    res3=(int)(astrocyte1*2);
	    res4=(int)(astrocyte2*2);
	    
	    g.setColor(new Color( Math.max(0,Math.min(125-res3,250)) , Math.max(0,Math.min(125+res3,250)) ,0));
	    g.drawLine(170, 610,160, 610);
	    g.drawLine(160, 610, 60, 600);
	    g.drawLine(160, 610,130, 640);
	    
	    g.setColor(new Color( Math.max(0,Math.min(125-res4,250)) , Math.max(0,Math.min(125+res4,250)) ,0));
	    g.drawLine(305, 610,320, 610);
	    g.drawLine(320, 610,420, 600);
	    g.drawLine(320, 610,350, 640);

	    // connexions neurones-astrocytes
	    res1=(int)(motorR*22.5);
	    res2=(int)(motorL*22.5);
	    
	    g.setColor(new Color( Math.max(0, Math.min(255, (int)(125-res1))),Math.max(0, Math.min(255, (int)(125+res1))),0 ));
	    g.drawLine(160, 720,200, 640);
	    g.setColor(new Color( Math.max(0, Math.min(255, (int)(125-res2))),Math.max(0, Math.min(255, (int)(125+res2))),0 ));
	    g.drawLine(320, 720,280, 640);

	    // connexions neurones-moteurs
	    g.setColor(new Color(Math.max(0, Math.min(255,  (int)(125-res1))),Math.max(0, Math.min(255, (int)(125+res1))),0 ));
	    g.drawLine(160, 720,330, 830);
	    g.setColor(new Color(Math.max(0, Math.min(255,  (int)(125-res2))),Math.max(0, Math.min(255, (int)(125+res2))),0 ));
	    g.drawLine(320, 720,150, 830);

	    // connexions bumper-astrocytes
	    if (bump) g.setColor(new Color(250,0,0));
	    else      g.setColor(new Color(100,100,100));
	    g.drawLine(240, 510,200, 580);
	    g.drawLine(240, 510,280, 580); 


	    ////////////////////////
	    // draw graphs
	    ////////////////////////
	    int index2=index+2;

	    for(int i=1;i<400;i++){
	        if (index2>=400) index2=index2%400;

	        res3=700+i;
	        res4=(index2+399)%400;

	        g.setColor(new Color(200,200,0));
	        g.drawLine(res3,(int)( 70-2*values[index2][0]), res3,(int)( 70-2*values[res4][0]));
	        g.drawLine(res3,(int)(130-2*values[index2][0]), res3,(int)(130-2*values[res4][0]));
	        
	        g.setColor(new Color( 50,  0,200));
	        g.drawLine(res3,(int)(190-values[index2][2]/2), res3,(int)(190-values[res4][2]/2));
	        g.setColor(new Color(150,150,  0));
	        g.drawLine(res3,(int)(190-values[index2][3]/2), res3,(int)(190-values[res4][3]/2));

	        g.setColor(new Color( 50,  0,200));
	        g.drawLine(res3,(int)(300-values[index2][4]/2), res3,(int)(300-values[res4][4]/2));
	        g.setColor(new Color(150,150,  0));
	        g.drawLine(res3,(int)(300-values[index2][5]/2), res3,(int)(300-values[res4][5]/2));

	        g.setColor(new Color(0,180,0));
	        g.drawLine(res3,(int)(410-Math.max(-60,Math.min(60,(int)values[index2][6]))/3), res3,(int)( 410-Math.max(-60,Math.min(60,(int)values[res4][6]))/3 ));
	        g.drawLine(res3,(int)(520-Math.max(-60,Math.min(60,(int)values[index2][7]))/3), res3,(int)( 520-Math.max(-60,Math.min(60,(int)values[res4][7]))/3 ));

	        g.setColor(new Color(180,0,0));
	        g.drawLine(res3,(int)(640-8*values[index2][8]), res3,(int)(640-8*values[res4][8]));
	        g.drawLine(res3,(int)(760-8*values[index2][9]), res3,(int)(760-8*values[res4][9]));

	        index2++;
	    }
	}
	
	
	public void drawControl(Graphics g){
	    int res1=0;
	    g.setColor(new Color(120,120,120));
	    
	    if (reward>=0){
	        res1=(int) (500+reward*16/10);
	        
	        g.drawLine(res1, 502, res1, 528);
	        g.fillOval(res1-3, 497, 6, 6);
	        g.fillOval(res1-3, 527, 6, 6);

	        g.drawLine(500, 552, 500, 578);
	        g.fillOval(497, 547, 6, 6);
	        g.fillOval(497, 577, 6, 6);
	    }
	    else{
	        res1=(int)(500-reward*16/10);;
	        
	        g.drawLine(res1, 552, res1, 578);
	        g.fillOval(res1-3, 547, 6, 6);
	        g.fillOval(res1-3, 577, 6, 6);

	        g.drawLine(500, 502, 500, 528);
	        g.fillOval(497, 497, 6, 6);
	        g.fillOval(497, 527, 6, 6);
	    }
	    
	    res1=(int) (580+synapse_1_1*8/10);
	    g.drawLine(res1, 620, res1, 650);
	    g.fillOval(res1-3, 617, 6, 6);
	    g.fillOval(res1-3, 647, 6, 6);

	    res1=(int) (580+synapse_1_2*8/10);
	    g.drawLine(res1, 680, res1, 710);
	    g.fillOval(res1-3, 677, 6, 6);
	    g.fillOval(res1-3, 707, 6, 6);

	    res1=(int) (580+synapse_2_1*8/10);
	    g.drawLine(res1, 760, res1, 790);
	    g.fillOval(res1-3, 757, 6, 6);
	    g.fillOval(res1-3, 787, 6, 6);

	    res1=(int) (580+synapse_2_2*8/10);
	    g.drawLine(res1, 820, res1, 850);
	    g.fillOval(res1-3, 817, 6, 6);
	    g.fillOval(res1-3, 847, 6, 6);
	}
	
	// get a string containing internal values
	public String getString(){
		String ret="";
		
		ret+=x+" "+y+" ";
		if (bump) ret+="1 ";
    	else ret="0 ";
		ret+=sensorL+" "+sensorR+" "+motorL+" "+motorR+" "+astrocyte1+" "+astrocyte2+" "
    	    +synapse_1_1+" "+synapse_1_2+" "+synapse_2_1+" "+synapse_2_2+" "+valueL+" "+valueR;
		
		return ret;
	}
	
}

package main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.JPanel;


public class SimuPanel extends JPanel implements MouseListener, MouseMotionListener{

	private static final long serialVersionUID = 1L;
	
	private Main main;
	
	int buttonLightX=520;
	int buttonLightY=250;
	boolean lightPressed=false;

	int buttonPauseX=520;
	int buttonPauseY=300;
	boolean pausePressed=false;

	int buttonResetX=520;
	int buttonResetY=350;
	boolean resetPressed=false;

	int buttonRecX=520;
	int buttonRecY=400;
	boolean recPressed=false;
	
	int pos_x;
	int pos_y;
	
	public SimuPanel(Main m){
		main=m;
		addMouseListener(this);
		addMouseMotionListener(this);
	}
	
	public void paintComponent(Graphics g){
		
		int l=0;

		g.setColor(Color.black);
		g.fillRect(0, 0, 1200, 950);
		 
        // draw simulator lights
        for (int i=10;i<470;i+=2){
            for (int j=10;j<470;j+=2){
                l=(int) main.luminosite[i][j];
                if (l>255) l=255;
                g.setColor(new Color(l,l,0));
                g.fillRect(i, j, 2, 2);
            }
        }


        // draw simulator borders
        g.setColor(Color.blue);
        g.drawRect(10, 10, 460, 460);

        // draw simulator interface
        drawInterface(g);
        drawNetwork(g);
        drawControlPanel(g);
        drawGraph(g);
		

        main.robot.drawRobot(g);
        
	    if (main.clic){
	    	main.robot.setPosition(pos_x,pos_y);
	    }
		
	}
	
	
	private void drawButton(Graphics g, int X,int Y,boolean press){
		
		if (press){
			g.setColor(new Color(80,80,130));
			g.fillRect(X,Y,120,30);
			
			g.setColor(new Color(150,150,150));
			g.drawLine(X-  2, Y+32, X+122, Y+32);
			g.drawLine(X+122, Y- 2, X+122, Y+32);
			g.setColor(new Color(50,50,50));
			g.drawLine(X-  2, Y- 2, X+122, Y- 2);
			g.drawLine(X-  2, Y- 2, X-  2, Y+32);
	    }
	    else{
			g.setColor(new Color(100,100,150));
			g.fillRect(X,Y,120,30);
			
			g.setColor(new Color(50,50,50));
			g.drawLine(X-  2, Y+32, X+122, Y+32);
			g.drawLine(X+122, Y- 2, X+122, Y+32);
			g.setColor(new Color(150,150,150));
			g.drawLine(X-  2, Y- 2, X+122, Y- 2);
			g.drawLine(X-  2, Y- 2, X-  2, Y+32);
	    }
		
	}
	
	
	private void drawInterface(Graphics g){

		g.setColor(Color.blue);
		g.drawRect(490, 10, 180, 460);

	    // step
		g.setColor(Color.blue);
		g.drawRect(510, 170, 140, 30);
		g.setColor(new Color(0,0,200));
		g.drawString("step = "+ main.step, 515, 190);

	    // robot light sensors
		g.setColor(new Color(100,100,100));
		g.fillRect(510,20,50,125);
		g.setColor(new Color(200,200,0));
		g.fillRect(512,(int) (145-main.robot.sensorL),46,(int)main.robot.sensorL);
		
		g.setColor(new Color(100,100,100));
		g.fillRect(600,20,50,125);
		g.setColor(new Color(200,200,0));
		g.fillRect(602,(int) (145-main.robot.sensorR),46,(int)main.robot.sensorR);

	    // light button
	    drawButton(g, buttonLightX,buttonLightY,lightPressed);
	    
	    g.setColor(new Color(150,150,0));
	    if ( main.light) g.drawRect(45+buttonLightX, 2+buttonLightY, 30, 26);
	    else      		 g.fillOval(57+buttonLightX,12+buttonLightY,  6,  6);

	    // pause button
	    drawButton(g, buttonPauseX,buttonPauseY,pausePressed);
	    g.setColor(Color.black);
	    if ( main.pause1) {
	    	g.drawLine(45+buttonPauseX,  3+buttonPauseY, 70+buttonPauseX, 15+buttonPauseY);
	    	g.drawLine(45+buttonPauseX, 27+buttonPauseY, 70+buttonPauseX, 15+buttonPauseY);
	    	g.drawLine(45+buttonPauseX, 27+buttonPauseY, 45+buttonPauseX,  3+buttonPauseY);
	    }
	    else{
	    	g.fillRect(50+buttonPauseX,  5+buttonPauseY, 5, 20);
	    	g.fillRect(60+buttonPauseX,  5+buttonPauseY, 5, 20);
	    }

	    // reset button
	    drawButton(g, buttonResetX,buttonResetY,resetPressed);
	    g.fillRect(47+buttonResetX, 5+buttonResetY, 21, 20);

	    // record button
	    drawButton(g, buttonRecX,buttonRecY,recPressed);
	    g.setColor(new Color(150,0,0));
	    g.fillOval(buttonRecX+52, buttonRecY+7, 16, 16);
	}
	
	
	private void drawControlPanel(Graphics g){
		g.setColor(Color.blue);
		g.drawRect(490, 480, 180, 410);
		
		g.setColor(new Color(50,150,50));
		g.fillRect(500, 500, 160, 30);
		g.setColor(Color.black);
		g.drawString("0       reward      100", 502, 520);
	    g.setColor(new Color(150,50,50));
	    g.fillRect(500, 550, 160, 30);
		g.setColor(Color.black);
	    g.drawString("0      punition     100", 502, 570);
	    
	    g.setColor(Color.blue);
	    g.drawLine(490, 600, 670, 600);

	    g.setColor(new Color(150,150,50));
	    g.fillRect(500, 620, 160, 30);
	    g.setColor(Color.black);
	    g.drawString("   synapse L +", 502, 640);

	    g.setColor(new Color(50,100,150));
	    g.fillRect(500, 680, 160, 30);
	    g.setColor(Color.black);
	    g.drawString("   synapse L -", 502, 700);

	    g.setColor(new Color(150,150,50));
	    g.fillRect(500, 760, 160, 30);
	    g.setColor(Color.black);
	    g.drawString("   synapse R +", 502, 780);

	    g.setColor(new Color(50,100,150));
	    g.fillRect(500, 820, 160, 30);
	    g.setColor(Color.black);
	    g.drawString("   synapse R -", 502, 840);

	    g.setColor(new Color(10,10,10));
	    g.drawLine(580, 620, 580, 650);
	    g.drawLine(580, 680, 580, 710);
	    g.drawLine(580, 760, 580, 790);
	    g.drawLine(580, 820, 580, 850);
	    

	    int res1,res2;
	    g.setColor(Color.black);
	    for (int i=0;i<=10;i++){
	        res1=500+i*16;
	        
	        g.drawLine(res1, 500, res1, 502);
	        g.drawLine(res1, 530, res1, 528);
	        g.drawLine(res1, 550, res1, 552);
	        g.drawLine(res1, 580, res1, 578);

	        res1=580+i*8;
	        res2=580-i*8;
	        
	        g.drawLine(res1, 620, res1, 622);
	        g.drawLine(res1, 680, res1, 682);
	        g.drawLine(res1, 760, res1, 762);
	        g.drawLine(res1, 820, res1, 822);
	        
	        g.drawLine(res1, 650, res1, 648);
	        g.drawLine(res1, 710, res1, 708);
	        g.drawLine(res1, 790, res1, 788);
	        g.drawLine(res1, 850, res1, 848);

	        g.drawLine(res2, 620, res2, 622);
	        g.drawLine(res2, 680, res2, 682);
	        g.drawLine(res2, 760, res2, 762);
	        g.drawLine(res2, 820, res2, 822);

	        g.drawLine(res2, 650, res2, 648);
	        g.drawLine(res2, 710, res2, 708);
	        g.drawLine(res2, 790, res2, 788);
	        g.drawLine(res2, 850, res2, 848);
	    }

	    main.robot.drawControl(g);
	}
	
	private void drawNetwork(Graphics g){
		g.setColor(Color.blue);
		g.drawRect(10,480,460,410);
	}
	
	
	private void drawGraph(Graphics g){
		
		g.setColor(Color.blue);
		g.drawRect(690,10,460,880);

	    // light graphs
		g.setColor(new Color(100,100,100));
		g.drawLine(700, 20, 700, 70);
		g.drawLine(700, 70,1100, 70);
		g.drawLine(700, 80, 700,130);
		g.drawLine(700,130,1100,130);

	    // synaps
		g.setColor(Color.blue);
		g.drawLine(690,135, 1150, 135);
		
		g.setColor(new Color(100,100,100));
		g.drawLine(700,140, 700,240);
		g.drawLine(700,190,1100,190);
		g.drawLine(700,250, 700,350);
		g.drawLine(700,300,1100,300);

	    // astrocyts
		g.setColor(Color.blue);
		g.drawLine(690,355, 1150, 355);
		
		g.setColor(new Color(100,100,100));
		g.drawLine(700,360, 700,460);
		g.drawLine(700,410,1100,410);
		g.drawLine(700,470, 700,570);
		g.drawLine(700,520,1100,520);

	    // neurons
		g.setColor(Color.blue);
		g.drawLine(690,575, 1150, 575);
		
		g.setColor(new Color(100,100,100));
		g.drawLine(700,590, 700,690);
		g.drawLine(700,640,1100,640);
		g.drawLine(700,710, 700,810);
		g.drawLine(700,760,1100,760);

	}

	
	
	public void mouseClicked(MouseEvent arg0) {}
	public void mouseEntered(MouseEvent arg0) {}
	public void mouseExited(MouseEvent arg0) {}
	
	
	public void mousePressed(MouseEvent e) {
		
		int x=e.getX();
		int y=e.getY();
		
        if ( (x>=buttonLightX)&&(x<=buttonLightX+120)&&(y>=buttonLightY)&&(y<=buttonLightY+30) ){
        	main.light = ! main.light;
            lightPressed=true;
            main.fillLuminosite( main.light);
        }

        if ( (x>=buttonPauseX)&&(x<=buttonPauseX+120)&&(y>=buttonPauseY)&&(y<=buttonPauseY+30) ){
        	main.pause1 = ! main.pause1;
            pausePressed=true;
        }

        if ( (x>=buttonResetX)&&(x<=buttonResetX+120)&&(y>=buttonResetY)&&(y<=buttonResetY+30) ){
        	main.robot.initialize(240,270,0);
        	main.robot.time=0;
        	main.pause1=true;
            resetPressed=true;
            main.step=0;
            main.newRecord=true;
        }

        if ( (x>=buttonRecX)&&(x<=buttonRecX+120)&&(y>=buttonRecY)&&(y<=buttonRecY+30) ){
        	main.record = ! main.record;
            recPressed= main.record;
        }

        // reward-punishment buttons
        if ( (x>=500)&&(x<=660)&&(y>=500)&&(y<=530) ){
        	main.robot.setReward( (x-500)*10/16);
        }
        if ( (x>=500)&&(x<=660)&&(y>=550)&&(y<=580) ){
        	main.robot.setReward( -(x-500)*10/16);
        }

        // synapses buttons
        if ( (x>=500)&&(x<=660)&&(y>=620)&&(y<=650) ){
        	main.robot.setSynapse(1,(x-580)*10/8);
        }
        if ( (x>=500)&&(x<=660)&&(y>=680)&&(y<=710) ){
        	main.robot.setSynapse(2,(x-580)*10/8);
        }
        if ( (x>=500)&&(x<=660)&&(y>=760)&&(y<=790) ){
        	main.robot.setSynapse(3,(x-580)*10/8);
        }
        if ( (x>=500)&&(x<=660)&&(y>=820)&&(y<=850) ){
        	main.robot.setSynapse(4,(x-580)*10/8);
        }


        // drag and drop
        if ( (x>=main.robot.x-20)&&(x<=main.robot.x+20)&&(y>=main.robot.y-20)&&(y<=main.robot.y+20) ){
        	 main.clic=true;
        	 pos_x=(int) main.robot.x;
        	 pos_y=(int) main.robot.y;
        }
    }
		
	public void mouseReleased(MouseEvent e) {
		main.clic=false;
        lightPressed=false;
        pausePressed=false;
        resetPressed=false;
	}

	public void mouseDragged(MouseEvent e) {
		if (main.clic){
			pos_x=e.getX();
			pos_y=e.getY();
		}
	}

	public void mouseMoved(MouseEvent e) {}
}

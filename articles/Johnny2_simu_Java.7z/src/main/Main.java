package main;

import java.awt.event.WindowEvent;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.JFrame;


public class Main extends JFrame{

	private static final long serialVersionUID = 1L;
	
	public Robot robot;
	
	public boolean light=true;
	public boolean clic=false;
	public boolean pause1=true;
	public boolean record=false;
	public boolean newRecord=true;
	
	public float[][] luminosite=new float[480][480];

	public int step=0;
	
	private SimuPanel simuPanel;
	
	public PrintWriter file;
	
	public Main(){
		
		try {
			file  = new PrintWriter("Johnny2_simu.txt");
		} catch (IOException e) {e.printStackTrace();}
		
		robot=new Robot(this);
	    robot.initialize(240,270,0);
	    
	    fillLuminosite(light);
	    
	    this.setTitle("Johnny 2.0");
    	this.setSize(1160, 940);
    	this.setLocationRelativeTo(null);               
    	this.setVisible(true);
		simuPanel = new SimuPanel(this);
		this.setContentPane(simuPanel);
    	
    	addWindowListener(new java.awt.event.WindowAdapter() {
		    public void windowClosing(WindowEvent winEvt) {
		    	
		        System.exit(0); 
		    }
		});
		
	    while(true){
	    	
	        // robot simulation
	        if (!clic && !pause1) robot.step(luminosite,light,240,240);

	        // record robot values
	        if (!pause1 && record){
	        	if (newRecord){
	        		file.println("+++");
	        		newRecord=false;
	        	}
		        String vals=step+" "+robot.getString()+" ";
		        if (light) vals+="1";
		        else vals+="0";
	        	file.println(vals);
	        }

	        simuPanel.repaint();

	        if (!pause1) step++;
	        
	        try{Thread.currentThread();
			Thread.sleep(20);}
			catch(Exception ie){}
	    }
	}
	
	
	
	public void fillLuminosite(boolean l){
	    int d=0;
	    if (l){
	        // light on center
	        for (int i=0;i<480;i++){
	            for (int j=0;j<480;j++){
	                d= (int) Math.sqrt( (240-i)*(240-i) + (240-j)*(240-j) );
	                d=d*2;
	                if (d<50)  luminosite[i][j]=250;
	                else if (d<400) luminosite[i][j]=400-d;
	                else       luminosite[i][j]=0;
	            }
	        }
	    }
	    else{
	        // light on borders
	        for (int i=0;i<480;i++){
	            for (int j=0;j<480;j++){
	                d= Math.min( Math.min( (i-10),(470-i) ) , Math.min( (j-10),(470-j) ) );
	                d=d*2;
	                if (d<250) luminosite[i][j]=250-d;
	                else       luminosite[i][j]=0;
	            }
	        }
	    }
	}
	
	public void close(){
		file.close();
	}
	
	
	
	public static void main(String[] args){
		new Main();
	}
}

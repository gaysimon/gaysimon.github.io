import time

gamme=[0,2,4,6,8,10,12,12,10,8,6,4,2,0]

while True:
	for note in gamme:
		# intention
		f=open("intended.txt","w")
     		f.write(str(note))
     		f.close()
		print str(note)+" -> ",
    		time.sleep(1)

		# read enacted
		f=open("enacted.txt","r")
    		enacted=f.read()
    		f.close()

		while len(enacted)==0:
			time.sleep(0.5)
			f=open("enacted.txt","r")
    			enacted=f.read()
    			f.close()

		print(enacted)
		f=open("enacted.txt","w")
	     	f.write("")
	     	f.close()

import java.util.ArrayList;


public class Historique {

	public int[] prise;
	public int[] pose;
	public int[] charge;
	public int[] vide;
	public agent cible;
	
	
	public Historique(agent a){
		prise=new int[1000];
		pose=new int[1000];
		charge=new int[1000];
		vide=new int[1000];
		cible=a;
	}
	
	public void upDate(){
			
		if (cible.chemin.get(cible.chemin.size()-1).action ==1){
			// nouvelle prise
			for(int i=prise.length-1;i>0;i--){
				prise[i]=prise[i-1];
			}
			prise[0]=0;
			
			pose[0]=pose[0]+1;
				
		        
			for(int i=charge.length-1;i>0;i--){
				charge[i]=charge[i-1];
			}
			charge[0]=0;
				
		}
			
		if (cible.chemin.get(cible.chemin.size()-1).action ==2){
			prise[0]+=1;
			
			for(int i=prise.length-1;i>0;i--){
				pose[i]=pose[i-1];
			}
			pose[0]=0;
			
			for(int i=vide.length-1;i>0;i--){
				vide[i]=vide[i-1];
			}
			vide[0]=0;
			
		}
		
		if (cible.chemin.get(cible.chemin.size()-1).action ==0){
			
			prise[0]=prise[0]+1;
			pose[0]=pose[0]+1;
			
			if (cible.prise!=0){
				charge[0]+=1;
			}
			else{
				vide[0]+=1;
			}
			
		}
		
		
	}
	
	
	public void afficher(){
		System.out.println();
		for(int i=0;i<5;i++){
			System.out.print(" "+prise[i]);
		}
		System.out.println();
		for(int i=0;i<5;i++){
			System.out.print(" "+pose[i]);
		}
		System.out.println();
		for(int i=0;i<5;i++){
			System.out.print(" "+charge[i]);
		}
		System.out.println();
		for(int i=0;i<5;i++){
			System.out.print(" "+vide[i]);
		}
		System.out.println();
	}
	
	
}

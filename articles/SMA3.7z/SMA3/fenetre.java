
import java.util.ArrayList;

import javax.swing.JFrame;
 
public class fenetre extends JFrame {
 
        public fenetre(grille n_f,ArrayList<agent> la,int size){
                
                this.setSize(600, 600);
                this.setLocationRelativeTo(null);               
                this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                
                this.setVisible(true);           
                this.setContentPane(new panneau(n_f,la,size));
                

        }
        
}

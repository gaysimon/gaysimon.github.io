import java.util.ArrayList;

public class test{


	
	public static void run(){
		
		
	  int size;
	  grille g;
	  carte m;
	  ArrayList<agent> listAgents;
	  Historique h;
  	  size=50;

      g=new grille(size,650);
      g.afficher();
      System.out.println();
	    try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
		}

      m=new carte(size);
      m.afficher();
      
	    try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
		}
      
      m.blackHole(8,8,30, 200);
      m.afficher();
      
      listAgents=new ArrayList<agent>();
       
      for (int i=0;i<25;i++){
    	  listAgents.add(new agent(25,25,m,g,size));
      }
      
      h=new Historique(listAgents.get(0));
      
      winMap wm=new winMap(m,listAgents,size);
      fenetre f=new fenetre(g,listAgents,size);
      WinHistorique wh=new WinHistorique(h);

	    try {
		Thread.sleep(500);
	} catch (InterruptedException e) {
	}
      
      for(int k=0;k<50000;k++){ 
    	for (int i=0;i<10000;i++){
    	for(int j=0;j<listAgents.size();j++){
    		(listAgents.get(j)).step(false,false);
    	}
    	h.upDate();
		
		m.evaporation();
        f.repaint();
        wm.repaint();
        wh.repaint();
      }
      }
      listAgents.get(0).afficher();
      h.afficher();
	}
	
	
    public static void main(String[] arg) {

    	new Interface();
        //run();

    }

}

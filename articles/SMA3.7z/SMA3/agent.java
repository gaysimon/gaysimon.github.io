import java.util.*;

public class agent{

     int xa;
     int ya;
     int dir;
     int size=50;
     int prise=0;
     int piste;
     
     int orientationX[]={1,1,0,-1,-1,-1,0,1};
     int orientationY[]={0,-1,-1,-1,0,1,1,1};

     Random generator = new Random();
     
     ArrayList<Case> chemin=new ArrayList<Case>();

     carte map;
     grille grid;
     
     public agent(int x,int y,carte c, grille g,int size){
            xa=x;
            ya=y;
            dir=0;
            map=c;
            grid=g;
            piste=0;
            this.size=size;
            chemin.add(new Case(xa,ya,0));
     }


     public void walk(){
            int direction= generator.nextInt( 8 );
            int[] proba=new int[8];
            int iter=0;
            
            //calcul des probabilit�es pour chaque direction
            
            for (int i=0;i<8;i++){
            	
                if ( ( (xa>0)|| ( (i!=3)&&(i!=4)&&(i!=5) ) )
                   &&( (ya>0)|| ( (i!=1)&&(i!=2)&&(i!=3) ) )
                   &&((xa<size-1)||((i!=1)&&(i!=0)&&(i!=7)))
                   &&((ya<size-1)||((i!=5)&&(i!=6)&&(i!=7)))){     //toute case accessible a une certaine probabilit� d'�tre atteinte
                	iter+=10;
                	
                	// champ d'attraction
                	if (prise!=0){
                     	iter+= map.map[xa+orientationX[i]][ya+orientationY[i]][11];
                	}
                	
                	if((dir!=(i+2)%8)&&(dir!=(i+3)%8)&&(dir!=(i+4)%8)&&(dir!=(i+5)%8)&&(dir!=(i+6)%8)){     //pour ne pas revenir sur ses pas, on limite la probabilit�
                	   iter+=20;
                	   if(dir==i){
                		   iter+=50;
                	   }
                	   if(prise==0){
                		   iter+=max(map.map[xa+orientationX[i]][ya+orientationY[i]][8],
                				     map.map[xa+orientationX[i]][ya+orientationY[i]][9],
                				     map.map[xa+orientationX[i]][ya+orientationY[i]][10]);
                	   }
                	}
                }
                proba[i]=iter;
            }
            
            

            
            // on d�termine la direction
            direction= generator.nextInt( iter );
            for (int i=7;i>=0;i--){
            	if (direction<proba[i]){
            		dir=i;
            	}
            }


            xa+=orientationX[dir];
            ya+=orientationY[dir];
            

            map.marquer(150*piste,dir,xa,ya,prise); 
              
              
            if(piste>=0){
                this.piste--;
             }         
        }
     
     
     public void step(boolean proba1,boolean proba2){
         int rand= generator.nextInt( 8 );
         int nb;
         
         
         
         // prise de la ressource ?
         if ((prise==0)&&(grid.g[xa][ya]!=0)){
        	 if (proba1){
        		 nb=grid.voisins(xa,ya,grid.g[xa][ya])+2;
        	 }
        	 else{
        		 nb=grid.voisins(xa,ya,grid.g[xa][ya])+1;
        	 }
        	 
        	 if (nb<rand){
        		 prise=grid.g[xa][ya];
        		 grid.prendre(xa, ya);
        		 piste=(int)(size/4);
        		 dir=(dir+4)%7;
        		 
        		 
                 if (chemin.size()>1000){
                 	chemin.remove(0);
                 }
                 chemin.add(new Case(xa,ya,1));
        		 
        	 }
        	 else{
                 this.walk();
            	 
                 if (chemin.size()>1000){
                  	chemin.remove(0);
                  }
                  chemin.add(new Case(xa,ya,0));
        	 }
         }
         else{
        	 // pose de la ressource ?
             if ((prise!=0)&&(grid.g[xa][ya]==0)){
            	 if (proba1){
            		 nb=grid.voisins(xa,ya,prise)-2;
            	 }
            	 else{
            		 nb=grid.voisins(xa,ya,prise)-1;
            	 }
            	 
            	 if (nb>rand){
            		 grid.deposer(xa, ya,prise);
            		 prise=0;
            		 piste=0;
            		 dir=(dir+4)%7;
            		 
            		 
                     if (chemin.size()>1000){
                      	chemin.remove(0);
                      }
                      chemin.add(new Case(xa,ya,2));
            		 
            	 }
            	 else{
                     this.walk();
                	 
                     if (chemin.size()>1000){
                      	chemin.remove(0);
                      }
                      chemin.add(new Case(xa,ya,0));
            	 }
             }
             else{
            	 
                 this.walk();
            	 
                 if (chemin.size()>1000){
                  	chemin.remove(0);
                  }
                  chemin.add(new Case(xa,ya,0));
             }
         }


     }
     
     
     public void afficher(){
    	 for(int i=0;i<chemin.size();i++){
    		 chemin.get(i).afficher();
    	 }
    	 System.out.println();
     }
     
     
     int max(int a,int b, int c){
    	 if ((a>=b)&&(a>=c)){
    		 return a;
    	 }
    	 else{
    		 if (b>=c){
    			 return b;
    		 }
    		 else{
    			 return c;
    		 }
    	 }
     }
     
}





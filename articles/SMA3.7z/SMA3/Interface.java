import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JSlider;
import javax.swing.JTextField;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;



public class Interface extends JFrame{

	
	
    private JPanel panel1 = new JPanel();
    private JPanel screens=new JPanel();
    private JPanel panel2=new JPanel();
	private JPanel attract=new JPanel();
    
    private JButton bouton_l = new JButton("lancer");
    private JButton bouton_turbo=new JButton("turbo");
    private JButton bouton_s = new JButton("step");
    private JButton bouton_p = new JButton("play");
    private JButton bouton_stop = new JButton("stop");
	
    private JButton bouton_pa=new JButton("ajouter agent");
    private JButton bouton_ma=new JButton("suprimer agent");
    private JButton bouton_pr=new JButton("ajouter ressource");
    private JButton bouton_mr=new JButton("supprimer ressource");
    
    private JButton bouton_h=new JButton("histogramme");
    
    private Historique h;
    private WinHistorique wh;
    
    private JSlider framesPerSecond = new JSlider(JSlider.HORIZONTAL,
            0, 100, 10);
	private JSlider pl_x;
	private JSlider pl_y;
	private JSlider pl_r;
	private JSlider pl_f;

    
    private JTextField jtfsize = new JTextField("50");
    private JTextField jtfnba = new JTextField("50");
    private JTextField jtfnbc = new JTextField("650");
    private JTextField nb_turbo = new JTextField("10000");
    private JCheckBox check1 = new JCheckBox("diminuer probabilite de prise");
    private JCheckBox check2 = new JCheckBox("diminuer probabilite de pose");
    
    private JLabel l1 = new JLabel("taille              ");
    private JLabel l2 = new JLabel("nombre d'agents     ");
    private JLabel l3 = new JLabel("nombre de ressources");
    
    private grille g;
    private carte m;
    private winMap wm;
    private fenetre f;

	  ArrayList<agent> listAgents;
	  int size=50;
	  
      private panneau panGrid;
      private panMap panCarte;
      
      JLabel nb_a = new JLabel();
      JLabel nb_r = new JLabel();
      JLabel etape = new JLabel();
      JLabel com_etape = new JLabel();
      private int step=0;
      
      private Thread t;

	  private boolean continuer;
	
    // constructeur
	public Interface(){
        this.setSize(1200, 800);
        this.setTitle("Systeme multi-agents");
        this.setLocationRelativeTo(null);               
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
        this.setResizable(false);
        
        
        this.setLayout(new BorderLayout());


        initInterface();

	}
	
	
    private void initInterface(){

        Font police = new Font("Arial", Font.BOLD, 10);

        jtfsize.setPreferredSize(new Dimension(120, 20));
        jtfnba.setPreferredSize(new Dimension(120, 20));
        jtfnbc.setPreferredSize(new Dimension(120, 20));
        
        
        
        JPanel param=new JPanel();
        JPanel param1=new JPanel();
        JPanel param2=new JPanel();
        JPanel param3=new JPanel();

        panel1.setPreferredSize(new Dimension(900, 100));
        
        l1.setPreferredSize(new Dimension(200, 20));
        l2.setPreferredSize(new Dimension(200, 20));
        l3.setPreferredSize(new Dimension(200, 20));
        
        param1.setPreferredSize(new Dimension(350, 25));
        param2.setPreferredSize(new Dimension(350, 25));
        param3.setPreferredSize(new Dimension(350, 25));

        listAgents=new ArrayList<agent>();
         
        
        
        
        ////////////////////////////////////////
        // panel1 : parametres d'initialisation

        param.setPreferredSize(new Dimension(350, 80));
        param.add(l1);
        param.add(jtfsize);
        param.add(l2);
        param.add(jtfnba);
        param.add(l3);
        param.add(jtfnbc);
        param.setBorder(BorderFactory.createLineBorder(Color.black));
        panel1.setBorder(BorderFactory.createLineBorder(Color.black));
        panel1.add(param);

        
        JPanel proba1=new JPanel();
        proba1.setPreferredSize(new Dimension(350, 80));
        proba1.add(check1);
        proba1.add(check2);
        panel1.add(proba1); 
        proba1.setBorder(BorderFactory.createLineBorder(Color.black));
        

        JPanel bouton=new JPanel();
        bouton.setPreferredSize(new Dimension(250, 80)); 
        bouton_l.setPreferredSize(new Dimension(200, 40));
        bouton_l.addActionListener(new RunListener());
        bouton.setBorder(BorderFactory.createLineBorder(Color.black));
        bouton_turbo.setPreferredSize(new Dimension(80, 25));
        bouton_turbo.addActionListener(new TurboListener());
        nb_turbo.setPreferredSize(new Dimension(110, 25));
        bouton.add(bouton_l);
        bouton.add(nb_turbo);
        bouton.add(bouton_turbo);
		panel1.add(bouton);
        
        
        this.getContentPane().add(panel1,BorderLayout.NORTH);
        
        

        
        ////////////////////////////////////////////////
        // panel2 : commandes principales
        panel2.setPreferredSize(new Dimension(1100, 150));
        panel2.setBorder(BorderFactory.createLineBorder(Color.black));
        
        

        nb_a.setPreferredSize(new Dimension(50, 50));
        nb_r.setPreferredSize(new Dimension(50, 50));
        
        JPanel controle=new JPanel();
        controle.setPreferredSize(new Dimension(400, 120));
        controle.setBorder(BorderFactory.createLineBorder(Color.black));
        

        
        bouton_pa.setPreferredSize(new Dimension(160, 50));
        bouton_ma.setPreferredSize(new Dimension(160, 50));
        bouton_pr.setPreferredSize(new Dimension(160, 50));
        bouton_mr.setPreferredSize(new Dimension(160, 50));
        
        bouton_pa.addActionListener(new pAgentListener());
        bouton_ma.addActionListener(new mAgentListener());
        bouton_pr.addActionListener(new pRessourceListener());
        bouton_mr.addActionListener(new mRessourceListener());
        
        controle.add(bouton_ma);
        controle.add(nb_a);
        controle.add(bouton_pa);
        controle.add(bouton_mr);
        controle.add(nb_r);
        controle.add(bouton_pr);
        
        panel2.add(controle);
        
        JPanel lecture=new JPanel();
        lecture.setPreferredSize(new Dimension(300, 120));
        lecture.setBorder(BorderFactory.createLineBorder(Color.black));
        
        framesPerSecond.setMajorTickSpacing(5000);
        framesPerSecond.setMinorTickSpacing(0);
        framesPerSecond.setPaintTicks(true);
        framesPerSecond.setPaintLabels(true);
        framesPerSecond.setPreferredSize(new Dimension(280, 45)); 
        
        bouton_s.setPreferredSize(new Dimension(80, 25));  
        bouton_s.addActionListener(new StepByStep());
		lecture.add(bouton_s,BorderLayout.SOUTH);

        
		bouton_p.setPreferredSize(new Dimension(80, 25));  
		bouton_p.addActionListener(new Run());
		lecture.add(bouton_p,BorderLayout.SOUTH);
		
		bouton_stop.setPreferredSize(new Dimension(80, 25));  
		bouton_stop.addActionListener(new Stop());
		lecture.add(bouton_stop,BorderLayout.SOUTH);
        
        lecture.add(framesPerSecond);
        com_etape.setPreferredSize(new Dimension(80, 15)); 
        etape.setPreferredSize(new Dimension(80, 15)); 
        lecture.add(com_etape);
        lecture.add(etape);

        bouton_h.setPreferredSize(new Dimension(120, 25));  
        bouton_h.addActionListener(new histogramme());
		lecture.add(bouton_h,BorderLayout.SOUTH);
        
        
		panel2.add(lecture);
			
		

		attract.setPreferredSize(new Dimension(300, 120));
		panel2.add(attract);
		
        this.getContentPane().add(panel2,BorderLayout.SOUTH);
        
        
        
        
        
        /////////////////////////////////////////////////
        // screens : affichage principal
        screens.setPreferredSize(new Dimension(1100, 510));
        screens.setBorder(BorderFactory.createLineBorder(Color.black));
        this.getContentPane().add(screens,BorderLayout.CENTER);
          
        
        bouton_pa.setEnabled(false);
        bouton_ma.setEnabled(false);
        bouton_pr.setEnabled(false);
        bouton_mr.setEnabled(false);
        
        bouton_s.setEnabled(false);
        bouton_p.setEnabled(false);
        bouton_stop.setEnabled(false);
        
        this.repaint();

        
    }
    
    
    
    
    
    
    
    
    public void addComponent(){
    	int nb_agents=(int)(Double.parseDouble(jtfnba.getText()));
    	int size=(int)Double.parseDouble(jtfsize.getText());
    	int nb_res=(int)(Double.parseDouble(jtfnbc.getText()));

        continuer=false;
    	
        bouton_pa.setEnabled(true);
        bouton_ma.setEnabled(true);
        bouton_pr.setEnabled(true);
        bouton_mr.setEnabled(true);
        
        bouton_s.setEnabled(true);
        bouton_p.setEnabled(true);
        bouton_stop.setEnabled(true);
    	
    	screens.removeAll();
    	listAgents=new ArrayList<agent>();
    	
        g=new grille(size,nb_res);
        m=new carte(size);
    	
        for (int i=0;i<nb_agents;i++){
      	  listAgents.add(new agent((int)(size/2),(int)(size/2),m,g,size));
        }

        panGrid=new panneau(g,listAgents,size);
        panCarte=new panMap(m,listAgents,size);
        
        panGrid.setPreferredSize(new Dimension(500, 500));
        panGrid.setBorder(BorderFactory.createLineBorder(Color.black));
        panCarte.setPreferredSize(new Dimension(500, 500));
        panCarte.setBorder(BorderFactory.createLineBorder(Color.black));
        
        screens.add(panGrid);
        screens.add(panCarte);
        this.getContentPane().add(screens,BorderLayout.CENTER);
        
        attract.removeAll();
        
		pl_x=new JSlider(JSlider.HORIZONTAL,
	            0, size, size/2);
		pl_x.addChangeListener(new LPListener());
		
		pl_y=new JSlider(JSlider.HORIZONTAL,
	            0, size, size/2);
		pl_y.addChangeListener(new LPListener());
		
		pl_r=new JSlider(JSlider.HORIZONTAL,
	            0, size*2, size/2);
		pl_r.addChangeListener(new LPListener());
		
		pl_f=new JSlider(JSlider.HORIZONTAL,
	            0, 500, 100);
		pl_f.addChangeListener(new LPListener());
		
		JLabel pos_x=new JLabel("position X");
		pos_x.setPreferredSize(new Dimension(80, 20));
		JLabel pos_y=new JLabel("position Y");
		pos_y.setPreferredSize(new Dimension(80, 20));
		JLabel pos_r=new JLabel("rayon d'action");
		pos_r.setPreferredSize(new Dimension(80, 20));
		JLabel pos_f=new JLabel("force");
		pos_f.setPreferredSize(new Dimension(80, 20));
		
		attract.add(pos_x);
		attract.add(pl_x);
		attract.add(pos_y);
		attract.add(pl_y);
		attract.add(pos_r);
		attract.add(pl_r);
		attract.add(pos_f);
		attract.add(pl_f);
		
		attract.setBorder(BorderFactory.createLineBorder(Color.black));
		
		panel2.add(attract);

        h=new Historique(listAgents.get(0));
    	wh=new WinHistorique(h);
        nb_a.setText(""+listAgents.size());
        nb_r.setText(""+g.nb);
        com_etape.setText(" etape : ");
        etape.setText(""+step);
        screens.updateUI();  
    }
    
    
    
    
    
    
    
    public void go(){
    	while (this.continuer){
    		for(int j=0;j<listAgents.size();j++){
    			(listAgents.get(j)).step(check1.isBorderPaintedFlat() ,check2.isBorderPaintedFlat());
    		}
    		m.evaporation();
    		screens.updateUI();
    		screens.repaint();
    		step++;
    		etape.setText(""+step);
            nb_r.setText(""+g.nb);
            h.upDate();
            wh.repaint();
            panel2.repaint();
    	    try {Thread.sleep((int)framesPerSecond .getValue());
    	    } catch (InterruptedException e) {}
    		
    	}
    }
    
    public void turbo(){
    	/*
        g=new grille((int)Double.parseDouble(jtfsize.getText()),(int)(Double.parseDouble(jtfnbc.getText())));
        m=new carte((int)Double.parseDouble(jtfsize.getText()));
        
        for (int i=0;i<Double.parseDouble(jtfnba.getText());i++){
      	  listAgents.add(new agent(25,25,m,g,(int)Double.parseDouble(jtfsize.getText())));
        }
        
        wm=new winMap(m,listAgents,(int)Double.parseDouble(jtfsize.getText()));
        f=new fenetre(g,listAgents,(int)Double.parseDouble(jtfsize.getText()));
*/
    	/*
    	addComponent();
        panGrid.repaint();
        panCarte.repaint();
		screens.updateUI();
		screens.repaint();
		
	    //try {Thread.sleep(1000);
		//} catch (InterruptedException e) {}

        for(int k=0;k<5000;k++){

        	for(int j=0;j<listAgents.size();j++){
        		(listAgents.get(j)).step(false,false);
        	}
        	
        	m.evaporation();
            panGrid.repaint();
            panCarte.repaint();
    		screens.updateUI();
    		screens.repaint();
    	
    	

        }*/
      
      for(int k=0;k<(int)Double.parseDouble(nb_turbo.getText());k++){

    	for(int j=0;j<listAgents.size();j++){
    		(listAgents.get(j)).step(false,false);
    	}
    	h.upDate();
		step++;
		etape.setText(""+step);
		m.evaporation();
      }
		screens.updateUI();
		screens.repaint();
		etape.setText(""+step);
        nb_r.setText(""+g.nb);
    }
    
    
    
	
	
    class RunListener implements ActionListener{
        public void actionPerformed(ActionEvent arg0) {
            addComponent();
        }
    }
    
    class TurboListener implements ActionListener{
        public void actionPerformed(ActionEvent arg0) {
              turbo();
        }
    }
    
    class pAgentListener implements ActionListener{
        public void actionPerformed(ActionEvent arg0) {
        	listAgents.add(new agent((int)size/2,(int)size/2,m,g,(int)Double.parseDouble(jtfsize.getText())));
            screens.updateUI();
            nb_a.setText(""+listAgents.size());
            nb_r.setText(""+g.nb);
        }
    }
    
    class mAgentListener implements ActionListener{
        public void actionPerformed(ActionEvent arg0) {
        	if(listAgents.size()>0){
        		listAgents.remove(listAgents.size()-1);
                screens.updateUI();
                nb_a.setText(""+listAgents.size());
                nb_r.setText(""+g.nb);
        	}
        }
    }
    
    class pRessourceListener implements ActionListener{
        public void actionPerformed(ActionEvent arg0) {
        	g.apparition();
            screens.updateUI();
            nb_a.setText(""+listAgents.size());
            nb_r.setText(""+g.nb);
        }
    }
    
    class mRessourceListener implements ActionListener{
        public void actionPerformed(ActionEvent arg0) {
        	g.disparition();
            screens.updateUI();
            nb_a.setText(""+listAgents.size());
            nb_r.setText(""+g.nb);
        }
    }
    
    class LPListener implements ChangeListener{
		public void stateChanged(ChangeEvent arg0) {
			m.blackHole((int)pl_x.getValue(), (int)pl_y.getValue(), (int)pl_r.getValue(),(int)pl_f.getValue());	
		    screens.updateUI();
			screens.repaint();
		}
    }
    
    
    class StepByStep implements ActionListener{
        public void actionPerformed(ActionEvent arg0) {
        	for(int j=0;j<listAgents.size();j++){
        		(listAgents.get(j)).step(check1.isBorderPaintedFlat() ,check2.isBorderPaintedFlat());
        	}
    		m.evaporation();
    		step++;
    		etape.setText(""+step);
    		screens.repaint();       
        }
    }
    
    
    class Run implements ActionListener{
        public void actionPerformed(ActionEvent arg0) {
            continuer=true;
            t = new Thread(new Play());
            t.start();
        	bouton_p.setEnabled(false);
        	bouton_s.setEnabled(false);
        }
    }
    
    class Stop implements ActionListener{
        public void actionPerformed(ActionEvent arg0) {
        	bouton_p.setEnabled(true);
        	bouton_s.setEnabled(true);
            continuer=false;
        }
    }
    
    
    class histogramme implements ActionListener{
        public void actionPerformed(ActionEvent arg0) {
        	runHistorique();
        }
    }
    
    
    class Play implements Runnable{
    	 
        public void run() {
                go();                   
        }               
    }
    
    public void runHistorique(){
    	wh=new WinHistorique(h);
    }

    
}

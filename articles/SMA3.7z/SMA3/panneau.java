


import java.awt.Graphics;
import java.util.ArrayList;
import java.awt.Color;


import javax.swing.JPanel;

 
public class panneau extends JPanel {
 
		public int[][] image;
		public ArrayList<agent> list;
        public int size=50;
        public panneau(grille grille,ArrayList<agent> la,int size){
              image=grille.g;
              list=la;
              this.size=size;
        }
	
        public void paintComponent(Graphics graph){

        	double x_size= this.getWidth()/(size-1);
        	double y_size= this.getHeight()/(size-1);
        	
            graph.setColor(Color.black);
        	
            if (size<100){
            	for(int i=1;i<size;i++){
            		graph.drawLine((int)(x_size*i), 0,(int)(x_size*i),this.getHeight() );
            		graph.drawLine(0, (int)(y_size*i),getWidth(),(int)(y_size*i) );
            	}
            }
            
            for(int i=0;i<size;i++){
            	for (int j=0;j<size;j++){
            		switch (image[i][j]){
            			case 1 : graph.setColor(Color.red);
            			         graph.fillOval((int)(i*x_size),(int)(j*y_size),(int)x_size,(int)y_size);
            			         break;
            			case 2 : graph.setColor(Color.blue);
            					graph.fillRect((int)(i*x_size),(int)(j*y_size),(int)x_size,(int)y_size);
            					break;
            			case 3 : graph.setColor(Color.green);
            				     graph.fillRoundRect((int)(i*x_size),(int)(j*y_size),(int)x_size,(int)y_size,5,5);
            				     break;
            			default : break;
            		}
            	}
            }
            
            for (int i=0;i<list.size();i++){
            	graph.setColor(Color.black);
            	graph.fillOval((int)((list.get(i).xa-0.85)*x_size),(int)((list.get(i).ya-0.85)*y_size),(int)(x_size/1.2),(int)(y_size/1.2));
        		
            	switch (list.get(i).prise){
    			case 1 : graph.setColor(Color.red);
    			         graph.fillOval((int)((list.get(i).xa-0.6)*x_size),(int)((list.get(i).ya-0.6)*y_size),(int)(x_size/3),(int)(y_size/3));
    			         break;
    			case 2 : graph.setColor(Color.blue);
    					graph.fillRect((int)((list.get(i).xa-0.6)*x_size),(int)((list.get(i).ya-0.6)*y_size),(int)(x_size/3),(int)(y_size/3));
    					break;
    			case 3 : graph.setColor(Color.green);
    				     graph.fillRoundRect((int)((list.get(i).xa-0.6)*x_size),(int)((list.get(i).ya-0.6)*y_size),(int)(x_size/3),(int)(y_size/3),2,2);
    				     break;
    			default : break;
    		}
            }
        	
        }   
        
}



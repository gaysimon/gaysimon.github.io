
import java.util.ArrayList;

import javax.swing.JFrame;
 
public class winMap extends JFrame {
 
        public winMap(carte n_f,ArrayList<agent> la,int size){
                
                this.setSize(600, 600);
                this.setLocationRelativeTo(null);               
                this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                
                this.setVisible(true);           
                this.setContentPane(new panMap(n_f,la,size));
                

        }
        
}
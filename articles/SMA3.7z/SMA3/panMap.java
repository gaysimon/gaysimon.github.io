

import java.awt.Graphics;
import java.util.ArrayList;
import java.awt.Color;


import javax.swing.JPanel;

 
public class panMap extends JPanel {
 
		public int[][][] image;
        public int size=50;
        public ArrayList<agent> list;
		
        public panMap(carte carte,ArrayList<agent> la,int size){
              image=carte.map;
              list=la;
              this.size=size;
        }
	
        public void paintComponent(Graphics graph){

        	double x_size= this.getWidth()/(size-1);
        	double y_size= this.getHeight()/(size-1);
        	

        	
            for(int i=0;i<size;i++){
            	for (int j=0;j<size;j++){
            		graph.setColor(new Color(250,250,Math.max(0,250-image[i][j][11]*5)));
            		graph.fillRect((int)((i-1)*x_size),(int)((j-1)*y_size),(int)x_size,(int)y_size);
            	}
            }
            
            graph.setColor(Color.black);
            
            if(size<100){
            	for(int i=1;i<size;i++){
            		graph.drawLine((int)(x_size*i), 0,(int)(x_size*i),this.getHeight() );
            		graph.drawLine(0, (int)(y_size*i),getWidth(),(int)(y_size*i) );
            	}
            }

            
            
            for(int i=0;i<size;i++){
            	for (int j=0;j<size;j++){

            		
            		if ((image[i][j][8]>=image[i][j][9])&&
            			(image[i][j][8]>=image[i][j][10])){
            			
            			if (image[i][j][8]>10){
            				graph.setColor(new Color(255,Math.max(0,160-image[i][j][8]/50),Math.max(0,160-image[i][j][8]/50)));
            				graph.fillRect((int)((i-1)*x_size),(int)((j-1)*y_size),(int)x_size,(int)y_size);
            			}
            		}
            		else{
                		if (image[i][j][9]>=image[i][j][10]){
                			if (image[i][j][9]>10){
                				graph.setColor(new Color(Math.max(0,160-image[i][j][9]/50),Math.max(0,160-image[i][j][9]/50),255));
                				graph.fillRect((int)((i-1)*x_size),(int)((j-1)*y_size),(int)x_size,(int)y_size);
                 			}
                		}
                		else{
                			if (image[i][j][10]>10){
                				graph.setColor(new Color(Math.max(0,150-image[i][j][10]/50),255,Math.max(0,160-image[i][j][10]/50)));
                				graph.fillRect((int)((i-1)*x_size),(int)((j-1)*y_size),(int)x_size,(int)y_size);
                 			}
                		}
            		}

            	}
            }
            
    		graph.setColor(Color.black);
            for(int i=0;i<size;i++){
            	for (int j=0;j<size;j++){

            		if (image[i][j][0]>0){
            			graph.drawLine( (int)(x_size*(i-1)-(x_size/2)),(int)(y_size*(j-1)+(y_size/2)),
				                 (int)(x_size*(i-1)+(x_size/2)),(int)(y_size*(j-1)+(y_size/2)));
            		}
            		if (image[i][j][1]>0){
            			graph.drawLine( (int)(x_size*(i-1)-(x_size/2)),(int)(y_size*j+(y_size/2)),
				                 (int)(x_size*(i-1)+(x_size/2)),(int)(y_size*(j-1)+(y_size/2)));
            		}
            		
            		if (image[i][j][2]>0){
            			graph.drawLine( (int)(x_size*(i-1)+(x_size/2)),(int)(y_size*(j-1)+(y_size/2)),
				                 (int)(x_size*(i-1)+(x_size/2)),(int)(y_size*j+(y_size/2)));
            		}
            		
            		if (image[i][j][3]>0){
            			graph.drawLine( (int)(x_size*(i-1)+(x_size/2)),    (int)(y_size*(j-1)+(y_size/2)),
				                 (int)(x_size*i+(x_size/2)),(int)(y_size*j+(y_size/2)));
            		}
            		
            		if (image[i][j][4]>0){
            			graph.drawLine( (int)(x_size*(i-1)+(x_size/2)),    (int)(y_size*(j-1)+(x_size/2)),
				                 (int)(x_size*i+(x_size/2)),(int)(y_size*(j-1)+(x_size/2)));
            		}
            		
            		if (image[i][j][5]>0){
            			graph.drawLine( (int)(x_size*(i-1)+(x_size/2)),    (int)(y_size*(j-1)+(y_size/2)),
				                 (int)(x_size*i+(x_size/2)),(int)(y_size*(j-1)-(y_size/2)));
            		}
            		
            		if (image[i][j][6]>0){
            			graph.drawLine( (int)(x_size*(i-1)+(x_size/2)),(int)(y_size*(j-1)+(x_size/2)),
				                 (int)(x_size*(i-1)+(x_size/2)),(int)(y_size*(j-1)-(x_size/2)));
            		}
            		
            		if (image[i][j][7]>0){
            			graph.drawLine( (int)(x_size*(i-1)-(x_size/2)),(int)(y_size*(j-1)-(y_size/2)),
				                 (int)(x_size*(i-1)+(x_size/2)),(int)(y_size*(j-1)+(y_size/2)));
            		}
            		
            		
            		
            	}
            	
            } 
    		graph.setColor(Color.black);
        	for (int i=0;i<list.size();i++){
        		graph.fillOval((int)((list.get(i).xa-0.85)*x_size),(int)((list.get(i).ya+-0.85)*y_size),(int)(x_size/1.2),(int)(y_size/1.2));
        	}
        }
}



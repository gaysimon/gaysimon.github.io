import java.util.*;

public class grille{

	public int size;
    public int[][] g;
    Random generator = new Random();
    public int nb;
    
    public grille(int size,int nb_ressources){
         int i=0;
         int j=0;
         int x;
         int y;
         int type;
         this.nb=nb_ressources;

         this.size=size;
         g= new int[size][size];
         
         for(i=0;i<size;i++){
            for(j=0;j<size;j++){
                g[i][j]=0;
            }
         }

         for(i=0;i<nb;i++){
                 x = generator.nextInt( size );
                 y = generator.nextInt( size );
                 type = generator.nextInt( 3 )+1;

                 while ( g[x][y] != 0){
                       x = generator.nextInt( size );
                       y = generator.nextInt( size );
                 }
                 g[x][y]=type;
         }
    }


    public void prendre(int x,int y){
           g[x][y]=0;
           nb--;
    }

    public void deposer(int x,int y,int type){
           g[x][y]=type;
           nb++;
    }

    public int voisins(int x,int y,int type){
           
          int nb=0;

          if ((x>0)&&(g[x-1][y]==type)){
                 nb++;
          }
          if ((x<size-1)&&(g[x+1][y]==type)){
                 nb++;
          }
          if ((y>0)&&(g[x][y-1]==type)){
                 nb++;
          }
          if ((y<size-1)&&(g[x][y+1]==type)){
                 nb++;
          }      
          if ((x>0)&&(y>0)&&(g[x-1][y-1]==type)){
                 nb++;
          }
          if ((x>0)&&(y<size-1)&&(g[x-1][y+1]==type)){
                 nb++;
              }
          if ((x<size-1)&&(y>0)&&(g[x+1][y-1]==type)){
                 nb++;
          }
          if ((x<size-1)&&(y<size-1)&&(g[x+1][y+1]==type)){
                 nb++;
          }
          return nb;
      }


      public void afficher(){
          int i,j;
          for(i=0;i<size;i++){
              for(j=0;j<size;j++){
                 System.out.print( g[i][j] + " ");
              }
              System.out.println();
           }
      }
      
      
      public void disparition(){
          int x = generator.nextInt( size );
          int y = generator.nextInt( size );
          if (nb>0){
        	  while ( g[x][y] == 0){
        		  x = generator.nextInt( size );
        		  y = generator.nextInt( size );
        	  }
        	  g[x][y]=0;
              nb--;
          }
      }
      
      public void apparition(){
    	  int type=generator.nextInt( 3 )+1;
          int x = generator.nextInt( size );
          int y = generator.nextInt( size );

          while ( g[x][y] != 0){
                x = generator.nextInt( size );
                y = generator.nextInt( size );
          }
          g[x][y]=type;
          nb++;
      }


}

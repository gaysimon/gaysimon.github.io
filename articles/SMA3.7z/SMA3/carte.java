import java.lang.Math;


	public class carte{
        public int size;
	    public int[][][] map;

	    
	    public carte(int size){
	         int i=0;
	         int j=0;
             this.size=size;
             map= new int[size][size][12];
	         for(i=0;i<size;i++){
	            for(j=0;j<size;j++){
	                map[i][j][0]=0;
	                map[i][j][1]=0;
	                map[i][j][2]=0;
	                map[i][j][3]=0;
	                map[i][j][4]=0;
	                map[i][j][5]=0;
	                map[i][j][6]=0;
	                map[i][j][7]=0;
	                map[i][j][8]=0;
	                map[i][j][9]=0;
	                map[i][j][10]=0;
	                
	                map[i][j][11]=0;
	                
	            }
	         }
	    }

        public void marquer(int marque,int sens,int x,int y,int type){
        	if(sens>=0){
        	    map[x][y][sens]=30;
        	}
        	if(map[x][y][8]<=5*marque){
        		map[x][y][7+type]+=marque;
        	}
        }

	      public void afficher(){
	          int i,j;
	          for(i=0;i<size;i++){
	              for(j=0;j<size;j++){

	                 System.out.print( map[i][j][11]);
	                 if (map[i][j][11]<10){
	                	 System.out.print("  ");
	                 }
	                 else{
	                	 System.out.print(" ");
	                 }
	              }
	              System.out.println();
	           }
	      }
	      
	      public void evaporation(){
	          for(int i=0;i<size;i++){
	              for(int j=0;j<size;j++){
                     for(int k=0;k<11;k++){
                    	 if (map[i][j][k]>0){
                    		 map[i][j][k]--;
                    	 }
                     }
	              }
	           }
	      }
	      
	      
	      public void blackHole(int x,int y, int r,int force){
	    	  int d;
	    	  for(int i=0;i<size;i++){
	    		  for(int j=0;j<size;j++){
	    			  d= (int)Math.sqrt( (double)((x-i)*(x-i) + (y-j)*(y-j) ));
	    			  if ( d<=r ){
	    				  if (d!=0){
	    				     map[i][j][11]=force/d;
	    				  }
		    			  else{
		    				  map[i][j][11]=force; 
		    			  }
	    			  }
	    			  else{
	    				  map[i][j][11]=0;
	    			  }

	    		  }
	    	  }
	      }


	}

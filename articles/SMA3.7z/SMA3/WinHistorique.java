import java.util.ArrayList;

import javax.swing.JFrame;


public class WinHistorique extends JFrame{

    public WinHistorique(Historique h){
        
        this.setSize(400, 400);
        this.setLocationRelativeTo(null);               
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        this.setVisible(true);           
        this.setContentPane(new panHistorique(h));
        

}
	
}

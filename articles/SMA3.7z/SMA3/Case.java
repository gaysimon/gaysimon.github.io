
public class Case {

	public int x;
	public int y;
	public int action;
	
	public Case(int x,int y,int a){
		this.x=x;
		this.y=y;
		this.action=a;
	}
	
	public void afficher(){
		System.out.print(" ("+x+", "+y+", "+action+")");
	}
	
}


import java.awt.Graphics;
import java.util.ArrayList;
import java.awt.Color;


import javax.swing.JPanel;


public class panHistorique extends JPanel{

	
	Historique h;
	
	public panHistorique(Historique h){
		this.h=h;
	}
	
    public void paintComponent(Graphics graph){
    	
    	
    	double y_size=this.getHeight()/5;
    	double x_size=this.getWidth()/10;
    	
    	
		graph.setColor(Color.RED);
    	for(int i=0;i<4;i++){
			graph.drawLine(0,(int)(y_size*(i+1)*1.1),this.getWidth(),(int)(y_size*(i+1)*1.1));
			graph.drawLine(0,(int)(y_size*(i+1)*1.1)-10,this.getWidth(),(int)(y_size*(i+1)*1.1)-10);
			graph.drawLine(0,(int)(y_size*(i+1)*1.1)-20,this.getWidth(),(int)(y_size*(i+1)*1.1)-20);
			graph.drawLine(0,(int)(y_size*(i+1)*1.1)-30,this.getWidth(),(int)(y_size*(i+1)*1.1)-30);
			graph.drawLine(0,(int)(y_size*(i+1)*1.1)-40,this.getWidth(),(int)(y_size*(i+1)*1.1)-40);
			graph.drawLine(0,(int)(y_size*(i+1)*1.1)-50,this.getWidth(),(int)(y_size*(i+1)*1.1)-50);
    	}
    	
		graph.setColor(Color.BLACK);
    	for(int i=0;i<10;i++){
			graph.fillRect((int)(x_size*i+x_size/11),(int)(y_size*1.1-Math.min(y_size,(h.prise[i]/10))),(int)(x_size*0.8),(int)Math.min(y_size,(h.prise[i]/10)));
    	}
    	
    	for(int i=0;i<10;i++){
			graph.fillRect((int)(x_size*i+x_size/11),(int)(y_size*2.2-Math.min(y_size,(h.pose[i]/10))),(int)(x_size*0.8),(int)Math.min(y_size,(h.pose[i]/10)));
    	}
    	
    	for(int i=0;i<10;i++){
			graph.fillRect((int)(x_size*i+x_size/11),(int)(y_size*3.3-Math.min(y_size,(h.charge[i]/10))),(int)(x_size*0.8),(int)Math.min(y_size,(h.charge[i]/10)));
    	}
    	
    	for(int i=0;i<10;i++){
			graph.fillRect((int)(x_size*i+x_size/11),(int)(y_size*4.4-Math.min(y_size,(h.vide[i]/10))),(int)(x_size*0.8),(int)Math.min(y_size,(h.vide[i]/10)));
    	}
    	
    }
	
	
}

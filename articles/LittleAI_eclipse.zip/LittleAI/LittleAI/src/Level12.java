import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Polygon;



public class Level12 extends Level{

	int target_x;
	int target_y;
	
	int eat_count=0;
	
	public Level12(){
		
		// interaction properties
		nbActions=3;
		nbInteraction=14;
		
		actionMap=new int[nbInteraction];
		actionMap[0]=0;			// left
		actionMap[1]=1;			// forward
		actionMap[2]=1;			// bump
		actionMap[3]=1;			// eat
		actionMap[4]=2;			// right
		
		actionMap[5]=0;			// appear when left
		actionMap[6]=0;			// disappear when left
		actionMap[7]=0;			// closer when left
		
		actionMap[8]=1;			// appear when forward
		actionMap[9]=1;			// disappear when forward
		actionMap[10]=1;		// closer when forward
		
		actionMap[11]=2;		// appear when right
		actionMap[12]=2;		// disappear when right
		actionMap[13]=2;		// closer when right
		
		valence=new int[nbInteraction];
		valence[0]=-2;
		valence[1]=3;
		valence[2]=-5;
		valence[3]=10;
		valence[4]=-2;
		
		valence[5]=1;
		valence[6]=-1;
		valence[7]=2;
		
		valence[8]=1;
		valence[9]=-1;
		valence[10]=2;
		
		valence[11]=1;
		valence[12]=-1;
		valence[13]=2;
		
		// size of the panel
		panel_width=3;
		panel_height=1;
		
		// default shapes and colors
		shapes=new int[nbActions];
		for (int i=0;i<nbActions;i++) shapes[i]=0;
		
		colors=new int[nbInteraction];
		for (int i=0;i<nbInteraction;i++) colors[i]=0;
		
		//define world
		world=new int[10][10];
		world[0][0]=1;world[1][0]=1;world[2][0]=1;world[3][0]=1;world[4][0]=1;world[5][0]=1;world[6][0]=1;world[7][0]=1;world[8][0]=1;world[9][0]=1;
		world[0][1]=1;world[1][1]=0;world[2][1]=0;world[3][1]=0;world[4][1]=0;world[5][1]=0;world[6][1]=0;world[7][1]=0;world[8][1]=0;world[9][1]=1;
		world[0][2]=1;world[1][2]=0;world[2][2]=0;world[3][2]=0;world[4][2]=0;world[5][2]=0;world[6][2]=0;world[7][2]=0;world[8][2]=0;world[9][2]=1;
		world[0][3]=1;world[1][3]=0;world[2][3]=0;world[3][3]=0;world[4][3]=0;world[5][3]=0;world[6][3]=0;world[7][3]=0;world[8][3]=0;world[9][3]=1;
		world[0][4]=1;world[1][4]=0;world[2][4]=0;world[3][4]=0;world[4][4]=0;world[5][4]=0;world[6][4]=0;world[7][4]=0;world[8][4]=0;world[9][4]=1;
		world[0][5]=1;world[1][5]=0;world[2][5]=0;world[3][5]=0;world[4][5]=0;world[5][5]=0;world[6][5]=0;world[7][5]=0;world[8][5]=0;world[9][5]=1;
		world[0][6]=1;world[1][6]=0;world[2][6]=0;world[3][6]=0;world[4][6]=0;world[5][6]=0;world[6][6]=0;world[7][6]=0;world[8][6]=0;world[9][6]=1;
		world[0][7]=1;world[1][7]=0;world[2][7]=0;world[3][7]=0;world[4][7]=0;world[5][7]=0;world[6][7]=0;world[7][7]=0;world[8][7]=0;world[9][7]=1;
		world[0][8]=1;world[1][8]=0;world[2][8]=0;world[3][8]=0;world[4][8]=0;world[5][8]=0;world[6][8]=0;world[7][8]=0;world[8][8]=0;world[9][8]=1;
		world[0][9]=1;world[1][9]=1;world[2][9]=1;world[3][9]=1;world[4][9]=1;world[5][9]=1;world[6][9]=1;world[7][9]=1;world[8][9]=1;world[9][9]=1;
		
		// set target
		target_x=6;
		target_y=4;
		world[target_x][target_y]=2;
		
		// default position of agent
		px=4;
		py=7;
		theta=0;
	}
	
	
	//////////////////////////////////////////////////////
	// world properties
	public void action(int a){
		int[] ret=new int[3];
		
		ret[0]=-1;
		ret[1]=-1;
		ret[2]=-1;
		
		color=Color.orange;
		
		boolean touch=false;
		
		
		
		// movement actions
		if (a==1){
				
			if (theta>=  Math.PI/4 && theta<3*Math.PI/4){ if (world[(int)px+1][(int)py]==1) touch=true;}
			if (theta>=5*Math.PI/4 && theta<7*Math.PI/4){ if (world[(int)px-1][(int)py]==1) touch=true;}
			if (theta>=7*Math.PI/4 || theta<  Math.PI/4){ if (world[(int)px][(int)py-1]==1) touch=true;}
			if (theta>=3*Math.PI/4 && theta<5*Math.PI/4){ if (world[(int)px][(int)py+1]==1) touch=true;}
			
			if (touch){	// bump
				ret[0]=2;
				color=Color.red;
			}
			else{
				px+=  Math.sin(theta);
				py+= -Math.cos(theta);
				
				px=Math.round(px);
				py=Math.round(py);
				
				// detect eat
				if (px==target_x && py==target_y){
					world[target_x][target_y]=0;
					while (px==target_x && py==target_y){
						target_x=(int)(Math.random()*(world.length-2))+1;
						target_y=(int)(Math.random()*(world[0].length-2))+1;
					}
					world[target_x][target_y]=2;
					ret[0]=3;  // eat
					eat_count++;
				}
				else{
					ret[0]=1; // move forward
					
					// relative position of the target
					int dx=0;
					int dy=0;
					
					if (theta>=  Math.PI/4 && theta<3*Math.PI/4){
						dx=(int)(target_y-py);
						dy=(int)(target_x-px);
					}
					if (theta>=5*Math.PI/4 && theta<7*Math.PI/4){
						dx=(int)(-target_y+py);
						dy=(int)(-target_x+px);
					}
					if (theta>=7*Math.PI/4 || theta<  Math.PI/4){
						dx=(int)(target_x-px);
						dy=(int)(-target_y+py);
					}
					if (theta>=3*Math.PI/4 && theta<5*Math.PI/4){
						dx=(int)(-target_x+px);
						dy=(int)(target_y-py);
					}
					
					if (dx<=0 && dy>=0) ret[1]=10;
					if (dx>=0 && dy>=0) ret[2]=10;
					
					if (dx<=0 && dy==-1) ret[1]=9;
					if (dx>=0 && dy==-1) ret[2]=9;
				}
			}
		}
		if (a==0){
			theta-=Math.PI/2;
			ret[0]=0;
			
			// relative position of the target
			int dx=0;
			int dy=0;
			
			if (theta>=  Math.PI/4 && theta<3*Math.PI/4){
				dx=(int)(target_y-py);
				dy=(int)(target_x-px);
			}
			if (theta>=5*Math.PI/4 && theta<7*Math.PI/4){
				dx=(int)(-target_y+py);
				dy=(int)(-target_x+px);
			}
			if (theta>=7*Math.PI/4 || theta<  Math.PI/4){
				dx=(int)(target_x-px);
				dy=(int)(-target_y+py);
			}
			if (theta>=3*Math.PI/4 && theta<5*Math.PI/4){
				dx=(int)(-target_x+px);
				dy=(int)(target_y-py);
			}
			
			if (dx<0 && dy>=0) ret[1]=5;
			if (dx>=0 && dy>0) ret[2]=5;
			
			if (dx>0 && dy>=0) ret[1]=6;
			if (dx>=0 && dy<0) ret[2]=6;
		}
		if (a==2){
			theta+=Math.PI/2;
			ret[0]=4;
			
			// relative position of the target
			int dx=0;
			int dy=0;
			
			if (theta>=  Math.PI/4 && theta<3*Math.PI/4){
				dx=(int)(target_y-py);
				dy=(int)(target_x-px);
			}
			if (theta>=5*Math.PI/4 && theta<7*Math.PI/4){
				dx=(int)(-target_y+py);
				dy=(int)(-target_x+px);
			}
			if (theta>=7*Math.PI/4 || theta<  Math.PI/4){
				dx=(int)(target_x-px);
				dy=(int)(-target_y+py);
			}
			if (theta>=3*Math.PI/4 && theta<5*Math.PI/4){
				dx=(int)(-target_x+px);
				dy=(int)(target_y-py);
			}
			
			if (dx<=0 && dy>0) ret[1]=11;
			if (dx>0 && dy>=0) ret[2]=11;
			
			if (dx<=0 && dy<0) ret[1]=12;
			if (dx<0 && dy>=0) ret[2]=12;
		}
		
		if (theta<0) theta+=2*Math.PI;
		if (theta>=2*Math.PI) theta-=2*Math.PI;

		push(ret);
	}
	
	public boolean solved(){

		return eat_count>=3;
	}
	
	
	//////////////////////////////////////////
	// draw agent
	public void drawAgent(Graphics2D g, float x, float y, int width){
		
		double cos=Math.cos(theta);
		double sin=Math.sin(theta);
		
		g.setColor(color);
		Polygon agent=new Polygon();

		agent.addPoint( (int)(                   width*0.5f*sin) , (int)(                - width*0.5f*cos));
		agent.addPoint( (int)(width*0.35f*cos  - width*0.45f*sin), (int)(width*0.35f*sin + width*0.45f*cos));
		agent.addPoint( (int)(                 - width*0.3f*sin) , (int)(                  width*0.3f*cos));
		agent.addPoint( (int)(-width*0.35f*cos - width*0.45f*sin), (int)(-width*0.35f*sin + width*0.45f*cos));
		
		agent.translate((int)x+width/2, (int)y+width/2);
		
		g.fillPolygon(agent);
		
		g.setColor(Color.black);
		g.drawPolygon(agent);
	}
}

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Polygon;



public class Level11 extends Level{

	boolean[] sensors;
	
	public Level11(){
		
		// interaction properties
		nbActions=6;
		nbInteraction=10;
		
		actionMap=new int[nbInteraction];
		actionMap[0]=0;			// touch left empty
		actionMap[1]=0;			// touch left wall
		actionMap[2]=1;			// touch front empty
		actionMap[3]=1;			// touch front wall
		actionMap[4]=2;			// touch right empty
		actionMap[5]=2;			// touch right wall
		
		actionMap[6]=3;			// left
		actionMap[7]=4;			// forward
		actionMap[8]=4;			// bump
		actionMap[9]=5;			// right
		
		valence=new int[nbInteraction];
		valence[0]=-1;
		valence[1]=-2;
		valence[2]=-1;
		valence[3]=-2;
		valence[4]=-1;
		valence[5]=-2;
		
		valence[6]=-2;
		valence[7]=5;
		valence[8]=-10;
		valence[9]=-2;
		
		// size of the panel
		panel_width=3;
		panel_height=2;
		
		// default shapes and colors
		shapes=new int[nbActions];
		for (int i=0;i<nbActions;i++) shapes[i]=0;
		
		colors=new int[nbInteraction];
		for (int i=0;i<nbInteraction;i++) colors[i]=0;
		
		//define world
		world=new int[6][6];
		world[0][0]=1;world[1][0]=1;world[2][0]=1;world[3][0]=1;world[4][0]=1;world[5][0]=1;
		world[0][1]=1;world[1][1]=0;world[2][1]=0;world[3][1]=0;world[4][1]=1;world[5][1]=1;
		world[0][2]=1;world[1][2]=0;world[2][2]=1;world[3][2]=0;world[4][2]=0;world[5][2]=1;
		world[0][3]=1;world[1][3]=0;world[2][3]=1;world[3][3]=1;world[4][3]=0;world[5][3]=1;
		world[0][4]=1;world[1][4]=0;world[2][4]=0;world[3][4]=0;world[4][4]=0;world[5][4]=1;
		world[0][5]=1;world[1][5]=1;world[2][5]=1;world[3][5]=1;world[4][5]=1;world[5][5]=1;
		
		// default position of agent
		px=1;
		py=4;
		theta=0;
		
		sensors=new boolean[3];
		for (int i=0;i<3;i++) sensors[i]=false;
	}
	
	
	//////////////////////////////////////////////////////
	// world properties
	public void action(int a){
		int[] ret=new int[1];
		
		for (int i=0;i<3;i++) sensors[i]=false;
		color=Color.orange;
		
		boolean touch=false;
		
		
		// touch action
		if (a<3){
			if (a==2){                    // feel right
				if (theta>=  Math.PI/4 && theta<3*Math.PI/4){ if (world[(int)px][(int)py+1]==1) touch=true;}
				if (theta>=5*Math.PI/4 && theta<7*Math.PI/4){ if (world[(int)px][(int)py-1]==1) touch=true;}
				if (theta>=7*Math.PI/4 || theta<  Math.PI/4){ if (world[(int)px+1][(int)py]==1) touch=true;}
				if (theta>=3*Math.PI/4 && theta<5*Math.PI/4){ if (world[(int)px-1][(int)py]==1) touch=true;}
			}
			if (a==0){                    // feel left
				if (theta>=  Math.PI/4 && theta<3*Math.PI/4){ if (world[(int)px][(int)py-1]==1) touch=true;}
				if (theta>=5*Math.PI/4 && theta<7*Math.PI/4){ if (world[(int)px][(int)py+1]==1) touch=true;}
				if (theta>=7*Math.PI/4 || theta<  Math.PI/4){ if (world[(int)px-1][(int)py]==1) touch=true;}
				if (theta>=3*Math.PI/4 && theta<5*Math.PI/4){ if (world[(int)px+1][(int)py]==1) touch=true;}
			}
			if (a==1){                    // feel front
				if (theta>=  Math.PI/4 && theta<3*Math.PI/4){ if (world[(int)px+1][(int)py]==1) touch=true;}
				if (theta>=5*Math.PI/4 && theta<7*Math.PI/4){ if (world[(int)px-1][(int)py]==1) touch=true;}
				if (theta>=7*Math.PI/4 || theta<  Math.PI/4){ if (world[(int)px][(int)py-1]==1) touch=true;}
				if (theta>=3*Math.PI/4 && theta<5*Math.PI/4){ if (world[(int)px][(int)py+1]==1) touch=true;}
			}
			
			if (touch){
				sensors[a]=true;
				ret[0]=a*2+1;
			}
			else ret[0]=a*2;
		}
		// movement actions
		else{
			
			if (a==4){
				
				if (theta>=  Math.PI/4 && theta<3*Math.PI/4){ if (world[(int)px+1][(int)py]==1) touch=true;}
				if (theta>=5*Math.PI/4 && theta<7*Math.PI/4){ if (world[(int)px-1][(int)py]==1) touch=true;}
				if (theta>=7*Math.PI/4 || theta<  Math.PI/4){ if (world[(int)px][(int)py-1]==1) touch=true;}
				if (theta>=3*Math.PI/4 && theta<5*Math.PI/4){ if (world[(int)px][(int)py+1]==1) touch=true;}
				
				if (touch){
					ret[0]=8;
					color=Color.red;
				}
				else{
					px+=  Math.sin(theta);
					py+= -Math.cos(theta);
					
					px=Math.round(px);
					py=Math.round(py);
					ret[0]=7;
				}
			}
			if (a==3){
				theta-=Math.PI/2;
				ret[0]=6;
			}
			if (a==5){
				theta+=Math.PI/2;
				ret[0]=9;
			}
			
			if (theta<0) theta+=2*Math.PI;
			if (theta>=2*Math.PI) theta-=2*Math.PI;
			
		}
		
		push(ret);
	}
	
	public boolean solved(){
		int counter=0;
		if (timeline[timeline.length-1][0]==-1) return false;
		for (int l=0;l<timeline.length;l++){
			if (timeline[l][0]==8) return false;
			if (timeline[l][0]==7) counter++;
		}
		
		return counter>2;
	}
	
	
	//////////////////////////////////////////
	// draw agent
	public void drawAgent(Graphics2D g, float x, float y, int width){
		
		double cos=Math.cos(theta);
		double sin=Math.sin(theta);
		
		g.setColor(color);
		Polygon agent=new Polygon();

		agent.addPoint( (int)(                   width*0.5f*sin) , (int)(                - width*0.5f*cos));
		agent.addPoint( (int)(width*0.35f*cos  - width*0.45f*sin), (int)(width*0.35f*sin + width*0.45f*cos));
		agent.addPoint( (int)(                 - width*0.3f*sin) , (int)(                  width*0.3f*cos));
		agent.addPoint( (int)(-width*0.35f*cos - width*0.45f*sin), (int)(-width*0.35f*sin + width*0.45f*cos));
		
		agent.translate((int)x+width/2, (int)y+width/2);
		
		g.fillPolygon(agent);
		
		g.setColor(Color.black);
		g.drawPolygon(agent);
		
		//draw touch actions
		if (timeline[0][0]==2 || timeline[0][0]==3){
			if (timeline[0][0]==3) // touch front wall
				g.setColor(Color.green);
			else
				g.setColor(Color.white);
			g.fillRect((int)(x+width/2 - (0.1*width) +width*Math.sin(theta)/2),
					   (int)(y+width/2 - (0.1*width) -width*Math.cos(theta)/2),
					   (int)(0.2*width),(int)(0.2*width));
			
			g.setColor(Color.black);
			g.drawRect((int)(x+width/2 - (0.1*width) +width*Math.sin(theta)/2),
					   (int)(y+width/2 - (0.1*width) -width*Math.cos(theta)/2),
					   (int)(0.2*width),(int)(0.2*width));
		}
		
		if (timeline[0][0]==0 || timeline[0][0]==1){
			if (timeline[0][0]==1) // touch left wall
				g.setColor(Color.green);
			else
				g.setColor(Color.white);
			g.fillRect((int)(x+width/2 - (0.1*width) -width*Math.cos(theta)/2),
					   (int)(y+width/2 - (0.1*width) -width*Math.sin(theta)/2),
					   (int)(0.2*width),(int)(0.2*width));
			
			g.setColor(Color.black);
			g.drawRect((int)(x+width/2 - (0.1*width) -width*Math.cos(theta)/2),
					   (int)(y+width/2 - (0.1*width) -width*Math.sin(theta)/2),
					   (int)(0.2*width),(int)(0.2*width));
		}
		
		if (timeline[0][0]==4 || timeline[0][0]==5){
			if (timeline[0][0]==5) // touch right wall
				g.setColor(Color.green);
			else
				g.setColor(Color.white);
			g.fillRect((int)(x+width/2 - (0.1*width) +width*Math.cos(theta)/2),
					   (int)(y+width/2 - (0.1*width) -width*Math.sin(-theta)/2),
					   (int)(0.2*width),(int)(0.2*width));
			
			g.setColor(Color.black);
			g.drawRect((int)(x+width/2 - (0.1*width) +width*Math.cos(theta)/2),
					   (int)(y+width/2 - (0.1*width) -width*Math.sin(-theta)/2),
					   (int)(0.2*width),(int)(0.2*width));
		}
	}
}

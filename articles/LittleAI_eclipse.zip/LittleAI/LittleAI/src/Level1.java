import java.awt.Color;



public class Level1 extends Level{

	
	public Level1(){
		
		// interaction properties
		nbActions=2;
		nbInteraction=2;
		
		actionMap=new int[nbInteraction];
		actionMap[0]=0;
		actionMap[1]=1;
		
		valence=new int[nbInteraction];
		valence[0]=1;
		valence[1]=-1;
		
		// size of the panel
		panel_width=2;
		panel_height=1;
		
		// default shapes and colors
		shapes=new int[nbActions];
		shapes[0]=0;
		shapes[1]=1;
		
		colors=new int[nbInteraction];
		for (int i=0;i<nbInteraction;i++) colors[i]=0;
		
		//define world
		world=new int[1][1];
		world[0][0]=0;
		
		// default position of agent
		px=0;
		py=0;
		theta=0;
	}
	
	
	//////////////////////////////////////////////////////
	// world properties
	public void action(int a){
		int[] ret=new int[1];
		ret[0]=a;
		if (a==0) color=Color.yellow;
		else color=Color.DARK_GRAY;
		push(ret);
	}
	
	public boolean solved(){
		return sum==10;
	}
}

package decision;

import platform.Agent;

/**
 * A generic class of decisional system
 * @author simon
 */
public class Decision {

	Agent agent;
	
	public Decision(Agent a){
		agent=a;
	}
	
	// define the list of sensors needed for this decision system
	public void defineSensors(){
	
	}
	
	// get the interaction to enact
	public double[] decision(float[] enacted){
		return null;
	}
}

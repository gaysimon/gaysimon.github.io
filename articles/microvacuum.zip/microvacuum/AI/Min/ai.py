""" A minimal ai module example """

from random import randint

class AI(object):
	""" PRI module example
	name : identifier for the module
	self.robot : pointer to interface with environment
	self.env   : pointer to the environment """


	name="Min"

	def __init__(self, robot,matrix):
		self.robot=robot
		self.env=matrix

	def intend(self):
		""" interact with environment
		in this example, the next action is randomly selected """
		r=randint(0,6)
		if r<=3:
			if self.robot.feel(0,1)!=1: self.robot.move(0,1,0)
		if r==4: self.robot.move(0,0, 1)
		if r==5: self.robot.move(0,0,-1)

	##############################################################

	def display(self):
		""" data to display at the bottom of display panel
		return : string"""
		return ""

	def getDisplayLine(self, l):
		""" data to display at left of display panel
		int l : line of display panel to complete
		return : string"""
		return ""

	def listCommands(self):
		""" get the list of command related to this ai module,
		displayed whe user press 'h' 
		return : string """		
		return ""

	def commandLine(self,args):
		""" process command lines from user.
		str[] line : command with arguments"""
		print("invalid command")

	def getAgentSymbol(self):
		""" get the id of the symbol in SKIN to represent the agent on display panel.
		Here, symbol depends of the orientation of the robot
		return : int """
		return self.robot.z

	##############################################################

	def load(self,text):
		""" load data in ai module.
		string text : data under the form of a string """		
		pass

	def save(self):
		""" generate a string containing data to save
		return : string """
		return ""



""" A PRI decisional example """

class Signature(object):
	
	def __init__(self, nb):
		self.pattern=[0.0 for y in range(nb)]
		self.prediction=0.0

	def learn(self, context, result):
		delta=result-self.prediction
		for i in range(len(context)):
			if context[i]==1: self.pattern[i]+=0.01*delta 

	def predict(self,context):
		self.prediction=0
		for i in range(len(context)-1):
			if context[i]==1: self.prediction += self.pattern[i]
		return self.prediction
			

class Agent(object):

	def __init__(self,primary, stimuli):
		self.nb_primary=primary
		self.nb_interactions=primary + stimuli*primary
		self.intended=0
		self.enacted=[0 for i in range(self.nb_interactions+1)]
		self.previousEnacted=[0 for i in range(self.nb_interactions+1)]
		self.sigList=[Signature(self.nb_interactions+1) for i in range(self.nb_interactions)]

	def decision(self):
		id_max=0
		val_max=0
		for i in range (self.nb_primary): 
			self.sigList[i].predict(self.enacted)
			if abs(abs(self.sigList[i].prediction)-1)>val_max:
				id_max=i
				val_max=abs(abs(self.sigList[i].prediction)-1)

		for i in range (self.nb_primary,self.nb_interactions):
			self.sigList[i].predict(self.enacted)

		ret=id_max
		self.intended=ret
		return ret

	def result(self, enacted):
		self.previousEnacted=self.enacted[:]
		self.enacted=enacted

		for i in range(self.nb_interactions):
			if enacted[i]!=0:
				self.sigList[i].learn(self.previousEnacted,enacted[i])




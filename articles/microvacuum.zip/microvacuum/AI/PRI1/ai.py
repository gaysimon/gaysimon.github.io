""" A ai module example for PRI implementations """


from AI.PRI1.agent import *

class AI(object):
	""" PRI module example
	name : identifier for the module
	self.robot : pointer to interface with environment
	self.env   : pointer to the environment
	self.agent : decisional module """	


	name="PRI1"

	def __init__(self, robot, matrix):
		self.robot=robot
		self.env=matrix
		self.agent=Agent(5,11*6*3)


	def intend(self):
		""" interact with environment
		the agent processes intended interaction from agent module,
		enacts it and defines enacted interactions """
		interaction=self.agent.decision()
		ret=""
		if interaction==0 or interaction==1 or interaction==2:
			if self.robot.feel(0,1)==1: ret=1
			else:
				self.robot.move(0,1,0)
				if self.robot.feel(0,0)==2:
					self.robot.change(0,0,0)
					self.env[self.robot.y][self.robot.x]=2
					ret=2
				else:ret=0
		elif interaction==3:
			self.robot.move(0,0,1)
			ret=3
		else:
			self.robot.move(0,0,-1)
			ret=4

		self.robot.see()

		# construct enacted vector
		result=[0 for y in range(self.agent.nb_interactions+1)]

		# opposite interactions
		if ret<3:
			result[0]=-1
			result[1]=-1
			result[2]=-1
		result[ret]=1

		# secondary interaction
		for i in range((5+198*ret),(5+198*(ret+1))): result[i]=-1

		for j in range(6):
			for i in range(11):
				if   self.robot.vision[i][j]==1: result[5+198*ret+j*11*3+i*3  ]=1
				elif self.robot.vision[i][j]==2: result[5+198*ret+j*11*3+i*3+1]=1
				elif self.robot.vision[i][j]==3: result[5+198*ret+j*11*3+i*3+2]=1

		result[len(result)-1]=1

		self.agent.result(result)

	def displaySignature(self,id):
		""" Display selected signature as a matrix of weights
		id : identifier of a signature in list"""
		for s in range(5):
			for j in range(6):
				disp=""
				for c in range(3):
					for i in range(11):
						if   int(self.agent.sigList[id].pattern[5+198*s+(5-j)*33+i*3+c]*10)==0:
							disp+=" . "
						elif int(self.agent.sigList[id].pattern[5+198*s+(5-j)*33+i*3+c]*10)>=0:
							disp+=" "+str(int(self.agent.sigList[id].pattern[5+198*s+(5-j)*33+i*3+c]*10))+" "
						else:   disp+=str(int(self.agent.sigList[id].pattern[5+198*s+(5-j)*33+i*3+c]*10))+" "
					disp+="   "
				print(disp)
			print(" ")

		print(" ".join(map(str, self.agent.sigList[id].pattern[0:5]))+" , "+ str(self.agent.sigList[id].pattern[-1]))

	##############################################################

	def display(self):
		""" data to display at the bottom of display panel
		here, intended interaction id and enacted primary interaction.
		return : string"""
		return str(self.agent.intended) +" -> "+str(self.agent.enacted[0:5])

	def getDisplayLine(self, l):
		""" data to display at left of display panel
		here, predictions of primary interactions
		int l : line of display panel to complete
		return : string"""
		if l<1 or l>5: return ""
		else: return "   "+str(self.agent.sigList[l-1].prediction)

	def listCommands(self):
		""" get the list of command related to this ai module,
		displayed whe user press 'h' 
		return : string """
		return "   'sig [id]': display signature of interaction id \n"

	def commandLine(self,line):
		""" process command lines from user.
		str[] line : command with arguments"""
		if line[0]=="sig":
			if len(line)==2:
				self.displaySignature(int(line[1]))
			else: print("'sig' command requires 1 argument")

		else: print("invalid command")

	def getAgentSymbol(self):
		""" get the id of the symbol in SKIN to represent the agent on display panel.
		Here, symbol depends of the orientation of the robot
		return : int """
		return self.robot.z

	##############################################################

	def load(self,text):
		""" load data in ai module.
		string text : data under the form of a string """
		lines=text.split("\n")
		for i in range(len(lines)-1):
			w=lines[i].split(" ")
			for j in range(len(self.agent.sigList[i].pattern)):
				self.agent.sigList[i].pattern[j]=float(w[j])


	def save(self):
		""" generate a string containing data to save
		return : string """
		ret=""
		for i in range(len(self.agent.sigList)):
			ret+=" ".join(map(str, self.agent.sigList[i].pattern))+"\n"
		return ret



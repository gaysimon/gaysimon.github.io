""" A ai module example for RI implementations """

from AI.RI1.agent import *

class AI(object):
	""" PRI module example
	name : identifier for the module
	self.robot : pointer to interface with environment
	self.env   : pointer to the environment
	self.agent : decisional module """	


	name="RI1"

	interaction_list=[">","x","e","^","v"]

	def __init__(self, robot, matrix):
		self.robot=robot
		self.env=matrix
		self.agent=Agent(AI.interaction_list)


	def intend(self):
		""" interact with environment
		the agent processes intended interaction from agent module,
		enacts it and defines enacted interactions """
		interaction=self.agent.decision()
		ret=""
		if interaction==">" or interaction=="x" or interaction=="e":
			if self.robot.feel(0,1)==1: ret=1
			else:
				self.robot.move(0,1,0)
				if self.robot.feel(0,0)==2:
					self.robot.change(0,0,0)
					self.env[self.robot.y][self.robot.x]=2
					ret=2
				else:ret=0
		elif interaction=="^":
			self.robot.move(0,0,1)
			ret=3
		else:
			self.robot.move(0,0,-1)
			ret=4

		self.robot.see()
		self.agent.result(AI.interaction_list[ret])


	##############################################################

	def display(self):
		""" data to display at the bottom of display panel
		here, intended interaction id and enacted primary interaction.
		return : string"""
		return self.agent.intended +" -> "+self.agent.enacted

	def getDisplayLine(self, l): return ""

	def listCommands(self): return ""

	def commandLine(self,line):
		print("invalid command")

	def getAgentSymbol(self):
		""" get the id of the symbol in SKIN to represent the agent on display panel.
		Here, symbol depends of the orientation of the robot
		return : int """
		return self.robot.z

	##############################################################

	def load(self,text):pass

	def save(self): return ""



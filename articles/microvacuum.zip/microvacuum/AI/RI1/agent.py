""" A RI decisional example """

from random import randint


class Agent(object):

	def __init__(self,inter_list):
		self.inter=inter_list
		self.intended="."
		self.enacted="."

	def decision(self):
		ret=self.inter[0]
		r=randint(0,6)
		if r==2: ret=self.inter[1]
		if r==3: ret=self.inter[2]
		if r==4: ret=self.inter[3]
		if r==5: ret=self.inter[4]
		self.intended=ret
		return ret

	def result(self, enacted):
		self.enacted=enacted

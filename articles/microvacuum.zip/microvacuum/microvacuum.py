"""Microvacuum is a console, easy to use, simulator for artificial agent """

import os
import time
import sys
import select
import tty
import termios


####################################################################################
# parameters of the simulation
from AI.PRI1.ai import *	# ai module
ENV="env1"			# environment descriptor
SKIN="skin1"			# display descriptor

TIMER=0.2			# delay between steps

DISP_VISION=True		# visibility of visual system
VISION_W=11			# width and depth of visual field
VISION_H=6			#
VISION_X=5			# position of agent in image
VISION_Y=0			#

####################################################################################
# Python version
def input_key(msg):
	return raw_input(msg)	# Python 2
	#return input(msg)	# Python 3

####################################################################################
# load environment matrix
readfile=open("env/"+ENV+".txt","r")
lines=readfile.read().split("\n")

# define size of the matrix
h=0
w=len(lines[0].split())
for j in lines:
	if len(j.split())>0:
		h+=1
		if len(j.split())<w: w=len(j.split())

# write the environment matrix
matrix=[[0 for y in range(h)] for x in range(w)]

j2=0
for j in lines:
	line=j.split()
	if len(line)>=w:
		for i in range(w): matrix[i][j2]=int(line[i])
		j2+=1
readfile.close()

#load environment skin
readfile=open("skin/"+SKIN+".txt","r")
lines=readfile.read().split("\n")
agent_skin=lines[0].split()
env_skin=lines[1].split()
readfile.close()


####################################################################################
class Robot(object):
	"""Robot is an interface between an artificial agent and its environment"""

	def __init__(self, px, py, rz):
		self.count=0
		self.x = px
		self.y = py
		self.z = rz
		self.ai=AI(self, matrix)
		self.vision=[[0 for y in range(VISION_H)] for x in range(VISION_W)]

	def feel(self, x,y):
		""" returns the value in cell at position (x,y) relative to the agent """
		if self.z==0:   return matrix[int(self.x+x)%w][int(self.y-y)%h]
		elif self.z==1: return matrix[int(self.x-y)%w][int(self.y-x)%h]
		elif self.z==2: return matrix[int(self.x-x)%w][int(self.y+y)%h]
		else:           return matrix[int(self.x+y)%w][int(self.y+x)%h]

	def see(self):
		""" defines the matrix of the visual field """
		for j in range(VISION_H):
			for i in range(VISION_W):
				self.vision[i][j]=self.feel(i-VISION_X,j-VISION_Y)

	def move(self,x,y,z):
		""" moves and/or rotates the agent of (translation x, transtaltion y, rotation z) """ 
		if   self.z==0:(self.x,self.y)=((self.x+x)%w,(self.y-y)%h)
		elif self.z==1:(self.x,self.y)=((self.x-y)%w,(self.y-x)%h)
		elif self.z==2:(self.x,self.y)=((self.x-x)%w,(self.y+y)%h)
		else:          (self.x,self.y)=((self.x+y)%w,(self.y+x)%h)
		self.z=(self.z+z)%4

	def change(self,x,y,id):
		""" changes the value of cell at position (x,y) relative to the agent """
		if self.z==0:   matrix[int(self.x+x)%w][int(self.y-y)%h]=id
		elif self.z==1: matrix[int(self.x-y)%w][int(self.y-x)%h]=id
		elif self.z==2: matrix[int(self.x-x)%w][int(self.y+y)%h]=id
		else:           matrix[int(self.x+y)%w][int(self.y+x)%h]=id

	def display(self):
		""" gets the agent symbol according to SKIN file """
		nb=self.ai.getAgentSymbol()
		if len(agent_skin)>nb: return agent_skin[nb]+" "
		else :  return agent_skin[0]+" "


####################################################################################
def isData():
	return select.select([sys.stdin], [], [], 0) == ([sys.stdin], [], [])

def print_pos(x, y, text):
	sys.stdout.write("\x1b7\x1b[%d;%df%s\x1b8" % (x, y, text))
	sys.stdout.flush()


def getDisplay():
	"""Get the simulation image: environment at left and visual system at center. Data from AI modules can be added at right and under main display
	return : string """
	disp="\n"
	for j in range(max(h,10)):
		disp+="  "
		# environment
		if (j<h):
			for i in range(w):
				if i==robot.x and j==robot.y:disp+=robot.display()
				else:
					if len(env_skin)>matrix[i][j]: disp+=env_skin[matrix[i][j]]+" "
					else :  disp+=str(matrix[i][j])+" "
		else : 
			for i in range(w): disp+="  "
		disp=disp+"    "

		# vision
		if DISP_VISION:
			if j>0 and j<7:
				for i in range(11):
					if len(env_skin)>robot.vision[i][6-j]:
						disp+=env_skin[robot.vision[i][6-j]]+" "
					else :  disp+=str(robot.vision[i][6-j])+" "
			else: disp+="                      "

		# additional data at right
		disp+=robot.ai.getDisplayLine(j)+"\n"

	return disp+"\n"+"  "+str(robot.count)+"  :  "+robot.ai.display()+"\n"

def envDisplay():
	"""Display panel on screen"""
	os.system("clear")
	print(getDisplay())

def load(fileName):
	"""Load AI data from a file"""
	try:
		f = open("saves/"+fileName+".txt","r")
		line=f.readline()
		args=line.split(" ")
		if args[0]!=robot.ai.name:
			k=""
			while k!="y" and k!="n":
				print("this file does not correspond to the used version of AI module. Continue anyway? (y or n) ")
				k=input_key(">")

			if k=="y":
				robot.ai.load(f.read())
				robot.count=int(args[1])
		else : 
			robot.ai.load(f.read())
			robot.count=int(args[1])
		f.close()
	except: print("error when opening file")

def save(fileName):
	"""Save AI data in a file"""
	f = open("saves/"+fileName+".txt","w")
	f.write(robot.ai.name+" "+str(robot.count)+"\n")
	f.write(robot.ai.save())
	f.close()

def screen(fileName):
	"""Save screen image"""
	f = open("screenshots/"+fileName+".txt","w")
	f.write(getDisplay())
	f.close()


####################################################################################
# start simulation

robot=Robot(int(w/2),int(h/2),0)

key="."
quit=False
envDisplay()

old_settings = termios.tcgetattr(sys.stdin)


while not quit:

	# command line mode
	print("command mode. Press 'h' for command list")
	termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_settings)

	while key!="r" and not quit:

		com=input_key(">")
		
		if com in ["h","H","help","Help","HELP","?"]: # help: displays available command lines
			print("command list: \n   'c [x] [y] [id]': change environment cell (x,y) to 'id' \n   'h': help \n   'load [file]': load agent data from file [file].txt \n   'm [x] [y] [rz]': move agent to position (x;y) and orientation rz \n   'q': quit simulator \n   'r': run simulation \n   's': next step \n   'save [file]': save agent data in file [file].txt \n   'screen [file]': take a screenshot of display panel and save in [file].txt \n   't' [time]: define a delay of [time] seconds between two steps \n   'v': display/hide visual system \n"+robot.ai.listCommands())

		elif com in ["q","Q","quit","Quit","QUIT","exit","Exit","EXIT"]: # quit simulator
			key="r"
			quit=True

		elif com in ["r","R","ret","Ret","RET","return","Return","RETURN"]: # starts/runs simulation"
			key="r"

		elif com in ["s","S","step","Step","STEP"]: # step: simulate one step
			robot.ai.intend()
			robot.count+=1

			envDisplay()

		elif com in ["v","V"]: # vision: display/hide visual system in display panel
			DISP_VISION=not DISP_VISION
			envDisplay()

		else: # commands with arguments
			args=com.split(" ")
			if args[0] in ["c","C"]: # changes the value of a cell
				if len(args)==4:
					matrix[int(args[1])%w][int(args[2])%h] = int(args[3])
					envDisplay()
				else: print("change command requires 3 arguments")

			elif args[0] in ["m","M"]: # moves the agent in environment
				if len(args)==4:
					robot.x=int(args[1])%w
					robot.y=int(args[2])%h
					robot.z=int(args[3])%4
					envDisplay()
				else: print("change command requires 3 arguments")

			elif args[0] in ["t","T","timer", "TIMER"]: # timer: changes the delay between steps
				if len(args)==2: TIMER=float(args[1])
				else: print("you must specify a value")


			elif args[0] in ["load", "Load", "LOAD"]: # load data from a file
				if len(args)==2: load(args[1])
				else: print("you must specify a file to load")

			elif args[0]=="save": # save data in a file
				if len(args)==2:
					if any(x in args[1] for x in ['/','\\','.',' ']): 
						print("Name file cannot contains special caracters \\, / or .")
					else:  save(args[1])
				else: print("you must specify a name for your file")

			elif args[0]=="screen": # save screen in a file
				if len(args)==2:
					if any(x in args[1] for x in ['/','\\','.',' ']): 
						print("Name file cannot contains special caracters \\, / or .")
					else:  screen(args[1])
				else: print("you must specify a name for your file")

			else: robot.ai.commandLine(args) # specific command lines of ai module 

	# simulation mode
	try:
		tty.setcbreak(sys.stdin.fileno())
		while key!="p" and not quit:
			# next step
			robot.ai.intend()
			envDisplay()
			print(" 'p' for pause, 'q' for quit \n")
			robot.count+=1
			time.sleep(TIMER)
			if isData():key = sys.stdin.read(1)
			if key=="q": quit=True
	finally: termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_settings)


	
	

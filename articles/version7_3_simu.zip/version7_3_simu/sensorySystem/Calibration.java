package version7_3_simu.sensorySystem;

import version7_3_simu.Interface.InteractionList;
import version7_3_simu.platform.Agent;


public class Calibration {

	private Agent agent;

	public int[][] map;
	
	
	public Calibration(Agent a){
		
		agent=a;

		map=new int[InteractionList.size1][InteractionList.size2];

		for (int i=0;i<InteractionList.size1;i++){
			for (int j=0;j<InteractionList.size2;j++){
				map[i][j]=-1;
			}
		}
	}
	
	
	
	public void getMap(){
		for (int i=0;i<InteractionList.size1;i++){
			for (int j=0;j<InteractionList.size2;j++){
				map[i][InteractionList.size2-1-j]=agent.colors.colorMap2[(int)(i*6.4)][(int)((j+20)*6.4)];
			}
		}
	}
	
}
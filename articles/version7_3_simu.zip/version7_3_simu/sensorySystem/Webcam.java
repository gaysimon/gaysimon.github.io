package version7_3_simu.sensorySystem;

import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;


public class Webcam{
	 
	private float width1 = 640, height1 = 480;
	private float width2 = 640, height2 = 480;
	public BufferedImage bf;
	
	public boolean connected=false;

	public int[][][] image;
 
 
	public Webcam() {
 
		image=new int[(int)width1][(int)height1][3];
		for (int i=0;i<width1;i++){
			for (int j=0;j<height1;j++){
				image[i][j][0]=0;
				image[i][j][1]=0;
				image[i][j][2]=0;
			}
		}
	}
 
	// capture an image from the camera
	public void setImage(){
		
		try{
		
			bf=ImageIO.read(new File(System.getProperty("user.home")+"/Ernest_simulator/simulation_image.jpg"));
			
			width2 = bf.getWidth();
			height2 = bf.getHeight();
			
			
			for (int i=1;i<width1-1;i++){
				for (int j=1;j<height1-1;j++){
					
					int i1=(int)( ((float)i-width1/2) * (1-0.25 * (float)(height1-j)/height1) + width1/2);
					
					int i2=(int)((float)i1*(width2/width1)/2.4);
					int j2=(int)((float)j*(height2/height1)/2.4+0.57*height2);
					
					image[i][j][0]=((bf.getRGB(i2,j2) & 0x00ff0000)>>16);
					image[i][j][1]=((bf.getRGB(i2,j2) & 0x0000ff00)>> 8);
					image[i][j][2]=((bf.getRGB(i2,j2) & 0x000000ff));
				}
			}
		}catch (Exception ex) {System.out.println(ex);}
		
	}

}

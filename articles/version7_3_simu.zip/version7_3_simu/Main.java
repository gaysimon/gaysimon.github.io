package version7_3_simu;

import java.util.ArrayList;

import version7_3_simu.platform.Agent;
import version7_3_simu.platform.Display;
import version7_3_simu.platform.UserInterfaceFrame;


public class Main {

	public UserInterfaceFrame userInterface;
	public Display display;
	private ArrayList<Agent> agentList;
	
	private boolean run=true;
	
	public Main(){
		agentList=new ArrayList<Agent>();
		display=new Display();
		
		addAgent(0);

		if (nbAgent()>0){
			selectAgent(0).setDisplay();
		}

		userInterface=new UserInterfaceFrame(this);
		
		while (run){
			int nb=nbAgent();
			for (int i=0;i<nb;i++){
				selectAgent(i).act();
			}
			
			display.repaint();

		}
	}
	
	
	////////////////////////////////////////////////////////
	// function used to manage the agent list
	public void addAgent(int ident){
		agentList.add(new Agent(ident,this));
	}
	public void resetList(){
		agentList.clear();
	}
	public int nbAgent(){
		return agentList.size();
	}
	
	public Agent selectAgent(int index){
		if (index<nbAgent()) return agentList.get(index);
		else              return null;
	}
	
	public Agent getAgent(int i){
		return agentList.get(i);
	}
	
	public Agent lastAgent(){
		return agentList.get(nbAgent()-1);
	}
	//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	// get the index of an agent designated by its ident
	public int agentIndex(int id){
		int index=-1;
		
		for (int i=0;i<nbAgent();i++){
			if (selectAgent(i).getIdent()==id) index=i;
		}
		
		return index;
	}
	
	
	public boolean isStopped(){
		int nb=nbAgent();
		boolean test=true;
		for (int i=0;i<nb;i++){
			if (selectAgent(i).action.getState()==1) test=false;
		}
		return test;
	}
	
	public boolean isStopped(int index){
		return (selectAgent(index).action.getState()==0);
	}
	
	public boolean isStarted(){
		int nb=nbAgent();
		boolean test=true;
		for (int i=0;i<nb;i++){
			if (selectAgent(i).action.getState()==0) test=false;
		}
		return test;
	}
	
	public boolean isStarted(int index){
		return (selectAgent(index).action.getState()==1);
	}
	
	
	// stop the simulation
	public void stop(){
		run=false;
	}
	
	public int getAgentIndex(){
		return 0;
	}
	
	public void saveImage(String path){
		display.saveImage(path);
	}
	
	
	
	///////////////////////////////////////////////////////
	
	public static void main(String[] args){
		new Main();
	}
	
}


package version7_3_simu.display;

import java.awt.Color;
import java.awt.Graphics;

import version7_3_simu.platform.Agent;

/**
 * Display the efficiency (average valence) of the system
 * @author simon gay
 */

/* - inherited from EnvPanel :
 *   Agent agent      : pointer to the agent
 */
public class EfficiencyPanel extends EnvPanel{
	
	private static final long serialVersionUID = 1L;

	public EfficiencyPanel(Agent a){
		super(a);
	}
	
	/**
	 * print the displayed image in a pdf file
	 */
	public void drawPDF(Graphics g){
		g.setColor(Color.white);
		
		g.fillRect(0, 0, 600, 400);
		
		g.setColor(Color.black);
		g.drawLine(0, 200, 600, 200);
			
		g.setColor(Color.green);
		
		for (int i=0;i< 200-1;i++){
			g.setColor(Color.green);
			g.drawLine( 600-i    *2, 200-agent.observer.timelineEfficiency1[i  ],
					    600-(i+1)*2, 200-agent.observer.timelineEfficiency1[i+1]);
			
			g.setColor(Color.red);
			g.drawLine( 600-i    *2, 200-agent.observer.timelineEfficiency2[i  ],
					    600-(i+1)*2, 200-agent.observer.timelineEfficiency2[i+1]);
			
			g.setColor(Color.orange);
			g.drawLine( 600-i    *2, 200-agent.observer.timelineEfficiency3[i  ],
					    600-(i+1)*2, 200-agent.observer.timelineEfficiency3[i+1]);
			
			g.setColor(Color.blue);
			g.drawLine( 600-i    *2, 200-agent.observer.timelineEfficiency4[i  ],
					    600-(i+1)*2, 200-agent.observer.timelineEfficiency4[i+1]);
		}
	}
	
	/**
	 * display valence average values
	 */
	public void paintComponent(Graphics g){
		g.setColor(Color.white);
		
		g.fillRect(0, 0, 1000, 400);
		
		g.setColor(Color.black);
		g.drawLine(0, 200, 1000, 200);

		g.setColor(Color.green);
		
		// draw graphs that display average valences for different time windows
		for (int i=0;i< 200-1;i++){
			g.setColor(Color.green);
			g.drawLine( 1000- i   *5, 200-agent.observer.timelineEfficiency1[i  ]/2,
					    1000-(i+1)*5, 200-agent.observer.timelineEfficiency1[i+1]/2);
			
			g.setColor(Color.red);
			g.drawLine( 1000- i   *5, 200-agent.observer.timelineEfficiency2[i  ]/2,
						1000-(i+1)*5, 200-agent.observer.timelineEfficiency2[i+1]/2);
			
			g.setColor(Color.orange);
			g.drawLine( 1000- i   *5, 200-agent.observer.timelineEfficiency3[i  ]/2,
					    1000-(i+1)*5, 200-agent.observer.timelineEfficiency3[i+1]/2);
			
			g.setColor(Color.blue);
			g.drawLine( 1000- i   *5, 200-agent.observer.timelineEfficiency4[i  ]/2,
					    1000-(i+1)*5, 200-agent.observer.timelineEfficiency4[i+1]/2);
		}
	}
}

package version7_3_simu.display;

import java.awt.Color;
import java.awt.Graphics;

import version7_3_simu.platform.Agent;
import version7_3_simu.platform.Observer;
import version7_3_simu.spaceMemory.Decision;

/**
 * Display the certitude values of interactions
 * @author simon
 */

/* - inherited from EnvPanel :
 *   Agent agent      : pointer to the agent
 */
public class PredictionPanel extends EnvPanel{

	private static final long serialVersionUID = 1L;
	
	private int width,length;
	
	public PredictionPanel(Agent a){
		super(a);
		
		length=Observer.length;
		width=1000/length;
	}
	
	public void paintComponent(Graphics g){
		g.setColor(Color.white);
		
		g.fillRect(0, 0, 1000, 800);
		
		g.setColor(Color.black);
		g.drawLine(0, 700, 1000, 700);
		g.drawLine(0, 100, 1000, 100);
		
		g.setColor(Color.green);
		g.drawLine(0, 100+(int)(600*Decision.incertitude), 1000, 100+(int)(600*Decision.incertitude));

		for (int i=0;i<length;i++){
			
			if (i!=agent.observer.index){
			
				for (int j=0;j<7;j++){
					if (j==0) g.setColor(Color.red);
					else if (j==1) g.setColor(Color.green);
					else if (j==2) g.setColor(Color.blue);
					else g.setColor(Color.gray);
					g.drawLine((length-agent.observer.index+ i   )%length*width,
							   (int)(700-(int)(agent.observer.timelinePrediction[(length-1+i  )%(length-1)][j]*600)),
							   (length-agent.observer.index+(i-1))%length*width,
							   (int)(700-(int)(agent.observer.timelinePrediction[(length-1+i-1)%(length-1)][j]*600)));
				}
			}
		}
	}
}

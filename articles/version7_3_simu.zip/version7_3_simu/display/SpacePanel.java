package version7_3_simu.display;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import version7_3_simu.Interface.InteractionList;
import version7_3_simu.platform.Agent;
import version7_3_simu.spaceMemory.BlurPattern;
import version7_3_simu.spaceMemory.Signature;

/**
 * Display space memory data
 * @author simon gay
 */

/* - inherited from EnvPanel :
 *   Agent agent      : pointer to the agent
 */
public class SpacePanel extends EnvPanel implements MouseListener{

	private static final long serialVersionUID = 1L;
	
	private int clic_x=0;
	private int clic_y=0;
	private int selected_interaction=-1;
	
	public SpacePanel(Agent a){
		super(a);
		addMouseListener(this);
	}
	
	public void paintComponent(Graphics g){
		g.setColor(Color.white);
		
		g.fillRect(0, 0, 1200, 1000);

		// points of selection
		int offsetX=100;
		
		// number of pattern
		g.setColor(Color.black);
		g.drawString(""+agent.spaceMemory.nbInteraction(), offsetX+205, 360);
		
		// learning switch
		if (agent.decision.learning()) g.setColor(Color.red);
		else g.setColor(Color.black);
		g.fillRect(offsetX+205, 380, 10, 10);
		
		// draw space map
		for (int i=0;i<InteractionList.size1;i++){
			for (int j=0;j<InteractionList.size2*2;j++){
				g.setColor(new Color(agent.spaceMemory.spaceMap[i][j][0],
						 			 agent.spaceMemory.spaceMap[i][j][1],
						 			 agent.spaceMemory.spaceMap[i][j][2]));
				g.fillRect(260+i*2, 10+(InteractionList.size2*2-j)*2, 2, 2);
			}
		}
		
		// predicted environments
		for (int m=0;m<agent.interactionList.nbInteraction();m++){
			for (int i=0;i<InteractionList.size1;i++){
				for (int j=0;j<InteractionList.size2*2;j++){
					g.setColor(new Color(agent.spaceMemory.getPredictionMap(m,i,j,0),
							 			 agent.spaceMemory.getPredictionMap(m,i,j,1),
							 			 agent.spaceMemory.getPredictionMap(m,i,j,2)));
					
					g.fillRect(520+i*2+210*((int)(m/2)), 240-j*2+245*(m%2), 2, 2);
				}
			}
		}
		
		///////////////////////////////////////////////////////////////////////////
		// draw perceived environment
		for (int i=0;i<InteractionList.size1;i++){
			for (int j=0;j<InteractionList.size2;j++){
				g.setColor(new Color(agent.spaceMemory.enactedEnsembles[0][i*InteractionList.size2*3+j*3  ],
									 agent.spaceMemory.enactedEnsembles[0][i*InteractionList.size2*3+j*3+1],
									 agent.spaceMemory.enactedEnsembles[0][i*InteractionList.size2*3+j*3+2]));
				g.fillRect(50+i*2, 130-j*2, 2, 2);
			}
		}

		for (int i=0;i<8;i++){
			g.setColor(new Color(1-(agent.spaceMemory.enactedEnsembles[0][InteractionList.size1*InteractionList.size2*3+i]/2+0.5f),
									agent.spaceMemory.enactedEnsembles[0][InteractionList.size1*InteractionList.size2*3+i]/2+0.5f,0));
			g.fillRect(50+12*i,10+ 130, 10, 10);
		}
		
		// draw previous environment
		for (int i=0;i<InteractionList.size1;i++){
			for (int j=0;j<InteractionList.size2;j++){
				g.setColor(new Color(agent.spaceMemory.enactedEnsembles[1][i*InteractionList.size2*3+j*3  ],
									 agent.spaceMemory.enactedEnsembles[1][i*InteractionList.size2*3+j*3+1],
									 agent.spaceMemory.enactedEnsembles[1][i*InteractionList.size2*3+j*3+2]));
				g.fillRect(50+i*2,10+270-j*2, 2, 2);
			}
		}

		for (int i=0;i<8;i++){
			g.setColor(new Color(1-(agent.spaceMemory.enactedEnsembles[1][InteractionList.size1*InteractionList.size2*3+i]/2+0.5f),
									agent.spaceMemory.enactedEnsembles[1][InteractionList.size1*InteractionList.size2*3+i]/2+0.5f,0));
			g.fillRect(50+12*i,10+280, 10, 10);
		}
		
		
		// list of interactions
		for (int i=0;i<agent.spaceMemory.nbInteraction();i++){
			if (selected_interaction==i) g.setColor(Color.red);
			else g.setColor(Color.black);
			g.fillOval(offsetX+200+((int)(i/30)*250),420+15*(i%30),5,5);
			
			g.setColor(Color.black);
			g.drawString(agent.spaceMemory.getInteraction(i).getName(1), offsetX+205+((int)(i/30)*250), 430+15*(i%30));
		}
		
		g.setColor(Color.black);
		int index=0;
		for (int i=0;i<agent.interactionList.nbInteraction();i++){
			String display=agent.spaceMemory.getInteraction(i).getName(0)+" : "+agent.spaceMemory.getInteraction(i).getValence()+" ; "
			               +( agent.spaceMemory.getInteraction(i).getValence()
			                 +agent.spaceMemory.getAdditional(i));
			if (agent.spaceMemory.getInteraction(i).getPrediction()>=0){
				display+=" , (";
				for (int j=0;j<agent.spaceMemory.getInteraction(i).predictions1.size();j++){
					if (i!=j){
						display+= agent.interactionList.getInteraction(j).valence()+" X ("
						         +agent.spaceMemory.getInteraction(j).predictions2.get(i)+" - "
						          +agent.spaceMemory.getInteraction(j).predictions1.get(i)+ ") + ";
					}
				}
				display+=" ) ";
						
				g.drawString(display, offsetX+200, 620+15*(index));
				index++;
			}
		}/**/
		
		/////////////////////////////////////////////////////////////////////////////////
		// draw patterns
		if (selected_interaction!=-1){
			int ident=selected_interaction;
			Signature s=agent.spaceMemory.getInteraction(ident).pattern;
			BlurPattern blur=agent.spaceMemory.getInteraction(ident).blur;
			float max=s.maxPattern;
			float max1=s.maxPattern1;
			float max2=s.maxPattern2;

			if (max1!=0){
				
				for (int i=0;i<InteractionList.size1;i++){
					for (int j=0;j<InteractionList.size2;j++){
						/*float r,gr,b;
						
						if (Math.abs(s.pattern[i*InteractionList.size2*3+j*3+2])<max1*0.6 || Math.abs(s.pattern[i*InteractionList.size2*3+j*3+2])<max*0.2) 
							 r=0.5f;
						else r=(s.pattern[i*InteractionList.size2*3+j*3+2]/max1+1)/2;
						
						if (Math.abs(s.pattern[i*InteractionList.size2*3+j*3  ])<max1*0.6 || Math.abs(s.pattern[i*InteractionList.size2*3+j*3  ])<max*0.2) 
							 gr=0.5f;
						else gr=(s.pattern[i*InteractionList.size1*3+j*3  ]/max1+1)/2;
						
						if (Math.abs(s.pattern[i*InteractionList.size2*3+j*3+1])<max1*0.6 || Math.abs(s.pattern[i*InteractionList.size2*3+j*3+1])<max*0.2) 
							 b=0.5f;
						else b=(s.pattern[i*InteractionList.size2*3+j*3+1]/max1+1)/2;
						
						g.setColor(new Color(r,gr,b));
						/**/
						
						g.setColor(new Color(Math.min(1, Math.max(0, s.pattern[i*InteractionList.size2*3+j*3  ]+1)/2),
								 			 Math.min(1, Math.max(0, s.pattern[i*InteractionList.size2*3+j*3+1]+1)/2),
								 			 Math.min(1, Math.max(0, s.pattern[i*InteractionList.size2*3+j*3+2]+1)/2)));
						
						g.fillRect(10+i*2,350+100-j*2, 2, 2);
					}
				}
				
				
				// blur pattern
				for (int i=0;i<InteractionList.size1;i++){
					for (int j=0;j<InteractionList.size2*2;j++){

						g.setColor(new Color(Math.max(0, Math.min(1, (blur.pattern[i][j][0]/max+1)/2)),
											 Math.max(0, Math.min(1, (blur.pattern[i][j][1]/max+1)/2)),
											 Math.max(0, Math.min(1, (blur.pattern[i][j][2]/max+1)/2))));
						
						g.fillRect(50+i*2,650+100-j*2, 2, 2);
					}
				}/**/
				
			}
			
			if (max2!=0){
				for (int i=0;i<8;i++){
					g.setColor(new Color(Math.max(-1, Math.min(1,(1-((s.pattern[InteractionList.size1*InteractionList.size2*3+i]/max2/2)+0.5f)))),
							             Math.max(-1, Math.min(1,(    s.pattern[InteractionList.size1*InteractionList.size2*3+i]/max2/2)+0.5f)),
							             0));
					g.fillRect( 50+i*15, 460, 10, 10);
				}
			}
			
			
			// display the movement produced by each primary interaction
			/*if (agent.spaceMemory.primitiveList.size()>=7){
				g.setColor(Color.blue);
				for (int i=0;i<InteractionList.size1;i+=5){
					for (int j=0;j<InteractionList.size2*2;j+=5){
						if (agent.spaceMemory.primitiveList.get(ident).vectorFlow[i][j][0]>=0 && agent.spaceMemory.primitiveList.get(ident).vectorFlow[i][j][0]<200
						  &&agent.spaceMemory.primitiveList.get(ident).vectorFlow[i][j][1]>=0 && agent.spaceMemory.primitiveList.get(ident).vectorFlow[i][j][1]<200){
						g.drawLine(480+i*2, 700-j*2,
								   480+Math.round(agent.spaceMemory.primitiveList.get(ident).vectorFlow[i][j][0])*2,
								   700-Math.round(agent.spaceMemory.primitiveList.get(ident).vectorFlow[i][j][1])*2);
						}
					}
				}
			}/**/
			
		}
		
	}
	
	
	///////////////////////////////////////////////////////////////////////////
	public Color getColor(float[][] map, int t, int i){
		return new Color( (Math.min(1, Math.max(-1, map[t][i  ]))+1)/2,
						  (Math.min(1, Math.max(-1, map[t][i+1]))+1)/2,
						  (Math.min(1, Math.max(-1, map[t][i+2]))+1)/2);
	}
	public Color getColor2(float[][] map, int t, int i){
		return new Color( (Math.min(1, Math.max(-1, map[t][i  ]))+1)/2,
						  (Math.min(1, Math.max(-1, map[t][i+1]))+1)/2,
						  0);
	}
	
	public Color getColor(float[] map, int i){
		return new Color( (Math.min(1, Math.max(-1, map[i  ]))+1)/2,
						  (Math.min(1, Math.max(-1, map[i+1]))+1)/2,
						  (Math.min(1, Math.max(-1, map[i+2]))+1)/2);
	}
	public Color getColor2(float[] map, int i){
		return new Color( (Math.min(1, Math.max(-1, map[i  ]))+1)/2,
						  (Math.min(1, Math.max(-1, map[i+1]))+1)/2,
						  0);
	}
	
	///////////////////////////////////////////////////////////////////////////
	public void mouseClicked(MouseEvent e) {

		clic_x=e.getX();
		clic_y=e.getY();
		
		float dmin=10;
		float d=10;
		
		selected_interaction=-1;
		
		int nbCol=(int)(agent.spaceMemory.nbInteraction()/15);
		int nbLast=agent.spaceMemory.nbInteraction()%15;
		
		for (int i=0;i<nbCol;i++){
			for (int j=0;j<15;j++){
				d= (300+250*i-clic_x)*(300+250*i-clic_x) + (420+j*15-clic_y)*(420+j*15-clic_y);
				d=(float) Math.sqrt(d);
				
				if (d<dmin){
					dmin=d;
					selected_interaction=i*15+j;
				}
			}
		}
		
		for (int j=0;j<nbLast;j++){
			d= (300+250*nbCol-clic_x)*(300+250*nbCol-clic_x) + (420+j*15-clic_y)*(420+j*15-clic_y);
			d=(float) Math.sqrt(d);
			
			if (d<dmin){
				dmin=d;
				selected_interaction=nbCol*15+j;
			}
		}

		if (clic_x>=(305) && clic_x<=(315) && clic_y>=380 && clic_y<=390) 
			agent.decision.setLearning();
	}

	@Override
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {}
	public void mouseReleased(MouseEvent e) {}
	
}

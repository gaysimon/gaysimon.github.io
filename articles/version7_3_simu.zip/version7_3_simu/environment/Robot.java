package version7_3_simu.environment;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;


/**
 * robot interface
 * @author simon gay
 */
public class Robot {

	private String fileIntended = System.getProperty("user.home")+"/Ernest_simulator/intended.txt";
	private String fileEnacted  = System.getProperty("user.home")+"/Ernest_simulator/enacted.txt";
	
	
	//////////////////////////////////////////////////////////////////////
	// sensors
	public int result;

	//--------------------------------------------------------------------
	
	public Robot(){

	}
	
	
	// robot command
	public void move(int msg){
		
		// send action
		try{
			
			PrintWriter file  = new PrintWriter(new FileWriter(fileIntended));
			file.print(msg);
			file.close();
		}
		catch (IOException e) {e.printStackTrace();}
		
		
		// get the response from the robot
		try{
			
			String line=null;
			
			while (line==null){
			
				// wait response
				try{Thread.currentThread();
					Thread.sleep(200);}
				catch(Exception ie){}
				
				InputStream ips=new FileInputStream(fileEnacted); 
				InputStreamReader ipsr=new InputStreamReader(ips);
				BufferedReader br=new BufferedReader(ipsr);
			
				line=br.readLine();	
				
				br.close();
			}
			
			PrintWriter file  = new PrintWriter(new FileWriter(fileEnacted));
			file.print("");
			file.close();
			
			result=Integer.parseInt(line);
		}
		catch (IOException e) {{
			e.printStackTrace();}
		}
	}
}

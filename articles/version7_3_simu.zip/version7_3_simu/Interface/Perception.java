package version7_3_simu.Interface;

import version7_3_simu.platform.Agent;

/**
 * convert signals from the robot into interactions
 * @author simon
 */
public class Perception {

	private Agent agent;

	private int enacted;
	
	public Perception(Agent a){
		agent=a;
	}

	
	
	// interpretation of enacted interaction according to action and inputs
	public PrimitiveInteraction recognize(){
		return agent.interactionList.getInteraction(agent.body.result);
	}
	
	public float[] recognizeEnactedEnsemble(PrimitiveInteraction enacted){

		float[] enactedEnsemble=new float[InteractionList.length];
		
		// initialize enacted ensemble
		for (int i=0;i<InteractionList.length;i++){
			enactedEnsemble[i]=0;
		}
		
		// set primary interaction
		enactedEnsemble[enacted.getIndex()+InteractionList.nbDF]=1;
		
		// set secondary interactions
		for (int i=0;i<InteractionList.size1;i++){
			for (int j=0;j<InteractionList.size2;j++){
				if (agent.calibration.map[i][j]!=-1 && agent.calibration.map[i][j]!=3){
					enactedEnsemble[i*InteractionList.size2*3 + j*3 +agent.calibration.map[i][j]]=1;
				}
					
			}
		}
		
		// bias input
		enactedEnsemble[InteractionList.length-1]=1;
		
		return enactedEnsemble;
	}
	
}

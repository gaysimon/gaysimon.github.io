package version7_3_simu.Interface;

/**
 * Definition of a primitive interaction
 * @author simon
 */
public class PrimitiveInteraction{

	private PrimitiveAction action;
	private PrimitivePerception perception;

	private float valence;
	
	private int index;							// index of the primary interaction
	
	public float[][][] vectorFlow;				// predefined movement produced by this interaction
	public boolean[][] visible;
	
	// primary interaction
	public PrimitiveInteraction(PrimitiveAction act, PrimitivePerception obs){
		action=act;
		perception=obs;
		
		int a=0;
		if (action.getName().equals(">")) a=0;
		if (action.getName().equals("^")) a=1;
		if (action.getName().equals("v")) a=2;
		if (action.getName().equals("\\"))a=3;
		if (action.getName().equals("/")) a=4;
		
		if (a==0) index=perception.getId();
		else      index=2+a;
		
		
		valence=InteractionList.valence(act, obs);
		
		vectorFlow=new float[200][200][2];
		visible=new boolean[200][200];
		for (int i=0;i<200;i++){
			for (int j=0;j<200;j++){
				visible[i][j]=false;
			}
		}
		loadFlow();
		
	}
	
	
	public boolean isEqual(PrimitiveInteraction inter){
		return this.action.isEqual(inter.action) && this.perception.isEqual(inter.perception);
	}
	
	// return true if inter is composed with the same action
	public boolean isAlternate(PrimitiveInteraction inter){
		return this.action.isEqual(inter.action);
	}
	
	/////////////////////////////////////////
	public PrimitiveAction getAction(){
		return action;
	}

	public PrimitivePerception getPerception(){
		return perception;
	}
	
	public float valence(){
		return valence;
	}
	
	public int getIndex(){
		return index;
	}
	
	public String getName(){
		return action.getName()+perception.getName();
	}
	
	
	///////////////////////////////////////////////////////////////////////////////////////
	// predefined relative movement produced by enacting interactions
	
	public static int forward=6;
	
	private void loadFlow(){
		if (action.getName().equals(">")){
			if (perception.getId()==1){
				for (int i=0;i<InteractionList.size1;i++){
					for (int j=0;j<InteractionList.size2*2;j++){
						vectorFlow[i][j][0]=i;
						vectorFlow[i][j][1]=j;
						
						visible[i][j]=true;
					}
				}
			}
			else{
				for (int i=0;i<InteractionList.size1;i++){
					for (int j=0;j<InteractionList.size2*2;j++){
						vectorFlow[i][j][0]=i;
						vectorFlow[i][j][1]=j+forward;
						
						if (i>=0 && i<InteractionList.size1 && j+forward>=0 && j+forward<InteractionList.size2*2) visible[i][j+forward]=true;
					}
				}
				
				// remove memory contains around the agent after interaction "eat"
				if (perception.getId()==2){
					for (int i=InteractionList.size1/2-10;i<InteractionList.size1/2+10;i++){
						for (int j=InteractionList.size2-10;j<InteractionList.size2+10;j++){
							vectorFlow[i][j][0]=-1;
							vectorFlow[i][j][1]=-1;
						}
					}
				}/**/
			}
			
		}
		else{
			if (action.getName().equals("^")){
				for (int i=0;i<InteractionList.size1;i++){
					for (int j=0;j<InteractionList.size2*2;j++){
						vectorFlow[i][j][0]=-j +InteractionList.size2 +InteractionList.size1/2;
						vectorFlow[i][j][1]= i +InteractionList.size2 -InteractionList.size1/2;
						
						if ((int)vectorFlow[i][j][0]>=0 && (int)vectorFlow[i][j][0]<InteractionList.size1
						 && (int)vectorFlow[i][j][1]>=0 && (int)vectorFlow[i][j][1]<InteractionList.size2*2) 
							visible[(int)vectorFlow[i][j][0]][(int)vectorFlow[i][j][1]]=true;
					}
				}
			}
			else{
				if (action.getName().equals("v")){
					for (int i=0;i<InteractionList.size1;i++){
						for (int j=0;j<InteractionList.size2*2;j++){
							vectorFlow[i][j][0]= j -InteractionList.size2 +(InteractionList.size1/2);
							vectorFlow[i][j][1]=-i +InteractionList.size2 +(InteractionList.size1/2);
							
							if ((int)vectorFlow[i][j][0]>=0 && (int)vectorFlow[i][j][0]<InteractionList.size1 
							 && (int)vectorFlow[i][j][1]>=0 && (int)vectorFlow[i][j][1]<InteractionList.size2*2) 
								visible[(int)vectorFlow[i][j][0]][(int)vectorFlow[i][j][1]]=true;
						}
					}
				}
				else{
					if (action.getName().equals("/")){
						for (int i=0;i<InteractionList.size1;i++){
							for (int j=0;j<InteractionList.size2*2;j++){
								vectorFlow[i][j][0]=(float)(Math.cos(Math.PI/4)*(i-InteractionList.size1/2)-Math.sin(Math.PI/4)*(j-InteractionList.size2) + InteractionList.size1/2);
								vectorFlow[i][j][1]=(float)(Math.sin(Math.PI/4)*(i-InteractionList.size1/2)+Math.cos(Math.PI/4)*(j-InteractionList.size2) + InteractionList.size2);
							}
						}
					}
					else{
						if (action.getName().equals("\\")){
							for (int i=0;i<InteractionList.size1;i++){
								for (int j=0;j<InteractionList.size2*2;j++){
									vectorFlow[i][j][0]=(float)(Math.cos(-Math.PI/4)*(i-InteractionList.size1/2)-Math.sin(-Math.PI/4)*(j-InteractionList.size2) + InteractionList.size1/2);
									vectorFlow[i][j][1]=(float)(Math.sin(-Math.PI/4)*(i-InteractionList.size1/2)+Math.cos(-Math.PI/4)*(j-InteractionList.size2) + InteractionList.size2);
								}
							}
						}
					}
				}
			}
		}
	}
}

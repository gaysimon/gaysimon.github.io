package version7_3_simu.spaceMemory;

import java.util.ArrayList;

import version7_3_simu.Interface.InteractionList;
import version7_3_simu.Interface.PrimitiveInteraction;

/**
 * Define composite interactions
 * @author simon
 */
public class Composite {

	public PrimitiveInteraction[] sequence;		// path of the composite interaction
	public Signature pattern;					// signature of the composite interaction
	public BlurPattern blur;

	private float prediction;  				// prediction according to the pattern
	
	public ArrayList<Float> predictions1;		// prediction of the blur pattern before interactions
	public ArrayList<Float> predictions2;		// predictions of the blur pattern after interactions
	
	private float valence;						// satisfaction value

	
	public Composite(PrimitiveInteraction[] seq){
		
		sequence=new PrimitiveInteraction[seq.length];
		valence=0;
		for (int i=0;i<seq.length;i++){
			sequence[i]=seq[i];
			valence+=seq[i].valence();
		}

		prediction=0;
		predictions1=new ArrayList<Float>();
		predictions2=new ArrayList<Float>();
		pattern=new Signature();
		blur=new BlurPattern();
	}
	
	public int size(){
		return sequence.length;
	}
	
	// equality functions
	public boolean isEqual(PrimitiveInteraction[] inter){
		if (this.size()!=inter.length) return false;
		else{
			boolean ret=true;
			int i=0;
			while (ret && i<this.size()){
				if (!this.sequence[i].isEqual(inter[i])) ret=false;
				i++;
			}
			return ret;
		}
	}
	
	// return the result of the composite interaction (1 success, -1 failure, 0 not used)
	public int checkSequence(PrimitiveInteraction[] seq){
		int ret=1;
		
		for (int i=this.size()-1;i>0;i--){
			if (!seq[i].isEqual(this.sequence[i])) ret=0;
		}
		
		if (ret==1){
			if (!seq[0].isAlternate(this.sequence[0])) ret=0;
			else{
				if (!seq[0].isEqual(this.sequence[0])) ret=-1;
			}
		}
		
		return ret;
	}
	
	// return true if this interaction is included in the path of seq
	public boolean isPath(Composite seq){
		if (seq.size()>=this.size()) return false;
		else{
			boolean ret=true;
			int diff=this.size()-seq.size();
			for (int i=seq.size()-1;i>=0;i--){
				if (!seq.sequence[i].isEqual(this.sequence[i+diff])) ret=false;
			}
			return ret;
		}
	}
	
	
	public void setPrediction(float[] img){
		prediction=pattern.prediction(img);
	}
	
	// compute prediction in current context
	public void setPrediction1(int nbInteraction, float[][][] img){
		while (nbInteraction>predictions1.size()) predictions1.add(0f);
		while (nbInteraction>predictions2.size()) predictions2.add(0f);
		
		float result=0;
		for (int i=0;i<InteractionList.size1;i++){
			for (int j=0;j<InteractionList.size2*2;j++){
				for (int k=0;k<3;k++){
					result+=blur.pattern[i][j][k]*img[i][j][k];
				}
			}
		}
		for (int m=0;m<nbInteraction;m++){
			predictions1.set(m,result);
		}
	}
	
	// compute predictions with predicted contexts
	public void setPrediction2(ArrayList<Float[][][]> predictionMap){
		while (predictionMap.size()>predictions1.size()) predictions1.add(0f);
		while (predictionMap.size()>predictions2.size()) predictions2.add(0f);
		for (int m=0;m<predictionMap.size();m++){
			float result=0;
			for (int i=0;i<InteractionList.size1;i++){
				for (int j=0;j<InteractionList.size2*2;j++){
					for (int k=0;k<3;k++){
						result+=blur.pattern[i][j][k]*predictionMap.get(m)[i][j][k];
					}
				}
			}
			predictions2.set(m,result);
		}
	}
	
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// getters
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	public float getValence(){
		return valence;
	}
	
	public float getPrediction(){
		return prediction;
	}
	
	public String getName(int param){
		String ret="";
		for (int i=size()-1;i>=0;i--){
			ret+="("+sequence[i].getName()+"),";
		}
		if (param>=1){
			ret+="    :   "+prediction+ "  ; ";
		}
		if (param>=2){
			for (int i=0;i<Math.min(predictions1.size(),predictions2.size());i++){
				ret+=(predictions2.get(i)-predictions1.get(i))+", ";
			}
		}
		return ret;
	}
	
}

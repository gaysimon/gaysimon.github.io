import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Polygon;



public class Level {


	public static int LENGTH=10;						// length of the timeline
	
	//////////////////////////////////////////////////////
	// display properties
	public int panel_width=1;
	public int panel_height=1;
	public int nbShapes=6;
	protected int[] shapes;								// shape of each action
	protected int[] colors;								// color of each interaction
	
	//////////////////////////////////////////////////////
	// interaction properties
	public int nbActions=1;
	public int nbInteraction=1;
	public int[] actionMap;								// give the action associated to each interaction
	public int[] valence;								// valences of interactions
	public int sum=0;
	public int tests=0;
	
	//////////////////////////////////////////////////////
	// world properties
	public int[][] world;								// matrix that define the environment
	
	//////////////////////////////////////////////////////
	// agent properties
	public float px=0;									// position and orientation of the agent in environment
	public float py=0;
	public float theta=0;
	public Color color=Color.orange;					// color of the agent (when displayed)

	//////////////////////////////////////////////////////
	// timeline
	public int[][] timeline;
	

	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	// Constructor
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public Level(){

		timeline=new int[LENGTH][1];
		for (int i=0;i<LENGTH;i++){
			timeline[i][0]=-1;
		}
	}
	
	//////////////////////////////////////////////////////
	// interaction properties
	public int valence(int i){
		if (i<0 || i>=nbInteraction) return 0;
		return valence[i];
	}
	
	//////////////////////////////////////////////////////
	// world properties
	public void action(int action){
	}
	
	
	//////////////////////////////////////////////////////
	// add enacted interaction(s) to timeline
	public void push(int[] inter){
		
		for (int l=LENGTH-1;l>0;l--) timeline[l]=timeline[l-1];
		timeline[0]=inter;
		
		sum=0;
		for (int l=0;l<LENGTH;l++) sum+=valence(timeline[l][0]);
		
		tests++;
	}
	
	//////////////////////////////////////////////////////
	// shape of interactions
	// shapes can be added or modified here
	public void drawShape(Graphics2D g, int id, Color c, int x, int y, int size){
		
		if (id==0){		// circle
			g.setColor(c);
			g.fillOval(x, y, size, size);
			g.setColor(Color.black);
			g.drawOval(x, y, size, size);
		}
		if (id==1){		// square
			g.setColor(c);
			g.fillRect(x, y, size, size);
			g.setColor(Color.black);
			g.drawRect(x, y, size, size);
		}
		if (id==2){		// triangle up
			g.setColor(c);
			Polygon polygon=new Polygon();
			polygon.addPoint(size/2+x, y);
			polygon.addPoint(x, size+y);
			polygon.addPoint(size+x, size+y);
			g.fillPolygon(polygon);
			g.setColor(Color.black);
			g.drawPolygon(polygon);
		}
		if (id==3){		// triangle down
			g.setColor(c);
			Polygon polygon=new Polygon();
			polygon.addPoint(size/2+x, size+y);
			polygon.addPoint(x, y);
			polygon.addPoint(size+x, y);
			g.fillPolygon(polygon);
			g.setColor(Color.black);
			g.drawPolygon(polygon);
		}
		if (id==4){		// triangle left
			g.setColor(c);
			Polygon polygon=new Polygon();
			polygon.addPoint(x, size/2+y);
			polygon.addPoint(size+x, y);
			polygon.addPoint(size+x, size+y);
			g.fillPolygon(polygon);
			g.setColor(Color.black);
			g.drawPolygon(polygon);
		}
		if (id==5){		// triangle right
			g.setColor(c);
			Polygon polygon=new Polygon();
			polygon.addPoint(size+x, size/2+y);
			polygon.addPoint(x, y);
			polygon.addPoint(x, size+y);
			g.fillPolygon(polygon);
			g.setColor(Color.black);
			g.drawPolygon(polygon);
		}
	}
	
	// draw environment
	public void drawEnvironment(Graphics2D g, int x, int y){
		
		int cellWidth=Math.min(100, Math.min(200/world.length, 200/world[0].length));
		int offsetX=(250-cellWidth*world.length)/2;
		int offsetY=(250-cellWidth*world[0].length)/2;
		
		g.setColor(Color.lightGray);
		g.fillRect(x, y, 250, 250);
		g.setColor(Color.black);
		g.drawRect(x, y, 250, 250);
		
		for (int i=0;i<world.length;i++){
			for (int j=0;j<world[i].length;j++){
				
				// define the color of cells here
				if (world[i][j]==1) g.setColor(Color.green);
				else if (world[i][j]==2) g.setColor(Color.blue);
				else if (world[i][j]==3) g.setColor(Color.red);
				else if (world[i][j]==4) g.setColor(Color.yellow);
				else if (world[i][j]==5) g.setColor(Color.magenta);
				else if (world[i][j]==6) g.setColor(Color.cyan);
				else if (world[i][j]==7) g.setColor(Color.orange);
				else if (world[i][j]==8) g.setColor(Color.gray);
				else if (world[i][j]==9) g.setColor(Color.lightGray);
				else if (world[i][j]==10)g.setColor(Color.darkGray);
				else g.setColor(Color.white);
				
				g.fillRect(x+offsetX+i*cellWidth, y+offsetY+j*cellWidth, cellWidth, cellWidth);
				
				if (cellWidth>20){
					g.setColor(Color.black);
					g.drawRect(x+offsetX+i*cellWidth, y+offsetY+j*cellWidth, cellWidth, cellWidth);
				}
			}
		}
		drawAgent(g, x+offsetX+px*cellWidth, y+offsetY+py*cellWidth, cellWidth);
	}
	
	// draw agent
	public void drawAgent(Graphics2D g, float x, float y, int width){
		g.setColor(color);
		g.fillOval( (int)(x+width*0.1f), (int)(y+width*0.1f), (int)(width*0.8f), (int)(width*0.8f));
		g.setColor(Color.black);
		g.drawOval( (int)(x+width*0.1f), (int)(y+width*0.1f), (int)(width*0.8f), (int)(width*0.8f));
	}
	
	public boolean solved(){
		return false;
	}
	
}

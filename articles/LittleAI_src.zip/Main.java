import javax.swing.JFrame;


public class Main  extends JFrame{
	
	private static final long serialVersionUID = 1L;

	DisplayPanel panel;
	
	public Main(){
		
		this.setTitle("AImergence");
    	this.setSize(700, 500);
    	this.setLocationRelativeTo(null);               
    	this.setVisible(true);
    	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    	panel=new DisplayPanel();
    	
    	this.setContentPane(panel);

	}

	///////////////////////////////////////////////////////
	// main function
	public static void main(String[] args){
		new Main();
	}
	
}

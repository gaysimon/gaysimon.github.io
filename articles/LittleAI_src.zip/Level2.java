import java.awt.Color;



public class Level2 extends Level{

	
	public Level2(){
		
		// interaction properties
		nbActions=2;
		nbInteraction=4;
		
		actionMap=new int[nbInteraction];
		actionMap[0]=0;
		actionMap[1]=0;
		actionMap[2]=1;
		actionMap[3]=1;
		
		valence=new int[nbInteraction];
		valence[0]=1;
		valence[1]=-1;
		valence[2]=1;
		valence[3]=-1;
		
		// size of the panel
		panel_width=2;
		panel_height=1;
		
		// default shapes and colors
		shapes=new int[nbActions];
		shapes[0]=0;
		shapes[1]=1;
		
		colors=new int[nbInteraction];
		for (int i=0;i<nbInteraction;i++) colors[i]=0;
		
		//define world
		world=new int[2][1];
		world[0][0]=0;
		world[1][0]=0;
		
		// default position of agent
		px=0;
		py=0;
		theta=0;
	}
	
	
	//////////////////////////////////////////////////////
	// world properties
	public void action(int a){
		int[] ret=new int[1];
		
		boolean bump=false;
		int step=0;
		while (!bump && step<10){
			
			px+=(a*2-1)*0.09;
			
			if (px<=-0.2 || px>=1.2) bump=true;
			
			try{Thread.currentThread();
			Thread.sleep(1);}
			catch(Exception ie){}
			
			step++;
		}
		px=Math.round(px);
		
		if (a==0){
			if (!bump){
				ret[0]=0;
				color=Color.orange;
			}
			else{
				ret[0]=1;
				color=Color.red;
			}
		}
		else{
			if (!bump){
				ret[0]=2;
				color=Color.orange;
			}
			else{
				ret[0]=3;
				color=Color.red;
			}
		}
		push(ret);
	}
	
	public boolean solved(){
		return sum==10;
	}
}

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.event.*;

import javax.swing.*;

import javax.swing.JPanel;


public class DisplayPanel extends JPanel  implements MouseListener, ActionListener{

	private static final long serialVersionUID = 1L;
	
	private static int MODE_PLAY=0;
	private static int MODE_SHAPE=1;
	private static int MODE_COLOR=2;
	
	private static int PLAY=0;
	private static int SUCCESS=1;
	private static int ENV=2;
	
	private int mode;
	
	private int completed;
	
	private Level level;
	
	private int[][] keyMap;
	private int buttonWidth;

	private int b_pressed_x=-1;
	private int b_pressed_y=-1;
	
	private int selected_interaction=-1;
	
	private int offset=0;
	
	private Timer animation;
	private Timer timerClic;
	
	private Color[] colors;
	
	private int id_level=0;
	
	Image backbuffer;
	Graphics backg;
	
	public DisplayPanel(){
		addMouseListener(this);
		
		animation = new Timer(10,this);
        animation.setRepeats(true);
        animation.start();
        
        timerClic = new Timer(1000,this);
        timerClic.setRepeats(true);
        timerClic.start();

        colors=new Color[8];
        
        colors[0]=Color.white;
        colors[1]=Color.black;
        
        colors[2]=Color.red;
        colors[3]=Color.green;
        colors[4]=Color.blue;
        
        colors[5]=Color.yellow;
        colors[6]=Color.cyan;
        colors[7]=Color.magenta;
        
        mode=MODE_PLAY;
        completed=PLAY;
        
        newLevel();
	}

	public void newLevel(){
		
		// connect new levels here
		if (id_level==0) level=new Level1();
		else if (id_level==1) level=new Level2();
		else if (id_level==2) level=new Level11();
		else if (id_level==3) level=new Level12();
		
		
		id_level++;
		
		keyMap=new int[level.panel_width][level.panel_height];
		
		int n=0;
		for (int i=0;i<level.panel_height;i++){
			for (int j=0;j<level.panel_width;j++){
				if (n<level.nbActions) keyMap[j][i]=n;
				else keyMap[j][i]=-1;
				n++;
			}
		}
		
		buttonWidth=Math.min(200/level.panel_height, 300/level.panel_width);
		
	}
	
	
	public void paintComponent(Graphics g){
		
		Graphics2D g2d = (Graphics2D)g;

		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
		
		g.setColor(Color.white);
		g.fillRect(-1, -1, 702, 502);
		
		g.setColor(Color.black);
		g.fillRect(500, 200, 150, 150);
		
		g2d.setColor(Color.white);
		g2d.drawString("WORLD", 550, 275);
		
		
		
		// draw control buttons
		g2d.setStroke(new BasicStroke(2));
		int id=0;
		for (int j=0;j<level.panel_height;j++){
		for (int i=0;i<level.panel_width;i++){
			
				if (keyMap[i][j]!=-1){
					if (i==b_pressed_x && j==b_pressed_y) 
						level.drawShape(g2d, level.shapes[id], Color.gray, 32+i*(buttonWidth+5), 262+j*(buttonWidth+5), buttonWidth-24);
					else 
						level.drawShape(g2d, level.shapes[id], Color.white, 32+i*(buttonWidth+5), 262+j*(buttonWidth+5), buttonWidth-24);
				}
				id++;
			}
		}
 
		// draw timeline
		g2d.setStroke(new BasicStroke(1));
		for (int l=0;l<Level.LENGTH;l++){
			for (int e=0;e<level.timeline[l].length;e++){
				if (level.timeline[l][e]!=-1){
					level.drawShape(g2d, level.shapes[level.actionMap[level.timeline[l][e]]], colors[level.colors[level.timeline[l][e]]], 100+e*50, (Level.LENGTH-l)*20+offset*2, 14);
					g2d.drawString(""+level.valence(level.timeline[l][e]), 120+e*50, 12+(Level.LENGTH-l)*20+offset*2);
				}
			}
		}
		
		// draw sum
		g.setColor(Color.green);
		g.fillRect(20,20,45,25);
		g.setColor(Color.black);
		g.drawString(""+level.sum, 35, 36);
		
		// draw success screen
		if (completed==SUCCESS){
			
			g2d.setColor(Color.gray);
			g2d.fillRect(364, 34, 300, 160);
			
			g2d.setColor(Color.white);
			g2d.fillRect(360, 30, 300, 160);
			
			g2d.setColor(Color.black);
			g2d.drawRect(360, 30, 300, 160);
			
			g2d.drawString("CONGRATULATION", 460, 50);
			g2d.drawString("You have mastered sensorimotor laws",380, 80);
			g2d.drawString("of the agent",380, 100);
			
			g2d.drawString("You are now allowed to observe the", 380,130);
			g2d.drawString("agent in its environment", 380,150);
			
			g2d.setColor(Color.orange);
			g2d.fillRect(480, 160, 50, 25);
			g2d.setColor(Color.black);
			g2d.drawRect(480, 160, 50, 25);
			g2d.drawString("OK", 495, 175);
		}
		
		// draw environment when success
		if (completed==ENV){
			level.drawEnvironment(g2d, 400, 100);
			
			g.setColor(Color.orange);
			g.fillRect(500, 380, 70, 30);
			g.setColor(Color.black);
			g.drawRect(500, 380, 70, 30);
			g.drawString("Next level",505,400);
		}
		
		// draw shape panel
		if (mode==MODE_SHAPE){
			g.setColor(Color.gray);
			g.fillRect(24, 104, 100*level.nbShapes,100);
			g.setColor(Color.white);
			g.fillRect(20, 100, 100*level.nbShapes,100);
			g.setColor(Color.black);
			g.drawRect(20, 100, 100*level.nbShapes,100);
			
			for (int i=0;i<level.nbShapes;i++){
				level.drawShape(g2d, i, Color.white, 20+25+i*100, 100+25, 50);
			}
		}
		
		// draw color mode
		if (mode==MODE_COLOR){
			g.setColor(Color.gray);
			g.fillRect(24, 54, 50,330);
			g.setColor(Color.white);
			g.fillRect(20, 50, 50,330);
			g.setColor(Color.black);
			g.drawRect(20, 50, 50,330);
			
			for (int c=0;c<8;c++){
				g.setColor(colors[c]);
				g.fillRect(28, 58+40*c, 34,34);
			}
			for (int c=0;c<8;c++){
				g.setColor(Color.black);
				g.drawRect(28, 58+40*c, 34,34);
			}
		}
		

	}


	public void mousePressed(MouseEvent e) {

		timerClic.start();
		
		int click_x=e.getX();
		int click_y=e.getY();

		if (mode==MODE_PLAY){
			
			// panel click
			for (int i=0;i<level.panel_width;i++){
				for (int j=0;j<level.panel_height;j++){
					if (keyMap[i][j]!=-1){
						
						if (click_x>32+i*(buttonWidth+5) && click_x<32+(i+1)*(buttonWidth+5) && click_y>262+j*(buttonWidth+5) && click_y<262+(j+1)*(buttonWidth+5)){
							b_pressed_x=i;
							b_pressed_y=j;
							repaint();
						}
					}
				}
			}
			
			// timeline click
			for (int l=0;l<Level.LENGTH;l++){
				for (int j=0;j<level.timeline[l].length;j++){
					if (level.timeline[l][j]!=-1 && click_x>=100+j*50 && click_x<115+j*50 && click_y>=(Level.LENGTH-l)*20 && click_y<(Level.LENGTH-l)*20+15){
						selected_interaction=level.timeline[l][j];
					}
				}
			}
		}
		
		
	}


	public void mouseReleased(MouseEvent e) {
		
		int click_x=e.getX();
		int click_y=e.getY();

		
		if (mode==MODE_PLAY){
			if (b_pressed_x!=-1 && b_pressed_y!=-1 && mode==MODE_PLAY){
				level.action(keyMap[b_pressed_x][b_pressed_y]);
				offset=10;
				animation.start();
				
				if (level.solved() && completed==PLAY) completed=SUCCESS;
			}
		}

		if (mode==MODE_SHAPE){
			if (click_x>20 && click_x<20+100*level.nbShapes && click_y>100 && click_y<200){
				double d;
				double min=2500;
				int imin=-1;
				for (int i=0;i<level.nbShapes;i++){
					d=(click_x-(70+100*i))*(click_x-(70+100*i)) + (click_y-150)*(click_y-(70+100*i));
					if (d<min){
						min=d;
						imin=i;
					}
				}
				if (imin!=-1){
					int id=-1;
					int c=0;
					
					for (int j=0;j<level.panel_height;j++){
						for (int i=0;i<level.panel_width;i++){
							if (i==b_pressed_x && j==b_pressed_y) id=c;
							c++;
						}
					}
					level.shapes[id]=imin;
				}
			}
			mode=MODE_PLAY;
			repaint();
		}

		if (mode==MODE_COLOR){
			if (click_x>20 && click_x<50 && click_y>50 && click_y<380){
				int c=-1;
				for (int i=0;i<8;i++){
					if (click_x>20 && click_x<50 && click_y>50+i*40 && click_y<50+(i+1)*40){
						c=i;
					}
				}
				if (c!=-1){
					level.colors[selected_interaction]=c;
				}
			}
			mode=MODE_PLAY;
			repaint();
		}
		
		b_pressed_x=-1;
		b_pressed_y=-1;
		selected_interaction=-1;
		repaint();
		
		timerClic.stop();

		if (completed==SUCCESS){
			if (click_x>480 && click_x<530 && click_y>160 && click_y<185){
				completed=ENV;
			}
		}

		if (completed==ENV){
			if (click_x>500 && click_x<570 && click_y>380 && click_y<410){
				newLevel();
				completed=PLAY;
			}
		}
	}
	
	public void mouseClicked(MouseEvent arg0) {}
	public void mouseEntered(MouseEvent arg0) {}
	public void mouseExited(MouseEvent arg0) {}
	
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource() == animation) {
			if (offset>0){
				offset--;
             	repaint();
            }
            else animation.stop();
		}

	    if(e.getSource() == timerClic) {
	    	if (b_pressed_x!=-1 && b_pressed_y!=-1){
	    		mode=MODE_SHAPE;
            	repaint();
            }
            if (selected_interaction!=-1){
            	mode=MODE_COLOR;
            	repaint();
            }
            timerClic.stop();
       }
	}
}

#ifndef ROBOT_H_INCLUDED
#define ROBOT_H_INCLUDED

#include "cv.h"
#include "highgui.h"
#include <string>
#include <stdio.h>
#include <ctype.h>
#include <iostream>

using namespace std;

class robot{

  public :

    float x,y,theta;

    bool bump;
    float sensorL,sensorR;
    float astrocyte1,astrocyte2;
    float synapse_1_1,synapse_1_2,synapse_2_1,synapse_2_2;
    float motorL,motorR;
    float valueL,valueR;
    int reward;
    int count;
    int countmax;

    int index;
    int indexCount;
    float values[400][10];






    robot();
    void initialize(int x0,int y0,float theta0);
    void step(float luminosite[480][480],bool l,int xl,int yl);
    void drawRobot(IplImage* sim);
    void drawControl(IplImage* sim);
    void setSynapse(int nb,float val);
    void setPosition(int x,int y);
    void setReward(int reward);
    void write(float* x,float*y,float*theta,int* b,float*lL,float*lR,float*mL,float*mR,
               float*aL,float*aR,float*sL1,float*sL2,float*sR1,float*sR2,float*vL,float*vR);


};

#endif // ROBOT_H_INCLUDED

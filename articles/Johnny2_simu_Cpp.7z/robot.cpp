#include <opencv/highgui.h>
#include <opencv/cv.h>
#include <stdio.h>
#include <ctype.h>
#include <iostream>
#include "robot.h"

using namespace std;

robot::robot(){

}


void robot::initialize(int x0,int y0,float theta0){
    x=x0;
    y=y0;
    theta=theta0;

    sensorL=0;
    sensorR=0;
    astrocyte1=10;
    astrocyte2=10;
    synapse_1_1=0;
    synapse_1_2=0;
    synapse_2_1=0;
    synapse_2_2=0;

    motorL=0;
    motorR=0;
    valueL=0;
    valueR=0;

    reward=0;
    count=0;
    countmax=100;

    bump=false;

    index=0;
    indexCount=0;
    for(int i=0;i<400;i++){
        for(int j=0;j<10;j++){
            values[i][j]=0;
        }
    }

}

void robot::step(float l[480][480],bool lightPos,int xl,int yl){

    float res1=0; // intermediate calculs
    float res2=0;

    float thetaRad=theta*3.14159/180;

    float sensorLx= 18*cos(thetaRad)- 20*sin(thetaRad)+x;
    float sensorLy=-18*sin(thetaRad)- 20*cos(thetaRad)+y;

    float sensorRx= 18*cos(thetaRad)+ 20*sin(thetaRad)+x;
    float sensorRy=-18*sin(thetaRad)+ 20*cos(thetaRad)+y;


    // indirect light
    sensorL= (l[(int)sensorLx][(int)sensorLy]/10);
    sensorR= (l[(int)sensorRx][(int)sensorRy]/10);


    // direct light if light source on center
    if (lightPos){
        float distance= sqrt( (x-xl)*(x-xl)+(y-yl)*(y-yl) );

        if (distance>0){
            res1=((x-xl)/distance);
            res2=((y-yl)/distance);
            float LthetaRad= (theta-45.)*3.14159/180.;
            float directL= (  res1 * ( sin(LthetaRad)) + res2 * (cos(LthetaRad)) );

            float RthetaRad= (theta+45.)*3.14159/180.;
            float directR= (  res1 * (-sin(RthetaRad)) + res2 * (-cos(RthetaRad)) );


            if (directL>0) sensorL+=directL*5;
            if (directR>0) sensorR+=directR*5;

            if (sensorL>25) sensorL=25;
            if (sensorR>25) sensorR=25;

        }
    }




    // compute motor neurons
    motorR= ((sensorL*(synapse_1_1 + astrocyte1)) + (25.-sensorL)*(synapse_1_2 +astrocyte1)) /500.;
    motorL= ((sensorR*(synapse_2_1 + astrocyte2)) + (25.-sensorR)*(synapse_2_2 +astrocyte2)) /500.;




    // update position
    float d= (motorR+motorL)/2;
    x+=d*cos(thetaRad);
    y+=d*(-sin(thetaRad));

    theta-= tan( (motorL-motorR)/40)*180/3.14159;
    if (theta>=360) theta-=360;
    if (theta<   0) theta+=360;


    // collision detection
    bump=false;

    if (x<40)  {
        x=40;
        if ( (theta>120)&&(theta<240) ) bump=true;
    }
    if (x>440) {
        x=440;
        if ( (theta>300)||(theta<60) ) bump=true;
    }
    if (y<40)  {
        y=40;
        if ( (theta>30)&&(theta<150) ) bump=true;
    }
    if (y>440) {
        y=440;
        if ( (theta>210)&&(theta<330) ) bump=true;
    }



    count++;


    // fill values matrix
    index=indexCount/5;
    if (index>=400){
        index=0;
        indexCount=0;
    }

    values[index][0]=sensorL;
    values[index][1]=sensorR;
    values[index][2]=synapse_1_2;
    values[index][3]=synapse_1_1;
    values[index][4]=synapse_2_2;
    values[index][5]=synapse_2_1;
    values[index][6]=astrocyte1;
    values[index][7]=astrocyte2;
    values[index][8]=motorR;
    values[index][9]=motorL;

    indexCount++;



    // astrocyts computing
    if (count>countmax){
        count=0;
        if (!bump){
            //cout<<astrocyte1<<" , "<<astrocyte2<<" , "<<endl;
            if (motorR+reward>valueR){
                synapse_1_1+= astrocyte1 * sensorL      /25.;
                if (synapse_1_1>100) synapse_1_1=100;
                synapse_1_2+= astrocyte1 * (25-sensorL)/25.;
                if (synapse_1_2>100) synapse_1_2=100;
            }
            else{
                synapse_1_1-= astrocyte1 * sensorL      /25.;
                synapse_1_2-= astrocyte1 * (25-sensorL)/25.;
            }

            if (motorL+reward>valueL){
                synapse_2_1+= astrocyte2 * sensorR      /25.;
                if (synapse_2_1>100) synapse_2_1=100;
                synapse_2_2+= astrocyte2 * (25-sensorR)/25.;
                if (synapse_2_2>100) synapse_2_2=100;
            }
            else{
                synapse_2_1-= astrocyte2 * sensorR      /25.;
                synapse_2_2-= astrocyte2 * (25-sensorR)/25.;
            }

            if (astrocyte1>0) astrocyte1=-10;
            else              astrocyte1= 10;

            if (astrocyte2>0) astrocyte2=-10;
            else              astrocyte2= 10;

            valueR=motorR+reward;
            valueL=motorL+reward;
            countmax=100;
        }
        else{
            valueR=-100;
            valueL=-100;

            synapse_1_1-= astrocyte1 * sensorL      /50.;
            synapse_1_2-= astrocyte1 * (25-sensorL)/50.;

            synapse_2_1-= astrocyte2 * sensorR      /50.;
            synapse_2_2-= astrocyte2 * (25-sensorR)/50.;

            if (astrocyte1>0) astrocyte1=-astrocyte1-20;
            else              astrocyte1=-astrocyte1+20;

            if (astrocyte2>0) astrocyte2=-astrocyte2-20;
            else              astrocyte2=-astrocyte2+20;
            countmax=10;
        }
        reward=0;
    }

}







void robot::drawRobot(IplImage* sim){

    float thetaRad=theta*3.14159/180;

    float res1,res2;
    int   res3,res4;

    ////////////////////////
    // draw robot
    ////////////////////////
    cvDrawCircle(sim,cvPoint(x,y),20,CV_RGB(150,150,150),-1);

    // wheels
    res1= cos(thetaRad);
    res2= sin(thetaRad);

    cvLine(sim, cvPoint(-5*res1-20*res2+x, 5*res2-20*res1 +y),
                cvPoint( 5*res1-20*res2+x,-5*res2-20*res1 +y), CV_RGB(50,70,50), 3, 8);

    cvLine(sim, cvPoint(-5*res1+20*res2+x, 5*res2+20*res1 +y),
                cvPoint( 5*res1+20*res2+x,-5*res2+20*res1 +y), CV_RGB(50,70,50), 3, 8);
    // light sensors
    cvLine(sim, cvPoint( 20*res1- 5*res2+x,-20*res2- 5*res1 +y),
                cvPoint( 15*res1-15*res2+x,-15*res2-15*res1 +y), CV_RGB(100,100,50), 2, 8);

    cvLine(sim, cvPoint( 20*res1+ 5*res2+x,-20*res2+ 5*res1 +y),
                cvPoint( 15*res1+15*res2+x,-15*res2+15*res1 +y), CV_RGB(100,100,50), 2, 8);
    // bumper
    if (bump) cvEllipse(sim, cvPoint(x,y), cvSize(24,24), theta/2, theta/2-60, theta/2+60, CV_RGB(250,0, 0), 2, 8, 0);
    else      cvEllipse(sim, cvPoint(x,y), cvSize(24,24), theta/2, theta/2-60, theta/2+60, CV_RGB(50,70,50), 2, 8, 0);




    ////////////////////////
    // draw network
    ////////////////////////

    //bumper
    if (bump) cvDrawRect(sim,cvPoint(150,500),cvPoint(330,510),CV_RGB(250,  0,  0),-1);
    else      cvDrawRect(sim,cvPoint(150,500),cvPoint(330,510),CV_RGB(100,100,100),-1);

    // light sensors
    cvDrawRect(sim,cvPoint(30,500),cvPoint(130,520),CV_RGB(100,100,100),-1);
    cvDrawRect(sim,cvPoint(350,500),cvPoint(450,520),CV_RGB(100,100,100),-1);

    cvDrawRect(sim,cvPoint(30,500),cvPoint( 30 + sensorL*4,520),CV_RGB(200,200,0),-1);
    cvDrawRect(sim,cvPoint(450-sensorR*4,500),cvPoint(450,520),CV_RGB(200,200,0),-1);

    // neurons
    cvDrawCircle(sim,cvPoint( 80,720),30,CV_RGB(125-motorR*22.5,125+motorR*22.5,0),-1);
    cvLine(sim, cvPoint(110,720), cvPoint(160,720), CV_RGB(125-motorR*22.5,125+motorR*22.5,0), 8, 8);
    cvDrawCircle(sim,cvPoint(400,720),30,CV_RGB(125-motorL*22.5,125+motorL*22.5,0),-1);
    cvLine(sim, cvPoint(370,720), cvPoint(320,720), CV_RGB(125-motorL*22.5,125+motorL*22.5,0), 8, 8);

    // astrocyts
    cvDrawCircle(sim,cvPoint(200,610),25,CV_RGB(max(0,min(125-(int)astrocyte1*2,250)),max(0,min(125+(int)astrocyte1*2,250)),0),10);
    cvDrawCircle(sim,cvPoint(280,610),25,CV_RGB(max(0,min(125-(int)astrocyte2*2,250)),max(0,min(125+(int)astrocyte2*2,250)),0),10);

    // synaps
    cvDrawCircle(sim,cvPoint(40,600),15,CV_RGB(125-synapse_1_1,125+synapse_1_1,0),-1);
    cvLine(sim, cvPoint(20,600), cvPoint(60,600), CV_RGB(0,0,0), 3, 8);
    cvDrawCircle(sim,cvPoint(40,600),20,CV_RGB(max(0,min(125-(int)astrocyte1*2,250)),max(0,min(125+(int)astrocyte1*2,250)),0),2);

    cvDrawCircle(sim,cvPoint(110,640),15,CV_RGB(125-synapse_1_2,125+synapse_1_2,0),-1);
    cvLine(sim, cvPoint(90,640), cvPoint(130,640), CV_RGB(0,0,0), 3, 8);
    cvDrawCircle(sim,cvPoint(110,640),20,CV_RGB(max(0,min(125-(int)astrocyte1*2,250)),max(0,min(125+(int)astrocyte1*2,250)),0),2);

    cvDrawCircle(sim,cvPoint(440,600),15,CV_RGB(125-synapse_2_1,125+synapse_2_1,0),-1);
    cvLine(sim, cvPoint(420,600), cvPoint(460,600), CV_RGB(0,0,0), 3, 8);
    cvDrawCircle(sim,cvPoint(440,600),20,CV_RGB(max(0,min(125-(int)astrocyte1*2,250)),max(0,min(125+(int)astrocyte1*2,250)),0),2);

    cvDrawCircle(sim,cvPoint(370,640),15,CV_RGB(125-synapse_2_2,125+synapse_2_2,0),-1);
    cvLine(sim, cvPoint(350,640), cvPoint(390,640), CV_RGB(0,0,0), 3, 8);
    cvDrawCircle(sim,cvPoint(370,640),20,CV_RGB(max(0,min(125-(int)astrocyte1*2,250)),max(0,min(125+(int)astrocyte1*2,250)),0),2);

    // motors
    cvDrawRect(sim,cvPoint(30,800),cvPoint(150,860),CV_RGB(100,100,100),-1);
    cvDrawRect(sim,cvPoint(330,800),cvPoint(450,860),CV_RGB(100,100,100),-1);

    cvLine(sim, cvPoint(32,830 - motorL*5), cvPoint(148,830 - motorL*5), CV_RGB(10,10,10), 1, 8);
    cvLine(sim, cvPoint(332,830 - motorR*5), cvPoint(448,830 - motorR*5), CV_RGB(10,10,10), 1, 8);

    // connexions sensor-synapses
    cvLine(sim, cvPoint(35,520), cvPoint(40,585), CV_RGB(250-sensorL*10,sensorR*10,0), 2, 8);
    cvLine(sim, cvPoint(125,520), cvPoint(110,625), CV_RGB(sensorL*10,250-sensorL*10,0), 2, 8);

    cvLine(sim, cvPoint(445,520), cvPoint(440,585), CV_RGB(250-sensorR*10,sensorL*10,0), 2, 8);
    cvLine(sim, cvPoint(355,520), cvPoint(370,625), CV_RGB(sensorR*10,250-sensorL*10,0), 2, 8);

    // connexions synapses-neurons
    cvLine(sim, cvPoint(40,615), cvPoint(50,710), CV_RGB( 125-sensorL*(synapse_1_1 + astrocyte1)/22 , 125+sensorL*(synapse_1_1+astrocyte1)/22,0)  , 2, 8);
    cvLine(sim, cvPoint(110,655), cvPoint(110,710), CV_RGB( 125-sensorL*(synapse_1_2 + astrocyte1)/22 , 125+sensorL*(synapse_1_2+astrocyte1)/22,0)  , 2, 8);

    cvLine(sim, cvPoint(440,615), cvPoint(430,710), CV_RGB( 125-sensorR*(synapse_2_1 + astrocyte1)/22 , 125+sensorR*(synapse_2_1+astrocyte1)/22,0)  , 2, 8);
    cvLine(sim, cvPoint(370,655), cvPoint(370,710), CV_RGB( 125-sensorR*(synapse_2_2 + astrocyte1)/22 , 125+sensorR*(synapse_2_2+astrocyte1)/22,0)  , 2, 8);

    // connexions astrocytes-synapses
    res3=(int)astrocyte1*2;
    res4=(int)astrocyte2*2;
    cvLine(sim, cvPoint(170,610), cvPoint(160,610), CV_RGB(max(0,min(125-res3,250)) , max(0,min(125+res3,250)),0) , 8, 8);
    cvLine(sim, cvPoint(160,610), cvPoint(60,600),  CV_RGB(max(0,min(125-res3,250)) , max(0,min(125+res3,250)),0) , 2, 8);
    cvLine(sim, cvPoint(160,610), cvPoint(130,640), CV_RGB(max(0,min(125-res3,250)) , max(0,min(125+res3,250)),0) , 2, 8);

    cvLine(sim, cvPoint(305,610), cvPoint(320,610), CV_RGB(max(0,min(125-res4,250)) , max(0,min(125+res4,250)),0) , 8, 8);
    cvLine(sim, cvPoint(320,610), cvPoint(420,600), CV_RGB(max(0,min(125-res4,250)) , max(0,min(125+res4,250)),0) , 2, 8);
    cvLine(sim, cvPoint(320,610), cvPoint(350,640), CV_RGB(max(0,min(125-res4,250)) , max(0,min(125+res4,250)),0) , 2, 8);

    // connexions neurones-astrocytes
    res1=motorR*22.5;
    res2=motorL*22.5;
    cvLine(sim, cvPoint(160,720), cvPoint(200,640), CV_RGB(125-res1,125+res1,0) , 2, 8);
    cvLine(sim, cvPoint(320,720), cvPoint(280,640), CV_RGB(125-res2,125+res2,0) , 2, 8);

    // connexions neurones-moteurs
    cvLine(sim, cvPoint(160,720), cvPoint(330,830), CV_RGB(125-res1,125+res1,0) , 2, 8);
    cvLine(sim, cvPoint(320,720), cvPoint(150,830), CV_RGB(125-res2,125+res2,0) , 2, 8);

    // connexions bumper-astrocytes
    if (bump)   cvLine(sim, cvPoint(240,510), cvPoint(200,580), CV_RGB(250,  0,  0) , 2, 8);
    else        cvLine(sim, cvPoint(240,510), cvPoint(200,580), CV_RGB(100,100,100) , 2, 8);

    if (bump)   cvLine(sim, cvPoint(240,510), cvPoint(280,580), CV_RGB(250,  0,  0) , 2, 8);
    else        cvLine(sim, cvPoint(240,510), cvPoint(280,580), CV_RGB(100,100,100) , 2, 8);





    ////////////////////////
    // draw graphs
    ////////////////////////
    int index2=index+2;

    for(int i=1;i<400;i++){
        if (index2>=400) index2=index2%400;

        res3=700+i;
        res4=(index2+399)%400;

        cvLine(sim, cvPoint(res3, 70-2*values[index2][0]), cvPoint(res3, 70-2*values[res4][0]), CV_RGB(200,200,  0) , 1, 8);
        cvLine(sim, cvPoint(res3,130-2*values[index2][1]), cvPoint(res3,130-2*values[res4][1]), CV_RGB(200,200,  0) , 1, 8);

        cvLine(sim, cvPoint(res3,190-values[index2][2]/2), cvPoint(res3,190-values[res4][2]/2), CV_RGB( 50,  0,200) , 1, 8);
        cvLine(sim, cvPoint(res3,190-values[index2][3]/2), cvPoint(res3,190-values[res4][3]/2), CV_RGB(150,150,  0) , 1, 8);

        cvLine(sim, cvPoint(res3,300-values[index2][4]/2), cvPoint(res3,300-values[res4][4]/2), CV_RGB( 50,  0,200) , 1, 8);
        cvLine(sim, cvPoint(res3,300-values[index2][5]/2), cvPoint(res3,300-values[res4][5]/2), CV_RGB(150,150,  0) , 1, 8);

        cvLine(sim, cvPoint(res3,410-max(-60,min(60,(int)values[index2][6]))/3), cvPoint(res3,410-max(-60,min(60,(int)values[res4][6]))/3), CV_RGB(0,180,0) , 1, 8);
        cvLine(sim, cvPoint(res3,520-max(-60,min(60,(int)values[index2][7]))/3), cvPoint(res3,520-max(-60,min(60,(int)values[res4][7]))/3), CV_RGB(0,180,0) , 1, 8);

        cvLine(sim, cvPoint(res3,640-8*values[index2][8]), cvPoint(res3,640-8*values[res4][8]), CV_RGB(180,0,0) , 1, 8);
        cvLine(sim, cvPoint(res3,760-8*values[index2][9]), cvPoint(res3,760-8*values[res4][9]), CV_RGB(180,0,0) , 1, 8);

        index2++;
    }


}


void robot::drawControl(IplImage* sim){
    int res1=0;
    if (reward>=0){
        res1=500+reward*16/10;
        cvLine(sim, cvPoint(res1,502), cvPoint(res1,528), CV_RGB(120,120,120) , 2, 8);
        cvDrawCircle(sim,cvPoint(res1,500),3,CV_RGB(120,120,120),-1);
        cvDrawCircle(sim,cvPoint(res1,530),3,CV_RGB(120,120,120),-1);

        cvLine(sim, cvPoint(500,552), cvPoint(500,578), CV_RGB(120,120,120) , 2, 8);
        cvDrawCircle(sim,cvPoint(500,550),3,CV_RGB(120,120,120),-1);
        cvDrawCircle(sim,cvPoint(500,580),3,CV_RGB(120,120,120),-1);

    }
    else{
        res1=500-reward*16/10;
        cvLine(sim, cvPoint(res1,552), cvPoint(res1,578), CV_RGB(120,120,120) , 2, 8);
        cvDrawCircle(sim,cvPoint(res1,550),3,CV_RGB(120,120,120),-1);
        cvDrawCircle(sim,cvPoint(res1,580),3,CV_RGB(120,120,120),-1);

        cvLine(sim, cvPoint(500,502), cvPoint(500,528), CV_RGB(120,120,120) , 2, 8);
        cvDrawCircle(sim,cvPoint(500,500),3,CV_RGB(120,120,120),-1);
        cvDrawCircle(sim,cvPoint(500,530),3,CV_RGB(120,120,120),-1);
    }

    res1=580+synapse_1_1*8/10;
    cvLine(sim, cvPoint(res1,620), cvPoint(res1,650), CV_RGB(120,120,120) , 2, 8);
    cvDrawCircle(sim,cvPoint(res1,620),3,CV_RGB(120,120,120),-1);
    cvDrawCircle(sim,cvPoint(res1,650),3,CV_RGB(120,120,120),-1);

    res1=580+synapse_1_2*8/10;
    cvLine(sim, cvPoint(res1,680), cvPoint(res1,710), CV_RGB(120,120,120) , 2, 8);
    cvDrawCircle(sim,cvPoint(res1,680),3,CV_RGB(120,120,120),-1);
    cvDrawCircle(sim,cvPoint(res1,710),3,CV_RGB(120,120,120),-1);

    res1=580+synapse_2_1*8/10;
    cvLine(sim, cvPoint(res1,760), cvPoint(res1,790), CV_RGB(120,120,120) , 2, 8);
    cvDrawCircle(sim,cvPoint(res1,760),3,CV_RGB(120,120,120),-1);
    cvDrawCircle(sim,cvPoint(res1,790),3,CV_RGB(120,120,120),-1);

    res1=580+synapse_2_2*8/10;
    cvLine(sim, cvPoint(res1,820), cvPoint(res1,850), CV_RGB(120,120,120) , 2, 8);
    cvDrawCircle(sim,cvPoint(res1,820),3,CV_RGB(120,120,120),-1);
    cvDrawCircle(sim,cvPoint(res1,850),3,CV_RGB(120,120,120),-1);
}


void robot::setPosition(int x2,int y2){
    x=x2;
    y=y2;
}


void robot::setSynapse(int nb,float value){
    switch(nb){
            case 1 :synapse_1_1=value;
                    break;
            case 2 :synapse_1_2=value;
                    break;
            case 3 :synapse_2_1=value;
                    break;
            case 4 :synapse_2_2=value;
                    break;
            default:break;
    }

}

void robot::setReward(int r){
    reward=r;
}


void robot::write(float* xw,float*yw,float*thetaw,int* b,float*lL,float*lR,float*mL,float*mR,
               float*aL,float*aR,float*sL1,float*sL2,float*sR1,float*sR2,float*vL,float*vR){

        *xw=x;
        *yw=y;
        *thetaw=theta;
        if (bump) *b=1;
        else      *b=0;
        *lL=sensorL;
        *lR=sensorR;
        *mL=motorL;
        *mR=motorR;
        *aL=astrocyte1;
        *aR=astrocyte2;
        *sL1=synapse_1_1;
        *sL2=synapse_1_2;
        *sR1=synapse_2_1;
        *sR2=synapse_2_2;
        *vL=valueL;
        *vR=valueR;
}

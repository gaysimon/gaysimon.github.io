#include <opencv/highgui.h>
#include <opencv/cv.h>
#include <iostream>
#include <fstream>
#include <string>
#include <time.h>
#include "robot.cpp"

using namespace std;



IplImage *simulateur = 0;
bool light=true;
bool clic=false;
bool pause1=true;
bool record=false;
bool newRecord=true;

robot *r1;

float luminosite[480][480];

int buttonLightX=520;
int buttonLightY=250;
bool lightPressed=false;

int buttonPauseX=520;
int buttonPauseY=300;
bool pausePressed=false;

int buttonResetX=520;
int buttonResetY=350;
bool resetPressed=false;

int buttonRecX=520;
int buttonRecY=400;
bool recPressed=false;

int step=0;
CvFont font;
time_t temps_act;
std::ofstream file( "robot.txt", std::ios_base::app );



string itos(int n){
    ostringstream oss;
    oss << n;

    return oss.str();
}


void drawButton(int X,int Y,bool press){
    if (press){
        cvDrawRect(simulateur,cvPoint(X,Y),cvPoint(X+120,Y+30),CV_RGB(80,80,130),-1);
        cvLine(simulateur, cvPoint(X-  2,Y+32), cvPoint(X+122,Y+32), CV_RGB(150,150,150), 2, 8);
        cvLine(simulateur, cvPoint(X+122,Y- 2), cvPoint(X+122,Y+32), CV_RGB(150,150,150), 2, 8);
        cvLine(simulateur, cvPoint(X-2,  Y- 2), cvPoint(X+122,Y- 2), CV_RGB(50,50,50), 2, 8);
        cvLine(simulateur, cvPoint(X-2,  Y- 2), cvPoint(X-  2,Y+32), CV_RGB(50,50,50), 2, 8);
    }
    else{
        cvDrawRect(simulateur,cvPoint(X,Y),cvPoint(X+120,Y+30),CV_RGB(100,100,150),-1);
        cvLine(simulateur, cvPoint(X-  2,Y+32), cvPoint(X+122,Y+32), CV_RGB(50,50,50), 2, 8);
        cvLine(simulateur, cvPoint(X+122,Y- 2), cvPoint(X+122,Y+32), CV_RGB(50,50,50), 2, 8);
        cvLine(simulateur, cvPoint(X-2,  Y- 2), cvPoint(X+122,Y- 2), CV_RGB(150,150,150), 2, 8);
        cvLine(simulateur, cvPoint(X-2,  Y- 2), cvPoint(X-  2,Y+32), CV_RGB(150,150,150), 2, 8);
    }
}


void drawInterface(){

    cvDrawRect(simulateur,cvPoint(490,10),cvPoint(670,470),CV_RGB(0,0,250),2);


    // step
    cvDrawRect(simulateur,cvPoint(510,170),cvPoint(650,200),CV_RGB(0,0,250),1);
    cvPutText( simulateur, ((string)("step = ")+itos(step)).c_str(), cvPoint(515,190), &font, CV_RGB(0,0,200) );

    // robot light sensors
    cvDrawRect(simulateur,cvPoint(510,145),cvPoint(560,20),CV_RGB(100,100,100),-1);
    cvDrawRect(simulateur,cvPoint(512,145),cvPoint(558,145-( (r1->sensorL)*5)),CV_RGB(200,200,0),-1);

    cvDrawRect(simulateur,cvPoint(600,145),cvPoint(650,20),CV_RGB(100,100,100),-1);
    cvDrawRect(simulateur,cvPoint(602,145),cvPoint(648,145-( (r1->sensorR)*5)),CV_RGB(200,200,0),-1);

    // light button
    drawButton(buttonLightX,buttonLightY,lightPressed);
    if (light) cvDrawRect(simulateur,cvPoint(buttonLightX+45,buttonLightY+2),cvPoint(buttonLightX+75,buttonLightY+28),CV_RGB(150,150,0),2);
    else       cvDrawCircle(simulateur,cvPoint(buttonLightX+60,buttonLightY+15),3,CV_RGB(150,150,0),-1);

    // pause button
    drawButton(buttonPauseX,buttonPauseY,pausePressed);
    if (pause1) {
        cvLine(simulateur, cvPoint(buttonPauseX+45,buttonPauseY+ 3), cvPoint(buttonPauseX+70,buttonPauseY+15), CV_RGB(0,0,0), 2, 8);
        cvLine(simulateur, cvPoint(buttonPauseX+45,buttonPauseY+27), cvPoint(buttonPauseX+70,buttonPauseY+15), CV_RGB(0,0,0), 2, 8);
        cvLine(simulateur, cvPoint(buttonPauseX+45,buttonPauseY+27), cvPoint(buttonPauseX+45,buttonPauseY+ 3), CV_RGB(0,0,0), 2, 8);
    }
    else{
        cvDrawRect(simulateur,cvPoint(buttonPauseX+50,buttonPauseY+5),cvPoint(buttonPauseX+55,buttonPauseY+25),CV_RGB(0,0,0),-1);
        cvDrawRect(simulateur,cvPoint(buttonPauseX+60,buttonPauseY+5),cvPoint(buttonPauseX+65,buttonPauseY+25),CV_RGB(0,0,0),-1);
    }

    // reset button
    drawButton(buttonResetX,buttonResetY,resetPressed);
    cvDrawRect(simulateur,cvPoint(buttonResetX+47,buttonResetY+5),cvPoint(buttonResetX+68,buttonResetY+25),CV_RGB(0,0,0),-1);


    // record button
    drawButton(buttonRecX,buttonRecY,recPressed);
    cvDrawCircle(simulateur,cvPoint(buttonRecX+60,buttonRecY+15),8,CV_RGB(150,0,0),-1);
}






void drawControlPanel(){
    cvDrawRect(simulateur,cvPoint(490,480),cvPoint(670,890),CV_RGB(0,0,250),2);

    cvDrawRect(simulateur,cvPoint(500,500),cvPoint(660,530),CV_RGB(50,150,50),-1);
    cvPutText( simulateur, "0    reward   100", cvPoint(502,520), &font, CV_RGB(0,0,0) );

    cvDrawRect(simulateur,cvPoint(500,550),cvPoint(660,580),CV_RGB(150,50,50),-1);
    cvPutText( simulateur, "0   punition  100", cvPoint(502,570), &font, CV_RGB(0,0,0) );


    cvLine(simulateur, cvPoint(490,600), cvPoint(670,600), CV_RGB(0,0,250), 1, 8);


    cvDrawRect(simulateur,cvPoint(500,620),cvPoint(660,650),CV_RGB(150,150,50),-1);
    cvPutText( simulateur, "   synapse L +", cvPoint(502,640), &font, CV_RGB(0,0,0) );

    cvDrawRect(simulateur,cvPoint(500,680),cvPoint(660,710),CV_RGB( 50,100,150),-1);
    cvPutText( simulateur, "   synapse L -", cvPoint(502,700), &font, CV_RGB(0,0,0) );


    cvDrawRect(simulateur,cvPoint(500,760),cvPoint(660,790),CV_RGB(150,150,50),-1);
    cvPutText( simulateur, "   synapse R +", cvPoint(502,780), &font, CV_RGB(0,0,0) );

    cvDrawRect(simulateur,cvPoint(500,820),cvPoint(660,850),CV_RGB( 50,100,150),-1);
    cvPutText( simulateur, "   synapse R -", cvPoint(502,840), &font, CV_RGB(0,0,0) );

    cvLine(simulateur, cvPoint(580,620), cvPoint(580,650), CV_RGB(10,10,10), 1, 8);
    cvLine(simulateur, cvPoint(580,680), cvPoint(580,710), CV_RGB(10,10,10), 1, 8);
    cvLine(simulateur, cvPoint(580,760), cvPoint(580,790), CV_RGB(10,10,10), 1, 8);
    cvLine(simulateur, cvPoint(580,820), cvPoint(580,850), CV_RGB(10,10,10), 1, 8);

    float res1,res2;
    for (int i=0;i<=10;i++){
        res1=500+i*16;
        cvLine(simulateur, cvPoint(res1,500), cvPoint(res1,502), CV_RGB(0,0,0), 1, 8);
        cvLine(simulateur, cvPoint(res1,530), cvPoint(res1,528), CV_RGB(0,0,0), 1, 8);
        cvLine(simulateur, cvPoint(res1,550), cvPoint(res1,552), CV_RGB(0,0,0), 1, 8);
        cvLine(simulateur, cvPoint(res1,580), cvPoint(res1,578), CV_RGB(0,0,0), 1, 8);

        res1=580+i*8;
        res2=580-i*8;
        cvLine(simulateur, cvPoint(res1,620), cvPoint(res1,622), CV_RGB(0,0,0), 1, 8);
        cvLine(simulateur, cvPoint(res1,680), cvPoint(res1,682), CV_RGB(0,0,0), 1, 8);
        cvLine(simulateur, cvPoint(res1,760), cvPoint(res1,762), CV_RGB(0,0,0), 1, 8);
        cvLine(simulateur, cvPoint(res1,820), cvPoint(res1,822), CV_RGB(0,0,0), 1, 8);

        cvLine(simulateur, cvPoint(res1,650), cvPoint(res1,648), CV_RGB(0,0,0), 1, 8);
        cvLine(simulateur, cvPoint(res1,710), cvPoint(res1,708), CV_RGB(0,0,0), 1, 8);
        cvLine(simulateur, cvPoint(res1,790), cvPoint(res1,788), CV_RGB(0,0,0), 1, 8);
        cvLine(simulateur, cvPoint(res1,850), cvPoint(res1,848), CV_RGB(0,0,0), 1, 8);


        cvLine(simulateur, cvPoint(res2,620), cvPoint(res2,622), CV_RGB(0,0,0), 1, 8);
        cvLine(simulateur, cvPoint(res2,680), cvPoint(res2,682), CV_RGB(0,0,0), 1, 8);
        cvLine(simulateur, cvPoint(res2,760), cvPoint(res2,762), CV_RGB(0,0,0), 1, 8);
        cvLine(simulateur, cvPoint(res2,820), cvPoint(res2,822), CV_RGB(0,0,0), 1, 8);

        cvLine(simulateur, cvPoint(res2,650), cvPoint(res2,648), CV_RGB(0,0,0), 1, 8);
        cvLine(simulateur, cvPoint(res2,710), cvPoint(res2,708), CV_RGB(0,0,0), 1, 8);
        cvLine(simulateur, cvPoint(res2,790), cvPoint(res2,788), CV_RGB(0,0,0), 1, 8);
        cvLine(simulateur, cvPoint(res2,850), cvPoint(res2,848), CV_RGB(0,0,0), 1, 8);
    }

    (*r1).drawControl(simulateur);
}

void drawNetwork(){
    cvDrawRect(simulateur,cvPoint(10,480),cvPoint(470,890),CV_RGB(0,0,250),2);
}


void drawGraph(){
    cvDrawRect(simulateur,cvPoint(690,10),cvPoint(1150,890),CV_RGB(0,0,250),2);
    // light graphs
    cvLine(simulateur, cvPoint(700,20), cvPoint(700,70), CV_RGB(100,100,100), 1, 8);
    cvLine(simulateur, cvPoint(700,70), cvPoint(1100,70), CV_RGB(100,100,100), 1, 8);

    cvLine(simulateur, cvPoint(700,80), cvPoint(700,130), CV_RGB(100,100,100), 1, 8);
    cvLine(simulateur, cvPoint(700,130), cvPoint(1100,130), CV_RGB(100,100,100), 1, 8);

    // synaps
    cvLine(simulateur, cvPoint(690,135), cvPoint(1150,135), CV_RGB(0,0,250), 1, 8);

    cvLine(simulateur, cvPoint(700,140), cvPoint(700,240), CV_RGB(100,100,100), 1, 8);
    cvLine(simulateur, cvPoint(700,190), cvPoint(1100,190), CV_RGB(100,100,100), 1, 8);

    cvLine(simulateur, cvPoint(700,250), cvPoint(700,350), CV_RGB(100,100,100), 1, 8);
    cvLine(simulateur, cvPoint(700,300), cvPoint(1100,300), CV_RGB(100,100,100), 1, 8);

    // astrocyts
    cvLine(simulateur, cvPoint(690,355), cvPoint(1150,355), CV_RGB(0,0,250), 1, 8);

    cvLine(simulateur, cvPoint(700,360), cvPoint(700,460), CV_RGB(100,100,100), 1, 8);
    cvLine(simulateur, cvPoint(700,410), cvPoint(1100,410), CV_RGB(100,100,100), 1, 8);

    cvLine(simulateur, cvPoint(700,470), cvPoint(700,570), CV_RGB(100,100,100), 1, 8);
    cvLine(simulateur, cvPoint(700,520), cvPoint(1100,520), CV_RGB(100,100,100), 1, 8);

    // neurons
    cvLine(simulateur, cvPoint(690,575), cvPoint(1150,575), CV_RGB(0,0,250), 1, 8);

    cvLine(simulateur, cvPoint(700,590), cvPoint(700,690), CV_RGB(100,100,100), 1, 8);
    cvLine(simulateur, cvPoint(700,640), cvPoint(1100,640), CV_RGB(100,100,100), 1, 8);

    cvLine(simulateur, cvPoint(700,710), cvPoint(700,810), CV_RGB(100,100,100), 1, 8);
    cvLine(simulateur, cvPoint(700,760), cvPoint(1100,760), CV_RGB(100,100,100), 1, 8);

}


void fillLuminosite(bool l){
    int d=0;
    if (l){
        // light on center
        for (int i=0;i<480;i++){
            for (int j=0;j<480;j++){
                d= sqrt( (240-i)*(240-i) + (240-j)*(240-j) );
                d=d*2;
                if (d<50)  luminosite[i][j]=250;
                else if (d<400) luminosite[i][j]=400-d;
                else       luminosite[i][j]=0;
            }
        }
    }
    else{
        // light on borders
        for (int i=0;i<480;i++){
            for (int j=0;j<480;j++){
                d= min( min( (i-10),(470-i) ) , min( (j-10),(470-j) ) );
                d=d*2;
                if (d<250) luminosite[i][j]=250-d;
                else       luminosite[i][j]=0;
            }
        }
    }
}





void on_mouse( int event, int x, int y, int flags, void* param ){
    if (event == CV_EVENT_LBUTTONDOWN){
        if ( (x>=buttonLightX)&&(x<=buttonLightX+120)&&(y>=buttonLightY)&&(y<=buttonLightY+30) ){
            light = !light;
            lightPressed=true;
            fillLuminosite(light);
        }

        if ( (x>=buttonPauseX)&&(x<=buttonPauseX+120)&&(y>=buttonPauseY)&&(y<=buttonPauseY+30) ){
            pause1 = !pause1;
            pausePressed=true;
        }

        if ( (x>=buttonResetX)&&(x<=buttonResetX+120)&&(y>=buttonResetY)&&(y<=buttonResetY+30) ){
            (*r1).initialize(240,270,0);
            pause1=true;
            resetPressed=true;
            step=0;
            time(&temps_act);
            newRecord=true;
        }

        if ( (x>=buttonRecX)&&(x<=buttonRecX+120)&&(y>=buttonRecY)&&(y<=buttonRecY+30) ){
            record = !record;
            recPressed=record;
            if (record){
                if (newRecord){
                    time(&temps_act);
                    file<<endl<<"---"<<ctime(&temps_act)<<endl;
                    newRecord=false;
                }
                else file<<"---"<<endl;
            }

        }

        // reward-punishment buttons
        if ( (x>=500)&&(x<=660)&&(y>=500)&&(y<=530) ){
            (*r1).setReward( (x-500)*10/16);
        }
        if ( (x>=500)&&(x<=660)&&(y>=550)&&(y<=580) ){
            (*r1).setReward( -(x-500)*10/16);
        }


        // synapses buttons
        if ( (x>=500)&&(x<=660)&&(y>=620)&&(y<=650) ){
            (*r1).setSynapse(1,(x-580)*10/8);
        }
        if ( (x>=500)&&(x<=660)&&(y>=680)&&(y<=710) ){
            (*r1).setSynapse(2,(x-580)*10/8);
        }
        if ( (x>=500)&&(x<=660)&&(y>=760)&&(y<=790) ){
            (*r1).setSynapse(3,(x-580)*10/8);
        }
        if ( (x>=500)&&(x<=660)&&(y>=820)&&(y<=850) ){
            (*r1).setSynapse(4,(x-580)*10/8);
        }


        // drag and drop
        if ( (x>=r1->x-20)&&(x<=r1->x+20)&&(y>=r1->y-20)&&(y<=r1->y+20) ){
            clic=true;

        }
    }

    if (event == CV_EVENT_LBUTTONUP){
         clic=false;
         lightPressed=false;
         pausePressed=false;
         resetPressed=false;
    }

    if (clic){
        (*r1).setPosition(x,y);
    }
}



////////////////////////////////////////////////////////////////////////////////////
//
////////////////////////////////////////////////////////////////////////////////////

int main(){

    simulateur = cvCreateImage( cvSize(1160,900), 8, 3 );
    cvNamedWindow( "Johnny 2.0", CV_WINDOW_AUTOSIZE );
    cvSetMouseCallback( "Johnny 2.0", on_mouse, 0 );
    cvInitFont( &font , CV_FONT_HERSHEY_TRIPLEX, 0.5, 0.5, 0.0, 1);

    fillLuminosite(light);

    r1=new robot();
    (*r1).initialize(240,270,0);

    float x,y,theta,lL,lR,mL,mR,aL,aR,sL1,sL2,sR1,sR2,vL,vR;
    int bumper;


    char key = ' ';

    time(&temps_act);

    while(key != 'q'){

        cvZero(simulateur);

        int l=0;

        // draw simulator lights
        for (int i=0;i<480;i+=2){
                for (int j=0;j<480;j+=2){
                    l=luminosite[i][j];
                    cvCircle(simulateur, cvPoint(i, j), 1, CV_RGB(l,l,0),1);
                    cvCircle(simulateur, cvPoint(i+1, j), 1, CV_RGB(l,l,0),1);
                    cvCircle(simulateur, cvPoint(i, j+1), 1, CV_RGB(l,l,0),1);
                    cvCircle(simulateur, cvPoint(i+1, j+1), 1, CV_RGB(l,l,0),1);
                }
        }


        // draw simulator borders
        cvDrawRect(simulateur,cvPoint(10,10),cvPoint(470,470),CV_RGB(0,0,250),2);

        // draw simulator interface
        drawInterface();
        drawNetwork();
        drawControlPanel();
        drawGraph();


        // robot simulation
        if ((!clic)&&(!pause1)) (*r1).step(luminosite,light,240,240);
        (*r1).drawRobot(simulateur);

        // record robot values
        if ((!pause1)&&(record)){
            (*r1).write(&x,&y,&theta,&bumper,&lL,&lR,&mL,&mR,&aL,&aR,&sL1,&sL2,&sR1,&sR2,&vL,&vR);
            file<<step<<"  "<<x<<"  "<<y<<"  "<<theta<<"  "<<bumper<<"  "<<lL<<"  "<<lR<<"  "<<mL<<"  "<<mR<<"  "
                <<aL<<"  "<<aR<<"  "<<sL1<<"  "<<sL2<<"  "<<sR1<<"  "<<sR2<<"  "<<vL<<"  "<<vR<<"  "<<light<<endl;
        }

        cvShowImage( "Johnny 2.0", simulateur );

        if (!pause1) step++;
        //file<<step<<endl;

        key = cvWaitKey(10);

    }

    file.close();

    return 0;
}

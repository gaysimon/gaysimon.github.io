import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;


public class DisplayPanel extends JPanel{

	private static final long serialVersionUID = 1L;
	
	private Main main;
	
	public DisplayPanel(Main m){
		main=m;
	}
	
	public void paintComponent(Graphics g){
		
		// background
		g.setColor(Color.white);
		g.fillRect(0,0, this.getWidth(), this.getHeight());
		
		// display frame
		g.setColor(Color.black);
		g.drawLine(320, 0, 320, 480);
		g.drawRect(0,0,640, 480);
		
		// display barcodes
		for (int i=0;i<main.lines_display.size()-8;i+=8){
			
			// display header
			g.setColor(Color.black);
			g.fillRect(main.lines_display.get(i)*4, main.lines_display.get(i+1)*2,4, main.lines_display.get(i+2)*2);
			
			// display the four bits
			if ((main.lines_display.get(i+7) & 0b00001000) !=0) g.setColor(Color.green);
			else g.setColor(Color.red);
			g.fillOval(main.lines_display.get(i)*4, main.lines_display.get(i+3)*2,4,4);
			
			if ((main.lines_display.get(i+7) & 0b00000100) !=0) g.setColor(Color.green);
			else g.setColor(Color.red);
			g.fillOval(main.lines_display.get(i)*4, main.lines_display.get(i+4)*2,4,4);
			
			if ((main.lines_display.get(i+7) & 0b00000010) !=0) g.setColor(Color.green);
			else g.setColor(Color.red);
			g.fillOval(main.lines_display.get(i)*4, main.lines_display.get(i+5)*2,4,4);
			
			if ((main.lines_display.get(i+7) & 0b00000001) !=0) g.setColor(Color.green);
			else g.setColor(Color.red);
			g.fillOval(main.lines_display.get(i)*4, main.lines_display.get(i+6)*2,4,4);
		}
	}
	
}

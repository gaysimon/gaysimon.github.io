import javax.swing.JFrame;


public class DisplayFrame extends JFrame{

	private static final long serialVersionUID = 1L;

	private DisplayPanel panel;
	private Main main;

	public DisplayFrame(Main m){
		main=m;
		this.setTitle("Display");
    	this.setSize(680, 550);
    	this.setLocationRelativeTo(null);               
    	panel=new DisplayPanel(m);
    	this.setContentPane(panel);
    	this.addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent e) {
            	main.close();	// close serial port
                System.exit(0);
            }
        });
    	this.setVisible(true);
	}
}
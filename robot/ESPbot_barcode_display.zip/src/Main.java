import java.util.ArrayList;

import jssc.SerialPort;
import jssc.SerialPortEvent;
import jssc.SerialPortEventListener;
import jssc.SerialPortException;

public class Main implements SerialPortEventListener {
		
	public static String PORT="ttyUSB";	// name of the port (name changes to 'COM' on windows systems)
	public static int PORT_NB=0;		// port number
	
	// serial interface
	private boolean connected=false;
	private SerialPort serialPort;
	
	public int msg=0;					// header detection
	public ArrayList<Integer> lines;
	public ArrayList<Integer> lines_display;
	
	
	public DisplayFrame display;		// display window
	
	public Main(){
		
		// initialize lists
		lines=new ArrayList<Integer>();
		lines_display=new ArrayList<Integer>();
		
		// open serial port
		while (!connected && Main.PORT_NB<30){
		try {
			serialPort = new SerialPort(Main.PORT+Main.PORT_NB);
			serialPort.openPort();
			serialPort.setParams(115200, 9, 1, 0);
			System.out.println(serialPort.getPortName());
			
			serialPort.addEventListener(this, SerialPort.MASK_RXCHAR);
			System.out.println("port opened");
			connected=true;
		} catch (SerialPortException e) {
				System.out.println("cannot connect port USB"+Main.PORT_NB);
				Main.PORT_NB++; // try next port
			}
		}
		
		// initialize display panel
		display=new DisplayFrame(this);
	}
	
	
	// close serial port (when closing display window)
	public void close(){
		try {
			if (serialPort.isOpened()){
				System.out.println("Port closed: " + serialPort.closePort());
			}
		} catch (SerialPortException e) {e.printStackTrace();}
	}
	
	
	// receive message from ESP32 board
	public void serialEvent(SerialPortEvent event) {

		int val=0;
		
        if(event.isRXCHAR() && event.getEventValue() > 0) {
            try {
                byte[] received=serialPort.readBytes();
                
                for(int i=0;i<received.length; i++){
                	
                	val=(int)(received[i]& 0xff);
                	
                	///////////////////////////////
                	// detect sequence 255-0-255
                	if (msg==0){
                		if (val==255) msg=1;
                	}
                	else if (msg==1){
                		if (val==0) msg=2;
                		else msg=0;
                	}
                	else if (msg==2){
                		if (val==255) msg=3;
                		else msg=0;
                	}
                	////////////////////////////////
                	
                	if (msg==3){ // header detected : new image
                		
                		// copy completed list for display panel 
                		lines_display.clear();
                		for (int n=0;n<lines.size();n++) lines_display.add(lines.get(n));
                		display.repaint();	// update display window
                		
                		// display lines' properties
                		if (lines.size()>2) System.out.println();
                		for (int l=0;l<lines.size()-8;l+=8){
                			System.out.println("++++ "
                			+lines.get(l)+" ; "			// horizontal position
                			+lines.get(l+1)+" ; "		// vertical position
                			+lines.get(l+2)+" ; "		// height
                			+lines.get(l+3)+" ; "		// vertical position 
                			+lines.get(l+4)+" ; "		//     of 
                			+lines.get(l+5)+" ; "		//     the 
                			+lines.get(l+6)+" ; "		//     four bits
                			+lines.get(l+7));			// code's id
                		}

                		// clear list for next sequence of data
                		lines.clear();
                		msg=0;
                	}
                	else{
                		// add received data in list
                		lines.add(val);
                	}
                }
            }
            catch (SerialPortException ex) {System.out.println("Error in receiving string from COM-port: " + ex);}
        }
    }
	
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public static void main(String[] args) {
		
		// change port's name for Windows operating systems
		if (System.getProperty("os.name").toLowerCase().contains("windows")){
			PORT="COM";
		}
		
		// change port nb if specified in parameters
		if (args.length>0){
			Main.PORT_NB=Integer.parseInt(args[0]);
		}
		
		new Main();		// start main program
	}

}

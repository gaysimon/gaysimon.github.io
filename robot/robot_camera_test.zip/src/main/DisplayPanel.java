package main;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;

// display panel
public class DisplayPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	
	private Main main;
	
	
	public DisplayPanel(Main m){
		main=m;
	}
	
	public void paintComponent(Graphics g){
		
		// background
		g.setColor(Color.white);
		g.fillRect(0,0, this.getWidth(), this.getHeight());
		
		// paint the image
		g.drawImage(main.camera.image, 0,0, null);
		
	}

}

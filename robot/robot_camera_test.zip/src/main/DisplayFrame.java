package main;

import javax.swing.JFrame;


// display window
public class DisplayFrame extends JFrame{

	private static final long serialVersionUID = 1L;

	private DisplayPanel panel;	// display panel

	public DisplayFrame(Main m){
		
		this.setTitle("Camera");
    	this.setSize(Camera.SIZE_X+5, Camera.SIZE_Y+10);
    	this.setLocationRelativeTo(null);               
    	panel=new DisplayPanel(m);
    	this.setContentPane(panel);
    	this.setVisible(true);
    	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
}
package main;


public class Main {

	
	public static String path="/home/pi/opencv/build/lib/";	// path of OpenCV .so libraries
	public static boolean raspberry=true;					// program runs on a raspberry pi (automatic detection)

	// camera interface
	public Camera camera;
	
	// display panel
	private DisplayFrame display;
	
	// count number of image acquisition
	private int counter=0;
	
	public Main(){
		

		// camera grabber
		camera=new Camera();
		
		// initialize display panel
		display=new DisplayFrame(this);
		
		
		try {Thread.sleep(20);
		} catch (InterruptedException e) {e.printStackTrace();}	
		
		
		while (true){
			
			camera.read();		// get new frame
			
			if (counter==0) {
				display.repaint();	// update display panel
				counter=5;
			}
			else counter--;

		}
	}
	
	
	
	//////////////////////////////////////////////////////
	public static void main(String[] args) {
		
		// detect if the program runs on raspberry pi
		if (!System.getProperty("user.name").equals("pi") && !System.getProperty("user.name").equals("root")) {
			System.out.println("User name: "+System.getProperty("user.name"));	// display user's name
			Main.raspberry=false;												// not a raspberry pi
		}
		
		new Main();	// start main algorithm
	}

}

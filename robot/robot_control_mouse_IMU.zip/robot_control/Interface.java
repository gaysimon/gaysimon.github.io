package robot_control;


import jssc.SerialPort;
import jssc.SerialPortException;
import jssc.SerialPortEvent;
import jssc.SerialPortEventListener;

public class Interface implements SerialPortEventListener {

	SerialPort serialPort;
	
	
	private int message_type=0;  // state
	public boolean ready=true;
	
	// received measures
	private int time0=0;
	private float ax0=0;
	private float ay0=0;
	private float az0=0;
	private float rx0=0;
	private float ry0=0;
	private float rz0=0;

	// data
	public int time=0;
	public float ax=0;
	public float ay=0;
	public float az=0;
	public float rx=0;
	public float ry=0;
	public float rz=0;

	
	public Interface(){
		try {
			serialPort = new SerialPort(Main.port);
			serialPort.openPort();
			serialPort.setParams(9600, 8, 1, 0);
			serialPort.addEventListener(this, SerialPort.MASK_RXCHAR);
			System.out.println("port opened");
		} catch (SerialPortException e) {e.printStackTrace();}
	}
	
	
	// send commands as a sequence of bytes starting with byte 255
	public void sendMsg(int px, int py, int rz){
		
		byte[] msg=new byte[4];
		msg[0]=(byte)255;
		msg[1]=(byte)(px+100);
		msg[2]=(byte)(py+100);
		msg[3]=(byte)(rz+100);

		try {
			serialPort.writeBytes(msg);
		} catch (SerialPortException e) {e.printStackTrace();}/**/
	}
	
	
	public void close(){
		try {
			System.out.println("Port closed: " + serialPort.closePort());
		} catch (SerialPortException e) {e.printStackTrace();}
	}
	

	
	public void serialEvent(SerialPortEvent event) {

		if(event.isRXCHAR() && event.getEventValue() > 0) {
            try {
                byte[] received=serialPort.readBytes();

                for(int i=0;i<received.length; i++){
                	
                	// new message
                	if ((received[i] & 0xff)==255){
                		message_type=1;
                	}
                	else{
                		
                		// get two bytes for delay
                		if (message_type==1){
                			time0=(received[i] & 0xff)*254;
                    		message_type=2;
                		}
                		else if (message_type==2){
                			time0+=(received[i] & 0xff);
                    		message_type=3;                    		
                		}
                		
                		// get two bytes for accX
                		else if (message_type==3){
                			ay0=(received[i] & 0xff)*254;
                    		message_type=4;                    		
                		}
                		else if (message_type==4){
                			ay0+=(received[i] & 0xff)-32258;
                			ay0=ay0/100;
                    		message_type=5;                    		
                		}

                		// get two bytes for accY
                		else if (message_type==5){
                			ax0=(received[i] & 0xff)*254;
                    		message_type=6;                    		
                		}
                		else if (message_type==6){
                			ax0+=(received[i] & 0xff)-32258;
                			ax0=ax0/100;
                    		message_type=7;                    		
                		}
                		
                		// get two bytes for accZ
                		else if (message_type==7){
                			az0=(received[i] & 0xff)*254;
                    		message_type=8;                    		
                		}
                		else if (message_type==8){
                			az0+=(received[i] & 0xff)-32258;
                			az0=az0/100;
                    		message_type=9;                    		
                		}
                		
                		// get two bytes for rotX
                		else if (message_type==9){
                			rx0=(received[i] & 0xff)*254;
                    		message_type=10;                    		
                		}
                		else if (message_type==10){
                			rx0+=(received[i] & 0xff)-32258;
                			rx0=rx0/100;
                    		message_type=11;                    		
                		}

                		// get two bytes for rotY
                		else if (message_type==11){
                			ry0=(received[i] & 0xff)*254;
                    		message_type=12;                    		
                		}
                		else if (message_type==12){
                			ry0+=(received[i] & 0xff)-32258;
                			ry0=ry0/100;
                    		message_type=13;                    		
                		}
                		
                		// get two bytes for rotZ
                		else if (message_type==13){
                			rz0=(received[i] & 0xff)*254;
                    		message_type=14;                    		
                		}
                		else if (message_type==14){
                			rz0+=(received[i] & 0xff)-32258;
                    		message_type=0;
                    		rz0=rz0/100;
                    		
                    		// set values
                    		ready=false;
                			time+=time0;
                			ax+=ax0;
                			ay+=ay0;
                			az+=az0;
                			rx+=rx0;
                			ry+=ry0;
                			rz+=rz0;
                    		ready=true;
                    		
                    		//System.out.println(time+" , "+ax+" , "+ay+" , "+az+" ; "+rx+" , "+ry+" , "+rz);
                		}
                	}
                }
            }
            catch (SerialPortException ex) {System.out.println("Error in receiving string from COM-port: " + ex);}
        }
    }
}

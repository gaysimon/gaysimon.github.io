package servers;

import java.net.InetSocketAddress;
import java.nio.ByteBuffer;

import org.java_websocket.WebSocket;
import org.java_websocket.handshake.ClientHandshake;
import org.java_websocket.server.WebSocketServer;

import platform.Main;


public class DataWebSocket extends WebSocketServer {
    
    private Main main;

    public DataWebSocket(InetSocketAddress address, Main m) {
    	super(address);
    	main=m;
    }
    

    @Override
	public void onOpen(WebSocket conn, ClientHandshake handshake) {
		System.out.println("new connection to " + conn.getRemoteSocketAddress());
	}

	@Override
	public void onClose(WebSocket conn, int code, String reason, boolean remote) {
		System.out.println("closed " + conn.getRemoteSocketAddress() + " with exit code " + code + " additional info: " + reason);
	}

	// process incomming messages
	@Override
	public void onMessage(WebSocket conn, String message) {
		
		System.out.println("received message from "	+ conn.getRemoteSocketAddress() + ": " + message);
		
		String[] elements=message.split(" ");
		
		if (elements.length>=2 && elements[0].equals("robot")){				// robot control
			main.setMove(elements[1]);
		}
		else if (elements.length>=2 && elements[0].equals("button")){		// handle messages from client
			System.out.println(elements[1]);
		}
		else if (elements.length>=2 && elements[0].equals("changemode")){	// change robot mode
			main.changeControlMode(elements[1]);
		}
		else if (elements.length>=2 && elements[0].equals("system")){		// software control
			if (elements[1].equals("stop")) main.run=false;
		}

	}

	@Override
	public void onMessage( WebSocket conn, ByteBuffer message ) {
		System.out.println("received ByteBuffer from "	+ conn.getRemoteSocketAddress());
	}

	@Override
	public void onError(WebSocket conn, Exception ex) {
		System.err.println("an error occurred on connection " + conn.getRemoteSocketAddress()  + ":" + ex);
	}
	
	@Override
	public void onStart() {
		System.out.println("server started successfully");
	}
}
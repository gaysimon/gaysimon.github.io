package servers;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Enumeration;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import platform.Main;


public class Server {

	public static String address="192.168.1.1";
	
	private static VideoSocket videoSocket;
	private static DataWebSocket dataSocket;
	private HttpServer server;
	
	
	public Server(Main m) {
		
		try {
			
			// get IP address of the server
			boolean found=false;
			Enumeration<NetworkInterface> Interfaces = NetworkInterface.getNetworkInterfaces();
			while(Interfaces.hasMoreElements() && !found){
			    NetworkInterface Interface = (NetworkInterface)Interfaces.nextElement();
			    Enumeration<InetAddress> Addresses = Interface.getInetAddresses();
			    while(Addresses.hasMoreElements() && !found){
			        InetAddress Address = (InetAddress)Addresses.nextElement();
			        if (Address.getHostAddress().toString().split("\\.")[0].equals("192")) {
			        	address=Address.getHostAddress().toString();
			        	found=true;
			        	System.out.println(Address.getHostAddress());
			        }
			    }
			}

			// start the server
			server=HttpServer.create(new InetSocketAddress(InetAddress.getByName(address),8080),0);
			server.createContext("/", new ServerHandler());
			server.setExecutor(null);
			server.start();
			System.out.println("Server started on port 8080");
			System.out.println("go to  http://"+Server.address+":8080 with browser");
			
			// create video socket for camera stream
			videoSocket = new VideoSocket(m);
			new Thread(videoSocket).start();
			
			// create socket to communicate with client
			dataSocket = new DataWebSocket(new InetSocketAddress(InetAddress.getByName(address),8002), m);
			dataSocket.setReuseAddr(true);
			dataSocket.start();

		} catch (IOException e1) {e1.printStackTrace();}
	}
	
	
	// send a message to the client
	public void broadcast(String msg) {
		dataSocket.broadcast(msg);
	}
	
	// stop the whole server
	public void stop() {
		try {
			videoSocket.stopStreamingServer();
			dataSocket.stop();
			server.stop(1);
		} catch (Exception e) {e.printStackTrace();}
	}
	
	/////////////////////////////
	// handle client's requests
	private class ServerHandler implements HttpHandler{

		public void handle(HttpExchange request) throws IOException {
			
			System.out.println("request "+request.getRequestMethod());
			
			if("GET".equals(request.getRequestMethod())) { // send web page
			
				String htmlResponse = new String(Files.readAllBytes(Paths.get(Main.PAGEPATH+"index.html")));
				request.sendResponseHeaders(200, htmlResponse.length());
	
				OutputStream output=request.getResponseBody();
				output.write(htmlResponse.getBytes());
		        output.flush();
		        output.close();
			}
		}
	}
	
}

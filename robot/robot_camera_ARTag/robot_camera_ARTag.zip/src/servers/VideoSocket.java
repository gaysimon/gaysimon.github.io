package servers;

import javax.imageio.ImageIO;

import main.Main;

import java.awt.image.BufferedImage;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

// socket to stream camera images
public class VideoSocket implements Runnable {

    private ServerSocket serverSocket;
    private Socket socket;
    private final String boundary = "stream";
    private OutputStream outputStream;
    private Main main;

    public VideoSocket(Main m) {
        main=m;
    }

    // initialize socket
    public void startStreamingServer() throws IOException {
        serverSocket = new ServerSocket(8001);
        socket = serverSocket.accept();
        writeHeader(socket.getOutputStream(), boundary);
    }

    private void writeHeader(OutputStream stream, String boundary) throws IOException {
        stream.write(("HTTP/1.0 200 OK\r\n" +
                "Connection: close\r\n" +
                "Max-Age: 0\r\n" +
                "Expires: 0\r\n" +
                "Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0\r\n" +
                "Pragma: no-cache\r\n" +
                "Content-Type: multipart/x-mixed-replace; " +
                "boundary=" + boundary + "\r\n" +
                "\r\n" +
                "--" + boundary + "\r\n").getBytes());
    }
    
    
    // stream image to web interface
    public void pushImage(BufferedImage img) throws IOException {
        if (img == null)
            return;
        try {
            outputStream = socket.getOutputStream();
            
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ImageIO.write(img, "jpg", baos);
            byte[] imageBytes = baos.toByteArray();
            outputStream.write(("Content-type: image/jpeg\r\n" +
                    "Content-Length: " + imageBytes.length + "\r\n" +
                    "\r\n").getBytes());
            outputStream.write(imageBytes);
            outputStream.write(("\r\n--" + boundary + "\r\n").getBytes());
            
            
        } catch (Exception ex) {
            socket = serverSocket.accept();
            writeHeader(socket.getOutputStream(), boundary);
        }
    }
    
    
    // thread sending an image every 50ms
    public void run() {
        try {
            startStreamingServer();

            while (true) {
                pushImage(main.output);
                try {Thread.sleep(50);
    			} catch (InterruptedException e) {e.printStackTrace();}
            }
        } catch (IOException e) {
            return;
        }
    }
    
    // close socket
    public void stopStreamingServer() throws IOException {
        socket.close();
        serverSocket.close();
    }
}
package robot;

import ARTag.Detector;
import main.Main;

// functions to control motors
public class Robot {

	private int vl=0;				// speed of left and right motors
	private int vr=0;
	
	public boolean moving=false;	// true when the robot is performing a move
	
	private MotorControl motors;	// GPIO interface
	
	// constructor: initialize GPIO interface 
	public Robot() {
		if (Main.raspberry) motors=new MotorControl();
	}
	
	
	public void action(int px, int pz, boolean search){
		
		int speed=100;		// default speed
		
		if (search) {	// search mode: rotate until finding an ARTag
			move(0,speed,100);
		}
		else {

			if (pz!=-1 && pz<Detector.maxSize+5) {	// if ARTag detected and not too close
				
				if (px>200) move(speed,0,80);		// control the
				else if (px<120) move(0,speed,80);	// robot according
				else move(speed,speed,200);			// to ARTag's position
			}
		}
	}
	
	
	// set motor speed for a given duration
	public void move(int l, int r, int time) {
		
		moving=true;
		setMotors(l,r);
		
		try {Thread.sleep(time);} 	// wait
		catch (InterruptedException e) {e.printStackTrace();}
		
		stop();
		moving=false;
	}
	
	
	// set speed value for each motor
	public void setMotors(int l, int r) {
		
		vl=l;
		vr=r;
		
		if (Main.raspberry) motors.setMotor(vl, vr);
		else System.out.println("set speed ("+vl+","+vr+")");
	}
	
	// stop the two motors
	public void stop() {
		if (Main.raspberry) motors.stop();
		else System.out.println("stop");
	}
	
}

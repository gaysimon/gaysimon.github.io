package robot;

import com.pi4j.wiringpi.Gpio;

// GPIO interface
public class MotorControl {
	
	public static int minSpeed=40;	// minimum speed to run a motor

	// set pins' properties
	public MotorControl() {
		
		// H-bridge pins
		Gpio.wiringPiSetupGpio();
		Gpio.pinMode(7, Gpio.OUTPUT);
		Gpio.pinMode(8, Gpio.OUTPUT);
		
		Gpio.digitalWrite(7, false);
		Gpio.digitalWrite(8, false);
		
		Gpio.pinMode(23, Gpio.OUTPUT);
		Gpio.pinMode(24, Gpio.OUTPUT);
		
		Gpio.digitalWrite(23, false);
		Gpio.digitalWrite(24, false);
		
		// PWM pins
		Gpio.pinMode(13, Gpio.PWM_OUTPUT);
		Gpio.pwmSetMode(Gpio.PWM_MODE_MS);
		Gpio.pwmSetClock(187);
		Gpio.pwmSetRange(1024);
		
		Gpio.pwmWrite(13, 1024);
		
		Gpio.pinMode(12, Gpio.PWM_OUTPUT);
		Gpio.pwmSetMode(Gpio.PWM_MODE_MS);
		Gpio.pwmSetClock(187);
		Gpio.pwmSetRange(1024);
		
		Gpio.pwmWrite(12, 1024);
		
		
		System.out.println("GPIO initialized");
	}
	
	// control motors with given speed values
	public void setMotor(int vg, int vd) {
		
		if (vg>minSpeed) {
			Gpio.digitalWrite(7, false);
			Gpio.digitalWrite(8, true);
			
			Gpio.pwmWrite(13, vg*10);
		}
		else if (vg<-minSpeed) {
			Gpio.digitalWrite(8, false);
			Gpio.digitalWrite(7, true);
			
			Gpio.pwmWrite(13, -vg*10);
		}
		else {
			Gpio.digitalWrite(7, false);
			Gpio.digitalWrite(8, false);
			
			Gpio.pwmWrite(13, 0);
		}
		
		
		if (vd>minSpeed) {
			Gpio.digitalWrite(23, false);
			Gpio.digitalWrite(24, true);
			
			Gpio.pwmWrite(12, vd*10);
		}
		else if (vd<-minSpeed) {
			Gpio.digitalWrite(24, false);
			Gpio.digitalWrite(23, true);
			
			Gpio.pwmWrite(12, -vd*10);
		}
		else {
			Gpio.digitalWrite(23, false);
			Gpio.digitalWrite(24, false);
			
			Gpio.pwmWrite(12, 0);
		}
	}
	
	
	// stop the two motors
	public void stop() {
		Gpio.digitalWrite(7, false);
		Gpio.digitalWrite(8, false);
		
		Gpio.pwmWrite(13, 0);
		
		Gpio.digitalWrite(23, false);
		Gpio.digitalWrite(24, false);
		
		Gpio.pwmWrite(12, 0);
	}
	
}

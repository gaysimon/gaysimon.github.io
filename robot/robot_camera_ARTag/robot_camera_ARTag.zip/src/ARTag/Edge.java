package ARTag;

import java.util.ArrayList;

import main.Camera;


public class Edge {

	public int id=0;
	public ArrayList<int[]> pointList;	// list of edge points
	
	public ArrayList<int[]> fastList;	// list of detected corners
	
	public int xmin=Camera.SIZE_X;		// bounding box
	public int xmax=0;
	public int ymin=Camera.SIZE_Y;
	public int ymax=0;
	
	public int centerX=0;				// center of the edge
	public int centerY=0;
	
	public int height=0;				// apparent height of the ARTag
	
	public int[][] points;   //   01
	                         //   23
	
	public int[][] FAST;				// matrix containing coordinates of the 12 FAST detector pixels
	
	public boolean valid=true;			// false when edge becomes invalid
	
	public int[][] image;				// rectified image of the ARTag
	public int code=0;					// decoded code
	
	public Edge(int i){
		id=i;
		pointList=new ArrayList<int[]>();
		fastList=new ArrayList<int[]>();
		points=new int[4][2];
		image=new int[100][100];
		
		// coordinate of the 12 pixels used for FAST detection
		FAST=new int[16][2];
		FAST[0][0]=-1;
		FAST[0][1]=3;
		FAST[1][0]=0;
		FAST[1][1]=3;
		FAST[2][0]=1;
		FAST[2][1]=3;
		
		FAST[3][0]=2;
		FAST[3][1]=2;
		
		FAST[4][0]=3;
		FAST[4][1]=1;
		FAST[5][0]=3;
		FAST[5][1]=0;
		FAST[6][0]=3;
		FAST[6][1]=-1;
		
		FAST[7][0]=2;
		FAST[7][1]=-2;
		
		FAST[8][0]=1;
		FAST[8][1]=-3;
		FAST[9][0]=0;
		FAST[9][1]=-3;
		FAST[10][0]=-1;
		FAST[10][1]=-3;
		
		FAST[11][0]=-2;
		FAST[11][1]=-2;
		
		FAST[12][0]=-3;
		FAST[12][1]=-1;
		FAST[13][0]=-3;
		FAST[13][1]=0;
		FAST[14][0]=-3;
		FAST[14][1]=1;
		
		FAST[15][0]=-2;
		FAST[15][1]=2;
		
	}
	
	public void add(int x, int y){
		int[] p={x,y};
		pointList.add(p);
	}	
	
	public void add(int[] p){
		pointList.add(p);
	}
	
	public int size(){
		return pointList.size();
	}
	
	public void clear(){
		pointList.clear();
	}
	
	
	// define the bounding box and the four corners of the edge
	public void getCorners(short[][] img){
		
		int x,y;
		
		for (int p=0;p<pointList.size();p++){
			
			x=pointList.get(p)[0];
			y=pointList.get(p)[1];
			
			// define bounding box
			if (x>xmax) xmax=x;
			if (x<xmin) xmin=x;
			if (y>ymax) ymax=y;
			if (y<ymin) ymin=y;
			
			
			// detect corners
			if (x-3>0 && x+3<Camera.SIZE_X-1 && y-3>0 && y+3<Camera.SIZE_Y-1){
				
				int nb=0;
				
				for (int i=0;i<16;i++){
					if (img[y+FAST[i][1]][x+FAST[i][0]]>0) nb++;
				}
				
				if (nb>11){
					fastList.add(pointList.get(p));
				}	
			}
		}
		
		// define center
		centerX=(xmax+xmin)/2;
		centerY=(ymax+ymin)/2;
		
		// remove double corner points
		for (int p=0;p<fastList.size();p++){
			for (int p2=p+1;p2<fastList.size();p2++){
				if (fastList.get(p)[0]-fastList.get(p2)[0]<=5 && fastList.get(p)[0]-fastList.get(p2)[0]>=-5
				 && fastList.get(p)[1]-fastList.get(p2)[1]<=5 && fastList.get(p)[1]-fastList.get(p2)[1]>=-5){
					fastList.remove(p2);
					p2--;
				}
			}
		}
		
		
		
		if (fastList.size()==4){
			
			// define the four corners
			for (int i=0;i<fastList.size();i++){
				
				if (fastList.get(i)[0]<centerX && fastList.get(i)[1]<centerY){
					points[0]=fastList.get(i);
				}
				else if (fastList.get(i)[0]>=centerX && fastList.get(i)[1]<centerY){
					points[1]=fastList.get(i);
				}
				else if (fastList.get(i)[0]<centerX && fastList.get(i)[1]>=centerY){
					points[2]=fastList.get(i);
				}
				else if (fastList.get(i)[0]>=centerX && fastList.get(i)[1]>=centerY){
					points[3]=fastList.get(i);
				}
			}
			
			// get apparent height
			int dx= ( ((points[2][0]+points[3][0])/2) - ((points[0][0]+points[1][0])/2) );
			int dy= ( ((points[2][1]+points[3][1])/2) - ((points[0][1]+points[1][1])/2) );
			height= (int)(Math.sqrt(dx*dx+dy*dy));
		}
		
		
		
		// detect invalid edge
		if (fastList.size()!=4) valid=false;
		else if (xmax-xmin<20 || ymax-ymin<20) valid=false;
		else if (points[0][0]==0 || points[0][1]==0 
		 || points[1][0]==0 || points[1][1]==0 
		 || points[2][0]==0 || points[2][1]==0 
		 || points[3][0]==0 || points[3][1]==0) valid=false;
	}

	
	// decode the ARTag
	public void setCode(short[][] img){

		int x0=points[0][0];
		int y0=points[0][1];
		
		int x1=points[1][0];
		int y1=points[1][1];
		
		int x2=points[2][0];
		int y2=points[2][1];
		
		int x3=points[3][0];
		int y3=points[3][1];
		
		
		int xc1, yc1, xc2, yc2, xc, yc;
		
		// rectify tag image
		for (int i=0;i<100;i++){
			xc1= ( i*x1 + (100-i)*x0 )/100;
			yc1= ( i*y1 + (100-i)*y0 )/100;

			xc2= ( i*x3 + (100-i)*x2 )/100;
			yc2= ( i*y3 + (100-i)*y2 )/100;
			
			for (int j=0;j<100;j++){
				xc= ( j*xc2 + (100-j)*xc1 )/100;
				yc= ( j*yc2 + (100-j)*yc1 )/100;
				
				image[i][j]=img[yc][xc];
			}
		}
		
		
		// read binary code
		code=0;
		for (int j=0;j<3;j++){
			for (int i=0;i<3;i++){
				code=code*2;
				if (image[35+15*i][35+15*j]==0) code++;
			}
		}
	}
	
	
}
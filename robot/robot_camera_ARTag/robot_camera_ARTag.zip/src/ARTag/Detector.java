package ARTag;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import org.opencv.core.Mat;
import org.opencv.core.MatOfByte;
import org.opencv.imgcodecs.Imgcodecs;

import main.Camera;

public class Detector {
	
	private static int SIZE_X=Camera.SIZE_X;
	private static int SIZE_Y=Camera.SIZE_Y;
	
	public static int maxSize=110;

	private short[][] image=null;
	private int[][] edgePoints;
	private int[][] edges;
	
	// Mat to byte[] structures
	private MatOfByte bytemat= new MatOfByte();;
	private byte[] bytes;
	
	
	public ArrayList<Edge> edgeList;	// list of detected codes
	
	
	public static int[] sequence=new int[] {};
	public int index=0;
	public static int current=-1;
	
	private float coeff=1;
	
	public boolean detected=false;		// current target detected
	public int px=0;					// horizontal position of the code
	public int pz=-1;					// apparent size of the code
	public boolean search=true;
	
	public Detector() {
		image=new short[SIZE_Y][Camera.SIZE_X];
		edgePoints=new int[SIZE_X][SIZE_Y];
		edges=new int[SIZE_X][SIZE_Y];
		
		edgeList=new ArrayList<Edge>();
		
		if (sequence.length>0) current=sequence[0];
	}
	
	public void detect(Mat img) {

		
		// convert to Byte array
		Imgcodecs.imencode(".bmp", img, bytemat);
		bytes = bytemat.toArray();
		
		
		// convert mat to matrix
		int c=54;
		int min=1000;
		int max=0;
		for (short i=(short)(SIZE_Y-1);i>=0;i--) {
			for (short j=0;j<SIZE_X;j++) {
				image[i][j]=(short)(  (bytes[c  ] & 0xff)   );
				image[i][j]=(short)(  (bytes[c+1] & 0xff)   );
				image[i][j]=(short)(  (bytes[c+2] & 0xff)   );
				image[i][j]=(short)(image[i][j]/3);
				
				if (image[i][j]>max) max=image[i][j];
				if (image[i][j]<min) min=image[i][j];
				
				c+=3;
			}
		}
		
		// binarize the image
		if (!detected) {
			coeff=0.4f;
			coeff+=Math.random();
		}
		
		int treshold=(int)((float)((max+min)/2)*coeff);	// generate a random variable treshold
		for (short i=(short)(SIZE_Y-1);i>=0;i--) {
			for (short j=0;j<SIZE_X;j++) {
				if (image[i][j]>treshold) image[i][j]=255;
				else image[i][j]=0;
			}
		}
		
		// reset matrices
		for (int i=0;i<SIZE_X;i++){
			for (int j=0;j<SIZE_Y;j++){
				edgePoints[i][j]=0;
				edges[i][j]=0;
			}
		}
		
		// detect edge points: looks for a white pixel with a black point around
		for (int i=1;i<SIZE_X-1;i++){
			for (int j=20;j<SIZE_Y-20;j++){
				
				if (image[j][i]>0){
					boolean found=false;
					for (int i1=-1;i1<=1;i1++){
						for (int j1=-1;j1<=1;j1++){
							if (image[j+j1][i+i1]==0) found=true;
						}
					}
					
					if (found){
						edgePoints[i][j]=255;
					}
				}
			}
		}
		
		///////////////////////////////////////////////////////////////////////////////////////////
		// detect edges
		///////////////////////////////////////////////////////////////////////////////////////////
		edgeList.clear();
		int id=0;
		for (int j=20;j<SIZE_Y-20;j++){
			for (int i=1;i<SIZE_X-1;i++){
			
				if (edgePoints[i][j]!=0){	// presence of an edge point
					
					ArrayList<int[]> neighbors=new ArrayList<int[]>();
					
					// detect edge point in four previous pixels
					if (edges[i-1][j]!=0){
						int[] p={i-1,j};
						neighbors.add(p);
					}
					if (edges[i-1][j-1]!=0){
						int[] p={i-1,j-1};
						neighbors.add(p);
					}
					if (edges[i][j-1]!=0){
						int[] p={i,j-1};
						neighbors.add(p);
					}
					if (edges[i+1][j-1]!=0){
						int[] p={i+1,j-1};
						neighbors.add(p);
					}
					
					// new edge
					if (neighbors.isEmpty()){
						id++;
						edgeList.add(new Edge(id));
						edgeList.get(edgeList.size()-1).add(i,j);
						edges[i][j]=id;
					}
					else{	// already known edge
						
						if (neighbors.size()==1){
							int ident=edges[neighbors.get(0)[0]][neighbors.get(0)[1]];
							edgeList.get(ident-1).add(i,j);
							edges[i][j]=ident;
						}
						else{
							int ident=edges[neighbors.get(0)[0]][neighbors.get(0)[1]];
							
							// get min ident
							for (int n=1;n<neighbors.size();n++){
								if (edges[neighbors.get(n)[0]][neighbors.get(n)[1]]<ident) ident=edges[neighbors.get(n)[0]][neighbors.get(n)[1]];
							}
							
							// merge edges
							for (int n=0;n<neighbors.size();n++){
								int ident2=edges[neighbors.get(n)[0]][neighbors.get(n)[1]];
								if (ident2>ident){
									for (int p=0;p<edgeList.get(ident2-1).size();p++){
										edgeList.get(ident-1).add(edgeList.get(ident2-1).pointList.get(p));
										edges[edgeList.get(ident2-1).pointList.get(p)[0]][edgeList.get(ident2-1).pointList.get(p)[1]]=ident;
									}
									edgeList.get(ident2-1).clear();
								}
							}
							
							edgeList.get(ident-1).add(i,j);
							edges[i][j]=ident;
						}
					}	
				}
			}
		}
		
		// remove empty edge lists
		for (int i=0;i<edgeList.size();i++){
			if (edgeList.get(i).size()==0){
				edgeList.remove(i);
				i--;
			}
		}
		
		
		///////////////////////////////////////////////////////////////////////////////////////////
		// detect corners
		///////////////////////////////////////////////////////////////////////////////////////////
		for (int i=0;i<edgeList.size();i++){
			edgeList.get(i).getCorners(image);
			if (!edgeList.get(i).valid){	// if invalid or white or black square
				edgeList.remove(i);
				i--;
			}
		}
		
		///////////////////////////////////////////////////////////////////////////////////////////
		// detect a specific ARTag
		///////////////////////////////////////////////////////////////////////////////////////////
		detected=false;
		pz=-1;
		int i=0;
		while (i<edgeList.size()) {
			edgeList.get(i).setCode(image);
			if (edgeList.get(i).code!=0 && edgeList.get(i).code!=511) {	// avoid white or black squares
				if (edgeList.get(i).code==current || (current==-1 && edgeList.get(i).height<maxSize+2)) {
					detected=true;
					search=false;
					px=edgeList.get(i).centerX;
					pz=edgeList.get(i).height;
					System.out.println(edgeList.get(i).code+" ; "+pz+" ; "+px);
				}
			}
			i++;
		}
		
		// change target
		if (detected && pz>=maxSize){
			pz=-1;
			index++;	// next marker
			if (index<sequence.length) current=sequence[index];
			else current=-1;
			search=true;
		}
	}
	
	
	// initialize sequence
	public void initialize() {
		index=0;
		if (sequence.length>0) current=sequence[0];
		else current=-1;
		search=true;
	}
	
	
	// convert matrix into bufferedImage
	public BufferedImage Matrix2bufferedImage() {
	    BufferedImage img = new BufferedImage(image[0].length/2, image.length/2, BufferedImage.TYPE_INT_RGB);
	    for(short i=0; i<image[0].length; i+=2) {
	        for(short j=0; j<image.length; j+=2) {
	            int val = image[j][i];
	            if (val>255) val=255;
	            Color newColor = new Color(val,val,val);
	            img.setRGB(i/2,j/2,newColor.getRGB());
	        }
	    }
	    
	    // draw detected ARTags
	    Graphics g = img.getGraphics();
	    for (int i=0;i<edgeList.size();i++){
			g.setColor(Color.red);
			for (int j=0;j<edgeList.get(i).fastList.size();j++){
				g.drawOval(edgeList.get(i).fastList.get(j)[0]/2-1, edgeList.get(i).fastList.get(j)[1]/2-1,3,3);
			}
			g.fillOval(edgeList.get(i).centerX/2-3, edgeList.get(i).centerY/2-3, 6, 6);
			g.setColor(Color.green);
			g.drawString(edgeList.get(i).code+" ; "+edgeList.get(i).height, edgeList.get(i).centerX/2-3, edgeList.get(i).centerY/2-10);
		}
	    
		return img;
	}
}

package robot_control;


public class Main {
	
	public static String port="COM5";	// write here the Bluetooth port used by Arduino
	
	
	private Interface inter;
	private DisplayFrame display;
	
	private int vx=0;
	private int vy=0;
	private int rz=0;
	
	private int vx1=0;
	private int vy1=0;
	private int rz1=0;
	
	public Main(){
		
		// initialize interface
		inter=new Interface();
		
		// initialize virtual joystick
		display=new DisplayFrame(this);
		
		
		while (true){
			
			controlRobot();
			
			try {Thread.sleep(10);} 
			catch (InterruptedException e) {e.printStackTrace();}
		}
	}
	
	
	// read input and send motor commands
	public void controlRobot(){
		
		// get speed values from virtual joystick
		vx=display.getVx();
		vy=display.getVy();
		rz=display.getRz();
		
		// bound values
		if (Math.abs(vx)<5) vx=0;
		if (vx> 100) vx= 100;
		if (vx<-100) vx=-100;
		
		if (Math.abs(vy)<5) vy=0;
		if (vy> 100) vy= 100;
		if (vy<-100) vy=-100;
		
		if (Math.abs(rz)<5) rz=0;
		if (rz> 100) rz= 100;
		if (rz<-100) rz=-100;
		
		// if values changed, send commant to the robot
		if (vx!=vx1 || vy!=vy1 || rz!=rz1){
			vx1=vx;
			vy1=vy;
			rz1=rz;
			
			inter.sendMsg(vx,vy,rz);
		}
	}
	
	
	// close serial port
	public void close(){
		inter.close();
	}
	

	////////////////////////////////////////////////////////////////
	public static void main(String[] args) {
		new Main();
	}

}

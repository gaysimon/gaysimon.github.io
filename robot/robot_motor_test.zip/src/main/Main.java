package main;

import robot.Robot;

public class Main {

	
	public static String path="/home/pi/opencv/build/lib/";	// path of OpenCV .so libraries
	public static boolean raspberry=true;					// program runs on a raspberry pi

	// robot controller
	public Robot robot;
	
	// display panel
	private DisplayFrame display;

	
	public Main(){
		
		// robot controller
		robot=new Robot();
		
		// initialize display panel
		display=new DisplayFrame(this);
		display.repaint();
	}
	
	
	
	//////////////////////////////////////////////////////
	public static void main(String[] args) {
		
		// detect if the program runs on raspberry pi
		if (!System.getProperty("user.name").equals("pi") && !System.getProperty("user.name").equals("root")) {
			System.out.println("User name: "+System.getProperty("user.name"));	// display user's name
			Main.raspberry=false;												// not a raspberry pi
		}
		
		new Main();	// start main algorithm
	}

}

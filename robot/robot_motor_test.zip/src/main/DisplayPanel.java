package main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JPanel;

// display panel
public class DisplayPanel extends JPanel implements MouseListener {

	private static final long serialVersionUID = 1L;
	
	private Main main;
	
	private int button=0;	// pressed button
	
	
	public DisplayPanel(Main m){
		main=m;
		addMouseListener(this);
	}
	
	public void paintComponent(Graphics g){
		
		// background
		g.setColor(Color.white);
		g.fillRect(0,0, this.getWidth(), this.getHeight());
		
		
		// draw buttons
		g.setColor(Color.lightGray);
		if (button==1) g.setColor(Color.gray);
		else g.setColor(Color.lightGray);
		g.fillOval( 10, 10, 100, 100);
		if (button==2) g.setColor(Color.gray);
		else g.setColor(Color.lightGray);
		g.fillRect(120, 10, 100, 100);
		if (button==3) g.setColor(Color.gray);
		else g.setColor(Color.lightGray);
		g.fillOval(230, 10, 100, 100);
		
		if (button==4) g.setColor(Color.gray);
		else g.setColor(Color.lightGray);
		g.fillRect( 10,120, 100, 100);
		if (button==5) g.setColor(Color.gray);
		else g.setColor(Color.lightGray);
		g.fillRect(120,120, 100, 100);
		if (button==6) g.setColor(Color.gray);
		else g.setColor(Color.lightGray);
		g.fillRect(230,120, 100, 100);
		
		if (button==7) g.setColor(Color.gray);
		else g.setColor(Color.lightGray);
		g.fillOval( 10,230, 100, 100);
		if (button==8) g.setColor(Color.gray);
		else g.setColor(Color.lightGray);
		g.fillRect(120,230, 100, 100);
		if (button==9) g.setColor(Color.gray);
		else g.setColor(Color.lightGray);
		g.fillOval(230,230, 100, 100);
		
		
		g.setColor(Color.black);
		g.drawOval( 10, 10, 100, 100);
		g.drawRect(120, 10, 100, 100);
		g.drawOval(230, 10, 100, 100);
		
		g.drawRect( 10,120, 100, 100);
		g.drawRect(120,120, 100, 100);
		g.drawRect(230,120, 100, 100);
		
		g.drawOval( 10,230, 100, 100);
		g.drawRect(120,230, 100, 100);
		g.drawOval(230,230, 100, 100);
		
		
		g.drawString("L+", 52, 62);
		g.drawString("turn Left", 35, 172);
		g.drawString("L-", 52, 282);
		
		g.drawString("Forward", 145, 62);
		g.drawString("Stop", 154, 172);
		g.drawString("Backward", 140, 282);
		
		g.drawString("R+", 272, 62);
		g.drawString("turn Right", 252, 172);
		g.drawString("R-", 272, 282);
		
	}

	public void mouseClicked(MouseEvent e) {}
	public void mouseEntered(MouseEvent arg0) {}

	public void mouseExited(MouseEvent e) {
		// stop robot when cursor get out of the window
		button=0;
		main.robot.stop();
		this.repaint();
	}

	public void mousePressed(MouseEvent e) {
		// control the robot according to pressed button
		
		int speed=90;	// default speed
		
		int x=e.getX();
		int y=e.getY();
		
		if (x>10 && x<110 && y>10 && y<110) {
			button=1;
			main.robot.setMotors(speed, 0);
		}
		else if (x>120 && x<220 && y>10 && y<110) {
			button=2;
			main.robot.setMotors(speed, speed);
		}
		else if (x>230 && x<330 && y>10 && y<110) {
			button=3;
			main.robot.setMotors(0, speed);
		}
		
		else if (x>10 && x<110 && y>120 && y<220) {
			button=4;
			main.robot.setMotors(-speed, speed);
		}
		else if (x>120 && x<220 && y>120 && y<220) {
			button=5;
			main.robot.stop();
		}
		else if (x>230 && x<330 && y>120 && y<220) {
			button=6;
			main.robot.setMotors(speed, -speed);
		}
		
		else if (x>10 && x<110 && y>230 && y<330) {
			button=7;
			main.robot.setMotors(-speed, 0);
		}
		else if (x>120 && x<220 && y>230 && y<330) {
			button=8;
			main.robot.setMotors(-speed, -speed);
		}
		else if (x>230 && x<330 && y>230 && y<330) {
			button=9;
			main.robot.setMotors(0, -speed);
		}
		
		this.repaint();
	}

	public void mouseReleased(MouseEvent e) {
		// stop the robot when releasing the button
		button=0;
		main.robot.stop();
		this.repaint();
	}

}

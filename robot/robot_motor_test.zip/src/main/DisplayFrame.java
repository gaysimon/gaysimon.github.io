package main;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;


// display window
public class DisplayFrame extends JFrame{

	private static final long serialVersionUID = 1L;

	private Main main;
	private DisplayPanel panel;	// display panel

	public DisplayFrame(Main m){
		
		main=m;
		
		this.setTitle("Control");
    	this.setSize(350, 370);
    	this.setLocationRelativeTo(null);               
    	panel=new DisplayPanel(m);
    	this.setContentPane(panel);
    	this.setVisible(true);
    	
    	this.addWindowListener(new WindowAdapter() {
    		   public void windowClosing(WindowEvent evt) {
    			   main.robot.stop();
    			   System.exit(0);

    		   }
    	});
	}
	
}
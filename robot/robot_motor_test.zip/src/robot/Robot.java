package robot;

import main.Main;

// functions to control motors
public class Robot {

	public int vl=0;				// speed of left and right motors
	public int vr=0;
	
	public boolean moving=false;	// true when the robot is performing a move
	
	private MotorControl motors;	// GPIO interface
	
	// constructor: initialize GPIO interface 
	public Robot() {
		if (Main.raspberry) motors=new MotorControl();
	}
	
	
	// set motor speed for a given duration
	public void move(int g, int d, int time) {
		
		moving=true;
		setMotors(g,d);
		
		try {Thread.sleep(time);} 	// wait
		catch (InterruptedException e) {e.printStackTrace();}
		
		stop();
		moving=false;
	}
	
	
	// set speed value for each motor
	public void setMotors(int l, int r) {
		
		vl=l;
		vr=r;
		
		if (Main.raspberry) motors.setMotor(vl, vr);
		else System.out.println("set speed ("+vl+","+vr+")");
	}
	
	// stop the two motors
	public void stop() {
		if (Main.raspberry) motors.stop();
		else System.out.println("stop");
	}
	
}

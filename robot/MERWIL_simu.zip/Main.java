
public class Main {

	
	public Robot robot;				// interface with environment
	

	
	public byte intended=0;			// intended and
	public byte enacted=0;			// enacted interactions
	
	public byte timeline=0;			// timeline of enacted interactions
	

	public short[] counters;		// count each observed sheme
	public short[] propositions;	// proposed interactions (for display purpose only)
	
	public short[] candidates;		// proposition value of interactions
	public short[] candidates2;		// propositions with alternatives' values
	
	public byte[] alternative;		// detected alternative of interactions
	
	public boolean step=false;
	public boolean play=false;
	
	public Main() {
		
		counters=new short[16];
		propositions=new short[16];
		candidates=new short[4];
		candidates2=new short[4];
		alternative=new byte[4];
		
		robot=new Robot(this);
		
		
		intended=0b00;	// first intended interaction
		
		// 00 -> r+
		// 01 -> r-
		// 10 -> l+
		// 11 -> l-
		
		// play and pause tempo
		while (!step && !play) {
			try { Thread.sleep(20);
			} catch (InterruptedException e) { e.printStackTrace(); }
		}
		step=false;
		
		
		while (true) {			
			
			////////////////////////////////////////////////////////////////////////////////////////////
			// perform intended interaction
			enacted=robot.act(intended);
			
			////////////////////////////////////////////////////////////////////////////////////////////
			// record new interaction in timeline
			timeline = (byte) (timeline <<2);
			timeline = (byte) (timeline | enacted);
			
			System.out.println("intended : "+String.format("%2s", Integer.toBinaryString(intended)).replace(' ', '0')
						    +" , enacted : "+String.format("%2s", Integer.toBinaryString(enacted )).replace(' ', '0') );
			
			// if failure, record alternative interaction
			if (enacted!=intended) alternative[intended]= (byte) (enacted | 0b1000);
			
			// increment counter of observed shemes
			counters[(timeline & 0b1111)]++;
			
			////////////////////////////////////////////////////////////////////////////////////////////
			// propositions
			for (int i=0;i<4;i++) candidates[i]=0;		// reset candidate values
			
			// get propositions' values
			for (int i=0;i<16;i++) {
				propositions[i]=0;
				
				if ( (timeline & 0b11) == (i & 0b1100)>>>2) {
					propositions[i] = (byte) ( (i & 0b11) | 0b1000);
					
					if ( (i & 0b01) == 0 ) candidates[(i & 0b11)]+=counters[i];	// valence = 1
					else 				   candidates[(i & 0b11)]-=counters[i]; // valence =-1
				}
			}
			
			// add alternatives' values
			for (int i=0;i<4;i++) {
				candidates2[i]=candidates[i];
				
				if ( (alternative[i] & 0b1000) !=0 ) candidates2[i]+=candidates[ (alternative[i] & 0b0011) ];
			}
			
			// find best proposition
			int max=candidates2[0];
			intended=0;
			
			for (int i=1;i<4;i++) {
				if (candidates2[i]>max) {
					max=candidates2[i];
					intended=(byte) i;
				}
			}
			
			
			////////////////////////////////////////////////////////////////////////////////////////////			
			// repaint display panel
			robot.repaint();
			
			// play and pause tempo
			while (!step && !play) {
				try { Thread.sleep(20);
				} catch (InterruptedException e) { e.printStackTrace(); }
			}
			step=false;
			
		}
		
	}
	
	

	
	
	
	public static void main(String[] args) {
		new Main();
	}

}

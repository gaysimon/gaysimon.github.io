package barcode;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import org.opencv.core.Mat;
import org.opencv.core.MatOfByte;
import org.opencv.imgcodecs.Imgcodecs;

import main.Camera;

public class Detector {
	
	private static int SIZE_X=Camera.SIZE_X;
	private static int SIZE_Y=Camera.SIZE_Y;
	
	public static int target=-1;
	
	public ArrayList<Code> codeList;	// detected barcodes
	
	public short[][] image=null;
	
	// Mat to byte[] structures
	private MatOfByte bytemat= new MatOfByte();;
	private byte[] bytes;
	
	public int px=-1;
	public int height=-1;
	public int orientation=-1;
	
	public Detector() {
		image=new short[SIZE_Y][Camera.SIZE_X];
		codeList=new ArrayList<Code>();
	}
	
	
	// detect barcodes in images	
	public void detect(Mat img) {
		
		
		// convert to Byte array
		Imgcodecs.imencode(".bmp", img, bytemat);
		bytes = bytemat.toArray();
		
		
		// convert mat to matrix
		int c=54;
		for (short i=(short)(SIZE_Y-1);i>=0;i--) {
			for (short j=0;j<SIZE_X;j++) {
				image[i][j]=(short)(  (bytes[c  ] & 0xff)   );
				image[i][j]+=(short)(  (bytes[c+1] & 0xff)   );
				image[i][j]+=(short)(  (bytes[c+2] & 0xff)   );
				image[i][j]=(short)(image[i][j]/3);
				c+=3;
			}
		}
		
		
		
		codeList.clear();
		
		int l1, l2, l3, l4;		// position and height of two consecutive horizontal lines (l1-l2 and l3-l4) 
		
		float h1, h2, h3;		// height of lines
		float d1;				// spacing between header lines
		float p3, p4;			// position of header and footer
		
		
		for (int i=0;i<SIZE_X;i+=4){	// read a column on four
			
			l1=-1;					// reset lines
			l2=-1;
			l3=-1;
			l4=-1;
			
			int j=2;
			while (j<SIZE_Y-2){
				
				//////////////////////////////////
				// detect horizontal black lines
				
				// detect light to dark gradient
				while (j<SIZE_Y-2 && image[j-1][i]+image[j-2][i]-image[j+1][i]-image[j+2][i]<40){
					j++;
				}
				if (j<SIZE_Y-2) l1=j;		// record beginning of the line
				while (j<SIZE_Y-2 && image[j-1][i]+image[j-2][i]-image[j+1][i]-image[j+2][i]>40) j+=2; // continue until the gradient disappears
				
				// detect dark to light gradient
				while (j<SIZE_Y-2 && image[j+1][i]+image[j+2][i]-image[j-1][i]-image[j-2][i]<40){
					j++;
				}
				if (j<SIZE_Y-2) l2=j;		// record ending of the line
				while (j<SIZE_Y-2 && image[j+1][i]+image[j+2][i]-image[j-1][i]-image[j-2][i]<40) j+=2; // continue until the gradient disappears
				
				
				// detect code when 2 lines are detected
				if (l2!=-1 && l4!=-1){
					
					// get lines' height
					h1=l4-l3;
					h2=l2-l1;
					// test line thickness
					if (h1/h2>1.7 && h1/h2<2.3){		// test ratio (h1 must be close to 2xh2)
						
						// get lines' spacing
						d1=l1-l4;
						// test spacing thickness
						if (d1/h2>0.7 && d1/h2<1.3){	// spacing must be close to second line's height
							
							// get header position and thickness 
							float height=l2-l3;
							float thick=height/4;
							
							// define footer line search window
							float w3=l2+10*thick-thick/2;
							float w4=l2+11*thick+thick/2; 
							p3=-1;					// top of footer line
							p4=-1;					// bottom of footer line
					
							// search footer line
							if (w4<SIZE_Y-2){
								for( int j2=(int)w3;j2<w4;j2++){
									if (image[j2-1][i]+image[j2-2][i]-image[j2+1][i]-image[j2+2][i]>40){
										p3=j2;	// record beginning of the line
									}
									if (image[j2+1][i]+image[j2+2][i]-image[j2-1][i]-image[j2-2][i]>40){
										p4=j2;	// record ending of the line
									}
								}
								
								if (p3!=-1 && p4!=-1){	
									// test bottom line
									h3=p4-p3;
									if (h3/h2>0.7 && h3/h2<1.3){	// fouter has the same thickness than header's second line
										
										//System.out.println(i+", "+ (int)l3+", "+ (int)l2+", "+ (int)p3+", "+ (int)p4);
										
										// record the code and get id
										Code code=new Code(i, (int)l3, (int)l2, (int)p3, (int)p4);
										code.readCode(image);
										
										// search for existing similar code
										if (code.code!=0 && code.value1>4 && code.value1<28){
											int k=0;
											boolean found=false;
											while (!found && k<codeList.size()){
												if (code.code==codeList.get(k).code) found=true;
												else k++;
											}
											if (found) codeList.get(k).merge(code);
											else codeList.add(code);
										}
										
										// reset line buffer
										l1=-1;
										l2=-1;
										l3=-1;
										l4=-1;
										
										// directly jump after the code
										j=(int) p4;
									}
								}
							}
						}
					}
				}
				// if no code is detected, copy second line as first line for a new detection
				l3=l1;
				l4=l2;
				l1=-1;
				l2=-1;
			}
		}
		
		// dislay detected codes
		for (int i=0;i<codeList.size();i++) {
			System.out.println("#"+i+" : code "+codeList.get(i).code
									+", pos_x="+(codeList.get(i).px1+codeList.get(i).px2)/2
									+", height="+codeList.get(i).height
									+" , orientation="+codeList.get(i).angle);
		}
		
		//////////////////////////////////////////////////////////////////
		// define position of target barcode
		if (target==-1) {	// if no target defined, get first barcode
			if (codeList.size()>0) {
				px=(codeList.get(0).px1+codeList.get(0).px2)/2;
				height=(int)codeList.get(0).height;
				orientation=(int)codeList.get(0).angle;
			}
			else {
				px=-1;
				height=-1;
				orientation=-1;
			}
		}
		else {				// follow given code
			boolean found=false;
			int i=0;
			while (!found && i<codeList.size()) {
				if (codeList.get(i).code==target) found=true;
				else i++;
			}
			if (found) {
				px=(codeList.get(i).px1+codeList.get(i).px2)/2;
				height=(int)codeList.get(i).height;
				orientation=(int)codeList.get(0).angle;
			}
			else {
				px=-1;
				height=-1;
				orientation=-1;
			}
		}
		
	}
	
	
	// draw the barcode on the image
	public BufferedImage Matrix2bufferedImage() {
		
			
		BufferedImage img = new BufferedImage(image[0].length, image.length, BufferedImage.TYPE_INT_RGB);
	    for(short i=0; i<image[0].length; i++) {
	        for(short j=0; j<image.length; j++) {
	            int val = image[j][i];
	            if (val>255) val=255;
	            Color newColor = new Color(val,val,val);
	            img.setRGB(i,j,newColor.getRGB());
	        }
	    }
		
		Graphics g = img.getGraphics();
		for (int i=0;i<codeList.size();i++){
			
			// draw header
			g.setColor(Color.green);
			g.fillRect(codeList.get(i).px1,codeList.get(i).py1,
					   codeList.get(i).px2-codeList.get(i).px1+1, 
					   codeList.get(i).py2-codeList.get(i).py1);
			
			// draw code
			for (int c=0;c<4;c++){
				if (codeList.get(i).barcode[c]==1) g.setColor(Color.green);
				else g.setColor(Color.red);
				g.fillRect(codeList.get(i).px1, 
						   (int)(codeList.get(i).py2+codeList.get(i).delta+codeList.get(i).delta*c), 
						   codeList.get(i).px2-codeList.get(i).px1+1, 
						   (int)codeList.get(i).delta);
			}
			
			// draw orientation
			g.setColor(Color.green);
			int size=(int)((codeList.get(i).value1+codeList.get(i).value2));
			g.fillOval((codeList.get(i).px1+codeList.get(i).px2)/2-size/4,
					   (int)(codeList.get(i).py2+7.5*codeList.get(i).delta)-size/8,
					   size/4,size/4);
		}

		return img;
	}
}

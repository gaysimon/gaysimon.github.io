package barcode;

public class Code {

	public int px1=0;		// horizontal position of the barcode
	public int px2=0;
	public int py1=0;		// vertical position of the header
	public int py2=0;
	public int py3=0;		// vertical position of the footer
	public int py4=0;
	
	public int[] barcode;	// code as a 4-bit code
	public float value1;	// analog value
	public float value2;
	
	public int code;		// code as a number
	
	public float delta;
	public float height;
	
	private float angle1;
	private float angle2;
	public float angle;		// orientation
	
	public Code(int x, int y1,int y2, int y3, int y4){
		px1=x;
		px2=x;
		py1=y1;
		py2=y2;
		py3=y3;
		py4=y4;
		
		height=y4-y1;
		delta=height/15;
		
		barcode=new int[8];
		code=0;
	}
	
	public void readCode(short[][] img){
		
		// get threshold value
		short max=0;
		short min=255;
		
		for (int i=py1;i<py2;i++){
			if (img[i][px1]>max) max=img[i][px1];
			if (img[i][px1]<min) min=img[i][px1];
		}
		
		int threshold=(max+min)/2;
		
		
		
		if (py4<800){
			
			// get limits
			float c1=py2+delta+delta/2; // position of middle of first code line
			
			// read 4 bits code
			code=0;
			for (int i=0;i<4;i++){
				code=code*2;
				if (img[(int)(c1+delta*i)][px1]<threshold){
					barcode[i]=1;
					code++;
				}
				else{
					barcode[i]=0;
				}
			}
			//System.out.println(code);
			
			
			// read analog value
			int v1=0;
			int v2=0;
			float c2=py2+delta*4+delta/2;
			for (int i=(int)c2;i<py3-delta/2;i++){
				if (img[i-1][px1]>threshold && img[i+1][px1]<threshold) v1=i;
				if (img[i-1][px1]<threshold && img[i+1][px1]>threshold) v2=i;
			}
			
			value1=(v2-v1)*100/height;
			value2=(v2-v1)*100/height;
			
			angle1=(Math.max(5, Math.min(22, value1 ) ) -5)*360/17;
			angle2=angle1;
			angle=angle1;
		}
	}
	
	// merge code detected on another row
	public void merge(Code c){
		if (px1>c.px1){
			px1=c.px1;
			value2=c.value2;
		}
		if (px2<c.px2){
			px2=c.px2;
			value1=c.value1;
		}
		
		if (angle1<=angle2) angle=(angle1+angle2)/2;
		else angle=((angle1+angle2+360)/2)%360;
	}
	
}
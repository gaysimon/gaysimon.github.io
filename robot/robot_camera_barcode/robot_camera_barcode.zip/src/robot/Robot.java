package robot;

import main.Main;

// functions to control motors
public class Robot {

	private int vl=0;				// speed of left and right motors
	private int vr=0;
	
	public boolean moving=false;	// true when the robot is performing a move
	
	private MotorControl motors;	// GPIO interface
	
	// constructor: initialize GPIO interface 
	public Robot() {
		if (Main.raspberry) motors=new MotorControl();
	}
	
	
	public void action(int px, int height){
		
		int speed=100;		// default speed

		if (px!=-1) {		// if barcode detected
			
			if (px>200) {		// target is on right side
				if (height>100)	move(0,-speed,80);			// too close
				else move(speed,0,80);
			}
			else if (px<120) {	// target is on left side
				if (height>100)	move(-speed,0,80);			// too close
				else move(0,speed,80);
			}
			else {				// target in front
				if (height>100)	move(-speed,-speed,100);	// too close
				else if (height<80)	move(speed,speed,100);	// too far
				else stop();
			}
		}
		else stop();
	}
	
	
	// set motor speed for a given duration
	public void move(int l, int r, int time) {
		
		moving=true;
		setMotors(l,r);
		
		try {Thread.sleep(time);} 	// wait
		catch (InterruptedException e) {e.printStackTrace();}
		
		stop();
		moving=false;
	}
	
	
	// set speed value for each motor
	public void setMotors(int l, int r) {
		
		vl=l;
		vr=r;
		
		if (Main.raspberry) motors.setMotor(vl, vr);
		else System.out.println("set speed ("+vl+","+vr+")");
	}
	
	// stop the two motors
	public void stop() {
		if (Main.raspberry) motors.stop();
		else System.out.println("stop");
	}
	
}

package main;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;

import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.core.MatOfByte;
import org.opencv.videoio.VideoCapture;
import org.opencv.videoio.Videoio;



public class Camera {

	// camera properties
	public static short SIZE_X=320;
	public static short SIZE_Y=240;

	private VideoCapture camera;
	
	public Mat img=new Mat();	// mat containing grabbed image
	
	// load OpenCV libraries
	static {
        loadOpenCVLibrary();
    }
	
	
	// initialize the camera
	public Camera() {
		
		camera=new VideoCapture(0);
		camera.set(Videoio.CAP_PROP_HW_ACCELERATION_USE_OPENCL,1);	// GPU acceleration

		camera.set(Videoio.CAP_PROP_FRAME_WIDTH, SIZE_X);			// camera properties
		camera.set(Videoio.CAP_PROP_FRAME_HEIGHT, SIZE_Y);
		camera.set(Videoio.CAP_PROP_BUFFERSIZE, 1);

		
		// get first frame
		camera.read(img);
	}
	
	
	// get and convert camera image
	public void read() {
		camera.read(img);
	}
	
	
	
	// load OpenCV libraries
	private static void loadOpenCVLibrary() {
		 
		 if (Main.raspberry) {	// if program runs on a raspberry pi, loads libraries in folder specified in 'path'
		    File folder = new File(Main.path);
		    File[] listOfFiles = folder.listFiles(); 
	
		    for (int i = 0; i < listOfFiles.length; i++) {
		        if (listOfFiles[i].isFile() && listOfFiles[i].getName().endsWith(".so")) {
		            File lib = new File(Main.path + listOfFiles[i].getName());
		            System.load(lib.getAbsoluteFile().toString());
		        }
		    }
		 }
		 else {	// if program runs on a PC, loads libraries installed on the system
			 System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
		 }
	}
	
	
	// convert OpenCV's Mat into BufferedImage
	public BufferedImage Mat2bufferedImage() {
		MatOfByte bytemat = new MatOfByte();
		Imgcodecs.imencode(".bmp", img, bytemat);
		byte[] bytes = bytemat.toArray();
		InputStream in = new ByteArrayInputStream(bytes);
		BufferedImage img = null;
		try {
			img = ImageIO.read(in);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return img;
	}
	
}

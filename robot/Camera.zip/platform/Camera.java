package platform;


import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;
import javax.swing.JPanel;


import org.opencv.core.*;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.videoio.VideoCapture;
import org.opencv.videoio.Videoio;
import org.opencv.core.Mat;

/**
 * Program to read images from a stereo camera
 * @author simon gay
 */
public class Camera {

	private VideoCapture camera1;
	
	public Mat img=new Mat();	// mat containing grabbed image
	
	private Rect rectR;			// rectangles used to crop
	private Rect rectL;			// left and right images
	
	public Mat imgL=new Mat();	// left image
	public Mat imgR=new Mat();	// right image
	
	public BufferedImage imageL=null;
	public BufferedImage imageR=null;
	
	
	
	// displayer
	private CameraFrame cameraFrame;
	
	
	// load OpenCV libraries
	static {
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
    }
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public Camera() {

		/////////////////////////////////////////////////////////////////////////
		// configure camera
		camera1=new VideoCapture(Main.CAMERA);
		camera1.set(Videoio.CAP_PROP_HW_ACCELERATION, 1);
		
		// parameters for a PS4Eye
		camera1.set(Videoio.CAP_PROP_FRAME_WIDTH, 3748);
		camera1.set(Videoio.CAP_PROP_FRAME_HEIGHT, 808);
		camera1.set(Videoio.CAP_PROP_FPS, Main.FRAMERATE);
		camera1.set(Videoio.CAP_PROP_BUFFERSIZE, 1);

		// set crop rectangles
		rectR=new Rect(48,0,1280,800);
		rectL=new Rect(48+1280,0,1280,800);
		
		cameraFrame=new CameraFrame(this, 1300,480);

		/////////////////////////////////////////////////////////////////////////
		
	    // get first frame
		camera1.read(img);
		
	    // delay for camera initialization
        try{Thread.sleep(200);
		}catch(InterruptedException ex){Thread.currentThread().interrupt();}
        
        // on Linux devices: can set the autoexposure mode of the camera
        if (Main.AUTOEXPOSURE) {
	        try {
				Runtime.getRuntime().exec(String.format("v4l2-ctl -c exposure_auto=0"));
			} catch (IOException e) {e.printStackTrace();}
        }
	}
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public void readImage() {

		if (camera1.read(img)) {
			
			///////////////////////////////////////////////////
			// prepare images
			
			// crop camera image 
			imgL=new Mat(img,rectL);
			imgR=new Mat(img,rectR);
			
			
			// convert Mat into BufferedImages
			imageL=Mat2bufferedImage(imgL);
			imageR=Mat2bufferedImage(imgR);
			
		}
		
		cameraFrame.repaint();
    }
	
	
	// paint in display panels
	public void paint(Graphics g, int w, int h, JPanel panel){
		
		// white background
		g.setColor(Color.white);
		g.fillRect(0, 0, w, h);
		
		// draw image
		if (imageL!=null) g.drawImage(imageL, 0, 0, 640, 400,0,0,1280,800, panel);
		if (imageR!=null) g.drawImage(imageR, 645, 0, 1285, 400,0,0,1280,800, panel);

	}
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	// convert Mat into bufferedImage
	public static BufferedImage Mat2bufferedImage(Mat image) {
		MatOfByte bytemat = new MatOfByte();
		Imgcodecs.imencode(".jpg", image, bytemat);
		byte[] bytes = bytemat.toArray();
		InputStream in = new ByteArrayInputStream(bytes);
		BufferedImage img = null;
		try {
			img = ImageIO.read(in);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return img;
	}
	
}

package platform;

public class Main {
	
	//////////////////////////////////////////////
	public static int CAMERA=1;					// select the camera number
	public static int FRAMERATE=60;				// if image is too dark, change to 30fps
	public static boolean AUTOEXPOSURE=false;	// set camera autoexposure (Linux only)
	//////////////////////////////////////////////
	
	// perception module
	public Camera camera=null;
	
	public Main(){
		
		camera=new Camera();
		
		while(true) {
			
			// read image
			camera.readImage();
			
		}
	}	

	////////////////////////////////////////
	public static void main(String[] args) {	
		new Main();
	}

}

package platform;

import javax.swing.JFrame;
import javax.swing.WindowConstants;


/**
 * A display frame for the stereo system
 * @author simon gay
 */
public class CameraFrame extends JFrame{

	private static final long serialVersionUID = 1L;
	
	private CameraPanel panel;

	public CameraFrame(Camera camera, int width, int heigh){
		
		this.setTitle("Camera");
    	this.setSize(width, heigh);
    	this.setLocationRelativeTo(null);               
    	panel=new CameraPanel(camera);
    	this.setContentPane(panel);
    	this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    	this.setVisible(true);
	}
}
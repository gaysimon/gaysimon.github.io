package vision;


import java.awt.Graphics;
import javax.swing.JPanel;


/**
 * A display panel for the stereo system
 * @author simon gay
 */
public class ContextPanel extends JPanel{
	
	private static final long serialVersionUID = 1L;

	
	private StereoVision stereo;

	
	public ContextPanel(StereoVision s){
		stereo=s;
	}

	public void paintComponent(Graphics g){
		if (stereo!=null) stereo.paint(g, this.getWidth(), this.getHeight(), this);
	}

}

package robot;

import jssc.SerialPort;
import jssc.SerialPortEvent;
import jssc.SerialPortEventListener;
import jssc.SerialPortException;
import platform.Main;

/**
 * A serial interface to communicate with an Arduino running the interpreter .ino code
 * @author simon gay
 */
public class Robot implements SerialPortEventListener{
	
	
	// Arduino interface	
	private SerialPort serialPort;
	
	
	// movement parameters	
	private int vx1=10000;
	private int vy1=10000;
	private int rz1=10000;
	
	// reception from Arduino
	private int message_type=0;  // 0 waiting
	
	public int time=0;
	public int counter=0;
	public float ax0=0;
	public float ay0=0;
	public float az0=0;
	public float rx0=0;
	public float ry0=0;
	public float rz0=0;
	private float angle_Z=0;
	public float angle_Z_deg;
	
	
	public Robot() {
		openPort();
	}
	
	public void openPort() {
		// open serial port
		try {
			serialPort = new SerialPort(Main.PORT);
			serialPort.openPort();
			serialPort.setParams(9600, 8, 1, 0);
			serialPort.addEventListener(this, SerialPort.MASK_RXCHAR);
		} catch (SerialPortException e) {e.printStackTrace();}
	}
	
	public void close(){
		try {
			System.out.println("Port closed: " + serialPort.closePort());
		} catch (SerialPortException e) {e.printStackTrace();}
	}
	
	// send command if there is a change
	public void move(int vx, int vy, int rz) {
		if (vx!=vx1 || vy!=vy1 || rz!=rz1) {
			sendMsg(vx, vy, rz);
			vx1=vx;
			vy1=vy;
			rz1=rz;
		}
	}
	
	// send command message on serial port
	private void sendMsg(int px, int py, int rz){
		
		byte[] msg=new byte[4];
		msg[0]=(byte)255;
		msg[1]=(byte)(px+100);
		msg[2]=(byte)(py+100);
		msg[3]=(byte)(rz+100);

		try {serialPort.writeBytes(msg);
		} catch (SerialPortException e) {e.printStackTrace();}/**/
	}
	
	
	// receive messages from the Arduino: wait for IMU data
	public void serialEvent(SerialPortEvent event) {

		if(event.isRXCHAR() && event.getEventValue() > 0) {
            try {
                byte[] received=serialPort.readBytes();

                for(int i=0;i<received.length; i++){
                	
                	// new message
                	if ((received[i] & 0xff)==255){
                		message_type=1;
                	}
                	else{
                		// get two bytes for delay
                		if (message_type==1){
                			time=(received[i] & 0xff)*254;
                    		message_type=2;
                		}
                		else if (message_type==2){
                			time+=(received[i] & 0xff);
                    		message_type=3;                    		
                		}
                		
                		// get two bytes for accX
                		else if (message_type==3){
                			ay0=(received[i] & 0xff)*254;
                    		message_type=4;                    		
                		}
                		else if (message_type==4){
                			ay0+=(received[i] & 0xff)-32258;
                			ay0=ay0/100;
                    		message_type=5;                    		
                		}

                		// get two bytes for accY
                		else if (message_type==5){
                			ax0=(received[i] & 0xff)*254;
                    		message_type=6;                    		
                		}
                		else if (message_type==6){
                			ax0+=(received[i] & 0xff)-32258;
                			ax0=ax0/100;
                    		message_type=7;                    		
                		}
                		
                		// get two bytes for accZ
                		else if (message_type==7){
                			az0=(received[i] & 0xff)*254;
                    		message_type=8;                    		
                		}
                		else if (message_type==8){
                			az0+=(received[i] & 0xff)-32258;
                			az0=az0/100;
                    		message_type=9;                    		
                		}
                		
                		// get two bytes for rotX
                		else if (message_type==9){
                			rx0=(received[i] & 0xff)*254;
                    		message_type=10;                    		
                		}
                		else if (message_type==10){
                			rx0+=(received[i] & 0xff)-32258;
                			rx0=rx0/100;
                    		message_type=11;                    		
                		}

                		// get two bytes for rotY
                		else if (message_type==11){
                			ry0=(received[i] & 0xff)*254;
                    		message_type=12;                    		
                		}
                		else if (message_type==12){
                			ry0+=(received[i] & 0xff)-32258;
                			ry0=ry0/100;
                    		message_type=13;                    		
                		}
                		
                		// get two bytes for rotZ
                		else if (message_type==13){
                			rz0=(received[i] & 0xff)*254;
                    		message_type=14;                    		
                		}
                		else if (message_type==14){
                			rz0+=(received[i] & 0xff)-32258;
                    		message_type=0;
                    		rz0=rz0/100;
                    		

                			
                			// get yaw angle
                			angle_Z+=rz0*(float)(time)/1000000f;
                			if (angle_Z<0)angle_Z+=Math.PI*2;
                			if (angle_Z>=Math.PI*2) angle_Z-=Math.PI*2;
                			
                			angle_Z_deg=(float)Math.toDegrees(angle_Z);
                			
                			
                    		//////////////////////////////////////////////////////////////////////
                			// angle remains at zero at the beginning (10 first measures) while the IMU stabilize
                    		if (counter<10){
                    			counter++;
                    			angle_Z=0;
                    			angle_Z_deg=0;
                    		}
                		}
                	}
                }
            }
            catch (SerialPortException ex) {System.out.println("Error in receiving string from COM-port: " + ex);}
        }
    }
	
	// reset current orientation
	public void resetAngle(){
		angle_Z=0;
		angle_Z_deg=0;
	}
	
}

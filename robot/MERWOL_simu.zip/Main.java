
public class Main {

	
	public Robot robot;				// interface with environment
	

	
	public byte intended=0;			// intended and
	public byte enacted=0;			// enacted interactions
	
	public byte timeline=0;			// timeline of enacted interactions
	
	
	public boolean step=false;
	public boolean play=false;
	
	public Main() {
		
		robot=new Robot(this);
		
		
		intended=0b00;	// first intended interaction
		
		// 00 -> r+
		// 01 -> r-
		// 10 -> l+
		// 11 -> l-
		
		// play and pause tempo
		while (!step && !play) {
			try { Thread.sleep(20);
			} catch (InterruptedException e) { e.printStackTrace(); }
		}
		step=false;
		
		
		while (true) {			
			
			////////////////////////////////////////////////////////////////////////////////////////////
			// perform intended interaction
			enacted=robot.act(intended);
			
			////////////////////////////////////////////////////////////////////////////////////////////
			// record new interaction in timeline
			timeline = (byte) (timeline <<2);
			timeline = (byte) (timeline | enacted);
			
			System.out.println("enacted : "+String.format("%2s", Integer.toBinaryString(enacted)).replace(' ', '0'));
			
			// next decision
			if ( (enacted & 0b01) !=0) {
				intended = (byte) ( intended ^ 0b10);	// change action
			}
			
			
			
			////////////////////////////////////////////////////////////////////////////////////////////			
			// repaint display panel
			robot.repaint();
			
			// play and pause tempo
			while (!step && !play) {
				try { Thread.sleep(20);
				} catch (InterruptedException e) { e.printStackTrace(); }
			}
			step=false;
			
		}
		
	}
	
	

	
	
	
	public static void main(String[] args) {
		new Main();
	}

}

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JPanel;

public class DisplayPanel extends JPanel implements MouseListener{
		
	private static final long serialVersionUID = 1L;

	public Main main;
	
	
	public DisplayPanel(Main m){
		main=m;
		addMouseListener(this);
	}

	
	public void paintComponent(Graphics g){
		
		// background
		g.setColor(Color.white);
		g.fillRect(0, 0, this.getWidth(), this.getHeight());
		
		// environment's borders
		g.setColor(Color.black);
		g.drawRect(10, 10, 400, 400);
		
		// draw robot
		g.setColor(Color.lightGray);
		g.fillOval((int)(4*main.robot.px), (int)(4*(100-main.robot.py)), 20,20);
		g.setColor(Color.black);
		g.drawOval((int)(4*main.robot.px), (int)(4*(100-main.robot.py)), 20,20);
		g.drawLine(10+(int)(4*main.robot.px), 10+(int)(4*(100-main.robot.py)),
				   10+(int)(4*main.robot.px+10*Math.cos(Math.toRadians(main.robot.rz))),
				   10+(int)(4*(100-main.robot.py)-10*Math.sin(Math.toRadians(main.robot.rz))));
		
		// draw light source
		g.setColor(Color.yellow);
		g.fillOval(5+(int)(4*main.robot.lx), 5+(int)(4*(100-main.robot.ly)), 10,10);
		g.setColor(Color.black);
		g.drawOval(5+(int)(4*main.robot.lx), 5+(int)(4*(100-main.robot.ly)), 10,10);
		
		
		// draw buttons
		g.setColor(Color.lightGray);
		g.fillRect(10, 420, 50, 20);
		g.fillRect(80, 420, 50, 20);
		g.setColor(Color.black);
		g.drawString("step", 21, 434);
		if (main.play)  g.drawString("pause", 85, 434);
		else 			g.drawString("play", 92, 434);
		
		
		// left panel
		g.setColor(Color.black);
		
		String msg;
		
		// write timeline
		g.drawString("timeline : "+String.format("%4s", Integer.toBinaryString(main.timeline & 0b1111)).replace(' ', '0'), 420, 20);
		int comp= 0b10000000;
		for (int i=0;i<4;i++) {
			if ( (main.timeline & comp) !=0) msg="l";
			else msg="r";
			comp= (comp>>>1);
		
			if ( (main.timeline & comp) !=0) msg+="-";
			else msg+="+";
			comp= (comp>>>1);
			
			msg+=" ;";
			g.drawString(msg, 420+i*25, 40);
		}
		
	}


	public void mouseClicked(MouseEvent e) {
		
		// change light source's position
		if (e.getX()>10 && e.getX()<410 && e.getY()>10 && e.getY()<410) {
			main.robot.lx=(e.getX()-10)/4;
			main.robot.ly=100-(e.getY()-10)/4;
			this.repaint();
		}
		
		// step button
		if (e.getX()>10 && e.getX()<60 && e.getY()>420 && e.getY()<440) {
			main.step=true;
		}
		
		// play/pause button
		if (e.getX()>80 && e.getX()<130 && e.getY()>420 && e.getY()<440) {
			main.play=!main.play;
		}
	}


	public void mouseEntered(MouseEvent arg0) {}
	public void mouseExited(MouseEvent arg0) {}
	public void mousePressed(MouseEvent arg0) {}
	public void mouseReleased(MouseEvent arg0) {}
		
}

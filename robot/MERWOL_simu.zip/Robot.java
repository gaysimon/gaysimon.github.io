
public class Robot {

	// position of the robot
	public float px=50;
	public float py=50;
	public double rz=0;
	
	// position of light source
	public int lx=20;
	public int ly=80;
	
	// sensor values and variations
	public double LDR1=0;
	public double LDR2=0;
	public double delta=0;
	
	// display window
	private DisplayFrame display;
	
	
	public Robot(Main m) {
		display=new DisplayFrame(m);
		
		// get first sensor value
		double angle=Math.toDegrees(Math.atan2(py-ly, px-lx))+180;
		angle=rz-angle;
		if (angle>180) angle-=360;
		if (angle<=-180) angle+=360;
		LDR1=180-Math.abs(angle);
	}
	
	public byte act(byte intend) {
		
		// move
		for (int m=0;m<20;m++) {
			if ( (intend & 0b10) !=0) rz+=1;
			else rz-=1;
			if (rz>=360) rz-=360;
			if (rz<0) rz+=360;
			px+=0.1*Math.cos(Math.toRadians(rz));
			py+=0.1*Math.sin(Math.toRadians(rz));
			
			// keep inside environment
			if (px<2.5) px=2.5f;
			if (py<2.5) py=2.5f;
			if (px>97.5) px=97.5f;
			if (py>97.5) py=97.5f;

			display.repaint();
			
			try {Thread.sleep(10);
			} catch (InterruptedException e) {e.printStackTrace();}
		}
		
		// measure variation
		LDR2=LDR1;	// save previous measure
		double angle=Math.toDegrees(Math.atan2(py-ly, px-lx))+180;
		angle=rz-angle;
		if (angle>180) 	 angle-=360;
		if (angle<=-180) angle+=360;
		LDR1=180-Math.abs(angle);	// get new measure
		
		delta=LDR1-LDR2;	// get variation
		
		// generate enacted interaction
		if (delta>0) 	return (byte) (intend & 0b10);	// keep action bit and set result bit to 0
		else			return (byte) (intend | 0b01);	// keep action bit and set result bit to 1
	}
	
	
	public void repaint() {
		display.repaint();
	}
}

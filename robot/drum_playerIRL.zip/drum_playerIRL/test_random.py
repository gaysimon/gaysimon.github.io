import time
import random

while True:

	# intention
	intention=random.randint(0,13)
	f=open("intended.txt","w")
     	f.write(str(intention))
     	f.close()
	print str(intention)+" -> ",
    	time.sleep(1)

	# read enacted
	f=open("enacted.txt","r")
    	enacted=f.read()
    	f.close()

	while len(enacted)==0:
		time.sleep(0.5)
		f=open("enacted.txt","r")
    		enacted=f.read()
    		f.close()

	print(enacted)
	f=open("enacted.txt","w")
     	f.write("")
     	f.close()

import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BOARD)

GPIO.setup(16,GPIO.IN, pull_up_down=GPIO.PUD_UP)

GPIO.setup(8,GPIO.OUT)
GPIO.setup(10,GPIO.OUT)

pwm1=GPIO.PWM(8,100)
pwm1.start(11)
time.sleep(0.7)
pwm1.stop()

previous_note=3

# erase intention file
f=open("intended.txt","w")
f.write("")
f.close()

# erase enaction file
f=open("enacted.txt","w")
f.write("")
f.close()

while True:

    # read intended
    f=open("intended.txt","r")
    intention=f.read()
    f.close()

    # erase intention file
    f=open("intended.txt","w")
    f.write("")
    f.close()

    drum=-1
    touch=False

    if len(intention)>0:

        # erase intention file
        f=open("enacted.txt","w")
        f.write("")
        f.close()

        print(intention)

        if   intention=="0" or intention=="1": drum=0
        elif intention=="2" or intention=="3": drum=1
        elif intention=="4" or intention=="5": drum=2
        elif intention=="6" or intention=="7": drum=3
        elif intention=="8" or intention=="9": drum=4
        elif intention=="10" or intention=="11": drum=5
        elif intention=="12" or intention=="13": drum=6
    
        if drum>=0:
            diff=abs(drum-previous_note)
            previous_note=drum
    
            note=drum*3+2
            pwm1=GPIO.PWM(8,100)
            pwm1.start(note)
            time.sleep(0.1+0.1*diff)
            pwm1.stop()

            time.sleep(0.05)

            pwm2=GPIO.PWM(10,100)
            pwm2.start(12)
            time.sleep(0.3)
            if GPIO.input(16):
                print('not touch')
            else:
                print('drum')
                touch=True
            
            pwm2.ChangeDutyCycle(16)
            time.sleep(0.3)
            pwm2.stop()

        # write enacted3
        f=open("enacted.txt","w")
        if touch:
            f.write(str(drum*2))
        else:
            f.write(str(drum*2+1))

        f.close()
        

    time.sleep(0.3)

pwm1.stop()
pwm2.stop()

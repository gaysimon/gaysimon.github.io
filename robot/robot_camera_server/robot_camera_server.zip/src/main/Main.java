package main;

import java.awt.image.BufferedImage;

import robot.Robot;
import servers.Server;


public class Main {

	
	public static String path="/home/pi/opencv/build/lib/";	// path of OpenCV .so libraries
	public static boolean raspberry=true;					// program runs on a raspberry pi (automatic detection)

	// camera interface
	private Camera camera;
	
	// robot controller
	private Robot robot;
	
	// servers
	private Server server;
	
	
	// Main system
	private boolean run=true;
	private int  counter=0;
	public BufferedImage output;
	
	/////////////////////////////////////////////////////////////////////////////////////////
	
	public Main(){
		

		// camera grabber
		camera=new Camera();
		
		// robot controller
		robot=new Robot();
		
		// servers
		server=new Server(this);
		
		
		try {Thread.sleep(20);
		} catch (InterruptedException e) {e.printStackTrace();}	
		
		/////////////////
		// used to measure execution time
		long time1=System.nanoTime()/1000000;
		long delay1=0;
		short nb=0;
		/////////////////
		
		
		// main execution loop
		while (run){
			
			/////////////////
			// measure time between frames
			delay1+=System.nanoTime()/1000000-time1;
			time1=System.nanoTime()/1000000;
			
			nb++;
			if (nb>20){
				nb=0;
				server.broadcast("framerate "+(delay1/20));
				delay1=0;
			}
			/////////////////
			
			// get new frame
			camera.read();
			
			if (counter==0) {	// process only one image on 2
				// image sent to web interface
				output=camera.Mat2bufferedImage();
				counter=1;
			}
			else counter--;
			
		}
		
		// close everything
		server.stop();
		robot.stop();
		
		System.out.println("########## system stopped ##########");
		System.exit(0);
	}
	
	/////////////////////////////////////////////////////////////////////////////////////////
	
	
	// control the robot
	public void robotCommand(String command) {
		int speed=80;
		if (command.equals("forward")) 			robot.setMotors(speed, speed);
		else if (command.equals("backward")) 	robot.setMotors(-speed, -speed);
		else if (command.equals("turnleft")) 	robot.setMotors(-speed, speed);
		else if (command.equals("turnright")) 	robot.setMotors(speed,-speed);
		else if (command.equals("stop")) 		robot.stop();
	}
	
	
	// main system commands
	public void systemCommand(String command) {
		if (command.equals("stop")) run=false;
	}
	

	// send a message to the web interface
	public void broadcast(String msg) {
		server.broadcast(msg);
	}
	
	
	/////////////////////////////////////////////////////////////////////////////////////////
	public static void main(String[] args) {
		
		// detect if the program runs on raspberry pi
		if (!System.getProperty("user.name").equals("pi") && !System.getProperty("user.name").equals("root")) {
			System.out.println("User name: "+System.getProperty("user.name"));	// display user's name
			Main.raspberry=false;												// not a raspberry pi
		}
		
		new Main();	// start main algorithm
	}

}

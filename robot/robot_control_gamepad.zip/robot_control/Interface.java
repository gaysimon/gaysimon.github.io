package robot_control;


import jssc.SerialPort;
import jssc.SerialPortException;

public class Interface {

	SerialPort serialPort;
	
	
	public Interface(){
		try {
			serialPort = new SerialPort(Main.port);
			serialPort.openPort();
			serialPort.setParams(9600, 8, 1, 0);
			System.out.println("port opened");
		} catch (SerialPortException e) {e.printStackTrace();}
	}
	
	
	// send commands as a sequence of bytes starting with byte 255
	public void sendMsg(int px, int py, int rz){
		
		byte[] msg=new byte[4];
		msg[0]=(byte)255;
		msg[1]=(byte)(px+100);
		msg[2]=(byte)(py+100);
		msg[3]=(byte)(rz+100);

		try {
			serialPort.writeBytes(msg);
		} catch (SerialPortException e) {e.printStackTrace();}/**/
	}
	
	
	public void close(){
		try {
			System.out.println("Port closed: " + serialPort.closePort());
		} catch (SerialPortException e) {e.printStackTrace();}
	}
	
}

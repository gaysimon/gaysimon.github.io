package servers;

import javax.imageio.ImageIO;

import platform.Main;

import java.awt.image.BufferedImage;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class VideoSocket implements Runnable {


    private ServerSocket serverSocket;
    private Socket socket;
    private final String boundary = "stream";
    private OutputStream outputStream;
    private boolean run=true;
    private Main main;

    public VideoSocket(Main m) {
        main = m;
    }

    // connect the socket
    public void startStreamingServer() throws IOException {
        serverSocket = new ServerSocket(8001);
        socket = serverSocket.accept();
        writeHeader(socket.getOutputStream(), boundary);
    }

    private void writeHeader(OutputStream stream, String boundary) throws IOException {
        stream.write(("HTTP/1.0 200 OK\r\n" +
                "Connection: close\r\n" +
                "Max-Age: 0\r\n" +
                "Expires: 0\r\n" +
                "Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0\r\n" +
                "Pragma: no-cache\r\n" +
                "Content-Type: multipart/x-mixed-replace; " +
                "boundary=" + boundary + "\r\n" +
                "\r\n" +
                "--" + boundary + "\r\n").getBytes());
    }
    
    
    // send image to client
    public void pushImage(BufferedImage img) throws IOException {
        if (img == null)
            return;
        try {
            outputStream = socket.getOutputStream();
            
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ImageIO.write(img, "jpg", baos);
            byte[] imageBytes = baos.toByteArray();
            outputStream.write(("Content-type: image/jpeg\r\n" +
                    "Content-Length: " + imageBytes.length + "\r\n" +
                    "\r\n").getBytes());
            outputStream.write(imageBytes);
            outputStream.write(("\r\n--" + boundary + "\r\n").getBytes());
            
        } catch (Exception ex) {
            socket = serverSocket.accept();
            writeHeader(socket.getOutputStream(), boundary);
        }
    }

    // start the thread sending images
    public void run() {
        try {
            
            startStreamingServer();
            System.out.print("video stream started");

            while (run) {
            	// send an image every 100ms
                pushImage(main.outputImage());
                try {Thread.sleep(100);
    			} catch (InterruptedException e) {e.printStackTrace();}
            }
        } catch (IOException e) {
            return;
        }
    }

    // stop video stream
    public void stopStreamingServer() throws IOException {
    	run=false;
        socket.close();
        serverSocket.close();
    }
}
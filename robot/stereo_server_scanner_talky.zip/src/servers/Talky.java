package servers;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class Talky {
	
	private HttpClient client =null;
	private HttpRequest request=null;
	public HttpResponse<String> response=null;
	
	private int id=-1;
	
	public Talky() {
		client = HttpClient.newHttpClient();
		id=Integer.parseInt(Server.address.split("\\.")[3]); // get last element of the IP address as id
		System.out.println("id = "+id);
	}
	
	
	public void sendMsg(int id, String msg) {
		try {
		     request = HttpRequest.newBuilder()
		                .uri(URI.create("http://192.168.1."+id+":8080"))	// address of recipient
		                .POST(HttpRequest.BodyPublishers.ofString(id+";"+msg))
		                .build();
		     System.out.println("sent : "+id+";"+msg);
		     response = client.send(request,HttpResponse.BodyHandlers.ofString());

		} catch (Exception e) {e.printStackTrace();}
	}
	
}

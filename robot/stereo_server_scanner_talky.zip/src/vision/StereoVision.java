package vision;


import java.util.ArrayList;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;
import javax.swing.JPanel;


import org.opencv.core.*;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;
import org.opencv.video.Video;
import org.opencv.videoio.VideoCapture;
import org.opencv.videoio.Videoio;
import org.opencv.core.Mat;
import org.opencv.core.Point;
import org.opencv.core.Scalar;

import platform.Main;

/**
 * A simplified stereo-vision system using the PS4Eye camera
 * @author simon gay
 */
public class StereoVision {

	private VideoCapture camera1;
	
	public Mat img=new Mat();	// mat containing grabbed image
	
	private Rect rectR;			// rectangles used to crop
	private Rect rectL;			// left and right images
	
	public Mat imgL=new Mat();	// left image
	public Mat imgR=new Mat();	// right image
	
	public Mat grayL=new Mat();	// left gray scale image
	public Mat grayR=new Mat();	// right gray scale image
	
	
	public short[][] imageL=new short[800][1280];		// matrix containing left image
	private int pixel;
	private BufferedImage output;	// left image for displayers
	
    private MatOfPoint2f pointsL1=new MatOfPoint2f();	// list of detected points of interests
    private MatOfPoint2f pointsL2=new MatOfPoint2f();	// in left and right images
    
    private MatOfByte statusL=new MatOfByte();			// vectors used for
    private MatOfFloat errorL=new MatOfFloat();			// point tracking
	
    
	public float[] histogram1;							// histograms for vertical
	public float[] histogram2;							// line detection

	
	private ArrayList<Point> list=new  ArrayList<Point>();
	
	public Line[] lines1;								// detected vertical lines
	public Line[] lines2;
	
	public ArrayList<float[]> context;					// map of surrounding points of interest

	
	// Mat to BufferedImage data structures
	private MatOfByte bytemat = new MatOfByte();
	private byte[] bytes;
	
	
	// displayer
	private ContextFrame contextFrame;
	
	
	// time measures
	long time1=0;
	long time2=0;
	int counter=0;
	
	// load OpenCV libraries
	static {
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
    }
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public StereoVision() {

		/////////////////////////////////////////////////////////////////////////
		// configure camera
		camera1=new VideoCapture(Main.CAMERA);
		camera1.set(Videoio.CAP_PROP_HW_ACCELERATION, 1);
		
		// parameters for a PS4Eye
		camera1.set(Videoio.CAP_PROP_FRAME_WIDTH, 3748);
		camera1.set(Videoio.CAP_PROP_FRAME_HEIGHT, 808);
		camera1.set(Videoio.CAP_PROP_FPS, Main.FRAMERATE);
		camera1.set(Videoio.CAP_PROP_BUFFERSIZE, 1);

		// initialize structures
	    context=new ArrayList<float[]>();
	    
		rectR=new Rect(48,0,1280,800);
		rectL=new Rect(48+1280,0,1280,800);
		
	    histogram1=new float[1280];
	    histogram2=new float[1280];
	    
	    lines1=new Line[1280];
	    lines2=new Line[1280];
	    
	    for (int i=0;i<1280;i++){
	    	lines1[i]=new Line(i);
	    	lines2[i]=new Line(i);
	    }
	    
		/////////////////////////////////////////////////////////////////////////
		
	    // get first frame
		camera1.read(img);
		
	    
	    if (Main.displayers) contextFrame=new ContextFrame(this,(short)1380,(short)440);
	    
	    // delay for camera initialization
        try{Thread.sleep(200);
		}catch(InterruptedException ex){Thread.currentThread().interrupt();}
        
        // on Linux devices: can set the autoexposure mode of the camera
        if (Main.AUTOEXPOSURE) {
	        try {
				Runtime.getRuntime().exec(String.format("v4l2-ctl -c exposure_auto=0"));
			} catch (IOException e) {e.printStackTrace();}
        }
	}
	
	// get camera image and convert into matrix
	public void readCamera() {
		
		if (camera1.read(img)){
			///////////////////////////////////////////////////
			// convert the stereo image into a B&W image 
			imgL=new Mat(img,rectL);
			Imgproc.cvtColor(imgL, grayL, Imgproc.COLOR_BGR2GRAY);
			
			// ****uncomment if image is too dark****
			//Imgproc.equalizeHist( grayL, grayL );
						
			// convert left image into matrix
			Imgcodecs.imencode(".bmp", grayL, bytemat);
			bytes = bytemat.toArray();
			int c=1078;
			for (int i=799;i>=0;i--){
				for (int j=0;j<1280;j++){
					imageL[i][j]=(short)(bytes[c]&0xff);
					c++;
				}
			}
		}
		
		if (Main.displayers) contextFrame.repaint();
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public void createContext() {

		if (camera1.read(img)) {
			
			time1= System.nanoTime()/1000000;
			
			///////////////////////////////////////////////////
			// prepare images
			
			// convert the stereo image into two B&W images 
			imgL=new Mat(img,rectL);
			imgR=new Mat(img,rectR);
			
			Imgproc.cvtColor(imgL, grayL, Imgproc.COLOR_BGR2GRAY);
			Imgproc.cvtColor(imgR, grayR, Imgproc.COLOR_BGR2GRAY);
			
			// ****uncomment if image is too dark****
			//Imgproc.equalizeHist( grayL, grayL );
			//Imgproc.equalizeHist( grayR, grayR );
			
			
			// convert left image into a matrix
			Imgcodecs.imencode(".bmp", grayL, bytemat);
			bytes = bytemat.toArray();
			int c=1078;
			for (int i=799;i>=0;i--){
				for (int j=0;j<1280;j++){
					imageL[i][j]=(short)(bytes[c]&0xff);
					c++;
				}
			}
			
			
			///////////////////////////////////////////////////
			// detect horizontal gradients and define vertical lines
			
			// reinitialize histograms
			for (int i=0;i<1280;i++) histogram1[i]=0;
			for (int i=0;i<1280;i++) histogram2[i]=0;
			

			// detect horizontal gradients and accumulate values in histograms
			int i2=3; // i-2
			for (int j=10;j<700;j+=20){
				i2=3;
	        	for (int i=5;i<1275;i++){
	        		pixel=imageL[j-1][i]+imageL[j][i]+imageL[j+1][i]-imageL[j-1][i2]-imageL[j][i2]-imageL[j+1][i2];
	        		if (pixel>10){
	        			histogram1[i-1]+=pixel*3;
	        			histogram1[i  ]+=pixel<<2;	// <=> x4
	        			histogram1[i+1]+=pixel*3;
	        		}
	        		else if (pixel<-10){
	        			histogram2[i-1]-=pixel*3;
	        			histogram2[i  ]-=pixel<<2;
	        			histogram2[i+1]-=pixel*3;
	        		}
	        		i2++;
	        	}
			}
			
			// remove non-maximal values in histograms
			for (int i=5;i<1275;i++){
				if (histogram1[i]>1000 && histogram1[i]>histogram1[i-1] && histogram1[i]>histogram1[i+1]) {
					for (int j=-20;j<=20;j++) {
						if (i+j>=0 && i+j<1280) {
							if (histogram1[i]>histogram1[i+j]+5) histogram1[i+j]=0;
						}
					}
				}
				else histogram1[i]=0;
			}
			for (int i=5;i<1275;i++){
				if (histogram2[i]>1000 && histogram2[i]>histogram2[i-1] && histogram2[i]>histogram2[i+1]) {
					for (int j=-20;j<=20;j++) {
						if (i+j>=0 && i+j<1280) {
							if (histogram2[i]>histogram2[i+j]+5) histogram2[i+j]=0;
						}
					}
				}
				else histogram2[i]=0;
			}
			
			
			///////////////////////////////////////////////////
			// measure distance of points on vertical lines through optical flow
			
			// collect and convert list of points
			list.clear();
			for (int j=10;j<700;j+=10){
	        	for (int i=2;i<1270;i++){
	        		if (histogram1[i]>1000) {
		        		if ( Math.abs(imageL[j][i]-imageL[j][i+2])>10 ) list.add(new Point(i,j));
	        		}
	        		else if (histogram2[i]>1000) {
		        		if ( Math.abs(imageL[j][i]-imageL[j][i-2])>10 ) list.add(new Point(i,j));
	        		}
	        	}
			}
			pointsL1.fromList(list); // convert point type
			
			
			// The optical flow algorithm is applied between left and right image (instead of two consecutive images)
			if (pointsL1.size().height>2 ){
				Video.calcOpticalFlowPyrLK(grayL, grayR, // left and right image
	                    pointsL1, pointsL2, // input and output point positions (left and right images)
	                    statusL, errorL,	// tracking success
	                    new Size(25,25),7);	// size and range of research window
			}
	
			
			// filter and record points in vertical lines
			if (pointsL1.size().height>2 ){
				
				// reset list of vertical lines
				for (int i=0;i<1280;i++) lines1[i].reset();
				for (int i=0;i<1280;i++) lines2[i].reset();
				
				for (int p=0;p<pointsL1.height();p++){
					// filter points according to position difference to remove impossible configurations
					if (pointsL1.get(p, 0)[0]>0 && pointsL1.get(p, 0)[0]<1280 && pointsL1.get(p, 0)[1]>0 && pointsL1.get(p, 0)[1]<800
	    	    	&&  pointsL2.get(p, 0)[0]>0 && pointsL2.get(p, 0)[0]<1280 && pointsL2.get(p, 0)[1]>0 && pointsL2.get(p, 0)[1]<800
	    	    	&&  errorL.get(p, 0)[0]<100
	    	    	&& pointsL1.get(p, 0)[1]-pointsL2.get(p, 0)[1]>15 && pointsL1.get(p, 0)[1]-pointsL2.get(p, 0)[1]<25
	    	    	&& pointsL1.get(p, 0)[0]-pointsL2.get(p, 0)[0]>0 &&pointsL1.get(p, 0)[0]-pointsL2.get(p, 0)[0]<300
	    	    	){
						
						// get position in cartesian coordinates
						// **** the equation's parameters may by changed ****
						float dist= (float) (9500/( ( (pointsL1.get(p, 0)[0]-pointsL2.get(p, 0)[0]) - 20.5  ) * 1.405 ));
						float py=(float) ((pointsL1.get(p, 0)[1]-400)*dist/804);
						// **************************************************
						
						// select points from a slice
						if (py>-80 && py<80) {	// slice depends of the height of the camera
						//if (py>-50 && py<120) {
						//if (py>-200 && py<10) {
							
							// draw disparity vectors
    						Imgproc.line(grayL, new Point(pointsL1.get(p, 0)[0],pointsL1.get(p, 0)[1]),
	    					      	new Point(pointsL2.get(p, 0)[0],pointsL2.get(p, 0)[1]), new Scalar( errorL.get(p, 0)[0]*5, errorL.get(p, 0)[0]*5, errorL.get(p, 0)[0]*5 ));
    						Imgproc.line(grayL, new Point(pointsL1.get(p, 0)[0],pointsL1.get(p, 0)[1]+1),
	    					      	new Point(pointsL2.get(p, 0)[0],pointsL2.get(p, 0)[1]+1), new Scalar( errorL.get(p, 0)[0]*5, errorL.get(p, 0)[0]*5, errorL.get(p, 0)[0]*5 ));
    						Imgproc.circle(grayL, new Point(pointsL1.get(p, 0)[0],pointsL1.get(p, 0)[1]), 5,  new Scalar( errorL.get(p, 0)[0]*5, errorL.get(p, 0)[0]*5, errorL.get(p, 0)[0]*5 ));
							
    						// record disparity in vertical lines
							if (histogram1[(int)pointsL1.get(p, 0)[0]]>0){
								lines1[(int)pointsL1.get(p, 0)[0]].addDistance(dist);
							}
							else if (histogram2[(int)pointsL1.get(p, 0)[0]]>0){
								lines2[(int)pointsL1.get(p, 0)[0]].addDistance(dist);
							}
						}
					}
				}
				
				
				///////////////////////////////////////////////////
				// define the context of surrounding points
				
				// compute median distance of vertical lines
				for (int i=0;i<1280;i++) lines1[i].setDistance();
				for (int i=0;i<1280;i++) lines2[i].setDistance();
				
				// define the map (or context) of surrounding points of interest
				context.clear();
				for (int i=0;i<1280;i++){
					if (lines1[i].d>0){
						context.add(new float[] {0, lines1[i].x, lines1[i].d, lines1[i].theta});
					}
					if (lines2[i].d>0){
						context.add(new float[] {1, lines2[i].x, lines2[i].d, lines2[i].theta});
					}
				}
			}
			
			// measure execution time
			time2+= (System.nanoTime()/1000000) - time1;
			counter++;
			if (counter>50){
				counter=0;
				System.out.println("loop: "+(float)(time2)/50+" ms");
				time2=0;
			}
        }
		
		if (Main.displayers) contextFrame.repaint();
    }
	
	
	// paint in display panels
	public void paint(Graphics g, int w, int h, JPanel panel){
		
		// white background
		g.setColor(Color.white);
		g.fillRect(0, 0, w, h);
		
		// draw image
		if (grayL.cols()!=0) g.drawImage(Mat2bufferedImage(grayL), 0, 0, 640, 400,0,0,1280,800, panel);
		
		// draw context in cartesian coordinates
		g.setColor(Color.black);
		g.fillRect(655, 10, 700, 320);
		for (int a=0;a<context.size();a++){
			if (context.get(a)[0]==0) g.setColor(Color.green);
			else if (context.get(a)[0]==1) g.setColor(Color.red);
			g.fillOval(655+320+(int)context.get(a)[1]/2-2, 330-(int)context.get(a)[2]/2-2, 5, 5);
		}
		
		g.setColor(Color.red);
		for (int i=0;i<1280;i++){
			if (histogram1[i]>2000) g.drawLine(i/2, 0, i/2, 400);
		}
		
		g.setColor(Color.green);
		for (int i=0;i<1280;i++){
			if (histogram2[i]>2000) g.drawLine(i/2, 0, i/2, 400);
		}
	}
	
	
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	// convert Mat into bufferedImage
	public static BufferedImage Mat2bufferedImage(Mat image) {
		MatOfByte bytemat = new MatOfByte();
		Imgcodecs.imencode(".jpg", image, bytemat);
		byte[] bytes = bytemat.toArray();
		InputStream in = new ByteArrayInputStream(bytes);
		BufferedImage img = null;
		try {
			img = ImageIO.read(in);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return img;
	}
	
	// Convert grayL Mat image into bufferedImage output
	public BufferedImage outputImage() {
		Mat output1=new Mat();
		Imgproc.resize( grayL, output1, new Size(320,202) );
		MatOfByte bytemat = new MatOfByte();
		Imgcodecs.imencode(".jpg", output1, bytemat);
		byte[] bytes = bytemat.toArray();
		InputStream in = new ByteArrayInputStream(bytes);
		try {
			output = ImageIO.read(in);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return output;
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////
	// line structure : a vertical line is a vector of points of interest belonging to the line
	// The distance is given by the median distance value of these points
	private class Line{
		
		public int px=0;
		
		public float x=0;
		public float d=-1;
		public float theta;
		
		public ArrayList<Float> dist;
		
		public Line(int p_x){
			px=p_x;
			dist=new ArrayList<Float>();
		}
		
		// insert new point's distance, ordered by distance
		public void addDistance(float d){
			boolean found=false;
			int i=0;
			
			while (!found && i<dist.size()){
				if (dist.get(i)>=d){
					dist.add(i,d);
					found=true;
				}
				else i++;
			}
			if (!found) dist.add(d);
		}
		
		public void setDistance(){
			if (dist.size()>5){
				d=dist.get(dist.size()/2);	// as distance are ordered, the median distance is the middle one
				x= ((float)px-640)*d/804;
				theta=(float)Math.toDegrees(Math.atan2(d, x));
			}
		}
		
		public void reset(){
			dist.clear();
			d=-1;
		}
	}
}

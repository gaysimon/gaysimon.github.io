package tracker;

import java.awt.image.BufferedImage;
import java.util.ArrayList;

import java.awt.Color;
import java.awt.Graphics;

/**
 * A simple vertical barcode reading system to detect and localize other robots or beacons
 * @author simon gay
 */
public class Scanner {

	public ArrayList<Code> codeList;	// detected barcodes
	
	public Scanner() {
		codeList=new ArrayList<Code>();
	}
	
	
	// detect barcodes in images	
	public void read(short [][] image) {
		
		codeList.clear();
		
		int l1, l2, l3, l4;		// position and height of two consecutive horizontal lines (l1-l2 and l3-l4) 
		
		float h1, h2, h3;		// height of lines
		float d1;				// spacing between header lines
		float p3, p4;	// position of header and footer
		
		
		for (int i=0;i<1280;i+=4){	// read a column on four
			
			l1=-1;					// reset lines
			l2=-1;
			l3=-1;
			l4=-1;
			
			int j=2;
			while (j<798){
				
				//////////////////////////////////
				// detect horizontal black lines
				
				// detect light to dark gradient
				while (j<798 && image[j-1][i]+image[j-2][i]-image[j+1][i]-image[j+2][i]<40){
					j++;
				}
				if (j<798) l1=j;		// record beginning of the line
				while (j<798 && image[j-1][i]+image[j-2][i]-image[j+1][i]-image[j+2][i]>40) j+=4; // continue until the gradient disappears
				
				// detect dark to light gradient
				while (j<798 && image[j+1][i]+image[j+2][i]-image[j-1][i]-image[j-2][i]<40){
					j++;
				}
				if (j<798) l2=j;		// record ending of the line
				while (j<798 && image[j+1][i]+image[j+2][i]-image[j-1][i]-image[j-2][i]<40) j+=4; // continue until the gradient disappears
				
				
				// detect code when 2 lines are detected
				if (l2!=-1 && l4!=-1){
					
					// get lines' height
					h1=l4-l3;
					h2=l2-l1;
					// test line thickness
					if (h1/h2>1.7 && h1/h2<2.3){		// test ratio (h1 must be close to 2xh2)
						
						// get lines' spacing
						d1=l1-l4;
						// test spacing thickness
						if (d1/h2>0.7 && d1/h2<1.3){	// spacing must be close to second line's height
							
							// get header position and thickness 
							float height=l2-l3;
							float thick=height/4;
							
							// define footer line search window
							float w3=l2+10*thick-thick/2;
							float w4=l2+11*thick+thick/2; 
							p3=-1;					// top of footer line
							p4=-1;					// bottom of footer line
					
							// search footer line
							if (w4<798){
								for( int j2=(int)w3;j2<w4;j2++){
									if (image[j2-1][i]+image[j2-2][i]-image[j2+1][i]-image[j2+2][i]>40){
										p3=j2;	// record beginning of the line
									}
									if (image[j2+1][i]+image[j2+2][i]-image[j2-1][i]-image[j2-2][i]>40){
										p4=j2;	// record ending of the line
									}
								}
								
								if (p3!=-1 && p4!=-1){	
									// test bottom line
									h3=p4-p3;
									if (h3/h2>0.7 && h3/h2<1.3){	// fouter has the same thickness than header's second line
										
										// record the code and get id
										Code code=new Code(i, (int)l3, (int)l2, (int)p3, (int)p4);
										code.readCode(image);
										
										// search for existing similar code
										if (code.code!=0 && code.value1>4 && code.value1<28){
											int k=0;
											boolean found=false;
											while (!found && k<codeList.size()){
												if (code.code==codeList.get(k).code) found=true;
												else k++;
											}
											if (found) codeList.get(k).merge(code);
											else codeList.add(code);
										}
										
										// reset line buffer
										l1=-1;
										l2=-1;
										l3=-1;
										l4=-1;
										
										// directly jump after the code
										j=(int) p4;
									}
								}
							}
						}
					}
				}
				// if no code is detected, copy second line as first line for a new detection
				l3=l1;
				l4=l2;
				l1=-1;
				l2=-1;
			}
		}
		
	}
	
	
	// draw the barcode on the image
	public BufferedImage displayCode(BufferedImage img) {
		
		try {
			Graphics g = img.getGraphics();
			for (int i=0;i<codeList.size();i++){
				
				// draw header
				g.setColor(Color.green);
				g.fillRect(codeList.get(i).px1/4,codeList.get(i).py1/4,
						   codeList.get(i).px2/4-codeList.get(i).px1/4+1, 
						   codeList.get(i).py2/4-codeList.get(i).py1/4);
				
				// draw code
				for (int c=0;c<4;c++){
					if (codeList.get(i).barcode[c]==1) g.setColor(Color.green);
					else g.setColor(Color.red);
					g.fillRect(codeList.get(i).px1/4, 
							   (int)(codeList.get(i).py2/4+codeList.get(i).delta/4+codeList.get(i).delta*c/4), 
							   codeList.get(i).px2/4-codeList.get(i).px1/4+1, 
							   (int)codeList.get(i).delta/4);
				}
				
				// draw orientation
				g.setColor(Color.green);
				int size=(int)((codeList.get(i).value1+codeList.get(i).value2)/2);
				g.fillOval((codeList.get(i).px1+codeList.get(i).px2)/8-size/4,
						   (int)(codeList.get(i).py2+7.5*codeList.get(i).delta)/4-size/4,
						   size/2,size/2);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return img;
	}
	
}

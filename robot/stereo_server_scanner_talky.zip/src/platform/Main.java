package platform;

import java.awt.image.BufferedImage;

import robot.Robot;
import vision.StereoVision;
import servers.*;
import tracker.Scanner;


public class Main {
	
	//////////////////////////////////////////////
	public static int CAMERA=1;					// select the camera number
	public static int FRAMERATE=60;				// if image is too dark, change to 30fps
	public static boolean AUTOEXPOSURE=false;	// set camera autoexposure (Linux only)
	public static String PORT="/dev/ttyACM0";	// Arduino serial port
	public static boolean displayers=false;		// display window
	public static String PAGEPATH="./";			// path of the html page file
	public static int CODE=9;					// barcode to track
	//////////////////////////////////////////////
	
	// perception module
	public StereoVision stereo=null;
	
	// robot interface module
	public Robot robot;
	public int robot_move=-1;
	public float ref_angle=0;
	public int mode=0; // 0 map, 1 tracker, 2 automatic tracking
	private int vx=0;
	private int vy=0;
	private int rz=0;
	
	// tracking module
	private Scanner scanner;
	
	// servers module
	private Server server;
	public Talky talky;
	
	// current status
	public boolean run=true;
	
	
	public Main(){
		
		// declare modules
		robot=new Robot();
		stereo=new StereoVision();
		scanner=new Scanner();
		server=new Server(this);
		talky=new Talky();
		
		stereo.createContext();
		
		try {Thread.sleep(200);
		} catch (InterruptedException e) {e.printStackTrace();}	
	
		
		// used to measure execution time
		long time1=System.nanoTime();
		long time2=System.nanoTime();
		long delay1=0;
		short counter=0;
		
		
		while(run) {
			
			/////////////////
			// measure time between frames
			time1 = System.nanoTime()/1000000;
			/////////////////
			
			if (mode==0) {
				stereo.createContext();			// read image and generate context
			}
			else {
				stereo.readCamera();			// get a single frame
				scanner.read(stereo.imageL);	// detect barcodes
			}
			

			
			
			// send data
			if (counter%2==0) sendContext();
			
			
			// control the robot
			if (mode==0 || mode==1) { // manual
				vx=0;vy=0;rz=0;
				
				if      (robot_move==1){
					vy=-40;
					float delta=(robot.angle_Z_deg-ref_angle+360)%360;	// correction from IMU's orientation
					if (delta>180) delta-=360;
					rz=(int) (-15*delta);
				}
				else if (robot_move==2){
					vy=40;
					float delta=(robot.angle_Z_deg-ref_angle+360)%360;
					if (delta>180) delta-=360;
					rz=(int) (-15*delta);
				}
				else if (robot_move==3) rz=90;
				else if (robot_move==4) rz=-90;
				else if (robot_move==5){
					vx=-80;
					float delta=(robot.angle_Z_deg-ref_angle+360)%360;
					if (delta>180) delta-=360;
					rz=(int) (-20*delta);
				}
				else if (robot_move==6){
					vx= 80;
					float delta=(robot.angle_Z_deg-ref_angle+360)%360;
					if (delta>180) delta-=360;
					rz=(int) (-20*delta);
				}
				robot.move(vx,vy,rz);
				
				
			}
			else if (mode==2) {	// tracking mode
				
				// find code in list
				int index=-1;
				int i=0;
				while (index==-1 && i<scanner.codeList.size()) {
					if (scanner.codeList.get(i).code==CODE) index=i;
					else i++;
				}
				
				// if detected, move according to the position of the code
				if (index!=-1) {
					vx=0;vy=0;rz=0;
					if (scanner.codeList.get(index).px1<610) 		rz=40;
					else if (scanner.codeList.get(index).px1<630) 	rz=20;
					else if (scanner.codeList.get(index).px1<790) 	rz=0;
					else if (scanner.codeList.get(index).px1<810) 	rz=20;
					else  											rz=-40;
					
					if (scanner.codeList.get(index).height<190)  	vy=-48;
					else if (scanner.codeList.get(index).height<210)vy=-24;
					else if (scanner.codeList.get(index).height<230)vy=0;
					else											vy=48;
				}
				else {vx=0;vy=0;rz=0;}
				robot.move(vx,vy,rz);
			}
			

			/////////////////
			// measure time between frames
			time2 = System.nanoTime()/1000000;
			delay1+=time2-time1;
			counter++;
			if (counter>50){
				server.broadcast("framerate "+(1000/((float)delay1/50)));
				counter=0;
				delay1=0;
			}
			/////////////////
		}
		
		// close server
		server.stop();
		
		System.out.println("########## system stopped ##########");
		System.exit(0);
	}
	
	// change movement of the robot
	public void setMove(String cmd){
		if      (cmd.equals("forward"  )) robot_move=1;
		else if (cmd.equals("backward" )) robot_move=2;
		else if (cmd.equals("turnleft" )) robot_move=3;
		else if (cmd.equals("turnright")) robot_move=4;
		else if (cmd.equals("moveleft" )) robot_move=5;
		else if (cmd.equals("moveright")) robot_move=6;
		else robot_move=0;
		
		ref_angle=robot.angle_Z_deg;	// copy IMU current angle
	}
	
	
	// send data to web client
	public void sendContext(){
		
		String msg="";
		
		if (mode==0) {
			if (stereo.context.size()>0){
				msg="context ";
				
				for (int a=0;a<stereo.context.size();a++){
					msg+=stereo.context.get(a)[0]+" "+stereo.context.get(a)[1]+" "+stereo.context.get(a)[2]+" ";
				}
				server.broadcast(msg);
			}
		}
		else {
			if (scanner.codeList.size()==0) {
				server.broadcast("data -1");
			}
			else {
				msg="data ";
				for (int i=0;i<scanner.codeList.size();i++) {
					msg+=scanner.codeList.get(i).code+" "
						+scanner.codeList.get(i).px1+" "
						+scanner.codeList.get(i).py1+" "
						+scanner.codeList.get(i).height+" ";
				}
				server.broadcast(msg);
			}
		}
	}
	
	
	public BufferedImage outputImage() {
		if (mode==0) {
			return stereo.outputImage();	// return image
		}
		else {
			BufferedImage output=stereo.outputImage();
			return scanner.displayCode(output);	// draw barcode on image
		}
	}
	
	/////////////////////////////////////////////////////////////////////////
	public void changeControlMode(String m) {
		if (m.equals("0")){
			mode=0;
			server.broadcast("mode stereo ");
		}
		else if (m.equals("1")){
			mode=1;
			server.broadcast("mode scanner ");
		}
		else if (m.equals("2")){
			mode=2;
			server.broadcast("mode tracking ");
		}
	}
	
	
	//////////////////////////////////
	public static void main(String[] args) {
		new Main();
	}

}

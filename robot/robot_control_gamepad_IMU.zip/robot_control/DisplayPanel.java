package robot_control;


import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.JPanel;


/**
 * control panel
 * @author simon Gay
 *
 */
public class DisplayPanel extends JPanel  implements MouseListener, MouseMotionListener{

	private static final long serialVersionUID = 1L;
	
	public boolean pressed=false;
	
	public int px0=0;	// initial cursor position
	public int py0=0;
	public int rz0=0;
	
	public int px=0;	// current cursor position
	public int py=0;
	public int rz=0;
	
	private int button=-1;
	
	public DisplayPanel(){
		super();
		addMouseListener(this);
		addMouseMotionListener(this);
	}
	
	public void paintComponent(Graphics g){
		
		// draw background
		g.setColor(Color.white);
		g.fillRect(0, 0, this.getWidth(), this.getHeight());
		
		// draw virtual joystick
		if (pressed){
			if (button==1){
				g.setColor(Color.gray);
				g.fillRect(px0-100, py0-100, 200, 200);
				
				g.setColor(Color.black);
				g.fillOval(px0-2, py0-2,5,5);
			}
			else if (button==3){
				g.setColor(Color.gray);
				g.fillRect(rz0-100, py0-100, 200, 200);
				
				g.setColor(Color.black);
				g.fillOval(rz0-2, py0-2,5,5);
			}
		}
		
	}


	public void mouseClicked(MouseEvent arg0) {}
	public void mouseEntered(MouseEvent arg0) {}
	public void mouseExited(MouseEvent arg0) {}
	
	// initialize virtual joystick
	public void mousePressed(MouseEvent e) {
		button=e.getButton();
		pressed=true;
		
		if (button==1){
			px0=e.getX();
			py0=e.getY();
			rz0=0;
		}
		else if (button==3){
			px0=0;
			py0=e.getY();
			rz0=e.getX();
		}
		px=px0;
		py=py0;
		rz=rz0;
		
		this.repaint();
	}
	
	// stop motion
	public void mouseReleased(MouseEvent arg0) {
		pressed=false;
		px=0;
		py=0;
		rz=0;
		px0=0;
		py0=0;
		rz0=0;
		button=-1;
		
		this.repaint();
	}

	// read virtual joystick
	public void mouseDragged(MouseEvent e) {
		if (pressed){
			if (button==1) px=e.getX();
			else if (button==3) rz=e.getX();
			py=e.getY();
		}
	}

	public void mouseMoved(MouseEvent e) {}
}
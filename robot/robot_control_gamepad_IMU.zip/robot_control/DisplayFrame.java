package robot_control;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;


/**
 * control frame
 * @author simon Gay
 *
 */
public class DisplayFrame extends JFrame{
	
	private static final long serialVersionUID = 1L;
	
	public DisplayPanel panel;
	
	private Main main;
	
	public DisplayFrame(Main m){
		
		super();
		
		main=m;
		
		this.setTitle("Control");
    	this.setSize(500, 500);
    	this.setLocationRelativeTo(null);               
    	
    	this.addWindowListener(new WindowAdapter() {
    	      public void windowClosing(WindowEvent e) {
    	    	main.close();
    	        System.exit(0);
    	      }
    	});

    	panel=new DisplayPanel();
    	this.setContentPane(panel);
    	this.setVisible(true);
	}
	
	public int getVx(){
		return panel.px-panel.px0;
	}
	public int getVy(){
		return panel.py-panel.py0;
	}
	public int getRz(){
		return panel.rz0-panel.rz;
	}
}
package robot_control;

import net.java.games.input.Controller;
import net.java.games.input.ControllerEnvironment;
import net.java.games.input.Event;
import net.java.games.input.EventQueue;

public class JoystickInterface {
	
	public int axeX=0;
	public int axeY=0;
	public int axeZ=0;
	
	private Controller[] controllers;
	private Controller gamepad=null;
	
	public JoystickInterface(){
		
		controllers = ControllerEnvironment.getDefaultEnvironment().getControllers();
		if (controllers.length == 0) {
			System.out.println("Found no controllers.");
			System.exit(0);
		}
		
		for (int i = 0; i < controllers.length; i++) {
			
			if (Main.gamepad.equals("")) System.out.println(controllers[i].getName());
			else{
				if (controllers[i].getName().equals(Main.gamepad)){
					gamepad=controllers[i];
					System.out.println("\nController "+controllers[i].getName()+" found");
				}
			}
		}
		if (gamepad==null){
			if (Main.gamepad.equals("")) System.out.println("\nplease find your contoller's name above. You can use mouse to control the robot");
			else System.out.println("\ncontroller not found, you can use mouse instead");
		}
	}
	
	public void readEvent(){
		
		if (gamepad!=null){
			gamepad.poll();
			EventQueue queue = gamepad.getEventQueue();
			Event event = new Event();
			
			// For each object in the queue
			while (queue.getNextEvent(event)) {
						
				if (event.getComponent().getName().equals("Axe X")){
					axeX=(int)(event.getValue()*100);
				}
				else if (event.getComponent().getName().equals("Axe Y")){
					axeY=(int)(event.getValue()*100);
				}
				else if (event.getComponent().getName().equals("Axe Z")){
					axeZ=(int)(-event.getValue()*100);
				}
						
				System.out.println("axe x="+axeX+" , axe y="+axeY+" ; axe z x="+axeZ);
			}
		}
	}
	
	public boolean controllerFound(){
		return gamepad!=null;
	}
}

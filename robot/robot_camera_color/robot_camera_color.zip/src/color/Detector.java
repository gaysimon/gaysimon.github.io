package color;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import org.opencv.core.Mat;
import org.opencv.core.MatOfByte;
import org.opencv.imgcodecs.Imgcodecs;

import main.Camera;

public class Detector {
	
	private static int SIZE_X=Camera.SIZE_X;
	private static int SIZE_Y=Camera.SIZE_Y;
	
	private short[][] image=null;
	
	private short[] histogram;
	
	public short color=0;
	
	public int px=0;
	public int value=0;
	
	// Mat to byte[] structures
	private MatOfByte bytemat= new MatOfByte();;
	private byte[] bytes;
	
	public Detector() {
		image=new short[SIZE_Y][Camera.SIZE_X];
		histogram=new short[SIZE_X];
	}
	
	
	// detect barcodes in images	
	public void detect(Mat img) {
		
		
		// convert to Byte array
		Imgcodecs.imencode(".bmp", img, bytemat);
		bytes = bytemat.toArray();
		
		
		// convert mat to matrix
		int c=54;
		for (short i=(short)(SIZE_Y-1);i>=0;i--) {
			for (short j=0;j<SIZE_X;j++) {
				if (color==0) image[i][j]=(short)Math.max(0,  (short)(  (bytes[c+2] & 0xff)   )  - (short)(  (bytes[c  ] & 0xff)   ) - (short)(  (bytes[c+1] & 0xff)  ));
				if (color==1) image[i][j]=(short)Math.max(0,  (short)(  (bytes[c+1] & 0xff)   )  - (short)(  (bytes[c  ] & 0xff)   ) - (short)(  (bytes[c+2] & 0xff)  ));
				if (color==2) image[i][j]=(short)Math.max(0,  (short)(  (bytes[c  ] & 0xff)   )  - (short)(  (bytes[c+1] & 0xff)   ) - (short)(  (bytes[c+2] & 0xff)  ));
				image[i][j]=(short)Math.min(255, image[i][j]*5);
				c+=3;
			}
		}
		
		for (int j=1;j<SIZE_X-1;j++) {
			histogram[j]=0;
			for (int i=0;i<SIZE_Y;i++) {
				histogram[j-1]+=image[i][j]>>1;	// divide by 2
				histogram[j  ]+=image[i][j];
				histogram[j+1]+=image[i][j]>>1;
			}
		}
		
		int max=0;
		int x=0;
		for (int i=1;i<SIZE_X-1;i++) {
			if (histogram[i]>max) {
				max=histogram[i];
				x=i;
			}
		}
		value=max;
		px=x;
		System.out.println(x+" , "+max);
		
	}
	
	
	// draw the barcode on the image
	public BufferedImage Matrix2bufferedImage() {
		
			
		BufferedImage img = new BufferedImage(image[0].length, image.length, BufferedImage.TYPE_INT_RGB);
	    for(short i=0; i<image[0].length; i++) {
	        for(short j=0; j<image.length; j++) {
	            int val = image[j][i];
	            if (val>255) val=255;
	            Color newColor = new Color(val,val,val);
	            img.setRGB(i,j,newColor.getRGB());
	        }
	    }
	    
	    // draw detected ARTags
	    Graphics g = img.getGraphics();
	    g.setColor(Color.red);
	    if (value>500) g.drawLine(px, 0, px, SIZE_Y);

		return img;
	}
}

package platform;

import vision.StereoVision;

public class Main {
	
	//////////////////////////////////////////////
	public static int CAMERA=1;					// select the camera number
	public static int FRAMERATE=60;				// if image is too dark, change to 30fps
	public static boolean AUTOEXPOSURE=false;	// set camera autoexposure (Linux only)
	//////////////////////////////////////////////
	
	// perception module
	public StereoVision stereo=null;
	
	public Main(){
		
		stereo=new StereoVision();
		
		while(true) {
			
			// read image and generate context
			stereo.createContext();
			
		}
	}	

	////////////////////////////////////////
	public static void main(String[] args) {	
		new Main();
	}

}

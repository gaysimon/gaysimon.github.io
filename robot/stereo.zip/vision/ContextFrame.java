package vision;

import javax.swing.JFrame;
import javax.swing.WindowConstants;


/**
 * A display frame for the stereo system
 * @author simon gay
 */
public class ContextFrame extends JFrame{

	private static final long serialVersionUID = 1L;
	
	private ContextPanel panel;

	public ContextFrame(StereoVision stereo, short width, short heigh){
		
		this.setTitle("Context");
    	this.setSize(width, heigh);
    	this.setLocationRelativeTo(null);               
    	panel=new ContextPanel(stereo);
    	this.setContentPane(panel);
    	this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    	this.setVisible(true);
	}
}